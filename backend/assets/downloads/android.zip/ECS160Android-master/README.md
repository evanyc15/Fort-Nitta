# FortNitta Android

## Building the project

Please refer to [this guide](https://hackpad.com/Getting-Started-Guide-ECS160Android-6b0A4MJiyhH).
