var searchData=
[
  ['log',['Log',['../classgame_1_1utils_1_1Log.html',1,'game::utils']]]
];
