var searchData=
[
  ['secondsuntildeadline',['SecondsUntilDeadline',['../classgame_1_1utils_1_1CTimeUtil.html#afa450fd3d8d6d6ebdaf19ad1d186d49f',1,'game::utils::CTimeUtil']]],
  ['seed',['Seed',['../classgame_1_1utils_1_1CRandomNumberGenerator.html#ae4bbe25e8b71353fe8154a38f7f37a66',1,'game::utils::CRandomNumberGenerator']]],
  ['selectedelement',['SelectedElement',['../classgame_1_1CInputState.html#abe3da914ffb3ef4d77986bccff802fc3',1,'game.CInputState.SelectedElement()'],['../classgame_1_1CInputState.html#a094badf9f9971beda09f04229323dffe',1,'game.CInputState.SelectedElement(CUIElement element)']]],
  ['selectedoption',['SelectedOption',['../classgame_1_1ui_1_1CSpinner.html#aa8683b0fc6689f8c172ba8d16e069f2a',1,'game::ui::CSpinner']]],
  ['setcamera',['setCamera',['../classgame_1_1CGame.html#a13f16e866c3a4167eff76a62ef6361c9',1,'game::CGame']]],
  ['setspritebatch',['setSpriteBatch',['../classgame_1_1CGame.html#a3a3831428279793d7ffc4e292e52fc81',1,'game::CGame']]],
  ['setviewport',['setViewport',['../classgame_1_1CGame.html#ad017ed8bae8845a3b642b055bfaca533',1,'game::CGame']]],
  ['shouldcontinueplaying',['ShouldContinuePlaying',['../classgame_1_1animations_1_1CAnimation.html#ac97b140a3ef82caf30ca085e030f55e9',1,'game::animations::CAnimation']]],
  ['shouldtakeprimaryaction',['ShouldTakePrimaryAction',['../classgame_1_1CAIPlayer.html#aa5333c6b391cef48d151542ceaf3c9ab',1,'game.CAIPlayer.ShouldTakePrimaryAction()'],['../classgame_1_1players_1_1CHumanPlayer.html#a2566b58a94e38333f26b825006dd1b1f',1,'game.players.CHumanPlayer.ShouldTakePrimaryAction()'],['../classgame_1_1players_1_1CPlayer.html#a0af1bcc1f084547e62a34d1a5c0ef471',1,'game.players.CPlayer.ShouldTakePrimaryAction()']]],
  ['shouldtakesecondaryaction',['ShouldTakeSecondaryAction',['../classgame_1_1CAIPlayer.html#a3f2e43ae182db512e47b782f07f10dc8',1,'game.CAIPlayer.ShouldTakeSecondaryAction()'],['../classgame_1_1players_1_1CHumanPlayer.html#aed61140b19c47c40d3baef73eb254fdd',1,'game.players.CHumanPlayer.ShouldTakeSecondaryAction()'],['../classgame_1_1players_1_1CPlayer.html#a1b2481c62b4e3900cf7b269a339d1f81',1,'game.players.CPlayer.ShouldTakeSecondaryAction()']]],
  ['size',['Size',['../classgame_1_1ui_1_1CUIElement.html#ab9b690497b65569e11f53fb44a7706fc',1,'game.ui.CUIElement.Size(Vector2 size)'],['../classgame_1_1ui_1_1CUIElement.html#aca797c1d1e465f1314b6a6412c14eec3',1,'game.ui.CUIElement.Size()']]],
  ['songvolume',['SongVolume',['../classgame_1_1sounds_1_1CSoundLibraryMixer.html#a460a18cd547adf53157948d872de6338',1,'game::sounds::CSoundLibraryMixer']]],
  ['sortcastlesfordrawing',['SortCastlesForDrawing',['../classgame_1_1CTerrainMap.html#aef363be4d83f05f5480e9cc5807070ef',1,'game::CTerrainMap']]],
  ['spritecompare',['SpriteCompare',['../classgame_1_1utils_1_1CMathUtil.html#af589ee6f63f486715cbdb1ba26d9a4d5',1,'game::utils::CMathUtil']]],
  ['stopsong',['StopSong',['../classgame_1_1sounds_1_1CSoundLibraryMixer.html#a89bf00099871141df3d5ed9f0ea46387',1,'game::sounds::CSoundLibraryMixer']]],
  ['stoptone',['StopTone',['../classgame_1_1sounds_1_1CSoundLibraryMixer.html#ab7092df9410d9a64002ae51137338b36',1,'game::sounds::CSoundLibraryMixer']]],
  ['stringmap',['StringMap',['../classgame_1_1CTerrainMap.html#aff0e67fb38492094a6bc4b333ebca4c4',1,'game::CTerrainMap']]],
  ['surroundcastle',['SurroundCastle',['../classgame_1_1CConstructionMap.html#af3bb6a37e32fa33fbb5b8cf086847944',1,'game::CConstructionMap']]]
];
