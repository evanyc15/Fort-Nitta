var searchData=
[
  ['buildconfig',['BuildConfig',['../classcom_1_1fortnitta_1_1game_1_1android_1_1BuildConfig.html',1,'com::fortnitta::game::android']]],
  ['buildconfig',['BuildConfig',['../classcom_1_1fortnitta_1_1game_1_1android_1_1test_1_1BuildConfig.html',1,'com::fortnitta::game::android::test']]]
];
