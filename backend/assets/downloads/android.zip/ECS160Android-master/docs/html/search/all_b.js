var searchData=
[
  ['ownedcastlecount',['OwnedCastleCount',['../classgame_1_1players_1_1CPlayer.html#aded614ddbd69a68aa5461592ec7ec001',1,'game::players::CPlayer']]]
];
