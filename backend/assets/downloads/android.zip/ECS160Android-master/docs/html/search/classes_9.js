var searchData=
[
  ['sburnandexplosion',['SBurnAndExplosion',['../classgame_1_1animations_1_1SBurnAndExplosion.html',1,'game::animations']]],
  ['sdirection',['SDirection',['../classgame_1_1SDirection.html',1,'game']]]
];
