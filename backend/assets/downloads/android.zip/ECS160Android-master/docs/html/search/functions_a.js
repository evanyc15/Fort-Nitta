var searchData=
[
  ['maketimeoutsecondsinfuture',['MakeTimeoutSecondsInFuture',['../classgame_1_1utils_1_1CTimeUtil.html#ae56553b046e3109ef4c76ca6a09cae18',1,'game::utils::CTimeUtil']]],
  ['mapfiledata',['MapFileData',['../classgame_1_1CTerrainMap.html#a97ff1b1a3f0c60bb990af5dd8a7dc9bc',1,'game::CTerrainMap']]],
  ['mapname',['MapName',['../classgame_1_1CTerrainMap.html#ae28eee1d295b3f95f728aee60d554a50',1,'game::CTerrainMap']]],
  ['margin',['Margin',['../classgame_1_1ui_1_1CLabel.html#a89a671ebc90fe8a02e760e6bae657010',1,'game.ui.CLabel.Margin(Vector2 margin)'],['../classgame_1_1ui_1_1CLabel.html#ae646b426946a18c0a32905e6b1fb4906',1,'game.ui.CLabel.Margin()']]],
  ['measuretext',['MeasureText',['../classgame_1_1tilesets_1_1CFontTileset.html#a9502f628806834d7099462528e7f22ef',1,'game::tilesets::CFontTileset']]],
  ['millisecondsuntildeadline',['MilliSecondsUntilDeadline',['../classgame_1_1utils_1_1CTimeUtil.html#afe6e9e7360f8dfb7e24591e52058ca0f',1,'game::utils::CTimeUtil']]]
];
