package game;

//*
/** @brief An AI player taking input from input state
// 

*/

import com.badlogic.gdx.math.Vector2;

import java.util.Map;

import game.players.CPlayer;


public class CAIPlayer extends CPlayer {
	/**
	* @brief Makes a new AI player setting as local player

*/
	public static int difficultylevel = 1;
	public static int numberCastleLocations = 0;
	public static int DTileWidth_rebuild;
	public static int DTileHeight_rebuild;
	public static int DMapHeight_rebuild;
	public static int DMapWidth_rebuild;
	public static CAIBridge DAIBridge = null;
	// Frame counting variables used to ensure the AI doesn't execute functions too quickly
	public int framecount; // *
	public int framelimit; // * // * @brief Updates cursor position based on mouse position
	/**
	* @param game Game to update


*/
	public void Update(CGame game) {
		this.DAIBridge.Update(game);
		Vector2 position = new Vector2();
		position.x = 130;
		position.y = 130;

		super.Update(game);
	}

	public CAIPlayer(CGame game) {
		DAIBridge = new CAIBridge();
		DAIBridge.Update(game);
		// std::cout << "AIPlayer Created" << std::endl;
		DIsLocalPlayer = true;
		DIsAI = true;
		// L = luaL_newstate();
		init_lua();
		framelimit = 30;
		framecount = framelimit;
		DWallShape.Randomize(game.GameState().DRandomNumberGenerator.Random());

	} // *

	public final void init_lua() {

        CKahluaInterface KI = CKahluaInterface.getInstance();
        KI.getExposer().exposeClass(CAIBridge.class);
        KI.runStringScript("test = NewCAIBridgeObj()");
        KI.runStringScript("myrandom = newrandom()");
        KI.runFileScript("test.lua");
        KI.runFileScript("castle_select.lua");
        KI.runFileScript("cannon_placement_ai.lua");
        KI.runFileScript("battle_ai.lua");
        KI.runFileScript("rebuild_ai.lua");
	} // * @brief Returns if left button is pressed
	/**
	* @param game Game to update
	*
	* @return true if left button pressed, false otherwise


*/
	public boolean ShouldTakePrimaryAction(CGame game) {
		return game.InputState().DButtonPressed == CInputState.EInputButton.ibLeftButton;
	}

	/** @brief Returns if right button is pressed
	*
	* @param game Game to update
	*
	* @return true if right button is pressed, false otherwise

*/
	public boolean ShouldTakeSecondaryAction(CGame game) {
		return game.InputState().DButtonPressed == CInputState.EInputButton.ibRightButton;
	}

	public void UpdateHoveredCastle(CGame game) {
		this.DAIBridge.Update(game);
		this.Update(game);
		int XTile;
		int YTile;
		CTerrainMap Map = game.GameState().TerrainMap();
		Vector2 TileIndex = Map.ConvertToTileIndex(new Vector2(DCursorPosition));
		XTile = (int) TileIndex.x;
		YTile = (int) TileIndex.y;

		int BestDistance = 999999;
		Castle BestCastle = null;

		for (Castle castle : Map.Castles()) {
			if (castle.DColor != DColor)
				continue;

			int Distance;
			int XPos = (int) castle.IndexPosition().x;
			int YPos = (int) castle.IndexPosition().y;

			Distance = (XPos - XTile) * (XPos - XTile) + (YPos - YTile) * (YPos - YTile);
			if (Distance < BestDistance) {
				BestDistance = Distance;
				BestCastle = castle;
			}
		}
        DHoveredCastle = BestCastle;

		// Simulate a castle select click
		if (!DPlacedHomeCastle)
			PlaceHomeCastle(game, DHoveredCastle);
	}

	public boolean TryToPlaceCannon(CGame game, Vector2 position) {
		boolean result = false;
		if (DAvailableCannons != 0) {
			// Find potential cannon positions and try to place them

			int XTile;
			int YTile;
			boolean XDir;
			boolean YDir;
			XDir = (DAvailableCannons & 0x1) != 0;
			YDir = (DAvailableCannons & 0x2) != 0;
			XTile = (int) DCursorPosition.x / 12;
			YTile = (int) DCursorPosition.y / 12;

			result = CAIScriptFunctions.getCannonLocs(DColor.getValue(), XTile, YTile, XDir, YDir, 40, 24, DAvailableCannons);

			// Temporary fix to overlaping AI cannons
			result = DAvailableCannons > 0
					&& game.GameState().ConstructionMap().IsSpaceOpenForColor(DColor, new Vector2(position),
							new Vector2(CCannon.CSize))
					&& game.GameState().TerrainMap().IsSpaceOpen(new Vector2(position), new Vector2(CCannon.CSize));
			if (result && DAvailableCannons > 0) {
				game.GameState().ConstructionMap().Cannons().add(new CCannon(DCursorTilePosition));
				DAvailableCannons--;
			} else {
			}
		}
		this.DAIBridge.Update(game);
		return result;
	}

	public void FireNextCannon(CGame game) {
		framelimit = 40;
		if (framecount >= framelimit) {
			if (DReadyCannons.size() > 0) {
				Map<String, Double> coords = CAIScriptFunctions.getxy(DColor.getValue());
				int x = coords.get("xpos").intValue();
				int y = coords.get("ypos").intValue();
				//int x = 0, y = 0;
				// convet form squares to pixels
				x *= 12;
				y *= 12;
				DCursorPosition.x = x + 6;
				DCursorPosition.y = y + 6;
				DReadyCannons.get(0).FireAt(game, DCursorPosition);
				DReadyCannons.remove(0);
				framecount = 0;
			}
		} else
			framecount++;
	}

	public boolean TryToPlaceWall(CGame game, Vector2 tile_position) {
		framelimit = 10;
		if (framecount >= framelimit) {
			// DWallShape.Randomize(game->GameState()->DRandomNumberGenerator.Random());
			// printf("Executing TryToPlaceWall()\n");
			framecount = 0;
			boolean DoMove = true;
			java.util.ArrayList<Castle> Castles = game.GameState().TerrainMap().Castles();
			java.util.Iterator<Castle> it = Castles.iterator();
			Vector2 bestpos = new Vector2();
			int mostwalls = 0;
			CConstructionMap Map = game.GameState().ConstructionMap();
			for (Castle castle : Castles) {
				if (castle.DColor != DColor || castle.DSurrounded) {

				} else {
					Vector2 p = castle.IndexPosition().cpy();
					// set the initial wall to check (upper left corner)
					p.x -= 3;
					p.y -= 3;
					int xdir = 0;
					int ydir = 0;
					xdir = 0;
					int wallcount = 0;
					// this for loop will check each tiletype in a "radius" of 2 from the given castle
					for (int i = 1; i <= 4; i++) {
						if (i == 1) {
							xdir = 1;
							ydir = 0;
						} else if (i == 2) {
							xdir = 0;
							ydir = 1;
						} else if (i == 3) {
							xdir = -1;
							ydir = 0;
						} else if (i == 4) {
							xdir = 0;
							ydir = -1;
						}
						for (int j = 1; j <= 8; j++) {
							p.x += xdir;
							p.y += ydir;
							if (Map.GetTileAt(new Vector2(p)) != null && Map.GetTileAt(new Vector2(p)).IsWall()) {
								wallcount++;
							}
						}
						// printf("\n");
					}
					if (wallcount >= mostwalls) {
						bestpos = castle.IndexPosition();
						mostwalls = wallcount;
					}
				}
			}
			DCursorPosition.x = -1;
			DCursorPosition.y = -1;
			if (0 > DCursorPosition.x) {
				int XTile;
				int YTile;
				int BestX;
				int BestY;
				int BestRotation;
				int BestCoverage;
				int BestInterference;

				XTile = (int) bestpos.x;
				YTile = (int) bestpos.y;

				DTileWidth_rebuild = 12;
				DTileHeight_rebuild = 12;
				DMapHeight_rebuild = 24-1;
				DMapWidth_rebuild = 40 - 1;
				Map<String, Double> Best = CAIScriptFunctions.findBestPlacement(DColor.getValue(), XTile, YTile);
				BestX = Best.get("X").intValue();
				BestY = Best.get("Y").intValue();
				BestRotation = Best.get("Rotation").intValue();
				BestCoverage = Best.get("BCoverage").intValue();
				BestInterference = Best.get("BInterference").intValue();
				//BestX = 0;
				//BestY = 0;
				//BestRotation = 0;

				if (0 > BestX) {
					DoMove = false;
				} else if (BestRotation != 0) {
					RotateWall(game);
					return false;
				} else {
					DCursorPosition.x = BestX * 40 + 6;
					DCursorPosition.y = BestY * 24 + 6;
					DCursorTilePosition.x = BestX;
					DCursorTilePosition.y = BestY;

					return (DWallShape.Place(game, this, new Vector2(DCursorTilePosition)));
				}
			}
		} else
			framecount++;

		return false;
	}

}
