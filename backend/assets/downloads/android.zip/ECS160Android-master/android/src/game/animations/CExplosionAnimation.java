package game.animations;

import com.badlogic.gdx.math.Vector2;

import game.CGame;
import game.tilesets.C3DTerrainTileset;

//*
/**
 * @brief The animation played when a cannonball explodes
 */
public class CExplosionAnimation extends CAnimation {

	public int tileType;

	/**
	 * @brief Makes a new animation at a position
	 * @param game
	 *            The game playing
	 * @param position
	 *            The position to play at
	 * @param explosionType
	 *            The type of explosion
	 */
	public CExplosionAnimation(CGame game, Vector2 position, Vector2 index,
			SBurnAndExplosion.EExplosionType explosionType) {
		super(new Vector2((float) ((index.x - 0.5) * game.Resources().DTilesets.D3DTerrainTileset.TileWidth()),
				(float) ((index.y - 1.5) * game.Resources().DTilesets.D3DTerrainTileset.TileHeight())), new Vector2(
				index), game.Resources().DTilesets.D3DExplosionTileset.GetBaseFrame(explosionType),
				game.Resources().DTilesets.D3DExplosionTileset.TileCount()
						/ SBurnAndExplosion.EExplosionType.etMax.getValue());
		switch (explosionType) {
		case etGroundExplosion0:
		case etGroundExplosion1:
			tileType = 0;
			break;
		case etWaterExplosion0:
		case etWaterExplosion1:
			tileType = 1;
			break;
		case etWallExplosion0:
		case etWallExplosion1:
			tileType = 2;
			break;
		default:
			break;
		}
	}

	/**
	 * @brief Updates the animation and spawns the appropriate animation if destroyed a wall or hit the ground
	 * @param game
	 *            Game updating
	 */
	public void Update(CGame game) {
		super.Update(game);

		if (!ShouldContinuePlaying()) {
			C3DTerrainTileset TerrainTileset = game.Resources().DTilesets.D3DTerrainTileset;
			if (tileType == 0) {
				game.GameState().DAnimations.add(new CBurnAnimation(
						game,
						new Vector2((DIndex.x) * TerrainTileset.TileWidth(), (DIndex.y) * TerrainTileset.TileHeight()),
						DIndex,
						game.GameState().DRandomNumberGenerator.Random() % 2 != 0 ? SBurnAndExplosion.EBurnType.btHoleBurn0
								: SBurnAndExplosion.EBurnType.btHoleBurn1));
			} else if (tileType == 2) {
				game.GameState().DAnimations.add(new CBurnAnimation(
						game,
						new Vector2((DIndex.x) * TerrainTileset.TileWidth(), (DIndex.y) * TerrainTileset.TileHeight()),
						DIndex,
						game.GameState().DRandomNumberGenerator.Random() % 2 != 0 ? SBurnAndExplosion.EBurnType.btRubbleBurn0
								: SBurnAndExplosion.EBurnType.btRubbleBurn1));
			}
		}
	}

	/**
	 * @brief Draws the animation using the burn tileset
	 * @param game
	 *            The game drawing
	 */
	public void Draw(CGame game) {
		super.Draw(game, game.Resources().DTilesets.D3DExplosionTileset);
	}
}
