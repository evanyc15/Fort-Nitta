package game.modes;

import game.CCannon;
import game.CGame;
import game.CTimer;
import game.players.CPlayer;
import game.sounds.CSounds;
import game.utils.CTimeUtil;

//*
/**
 * @brief Mode where players fire cannonballs and destroy walls
 */
public class CBattleMode extends CMapMode {

	private int DBattleType;

	/**
	 * @brief Sets up the timer and cannons that are ready
	 * @param game
	 *            The game entering
	 */
	public void Enter(CGame game) {
		super.Enter(game);
		CTimer Timer = game.GameState().DTimer;
		Timer.DTimeout = CTimeUtil.MakeTimeoutSecondsInFuture(1);
		game.Resources().DSounds.PlaySoundClip(CSounds.ESoundClipType.sctReady);

		java.util.ArrayList<CPlayer> Players = game.GameState().DPlayers;
		for (CPlayer player : Players) {
			player.DReadyCannons.clear();
		}

		java.util.ArrayList<CCannon> Cannons = game.GameState().ConstructionMap().Cannons();
		for (CCannon cannon : Cannons) {
			CPlayer Player = cannon.GetPlayerOwner(game);
			if (Player != null) {
				Player.DReadyCannons.add(cannon);
			}
		}
		DBattleType = 0;
	}

	/**
	 * @brief Determines if players are firing cannons and whether game should go to next mode
	 * @param game
	 *            The game updating
	 */
	public void Update(CGame game) {
		super.Update(game);
        game.GameState().DWind.WindUpdate(game.GameState().DRandomNumberGenerator.Random(), game.GameState().DRandomNumberGenerator.Random(), game.GameState().DRandomNumberGenerator.Random());

		if (DBattleType == 0) {
			if (CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) < 0) {
				DBattleType++;
				CTimer Timer = game.GameState().DTimer;
				Timer.DTimeout = CTimeUtil.MakeTimeoutSecondsInFuture(1);
				game.Resources().DSounds.PlaySoundClip(CSounds.ESoundClipType.sctAim);
			}
		} else if (DBattleType == 1) {
			if (CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) < 0) {
				DBattleType++;
				CTimer Timer = game.GameState().DTimer;
				Timer.DTimeout = CTimeUtil.MakeTimeoutSecondsInFuture(15);
				game.Resources().DSounds.PlaySoundClip(CSounds.ESoundClipType.sctFire);
			}
		} else if (DBattleType == 2) {
			for (CPlayer Player : game.GameState().DPlayers) {
				if (Player.ShouldTakePrimaryAction(game)
						&& CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) >= 0) {
					Player.FireNextCannon(game);
				} else if (Player.DIsAI && CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) >= 0) {
					Player.FireNextCannon(game);
				}
			}
			if (CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) < 0) {
				DBattleType++;
				CTimer Timer = game.GameState().DTimer;
				Timer.DTimeout = CTimeUtil.MakeTimeoutSecondsInFuture(2);
				game.Resources().DSounds.PlaySoundClip(CSounds.ESoundClipType.sctCeasefire);
			}
		} else if (DBattleType == 3) {
			if (CTimeUtil.SecondsUntilDeadline(game.GameState().DTimer.DTimeout) < 0
					&& game.GameState().DCannonballs.size() == 0 && game.GameState().DAnimations.size() == 0) {
				game.SwitchMode(new CBannerTransitionMode(game, "REBUILD WALLS TO STAY ALIVE", this, new CRebuildMode()));
			}
		}
	}

	/**
	 * @brief Draws the 3D map and the target reticules for the players
	 * @param game
	 *            The game drawing
	 */
	public void Draw(CGame game) {
		super.Draw3D(game);
		super.Draw(game);
		super.DrawTargetCursors(game);
	}
}
