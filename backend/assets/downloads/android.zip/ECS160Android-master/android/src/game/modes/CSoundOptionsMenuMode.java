package game.modes;

import com.badlogic.gdx.math.Vector2;

import game.CGame;
import game.animations.DefineConstants;
import game.ui.CButton;
import game.ui.CSpinner;
import game.ui.CStackElement;

//*
/**
 * @brief Mode where user edits options
 */
public class CSoundOptionsMenuMode extends CMenuMode {

	// @Button for going back to main menu
	private CButton DBackButton;
	// @List of buttons for each option
	private java.util.ArrayList<CButton> DOptions = new java.util.ArrayList<CButton>();
	// @Spinner for volume
	private CSpinner Volume;

	public CSoundOptionsMenuMode(CGame game) {
		super("SOUND OPTIONS");
		CStackElement S = new CStackElement();
		S.Size(new Vector2(DefineConstants.GAME_WIDTH, DefineConstants.GAME_HEIGHT));
		S.Position(new Vector2(DefineConstants.GAME_WIDTH / 2, DefineConstants.GAME_HEIGHT / 2));
		S.Anchor(new Vector2(0.5f, 0.5f));

		java.util.ArrayList<String> options = new java.util.ArrayList<String>();
		options.add("0");
		options.add("1");
		options.add("2");
		options.add("3");
		options.add("4");
		options.add("5");
		Volume = new CSpinner(game, "VOLUME", options, new Vector2(15, 15));
		S.AddChildElement(Volume);
		DRootElement.AddChildElement(S);

		DBackButton = new CButton(game, "BACK");
		DBackButton.Position(new Vector2(0, DefineConstants.GAME_HEIGHT));
		DBackButton.Anchor(new Vector2(0, 1));
		DRootElement.AddChildElement(DBackButton);

	}

	public void Update(CGame game) {
		super.Update(game);

		if (DBackButton.IsPressed()) {
			game.SwitchMode(new COptionsMode(game));
		}

	}
}
