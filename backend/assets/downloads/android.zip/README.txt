Android:

Run on Android Studio