Android:
1) Download zip
2) Run on Android Studio