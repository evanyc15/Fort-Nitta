Android:

Run on Android Studio

1) Locate green triangle at top and press to run simulator
2) Click on running simulator to open game