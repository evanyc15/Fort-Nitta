OSX:

Find FortNitta.xcodeproj file inside FortNitta folder to run game