OSX:
1) Download zip
2) Find FortNitta.xcodeproj file inside FortNitta folder to open game