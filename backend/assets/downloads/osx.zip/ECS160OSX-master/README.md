# ECS 160 OSX Development Team

## Team Members
    Pasha Pourmand  
	Alton Fong  
	Michael Robert Banzon  
	Vishnupriya Ravi
	Shehzad Lokhandwalla
	Holman Su 
	Alan Pham  
	Tsun Chung 
	Justin Phan   
	Yicheng Li  
	Mohamed Odeh 
	Caileigh Brown  
	Dawn Chumley 
	Evan SooHoo  
	Nico Lo  

## Coding Conventions
[Inspired by Apple's Coding guidelines for Cocoa](https://developer.apple.com/library/mac/documentation/Cocoa/Conceptual/CodingGuidelines/CodingGuidelines.html#//apple_ref/doc/uid/10000146-SW1)

### Indentation
+ Uses 4 spaces
    
### Multiline Comments
+ Uses slashes and asterisks 

Example:
	
	/*
		This is a multiline comment
	*/

### Single line comments
+ Done above the code being commented on

Example:
   

    // This code calls the function to do the thing
    [self doTheThing];

### Function Naming
+ Camel Case

### Variable Naming
+ Camel Case 

Example: 

    int thisIsAVariable;
    
### Tag Comments
+ TODO: Tag for finish code here
+ NOTE: Tag for telling the programmer something important
+ FIXME: Tag for problematic code