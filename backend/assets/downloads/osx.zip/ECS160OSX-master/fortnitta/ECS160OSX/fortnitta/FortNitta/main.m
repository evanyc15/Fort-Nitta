//
//  main.m
//  FortNitta
//
//  Created by Mohamed Odeh on 1/18/15.
//  Copyright (c) 2015 Mohamed Odeh. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}


