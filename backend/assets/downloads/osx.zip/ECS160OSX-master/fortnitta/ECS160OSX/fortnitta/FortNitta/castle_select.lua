--local math = require "math"
getCastleLocation = function()
  math.randomseed( tonumber(tostring(os.time()):reverse():sub(1,6)) )
  number = math.random(0, test.numberCastleLocations() - 1)
  return(number)
end