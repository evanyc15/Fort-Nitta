//
//  AI Controller.m
//  FortNitta
//
//  Created by Alexander Sergian on 2/25/15.
//  Copyright (c) 2015 OSX Team. All rights reserved.
//

#import "AI Controller.h"
#import "GameScene.h"

int xPos;
int yPos;
int aiCheckArray[26][42] = {0};

@implementation AI_Controller

- (id) init : (int) AI_difficulty {
    self = [super init];
    if (self) {
        // initialize Lua and load our lua libraries
        L = luaL_newstate(); // create a new state structure for the interpreter
        luaL_openlibs(L); // load all the basic libraries into the interpreter
        difficulty = AI_difficulty;
    }
    return self;
} // init()



-(int) get_AI_castle {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"castle_select" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    
    // put the pointer to the lua function we want on top of the stack
    lua_getglobal(L,"getCastleLocation");
    
    // call the function on top of thestack
    err = lua_pcall(L, 0, 1, 0);
    int number = lua_tonumber(L, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
        return 0;
    } // if: print out errors, if any
    
    return number;
} // get_AI_castle()



//-(void) place_cannons: (int*) number : (int) mapWidth : (int) mapHeight : (int*) x : (int*) y {
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//}



-(void) place_cannon: (int*) aiColor : (int) mapWidth : (int) mapHeight : (int*) x : (int*) y {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"cannon_placement_ai" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    
    // put the pointer to the lua function we want on top of the stack
    lua_getglobal(L,"getCannonLocs");
    
    int colorIndex = *aiColor;
    int xTile = 0;
    int yTile = 0;
    int xDir = -1; // scan horizontally to the right (wraps around)
    int yDir = 1; // scan vertically downwards (wraps around)
    
    lua_pushnumber(L, colorIndex);
    lua_pushnumber(L, xTile);
    lua_pushnumber(L, yTile);
    lua_pushnumber(L, xDir);
    lua_pushnumber(L, yDir);
    lua_pushnumber(L, mapWidth);  // 42 (2 are gray border tiles)
    lua_pushnumber(L, mapHeight); // 26 (2 are gray border tiles)
    
    // call the function on top of thestack
    err = lua_pcall(L, 7, 0, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
        return;
    } // if: print out errors, if any
    
    //*number = [self get_AI_castle] + 5;
    *x = xPos;
    *y = yPos;
    
    /*while (*x == 0 && *y == 0) {
        *x = arc4random_uniform(3) - 1;
        *y = arc4random_uniform(3) - 1;
    } */// while: avoid the center (castle center is there)
    
    //*number = arc4random_uniform(5) + 5;
} // place_cannon()



-(void) battle_mode: (int*) x : (int*) y {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"battle_ai" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    lua_getglobal(L,"getxy"); // get LUA function
    
    int colorIndex = 0;
    lua_pushnumber(L, colorIndex);
    lua_pushnumber(L, difficulty);
    
    // call the function you just got
    err = lua_pcall(L, 2, 1, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
    } // if: print out errors, if any
    
    int top = lua_gettop(L);
    int coord[2];
    int index = 0;
    
    /* table is in the stack at index 't' */
    lua_pushnil(L);  /* first key */
    
    /* uses 'key' (at index -2) and 'value' (at index -1) */
    while (lua_next(L, top) != 0) {
        coord[index] = (int) lua_tonumber(L, -1);
        
        lua_pop(L, 1);
        index++;
    } // while: iterate through table and grab the x/y coordinates to fire
    
    
    *x = coord[0];
    *y = coord[1];
} // battle_mode()



-(void) rebuild {
    lua_settop(L, 0); // reset stack

    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"rebuild_ai" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    lua_getglobal(L,"findBestPlacement"); // get LUA function
    
    int colorIndex = 0;
    int xTile = 25;
    int yTile = 10;
    
    lua_pushnumber(L, colorIndex);
    lua_pushnumber(L, xTile);
    lua_pushnumber(L, yTile);
    lua_pushnumber(L, difficulty);
    err = lua_pcall(L, 4, 1, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
    } // if: print out errors, if any
} // rebuild()



/* DEBUG FUNCTION: Prints out Stack Contents */

-(void) stackdump_g {
    int i;
    int top = lua_gettop(L);
    
    printf("total in stack %d\n",top);
    
    for (i = 1; i <= top; i++)
    {  /* repeat for each level */
        int t = lua_type(L, i);
        switch (t) {
            case LUA_TSTRING:  /* strings */
                printf("string: '%s'\n", lua_tostring(L, i));
                break;
            case LUA_TBOOLEAN:  /* booleans */
                printf("boolean %s\n",lua_toboolean(L, i) ? "true" : "false");
                break;
            case LUA_TNUMBER:  /* numbers */
                printf("number: %g\n", lua_tonumber(L, i));
                break;
            default:  /* other values */
                printf("%s\n", lua_typename(L, t));
                break;
        } // switch(L)
        printf("  ");  /* put a separator */
    } // for each element in the stack
    printf("\n");  /* end the listing */
} // stackdump_g

@end



/* 
 * Functions called by LUA file
 * They must be global for LUA to find them
 */

static int numberCastleLocations(lua_State *L){
    int numberCastleLocations = 5;
    lua_pushnumber(L, numberCastleLocations);
    
    return 1;
} // numberCastleLocations()



static int isValidCannonLoc(lua_State *L) {
    int colorIndex = lua_tonumber(L, 1);
    int xAttempt = lua_tonumber(L, 2);
    int yAttempt = lua_tonumber(L, 3);
    
    if(mapTiles[yAttempt][xAttempt] == colorIndex && mapTiles[yAttempt][xAttempt + 1] == colorIndex &&
       mapTiles[yAttempt + 1][xAttempt] == colorIndex && mapTiles[yAttempt + 1][xAttempt + 1] == colorIndex &&
       aiCheckArray[yAttempt][xAttempt] != 1 && aiCheckArray[yAttempt][xAttempt + 1] != 1 &&
       aiCheckArray[yAttempt + 1][xAttempt] != 1 && aiCheckArray[yAttempt + 1][xAttempt + 1] != 1){
        aiCheckArray[yAttempt][xAttempt] = 1;
        aiCheckArray[yAttempt][xAttempt + 1] = 1;
        aiCheckArray[yAttempt + 1][xAttempt] = 1;
        aiCheckArray[yAttempt + 1][xAttempt + 1] = 1;
        return 1;
    }
    if (xAttempt == 0 && yAttempt == 0) {
        return 1;
    }
    return 0;
} // isValidCannonLoc()



static int setDAITarget(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1);
    xPos = lua_tonumber(L, 2);
    yPos = lua_tonumber(L, 3);
    
    
    return 0;
} // setDAITarget()



static int getDAITargetX(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1);
    
    return 1;
} // getDAITargetX()



static int getWallType(lua_State *L) {
    int x = lua_tonumber(L, 1);
    int y = lua_tonumber(L, 2);
    char checkEnemeyWall;
    
    if (aiControllerColor == 4){
        checkEnemeyWall = 'R';
    } else {
        checkEnemeyWall = 'B';
    }
    
    
    
    if (mapTiles[y][x] == 1 && mapArray[y][x] == checkEnemeyWall) {
        lua_pushnumber(L, 2);
    }
    
    return 1;
} // getWallType()



static int getWallShapeHeight(lua_State *L) {
    return 0;
} // getWallShapeHeight()



static int getWallShapeWidth(lua_State *L) {
    return 0;
} // getWallShapeWidth()



static int DMapHeight_rebuild(lua_State *L) {
    return 0;
} // DMapHeight_rebuild()



static int DMapWidth_rebuild(lua_State *L) {
    return 0;
} // DMapWidth_rebuild()



static int getValidWallPlacement(lua_State *L) {
    return 0;
} // getValidWallPlacement()



static int getWallShapeIsBlock(lua_State *L) {
    return 0;
} // getWallShapeIsBlock()



static int rotateWallShape(lua_State *L) {
    return 0;
} // rotateWallShape()



static const struct luaL_Reg castlelib_f [] = {
    {"numberCastleLocations", numberCastleLocations},
    {"isValidCannonLoc", isValidCannonLoc},
    {"setDAITarget", setDAITarget},
    {"getDAITargetX", getDAITargetX},
    {"getWallType", getWallType},
    
    {"getWallShapeHeight", getWallShapeHeight},
    {"getWallShapeWidth", getWallShapeWidth},
    {"DMapHeight_rebuild", DMapHeight_rebuild},
    {"DMapWidth_rebuild", DMapWidth_rebuild},
    {"getValidWallPlacement", getValidWallPlacement},
    {"getWallShapeIsBlock", getWallShapeIsBlock},
    {"rotateWallShape", rotateWallShape},
    {NULL, NULL}
};



int luaopen_mylib (lua_State *L) {
    luaL_register(L, "test", castlelib_f);
    return 1;
} // luaopen_mylib()