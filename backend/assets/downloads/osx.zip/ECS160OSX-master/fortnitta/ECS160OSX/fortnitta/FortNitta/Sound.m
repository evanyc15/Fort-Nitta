/*
 *  Sound.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "Sound.h"
#import <AVFoundation/AVFoundation.h>

@implementation Sound

/* Plays the menu midi */
- (void)playMenuMidi{
    NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"menu" withExtension:@"mid"];
    MusicPlayer player = NULL;
    NewMusicPlayer(&player);
    MusicSequence sequence = NULL;
    NewMusicSequence(&sequence);
    MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
    MusicPlayerSetSequence(player, sequence);
    MusicPlayerStart(player);
}
- (void)playPlaceMidi{
    NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"place" withExtension:@"mid"];
    MusicPlayer player = NULL;
    NewMusicPlayer(&player);
    MusicSequence sequence = NULL;
    NewMusicSequence(&sequence);
    MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
    MusicPlayerSetSequence(player, sequence);
    MusicPlayerStart(player);
}
- (void)playWinMidi{
    NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"win" withExtension:@"mid"];
    MusicPlayer player = NULL;
    NewMusicPlayer(&player);
    MusicSequence sequence = NULL;
    NewMusicSequence(&sequence);
    MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
    MusicPlayerSetSequence(player, sequence);
    MusicPlayerStart(player);
}
- (void)playRebuildMidi{
    NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"rebuild" withExtension:@"mid"];
    MusicPlayer player = NULL;
    NewMusicPlayer(&player);
    MusicSequence sequence = NULL;
    NewMusicSequence(&sequence);
    MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
    MusicPlayerSetSequence(player, sequence);
    MusicPlayerStart(player);
}
- (void)playTapsMidi{
    NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"taps" withExtension:@"mid"];
    MusicPlayer player = NULL;
    NewMusicPlayer(&player);
    MusicSequence sequence = NULL;
    NewMusicSequence(&sequence);
    MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
    MusicPlayerSetSequence(player, sequence);
    MusicPlayerStart(player);
}

- (AVAudioPlayer *)setupAudioPlayerWithFile:(NSString *)file type:(NSString *)type{
    // 1
    NSString *path = [[NSBundle mainBundle] pathForResource:file ofType:type];
    NSURL *url = [NSURL fileURLWithPath:path];
    
    // 2
    NSError *error;
    
    // 3
    audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    
    // 4
    if (!audioPlayer) {
        NSLog(@"%@",[error description]);
    }
    
    // 5
    return audioPlayer;
}

@end
