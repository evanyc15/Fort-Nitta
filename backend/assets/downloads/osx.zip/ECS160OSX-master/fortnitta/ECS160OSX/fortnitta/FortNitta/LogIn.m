/*
 *  LogIn.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "MainMenu.h"
#import "LogIn.h"
#include "SelectMap.h"

#include "Sound.h"
#include "GameScene.h"

//temporary storage for username and password until networks are implemented
NSTextField *userName;
NSTextField *password;

NSTrackingArea *entered;
SKSpriteNode *enterButton;

//temp value for if login is true
int login = 0;

@implementation LogIn

/*** SET UP LOGIN VIEW ***/
-(void)didMoveToView:(SKView *)view {
    [self backGroundBricks];
    [self buildLogin];
    
    /*** Set Up Log in information ***/
    //UserName
    NSRect userField = NSMakeRect((self.size.width)*0.4, (self.size.height)*0.55, 200, 30);
    userName = [[NSTextField alloc] initWithFrame:userField];
    [userName setStringValue:@"Username"];
    [userName setEditable:YES];
    [userName setBackgroundColor:[NSColor whiteColor]];
    [userName setFont:[NSFont fontWithName:@"Helvetica" size:20]];
    [self.view addSubview:userName];
    [userName setWantsLayer:YES];
    
    //Password
    NSRect passwordField = NSMakeRect((self.size.width)*0.4, (self.size.height)*0.45, 200, 30);
    password = [[NSTextField alloc] initWithFrame:passwordField];
    [password setStringValue:@"Password"];
    [password setEditable:YES];
    [password setBackgroundColor:[NSColor whiteColor]];
    [password setFont:[NSFont fontWithName:@"Helvetica" size:20]];
    [self.view addSubview:password];
    [password setWantsLayer:YES];
    
    //Enter tracking area
    NSRect enterField = NSMakeRect(350, 213, 77, 22);
    entered = [[NSTrackingArea alloc] initWithRect:enterField
                                           options: (NSTrackingMouseEnteredAndExited |
                                                     NSTrackingMouseMoved |
                                                     NSTrackingActiveInKeyWindow )
                                             owner:self userInfo:nil];
    [self.view addTrackingArea:entered];
}

//create Login view
-(void)buildLogin{
    [self title];
    [self User];
    [self Password];
    [self Enter: @"FontKingthingsBlack copy"];
}

/** MOUSE OPERATIONS **/

/***
 
 In MouseDown, implement the networks end, i.e. send login information out
 and then recieve confirmation of log in. Use confirmation to move onto next scene.
 
 ***/

//indicate mouse left click
-(void)mouseDown:(NSEvent *)theEvent {
    
    //get mouse postion
    NSPoint mouseDownPos = [theEvent locationInWindow];
    //NSLog(@"x: %f y: %f", mouseDownPos.x,mouseDownPos.y);
    
    
    //enter is clicked
    if(mouseDownPos.x >= 350 && mouseDownPos.x <= 427 &&
       mouseDownPos.y >= 213 && mouseDownPos.y <= 235) {
        
        
        /** HERE WE OBTAIN THE STRINGS FOR USERNAME AND PASSWORD FOR NETWORKS **/
        NSLog(@"%@", [userName stringValue]);
        NSLog(@"%@", [password stringValue]);
        
        if (login == 0) {
            [userName setStringValue:@""];
            [password setStringValue:@""];
        }
        
    }
}

//highlight enter when mouse hovered over
-(void)mouseEntered:(NSEvent *)theEvent {
    [enterButton removeFromParent];
    [self Enter: @"FontKingthingsWhite copy"];
}

//remove mouse highlight
-(void)mouseExited:(NSEvent *)theEvent {
    [enterButton removeFromParent];
    [self Enter: @"FontKingthingsBlack copy"];
}

/** DISPLAY FUNCTIONS **/

//function that prints out the characters to the screen
-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    [self addChild:A];
}

//function to get the characters/images from the png into an array of tiles
+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

//title of the Login Page
-(void)title{
    int level = 550;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:440 alpha:50 file:alphabet];//   L
    [self letter:level X:460 alpha:47 file:alphabet];//   O
    [self letter:level X:480 alpha:55 file:alphabet];//   G
    [self letter:level X:515 alpha:53 file:alphabet];//   I
    [self letter:level X:530 alpha:48 file:alphabet];//   N
}

//User Name indicator
-(void) User{
    int level = (self.size.height)*0.62;
    int horizon = (self.size.width)*0.4;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:(horizon - 100) alpha:41 file:alphabet];// U
    [self letter:level X:(horizon - 75) alpha:43 file:alphabet];//  S
    [self letter:level X:(horizon - 55) alpha:57 file:alphabet];//  E
    [self letter:level X:(horizon - 35) alpha:44 file:alphabet];//  R
    [self letter:level X:(horizon - 15) alpha:48 file:alphabet];//  N
    [self letter:level X:horizon + 5 alpha:61 file:alphabet];//     A
    [self letter:level X:horizon + 25 alpha:49 file:alphabet];//    M
    [self letter:level X:horizon + 50 alpha:57 file:alphabet];//    E
}

//Password indicator
-(void) Password{
    int level = (self.size.height)*0.50;
    int horizon = (self.size.width)*0.4;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:(horizon - 100) alpha:46 file:alphabet];// P
    [self letter:level X:(horizon - 80) alpha:61 file:alphabet];//  A
    [self letter:level X:(horizon - 60) alpha:43 file:alphabet];//  S
    [self letter:level X:(horizon - 40) alpha:43 file:alphabet];//  S
    [self letter:level X:(horizon - 20) alpha:39 file:alphabet];//  W
    [self letter:level X:horizon + 5 alpha:47 file:alphabet];//     O
    [self letter:level X:horizon + 25 alpha:44 file:alphabet];//    R
    [self letter:level X:horizon + 50 alpha:58 file:alphabet];//    D
}

//Enter
-(void) Enter:(NSString*)file{
    int level = (self.size.height)*0.35;
    int horizon = (self.size.width)*0.55;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    
    enterButton = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(40,0)];
    
    [enterButton addChild:N];
    [enterButton addChild:T];
    [enterButton addChild:E];
    [enterButton addChild:R];
    
    enterButton.scale = 2;
    enterButton.position = CGPointMake(horizon-100,level);
    [self addChild:enterButton];
    
}

//create the background bricks for the menu
-(void)backGroundBricks{
    NSMutableArray *bricks = [MainMenu fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [MainMenu fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                }
            }
        }
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
        }
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    [self titleBox:(300) :615: 700 : 500];
    //[self title];
}

//create backgound title box
-(void)titleBox:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [MainMenu fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [MainMenu fillCastleCSet:@"Mortar copy" withTileNumber:28];
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (unsigned long int ycount = upperLeftX; ycount >= lowerRightY ; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < upperLeftX-20) && (xcount < lowerRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
            }
            else{
                if (ycount < upperLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < lowerRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(lowerRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
    }
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightX -25; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +45; xcount <= lowerRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
}

@end