/*
 *  AppDelegate.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "AppDelegate.h"
#import "GameScene.h"
#import "MainMenu.h"

@implementation SKScene (Unarchive)

+ (instancetype)unarchiveFromFile:(NSString *)file {
    /* Retrieve scene file path from the application bundle */
    NSString *nodePath = [[NSBundle mainBundle] pathForResource:file ofType:@"sks"];
    /* Unarchive the file to an SKScene object */
    NSData *data = [NSData dataWithContentsOfFile:nodePath
                                          options:NSDataReadingMappedIfSafe
                                            error:nil];
    NSKeyedUnarchiver *arch = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    [arch setClass:self forClassName:@"SKScene"];
    SKScene *scene = [arch decodeObjectForKey:NSKeyedArchiveRootObjectKey];
    [arch finishDecoding];
        
    return scene;
}

@end

@implementation AppDelegate

@synthesize window = _window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {


    MainMenu *scene = [MainMenu unarchiveFromFile:@"MainMenu"];
    
    //Used for Debug Mode
    //GameScene *scene = [GameScene unarchiveFromFile:@"GameScene"];
    
	CGSize s;
	s.width = 1008;
	s.height = 624;
	scene.size = s;

    /* Set the scale mode to scale to fit the window */
    scene.scaleMode = SKSceneScaleModeAspectFit;
    [self.skView presentScene:scene];

    /* Sprite Kit applies additional optimizations to improve rendering performance */
    self.skView.ignoresSiblingOrder = YES;
    
    //self.skView.showsFPS = YES;
    //self.skView.showsNodeCount = YES;
    
    _window.acceptsMouseMovedEvents = YES; //this tells it to accept mouse movement
    [_window makeFirstResponder:self.skView.scene]; //add to scene mouse move
    
}

- (void)awakeFromNib {
    // Keep the aspect ratio constant at its current value
    [_window setAspectRatio:_window.frame.size];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    return YES;
}

@end
