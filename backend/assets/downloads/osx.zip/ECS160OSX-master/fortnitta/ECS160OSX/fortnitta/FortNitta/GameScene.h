/*
 *  GameScene.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <SpriteKit/SpriteKit.h>
#import <AVFoundation/AVFoundation.h>
#include "AI Controller.h"

// use as reference piece in constructing wall pieces
SKSpriteNode *refWallPiece;

// store Location for tile pieces
CGPoint storedLocation;

// stores locations of walls and checkerboard areas
NSInteger mapTiles[26][42];

// used to account for edge cases when filling in checkerboard (like River)
NSInteger fillArr[26][42];

// used to check if it touched wall (To Prevent from changing piece)
Boolean wallEncounter;

//Store the Original Map with color locations
char mapArray[26][42];

//Store the Number of Castles Highlighted = Cannon Amount from RebuildMode
int cannonAmount;

//Main Ai Cannon Count
int aiCannonAmount;

//Main player Color
int player;
//Main Ai Color
int aiColor;

//Store the ai cursor position to be used in battleMode
CGPoint oldCursorPosition;
//Ai Cursor
SKSpriteNode *aiCursor;


@interface GameScene : SKScene
{
    int initArr;
    int mapCastleCount;
    int selectedCannonCount; //mode indicators
    float selectedCastleX;
    float selectedCastleY;
    int groundSpecial;
    AVAudioPlayer *cannonFireSound0;
}

+(void)mapTilesY:(NSInteger)y X:(NSInteger)x value:(NSInteger)value;
+(NSUInteger)mapTilesY:(NSInteger)y X:(NSInteger)x;
+(NSMutableArray*)fillTileSet: (NSString*)tileSet;

@end
