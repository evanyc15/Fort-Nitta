/*
 *  MainMenu.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <SpriteKit/SpriteKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface MainMenu : SKScene

+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount;

@end
