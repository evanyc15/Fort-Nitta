/*
 *  CastleHighLight.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */


#import "GameScene.h"
#import "CastleHighLight.h"
#import <Foundation/Foundation.h>

#define tileEdge 24
#define tileScale 2


@implementation CastleHighLight


// The idea is to take parts of PNG to construct the highlight and make it a single node for ease of use.
// This creates a SpriteNode of the  surrounding blue border of the castle.

+(SKSpriteNode *)createCastleHighlight: (int) player {
    
    
    NSImage * img = [NSImage imageNamed:@"2DCastleSelect copy"];
    NSImage * img2 = [NSImage imageNamed:@"2DCastleCannon copy"];
    NSImage* image = [[NSImage alloc] initWithSize:NSMakeSize(48,48)];
    int castle = 0;
    int color = 0;
    
    //Player is Yellow
    if(player == 2){
        color = 16;
        castle = 56;
    }
    //Player is Red
    else if(player == 3){
        color = 8;
        castle = 58;
    }
    //Player is Blue
    else{
        color = 0;
        castle = 60;
    }
    
    [image lockFocus];
    
    // NSMakePoint(x, y)
    // NSZeroRect to specify whole image
    // NSMakeRect to specify what part of image to draw (x, y, width, height)
    
    // top row of highlight
    [img drawAtPoint:NSMakePoint(0, 36) fromRect:NSMakeRect(0, 12*(16-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(12, 36) fromRect:NSMakeRect(0, 12*(23-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(24, 36) fromRect:NSMakeRect(0, 12*(23-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(36, 36) fromRect:NSMakeRect(0, 12*(22-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    
    // middle left of highlight
    [img drawAtPoint:NSMakePoint(0, 24) fromRect:NSMakeRect(0, 12*(17-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(0, 12) fromRect:NSMakeRect(0, 12*(17-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    
    // middle right of highlight
    [img drawAtPoint:NSMakePoint(36, 24) fromRect:NSMakeRect(0, 12*(21-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(36, 12) fromRect:NSMakeRect(0, 12*(21-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    
    // bottom row of highlight
    [img drawAtPoint:NSMakePoint(0, 0) fromRect:NSMakeRect(0, 12*(18-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(12, 0) fromRect:NSMakeRect(0, 12*(19-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(24, 0) fromRect:NSMakeRect(0, 12*(19-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    [img drawAtPoint:NSMakePoint(36, 0) fromRect:NSMakeRect(0, 12*(20-color), 12, 12) operation:NSCompositeSourceOver fraction:1.0];
    
    // Blue Castle HighLighting
    [img2 drawAtPoint:NSMakePoint(12, 12) fromRect:NSMakeRect(0, 12*castle, 24, 24) operation:NSCompositeSourceOver fraction:1.0];
    
    [image unlockFocus];
    
    SKSpriteNode* theSprite = [SKSpriteNode spriteNodeWithTexture:[SKTexture textureWithImage:image]];
    [theSprite setName:(NSString *)@"highlight"];
    return theSprite;
}


//Creation of Normal Walls
+(void)createCastleWall: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player {
    
    //Initializing Wall Array
    NSMutableArray *tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    
    //Initializing Startin Positions for the walls (Addition and subtraction of #s is guess&check)
    int initPositionX = castleXCoordinate-108;
    int initPositionY = castleYCoordinate+85;
    int wallColorOffset;
    
    //Blue Walls
    if (player == 4) {
        wallColorOffset = 0;
    }
    //Red Walls
    else if (player == 3){
        wallColorOffset = 16;
    }
    //Yellow walls
    else {
        wallColorOffset = 32;
    }
    //Building the wall from top -> middle -> bottom
    //Top Left Corner
    int i = 2;
    SKSpriteNode *topLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    topLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY);
    topLeftPiece.scale = tileScale;
    topLeftPiece.name = @"wall";
    topLeftPiece.zPosition = 1.2;
    [scene addChild:topLeftPiece];
    
    //Top Side of Wall
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY);
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Top Right Corner
    SKSpriteNode *topRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-wallColorOffset]];
    topRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY);
    topRightPiece.scale = tileScale;
    topRightPiece.name = @"wall";
    topRightPiece.zPosition = 1.2;
    [scene addChild:topRightPiece];
    
    
    //Left Side of Wall
    i = 1;
    while(i<7){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Right Side of Wall
    i = 1;
    while(i<7){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Bottom Left Corner
    SKSpriteNode *bottomLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-wallColorOffset]];
    bottomLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*7));
    bottomLeftPiece.scale = tileScale;
    bottomLeftPiece.name = @"wall";
    bottomLeftPiece.zPosition = 1.2;
    [scene addChild:bottomLeftPiece];
    
    
    //Bottom Side of Wall
    i=2;
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY - (tileEdge*7));
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    
    //Bottom Right Corner
    SKSpriteNode *bottomRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    bottomRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*7));
    bottomRightPiece.scale = tileScale;
    bottomRightPiece.name = @"wall";
    bottomRightPiece.zPosition = 1.2;
    [scene addChild:bottomRightPiece];
    i++;
    
}

+(void)createCastleWallPiece: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player{
    //Initializing Wall Array
    NSMutableArray *tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    
    //Initializing Startin Positions for the walls (Addition and subtraction of #s is guess&check)
    int initPositionX = castleXCoordinate-108;
    int initPositionY = castleYCoordinate+85;
    int wallColorOffset;
    
    //Blue Walls
    if (player == 4) {
        wallColorOffset = 0;
    }
    //Red Walls
    else if (player == 3){
        wallColorOffset = 16;
    }
    //Yellow walls
    else
        wallColorOffset = 32;
    
    //Building the wall from top -> middle -> bottom
    //Top Left Corner
    int i = 2;
    SKSpriteNode *topLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    topLeftPiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY);
    topLeftPiece.scale = tileScale;
    topLeftPiece.name = @"wall";
    topLeftPiece.zPosition = 1.2;
    [scene addChild:topLeftPiece];
    
    SKSpriteNode *topLeftMidPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    topLeftMidPiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY - tileEdge);
    topLeftMidPiece.scale = tileScale;
    topLeftMidPiece.name = @"wall";
    topLeftMidPiece.zPosition = 1.2;
    [scene addChild:topLeftMidPiece];
    
    SKSpriteNode *topLeftBottomPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    topLeftBottomPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - tileEdge);
    topLeftBottomPiece.scale = tileScale;
    topLeftBottomPiece.name = @"wall";
    topLeftBottomPiece.zPosition = 1.2;
    [scene addChild:topLeftBottomPiece];
    
    i = 3;
    //Top Side of Wall
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY);
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Top Right Corner
    SKSpriteNode *topRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-wallColorOffset]];
    topRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY);
    topRightPiece.scale = tileScale;
    topRightPiece.name = @"wall";
    topRightPiece.zPosition = 1.2;
    [scene addChild:topRightPiece];
    
    
    //Left Side of Wall
    i = 2;
    while(i<7){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Right Side of Wall
    i = 1;
    while(i<7){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Bottom Left Corner
    SKSpriteNode *bottomLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-wallColorOffset]];
    bottomLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*7));
    bottomLeftPiece.scale = tileScale;
    bottomLeftPiece.name = @"wall";
    bottomLeftPiece.zPosition = 1.2;
    [scene addChild:bottomLeftPiece];
    
    
    //Bottom Side of Wall
    i=2;
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY - (tileEdge*7));
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    
    //Bottom Right Corner
    SKSpriteNode *bottomRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    bottomRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*7));
    bottomRightPiece.scale = tileScale;
    bottomRightPiece.name = @"wall";
    bottomRightPiece.zPosition = 1.2;
    [scene addChild:bottomRightPiece];
    i++;
}

//Creation of Wall for Castle Number 1
+(void)createCastleWallCorner: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player{
    
    //Initializing Wall Array
    NSMutableArray *tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    
    
    
    //Initializing Starting Positions of the Wall (Addition and subtraction of #s is guess&check)
    int initPositionX = castleXCoordinate-109;
    int initPositionY = castleYCoordinate+84;
    int wallColorOffset;
    
    //Blue Walls
    if (player == 4) {
        wallColorOffset = 0;
    }
    //Red Walls
    else if (player == 3){
        wallColorOffset = 16;
    }
    //Yellow walls
    else {
        wallColorOffset = 32;
    }
    
    //Top Left Corner
    int i = 2;
    SKSpriteNode *topLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    topLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY);
    topLeftPiece.scale = tileScale;
    topLeftPiece.name = @"wall";
    topLeftPiece.zPosition = 1.2;
    [scene addChild:topLeftPiece];
    
    //Top Side of Wall
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY);
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Top Right Corner
    SKSpriteNode *topRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-wallColorOffset]];
    topRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY);
    topRightPiece.scale = tileScale;
    topRightPiece.name = @"wall";
    topRightPiece.zPosition = 1.2;
    [scene addChild:topRightPiece];
    
    
    //Left Side of Wall
    i = 1;
    while(i<7){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Right Side of Wall
    i = 1;
    while(i<5){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Bottom Left Corner (.3 Is used as a cheap fix)
    SKSpriteNode *bottomLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-wallColorOffset]];
    bottomLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*7)+.3);
    bottomLeftPiece.scale = tileScale;
    bottomLeftPiece.name = @"wall";
    bottomLeftPiece.zPosition = 1.2;
    [scene addChild:bottomLeftPiece];
    
    
    //Bottom Side of Wall
    i=2;
    while(i<6){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY - (tileEdge*7));
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Zig-Zag Corner - 45,42,45,42,45
    
    SKSpriteNode *zigPiece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece1.position = CGPointMake(initPositionX + (tileEdge*6), initPositionY - (tileEdge*7));
    zigPiece1.scale = tileScale;
    zigPiece1.name = @"wall";
    zigPiece1.zPosition = 1.2;
    [scene addChild:zigPiece1];
    
    
    SKSpriteNode *zigPiece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    zigPiece2.position = CGPointMake(initPositionX + (tileEdge*6), initPositionY - (tileEdge*6));
    zigPiece2.scale = tileScale;
    zigPiece2.name = @"wall";
    zigPiece2.zPosition = 1.2;
    [scene addChild:zigPiece2];
    
    
    SKSpriteNode *zigPiece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece3.position = CGPointMake(initPositionX + (tileEdge*7), initPositionY - (tileEdge*6));
    zigPiece3.scale = tileScale;
    zigPiece3.name = @"wall";
    zigPiece3.zPosition = 1.2;
    [scene addChild:zigPiece3];
    
    
    SKSpriteNode *zigPiece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    zigPiece4.position = CGPointMake(initPositionX + (tileEdge*7), initPositionY - (tileEdge*5));
    zigPiece4.scale = tileScale;
    zigPiece4.name = @"wall";
    zigPiece4.zPosition = 1.2;
    [scene addChild:zigPiece4];
    
    SKSpriteNode *zigPiece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece5.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*5));
    zigPiece5.scale = tileScale;
    zigPiece5.name = @"wall";
    zigPiece5.zPosition = 1.2;
    [scene addChild:zigPiece5];
    
}



//Creation of Wall for Castle Number 1
+(void)createCastleWallDip: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player {
    
    //Initializing Wall Array
    NSMutableArray *tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    
    
    
    //Initializing Startin Positions for the walls (Addition and subtraction of #s is guess&check)
    int initPositionX = castleXCoordinate-108;
    int initPositionY = castleYCoordinate+85;
    int wallColorOffset;
    
    //Blue Walls
    if (player == 4) {
        wallColorOffset = 0;
    }
    //Red Walls
    else if (player == 3){
        wallColorOffset = 16;
    }
    //Yellow walls
    else {
        wallColorOffset = 32;
    }
    
    //Top Left Corner
    int i = 2;
    SKSpriteNode *topLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    topLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY);
    topLeftPiece.scale = tileScale;
    topLeftPiece.name = @"wall";
    topLeftPiece.zPosition = 1.2;
    [scene addChild:topLeftPiece];
    
    //Top Side of Wall
    while(i<8){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY);
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Top Right Corner
    SKSpriteNode *topRightPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-wallColorOffset]];
    topRightPiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY);
    topRightPiece.scale = tileScale;
    topRightPiece.name = @"wall";
    topRightPiece.zPosition = 1.2;
    [scene addChild:topRightPiece];
    
    
    //Left Side of Wall
    i = 1;
    while(i<6){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Right Side of Wall
    i = 1;
    while(i<5){
        SKSpriteNode *lrmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-wallColorOffset]];
        lrmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*i));
        lrmiddlepiece.scale = tileScale;
        lrmiddlepiece.name = @"wall";
        lrmiddlepiece.zPosition = 1.2;
        [scene addChild:lrmiddlepiece];
        i++;
    }
    
    //Bottom Left Corner (.3 Is used as a cheap fix)
    SKSpriteNode *bottomLeftPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-wallColorOffset]];
    bottomLeftPiece.position = CGPointMake(initPositionX + (tileEdge), initPositionY - (tileEdge*6));
    bottomLeftPiece.scale = tileScale;
    bottomLeftPiece.name = @"wall";
    bottomLeftPiece.zPosition = 1.2;
    [scene addChild:bottomLeftPiece];
    
    
    //Bottom Side of Wall
    i=2;
    while(i<4){
        SKSpriteNode *tbmiddlepiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
        tbmiddlepiece.position = CGPointMake(initPositionX + (tileEdge*i), initPositionY - (tileEdge*6));
        tbmiddlepiece.scale = tileScale;
        tbmiddlepiece.name = @"wall";
        tbmiddlepiece.zPosition = 1.2;
        [scene addChild:tbmiddlepiece];
        i++;
    }
    
    //Concave+Zig-Zag - 48,39,46,45,42,45,42,45
    
    SKSpriteNode *zigPiece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-wallColorOffset]];
    zigPiece1.position = CGPointMake(initPositionX + (tileEdge*4), initPositionY - (tileEdge*6));
    zigPiece1.scale = tileScale;
    zigPiece1.name = @"wall";
    zigPiece1.zPosition = 1.2;
    [scene addChild:zigPiece1];
    
    SKSpriteNode *zigPiece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-wallColorOffset]];
    zigPiece2.position = CGPointMake(initPositionX + (tileEdge*4), initPositionY - (tileEdge*7)+.6);
    zigPiece2.scale = tileScale;
    zigPiece2.name = @"wall";
    zigPiece2.zPosition = 1.2;
    [scene addChild:zigPiece2];
    
    SKSpriteNode *zigPiece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-wallColorOffset]];
    zigPiece3.position = CGPointMake(initPositionX + (tileEdge*5), initPositionY - (tileEdge*7)+.6);
    zigPiece3.scale = tileScale;
    zigPiece3.name = @"wall";
    zigPiece3.zPosition = 1.2;
    [scene addChild:zigPiece3];
    
    SKSpriteNode *zigPiece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece4.position = CGPointMake(initPositionX + (tileEdge*6), initPositionY - (tileEdge*7)+.6);
    zigPiece4.scale = tileScale;
    zigPiece4.name = @"wall";
    zigPiece4.zPosition = 1.2;
    [scene addChild:zigPiece4];
    
    SKSpriteNode *zigPiece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    zigPiece5.position = CGPointMake(initPositionX + (tileEdge*6), initPositionY - (tileEdge*6)+.3);
    zigPiece5.scale = tileScale;
    zigPiece5.name = @"wall";
    zigPiece5.zPosition = 1.2;
    [scene addChild:zigPiece5];
    
    SKSpriteNode *zigPiece6 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece6.position = CGPointMake(initPositionX + (tileEdge*7), initPositionY - (tileEdge*6)+.5);
    zigPiece6.scale = tileScale;
    zigPiece6.name = @"wall";
    zigPiece6.zPosition = 1.2;
    [scene addChild:zigPiece6];
    
    SKSpriteNode *zigPiece7 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-wallColorOffset]];
    zigPiece7.position = CGPointMake(initPositionX + (tileEdge*7), initPositionY - (tileEdge*5)+.3);
    zigPiece7.scale = tileScale;
    zigPiece7.name = @"wall";
    zigPiece7.zPosition = 1.2;
    [scene addChild:zigPiece7];
    
    SKSpriteNode *zigPiece8 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-wallColorOffset]];
    zigPiece8.position = CGPointMake(initPositionX + (tileEdge*8), initPositionY - (tileEdge*5)+.5);
    zigPiece8.scale = tileScale;
    zigPiece8.name = @"wall";
    zigPiece8.zPosition = 1.2;
    [scene addChild:zigPiece8];
}
@end