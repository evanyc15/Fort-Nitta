/*
 *  Options.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "Options.h"
#include "MainMenu.h"
#include "SoundOptions.h"
@implementation Options

SKSpriteNode* Back;
SKSpriteNode* Sound;
SKSpriteNode* Network;

// View of Options
-(void)didMoveToView:(SKView *)view {
    
    // Initialize text/bricks to the screen
    [self backGroundBricks];
    [self optionsSelect];
}

// For clicking events
-(void)mouseDown:(NSEvent *)theEvent {
    
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    // If user clicks 'back', go to main menu
    if(mouseDownPos.x >= 72 && mouseDownPos.x <= 131 &&
       mouseDownPos.y >= 121 && mouseDownPos.y <= 139) {
        MainMenu *scene = [MainMenu sceneWithSize:self.view.bounds.size];
        
        //set up main menu size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
    
    // if user clicks 'sound' go to sound options menu
    else if(mouseDownPos.x >= 346 && mouseDownPos.x <= 420 && mouseDownPos.y >= 360 && mouseDownPos.y <= 380) {
        SoundOptions *scene = [SoundOptions sceneWithSize:self.view.bounds.size];
        
        //set up main menu size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
}

// For highlighting
-(void)mouseMoved:(NSEvent *)theEvent {
    NSPoint mousePos = [theEvent locationInWindow];
    
    // If user mouseover 'sound', highlight
    if(mousePos.x >= 346 && mousePos.x <= 420 &&
       mousePos.y >= 360 && mousePos.y <= 380) {
        [Sound removeFromParent];
        [self soundSelection: @"FontKingthingsWhite copy"];
    }
    else{
        [Sound removeFromParent];
        [self soundSelection: @"FontKingthingsBlack copy"];
    }
    
    // If user mouseover 'network', highlight
    if(mousePos.x >= 332 && mousePos.x <= 452 &&
       mousePos.y >= 279 && mousePos.y <= 297) {
        [Network removeFromParent];
        [self networkSelection: @"FontKingthingsWhite copy"];
    }
    else{
        [Network removeFromParent];
        [self networkSelection: @"FontKingthingsBlack copy"];
    }
    
    // If user mouseover 'back', highlight
    if(mousePos.x >= 72 && mousePos.x <= 131 &&
       mousePos.y >= 121 && mousePos.y <= 139) {
        [Back removeFromParent];
        [self backLeft:@"FontKingthingsWhite copy"];
    }
    else{
        [Back removeFromParent];
        [self backLeft: @"FontKingthingsBlack copy"];
    }
}

-(void)optionsSelect{
    int horizon = 500;
    int level = 550;
    NSMutableArray *alphabet = [Options fillCastleCSet:@"FontKingthingsWhite copy"withTileNumber:95];
    [self letter:level X:(horizon - 60) alpha:47 file:alphabet];//  O
    [self letter:level X:(horizon - 40) alpha:46 file:alphabet];//  P
    [self letter:level X:(horizon - 20) alpha:42 file:alphabet];//  T
    [self letter:level X:(horizon) alpha:53 file:alphabet];     //  I
    [self letter:level X:(horizon + 10) alpha:47 file:alphabet];//  O
    [self letter:level X:(horizon + 30) alpha:48 file:alphabet];//  N
    [self letter:level X:(horizon + 50) alpha:43 file:alphabet];//  S
    [self soundSelection:@"FontKingthingsBlack copy"];
    [self networkSelection:@"FontKingthingsBlack copy"];
    [self backLeft:@"FontKingthingsBlack copy"];
}

-(void)networkSelection:(NSString*)file{
    int horizon = 430;
    int level =300;
    NSMutableArray *alphabet = [Options fillCastleCSet:file withTileNumber:95];
    
    Network = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(15,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(25,0)];
    
    SKSpriteNode* W = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:7]];
    [W setPosition:CGPointMake(35,0)];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(50,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(60,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:19]];
    [K setPosition:CGPointMake(70,0)];
    
    [Network addChild:E];
    [Network addChild:T];
    [Network addChild:W];
    [Network addChild:O];
    [Network addChild:R];
    [Network addChild:K];
    
    Network.scale = 2;
    Network.position = CGPointMake(horizon,level);
    [self addChild:Network];
}

-(void)soundSelection:(NSString*)file{
    int horizon = 450;
    int level = 400;
    NSMutableArray *alphabet = [Options fillCastleCSet:file withTileNumber:95];
    
    Sound = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    [N setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* D = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:26]];
    [D setPosition:CGPointMake(40,0)];
    
   
    
    [Sound addChild:O];
    [Sound addChild:U];
    [Sound addChild:N];
    [Sound addChild:D];

    Sound.scale = 2;
    Sound.position = CGPointMake(horizon,level);
    [self addChild:Sound];
    
}

-(void)backLeft:(NSString *)file{
    int level;
    level = 100;
    NSMutableArray *alphabet = [Options fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:horizon alpha:60 file:alphabet];//backLeft                 B
     [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backLeft          A
     [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backLeft          C
     [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backLeft          K
     */
    
    Back = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:51]];
    [K setPosition:CGPointMake(30,0)];
    
    [Back addChild:A];
    [Back addChild:C];
    [Back addChild:K];
    
    Back.scale = 2;
    Back.position = CGPointMake(100,level);
    [self addChild:Back];
}


+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    [self addChild:A];
}

-(void)number:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2 *1.5;
    A.position = CGPointMake(x,(y +5));
    [self addChild:A];
}

-(void)titleBox:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [Options fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [Options fillCastleCSet:@"Mortar copy" withTileNumber:28];
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (unsigned long int ycount = upperLeftX; ycount >= lowerRightY ; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < upperLeftX-20) && (xcount < lowerRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < upperLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < lowerRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(lowerRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightX -25; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +45; xcount <= lowerRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    
    
    
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
    
    
}

-(void)backGroundBricks{
    NSMutableArray *bricks = [Options fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [Options fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
            
        }
        
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    [self titleBox:(300) :615: 700 : 500];
    
}

@end
