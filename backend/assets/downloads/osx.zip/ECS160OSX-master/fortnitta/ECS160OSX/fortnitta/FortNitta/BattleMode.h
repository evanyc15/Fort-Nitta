/*
 *  BattleMode.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <SpriteKit/SpriteKit.h>

float cannonPosX[50];
float cannonPosY[50];

@interface BattleMode : SKScene

+(void)cannonPosX:(NSInteger)x value:(float)value;
+(float)cannonPosX:(NSInteger)x;

+(void)cannonPosY:(NSInteger)y value:(float)value;
+(float)cannonPosY:(NSInteger)y;


@end
