/*
 *  WallPieces.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */


#import "GameScene.h"
#import "RebuildMode.h"
#import "WallPieces.h"
#import <Foundation/Foundation.h>

#define tileEdge 24
#define tileScale 2

@implementation WallPieces
// Blue starts at 48
//Red Starts at 32 , so color = 62
//Yello Starts at 16, so color = 78

int mainColor = 0;

//Used to store the color char
char colorName;

+(void)setColor: (int) color{
    if(color == 2){
        //Set Color to Yellow
        mainColor = 80;
        colorName = 'Y';
    }
    else if(color == 3){
        //Set Color to Red
        mainColor = 64;
        colorName = 'R';
    }
    else if(color == 4){
        //Set color to Blue
        mainColor = 48;
        colorName = 'B';
    }
}




+(Boolean)ifPlaceable: (GameScene *)scene pos: (CGPoint)location{
  
    NSArray *nodes = [scene nodesAtPoint:location];
    for (SKSpriteNode *object in nodes) {
        // cursor is always touching cannonHover so below is to ignore cannonHover node
        if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"]){
            return false;
            break;
        }
    }
    return true;
}


/*
 Creating individual sprite nodes to create each piece
 Since hover pieces started at 84, a certain # to get individual colors
 
*/

/*  ___
    |__|
 */
+(void)monomino: (GameScene *) scene {
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && [self ifPlaceable:scene pos: storedLocation] &&
       mapArray[yPosArr][xPosArr] == colorName){
        NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
        refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:84 - mainColor]];
        [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
        wallEncounter = false;
    }
    else{
        wallEncounter = true;
    }

}


/*  ___
    |  |
    |__|
 */
+(void)domino: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location]){
        
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode * piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
    
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
    
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
        
    }
    else{
        wallEncounter = true;
    }
}


+(void)dominoAlt: (GameScene *) scene {
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName){
        
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
        
            // left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
        
            // right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ___
    | |__
    |____|
 */
+(void)trominoL: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName) {

        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
        
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)trominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y -= tileEdge;
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)trominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr][xPosArr - 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // top left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
            }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)trominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ___
    |  |
    |  |
    |__|
 */
+(void)trominoI: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)trominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ___
    |  |__
    |__   |
       |__|
 */
+(void)tetrominoZ: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];

            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
        
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoZAlt: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr - 1] == colorName && mapArray[yPosArr + 1][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];

            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}

/*  ___
    |  |
    |  |
    |  |
    |__|
 */
+(void)tetrominoI: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr] == colorName && mapArray[yPosArr + 3][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr][xPosArr + 2] == colorName && mapArray[yPosArr][xPosArr + 3] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ____
    |   |
    |___|
 */
+(void)tetrominoCube: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ________
    |__  __|
      |__|
 */
+(void)tetrominoT: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoTAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // left piece sticking out
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];

            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoTAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // left bottom piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle bottom piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoTAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr - 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr - 1] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // right piece sticking out
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  __
    | |
    | |_
    |___|
 */
+(void)tetrominoL: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}

+(void)tetrominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= (2 * tileEdge);
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)tetrominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr][xPosArr + 2] == colorName && mapArray[yPosArr - 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // bottom middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*    ____
    __|  _|
    |__ |
      |_|
 */
+(void)pentominoF: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr - 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoFAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += (2 * tileEdge);
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // left middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoFAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr - 1] == colorName) {
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
        
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoFAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName) {
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle center piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ___
    |  |
    |  |
    |  |
    |  |
    |__|
 */
+(void)pentominoI: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 4][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 3][xPosArr] == colorName && mapArray[yPosArr + 4][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // 2nd middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // 3rd middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // 4th middle piece piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr][xPosArr + 4] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr][xPosArr + 3] == colorName && mapArray[yPosArr][xPosArr + 4] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
        
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  __
    | |
    | |
    | |_
    |___|
 */
+(void)pentominoL: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 3][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 3][xPosArr] == colorName && mapArray[yPosArr + 3][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= (3 * tileEdge);
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr][xPosArr + 3] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
        
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 3][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr][xPosArr + 3] == colorName && mapArray[yPosArr - 1][xPosArr + 3] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            
            // left bottom piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*     __
      | |
    __| |
    | __|
    |_|
 */
+(void)pentominoN: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == colorName && mapArray[yPosArr - 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            
            // top piece of left column
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // bottom piece of left column
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece of right column
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            //  middle piece of right column
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // top piece of right column
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoNAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr + 3] == colorName) {
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            //  bottom middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoNAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 3][xPosArr - 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoNAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr + 3] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  ____
    |   |
    | __|
    |_|
 */
+(void)pentominoP: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // extra piece sticking out of cube
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoPAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
    
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoPAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
                NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
                refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
                SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - mainColor]];
                SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
                SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
                SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
                
                // top piece sticking out
                [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
                
                // middle right piece
                [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
                
                // middle left piece
                [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
                
                // bottom left piece
                [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
                
                // bottom right piece
                [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
                wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoPAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){

            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // piece sticking out
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  _______
    |__  __|
      |  |
      |__|
 */
+(void)pentominoT: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
    
            // bottom
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoTAlt1: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            // middle left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoTAlt2: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += (2 * tileEdge);
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 2][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoTAlt3: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];

            // middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*  __    __
    | |__| |
    |______|
 */
+(void)pentominoU: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += (2 * tileEdge);
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= (2 * tileEdge);
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 2] == colorName && mapArray[yPosArr + 1][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
        
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // left bottom piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle bottom piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoUAlt1: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr - 1] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoUAlt2: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr - 1][xPosArr] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr - 1][xPosArr] == colorName && mapArray[yPosArr - 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoUAlt3: (GameScene *) scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*
 __
 | |
 | |___
 |_____|
 */
+(void)pentominoV:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoVAlt1:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr][xPosArr - 2] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr - 1] == colorName && mapArray[yPosArr][xPosArr - 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == colorName && mapArray[yPosArr + 2][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoVAlt2:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == colorName && mapArray[yPosArr + 2][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoVAlt3:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 2][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom middle piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*
    ____
    |  |__
    |___  |__
        |_____|
 
 */
+(void)pentominoW:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            //middle left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle step piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoWAlt1:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr - 1] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == colorName && mapArray[yPosArr + 2][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoWAlt2:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == colorName && mapArray[yPosArr + 2][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
        
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoWAlt3:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == colorName && mapArray[yPosArr + 2][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];

            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*
      ___
    __|  |__
    |__   __|
      |__|
 */
+(void)pentominoX:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    piece2Location.y += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr - 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:99 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            //Middle Piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*
 __
 | |
 | |_
 |  _|
 |_|
 
 */
+(void)pentominoY:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 3][xPosArr] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoYAlt1:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= (2 * tileEdge);
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr][xPosArr + 3] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
 
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoYAlt2:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y += (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 2][xPosArr] == colorName &&
       mapArray[yPosArr + 3][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // line-going-down pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoYAlt3:(GameScene *)scene {

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr][xPosArr + 2] == colorName &&
       mapArray[yPosArr][xPosArr + 3] == colorName && mapArray[yPosArr - 1][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
    
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            
            // bottom left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // bottom middle pieces
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
        
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // piece sticking out on top
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


/*
    ____
    |__ |
      | |__
      |____|
 
 */
+(void)pentominoZ:(GameScene *)scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr][xPosArr + 1] == colorName && mapArray[yPosArr + 1][xPosArr + 1] == colorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == colorName && mapArray[yPosArr + 2][xPosArr + 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - mainColor]];
            
            // top left piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // top right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];

            // bottom left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}


+(void)pentominoZAlt:(GameScene *)scene{

    NSInteger xPosArr = round(storedLocation.x / 24) - 1;
    NSInteger yPosArr = 26 - round(storedLocation.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = storedLocation;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;

    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == colorName &&
       mapArray[yPosArr + 1][xPosArr] == colorName && mapArray[yPosArr + 1][xPosArr - 1] == colorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == colorName && mapArray[yPosArr + 2][xPosArr - 2] == colorName){
        
        if([self ifPlaceable:scene pos:storedLocation] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            refWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - mainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - mainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - mainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - mainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - mainColor]];
            // top piece
            [RebuildMode combineWalls:scene sprite:refWallPiece pos:storedLocation];
            
            // middle right piece
            [RebuildMode combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildMode combineWalls:scene sprite:piece3 pos:piece3Location];

            // middle left piece
            [RebuildMode combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildMode combineWalls:scene sprite:piece5 pos:piece5Location];
            wallEncounter = false;
        }
        else{
            wallEncounter = true;
        }
    }
    else{
        wallEncounter = true;
    }
}



@end
