/*
 *  CastleHighLight.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <Foundation/Foundation.h>



@interface CastleHighLight : NSObject

+(SKSpriteNode *)createCastleHighlight: (int) player;

+(void)createCastleWallCorner: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player;
+(void)createCastleWall: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player;
+(void)createCastleWallDip: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player;
+(void)createCastleWallPiece: (SKScene *) scene xCord:(int) castleXCoordinate yCord: (int) castleYCoordinate color:(int) player;

@end

