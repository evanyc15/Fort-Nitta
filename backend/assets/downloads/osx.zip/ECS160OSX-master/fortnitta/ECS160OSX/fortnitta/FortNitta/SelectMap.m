/*
 *  SelectMap.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "SelectMap.h"
#include "GameSelection.h"
#include "MainMenu.h"

SKSpriteNode *BackRight;

SKSpriteNode *MapOne;
SKSpriteNode *MapOneDetails;

@implementation SelectMap

/* View of Select Map Menu */
-(void)didMoveToView:(SKView *)view {
    
    [self backGroundBricks];
    [self selectMap];
}

/* Implement map selection */
-(void)mouseDown:(NSEvent *)theEvent {
    
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    //NSLog(@"x: %f y: %f", mouseDownPos.x,mouseDownPos.y);
    
    //clicked back, return to main menu
    if(mouseDownPos.x >= 666 && mouseDownPos.x <= 731 &&
       mouseDownPos.y >= 121 && mouseDownPos.y <= 141) {
        MainMenu *scene = [MainMenu sceneWithSize:self.view.bounds.size];
        
        //set up MainMenu size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
    
    //map selected, move on to Game Selection
    else if(mouseDownPos.x >= 78 && mouseDownPos.x <= 245 &&
            mouseDownPos.y >= 397 && mouseDownPos.y <= 419) {
        GameSelection *scene = [GameSelection sceneWithSize:self.view.bounds.size];
        
        //set up GameSelection size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
    
}

//check if mouse hovers words, if so highlight
-(void)mouseMoved:(NSEvent *)theEvent {
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    //NSLog(@"x: %f y: %f", mouseDownPos.x,mouseDownPos.y);
    
    // Highlighting for back
    if(mouseDownPos.x >= 666 && mouseDownPos.x <= 731 &&
       mouseDownPos.y >= 121 && mouseDownPos.y <= 141) {
        
        [BackRight removeFromParent];
        [self backRight: @"FontKingthingsWhite copy"];
        
    }
    else{
        [BackRight removeFromParent];
        [self backRight: @"FontKingthingsBlack copy"];
        
    }
    //highlight for map one
    if(mouseDownPos.x >= 78 && mouseDownPos.x <= 245 &&
       mouseDownPos.y >= 397 && mouseDownPos.y <= 419) {
        
        [MapOne removeFromParent];
        [MapOneDetails removeFromParent];
        [self mapOneHighLight];
        
    }
    else{
        [MapOne removeFromParent];
        [MapOneDetails removeFromParent];
        [self mapOne: @"FontKingthingsBlack copy"];
        
    }
}

+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    [self addChild:A];
}

-(void)number:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2 *1.5;
    A.position = CGPointMake(x,(y +5));
    [self addChild:A];
}

-(void)backRight:(NSString*)file{
    int level, horizon;
    level = 100;
    horizon = 850;
    NSMutableArray *alphabet = [SelectMap fillCastleCSet:file withTileNumber:95];
    
    /*
    [self letter:level X:horizon alpha:60 file:alphabet];//backRight                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backRight          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backRight          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backRight          K
    */
     
    BackRight = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:51]];
    [K setPosition:CGPointMake(30,0)];
    
    [BackRight addChild:A];
    [BackRight addChild:C];
    [BackRight addChild:K];
    
    BackRight.scale = 2;
    BackRight.position = CGPointMake(horizon,level);
    [self addChild:BackRight];
}

-(void)selectMap{
    int level = 550;
    NSMutableArray *alphabet = [SelectMap fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:400 alpha:43 file:alphabet];//SELECTMAP    S
    [self letter:level X:420 alpha:57 file:alphabet];//SELECTMAP    E
    [self letter:level X:440 alpha:50 file:alphabet];//SELECTMAP    L
    [self letter:level X:460 alpha:57 file:alphabet];//SELECTMAP    E
    [self letter:level X:480 alpha:59 file:alphabet];//SELECTMAP    C
    [self letter:level X:500 alpha:42 file:alphabet];//SELECTMAP    T
    [self letter:level X:540 alpha:49 file:alphabet];//SELECTMAP    M
    [self letter:level X:560 alpha:61 file:alphabet];//SELECTMAP    A
    [self letter:level X:580 alpha:46 file:alphabet];//SELECTMAP    P
    
    [self mapOne:@"FontKingthingsBlack copy"];
    [self backRight:@"FontKingthingsBlack copy"];
}
-(void)mapOne:(NSString*)file{
    int level = 450;
    NSMutableArray *alphabet = [SelectMap fillCastleCSet:file withTileNumber:95];
    /*
    [self letter:level X:110 alpha:48 file:alphabet];//mapOne    N
    [self letter:level X:130 alpha:15 file:alphabet];//mapOne    O
    [self letter:level X:150 alpha:12 file:alphabet];//mapOne    R
    [self letter:level X:170 alpha:10 file:alphabet];//mapOne    T
    [self letter:level X:190 alpha:22 file:alphabet];//mapOne    H
    [self letter:level X:210 alpha:81 file:alphabet];//mapOne    -
    [self letter:level X:230 alpha:43 file:alphabet];//mapOne    S
    [self letter:level X:250 alpha:15 file:alphabet];//mapOne    O
    [self letter:level X:270 alpha:9 file:alphabet];//mapOne     U
    [self letter:level X:290 alpha:10 file:alphabet];//mapOne    T
    [self letter:level X:310 alpha:22 file:alphabet];//mapOne    H
    */
     
    MapOne = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* Dash = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    [Dash setPosition:CGPointMake(50,0)];
    
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake(60,0)];
    
    SKSpriteNode* O2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O2 setPosition:CGPointMake(70,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(80,0)];
    
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(90,0)];
    
    SKSpriteNode* H2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H2 setPosition:CGPointMake(100,0)];
    
    [MapOne addChild:O];
    [MapOne addChild:R];
    [MapOne addChild:T];
    [MapOne addChild:H];
    [MapOne addChild:Dash];
    [MapOne addChild:S];
    [MapOne addChild:O2];
    [MapOne addChild:U];
    [MapOne addChild:T2];
    [MapOne addChild:H2];
    
    
    MapOne.scale = 2;
    MapOne.position = CGPointMake(110,level);
    [self addChild:MapOne];
    
}

-(void)mapOneHighLight{
    int level, horizon;
    level = 300;
    horizon = 700;
    NSMutableArray *alphabet = [SelectMap fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self mapOne:@"FontKingthingsWhite copy"];
    
    /*
    [self number:level X:horizon alpha:76 file:alphabet];//mapOneHighLight                 2
    [self letter:level X:(horizon +20) alpha:46 file:alphabet];//mapOneHighLight           P
    [self letter:level X:(horizon +40) alpha:50 file:alphabet];//mapOneHighLight           L
    [self letter:level X:(horizon +60) alpha:61 file:alphabet];//mapOneHighLight           A
    [self letter:level X:(horizon +80) alpha:37 file:alphabet];//mapOneHighLight           Y
    [self letter:level X:(horizon +100) alpha:57 file:alphabet];//mapOneHighLight          E
    [self letter:level X:(horizon +120) alpha:44 file:alphabet];//mapOneHighLight          R
    [self letter:level X:(horizon +140) alpha:43 file:alphabet];//mapOneHighLight          S
    
    [self number:(level - 50) X:(horizon +20) alpha:74 file:alphabet];//mapOneHighLight    4
    [self number:(level - 50) X:(horizon +45) alpha:78 file:alphabet];//mapOneHighLight    0
    [self letter:(level - 50) X:(horizon +65) alpha:38 file:alphabet];//mapOneHighLight    X
    [self number:(level - 50) X:(horizon +95) alpha:76 file:alphabet];//mapOneHighLight    2
    [self letter:(level - 50) X:(horizon +115) alpha:72 file:alphabet];//mapOneHighLight   6
    */
    
    MapOneDetails = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:76]];
    
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(50,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(60,0)];
    
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake(70,0)];
    
    SKSpriteNode* four = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:74]];
    [four setPosition:CGPointMake(20,-20)];
    
    SKSpriteNode* zero = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero setPosition:CGPointMake(30,-20)];

    SKSpriteNode* X = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:6]];
    [X setPosition:CGPointMake(40,-20)];
    
    SKSpriteNode* two = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:76]];
    [two setPosition:CGPointMake(50,-20)];
    
    SKSpriteNode* six = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:72]];
    [six setPosition:CGPointMake(60,-20)];

    [MapOneDetails addChild:P];
    [MapOneDetails addChild:L];
    [MapOneDetails addChild:A];
    [MapOneDetails addChild:Y];
    [MapOneDetails addChild:E];
    [MapOneDetails addChild:R];
    [MapOneDetails addChild:S];
    [MapOneDetails addChild:four];
    [MapOneDetails addChild:zero];
    [MapOneDetails addChild:X];
    [MapOneDetails addChild:two];
    [MapOneDetails addChild:six];
    
    MapOneDetails.scale = 2;
    MapOneDetails.position = CGPointMake(horizon,level);
    [self addChild:MapOneDetails];
}

-(void)backGroundBricks{
    NSMutableArray *bricks = [SelectMap fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [SelectMap fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
            
        }
        
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    //[self titleBox:(300) :615: 700 : 500];
    //[self title];
    
}

@end

