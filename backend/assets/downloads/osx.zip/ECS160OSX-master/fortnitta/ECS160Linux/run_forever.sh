while [ 1 ]
do
	./make_and_run.sh
done
