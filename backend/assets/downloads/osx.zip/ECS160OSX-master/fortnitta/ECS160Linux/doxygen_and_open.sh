doxygen && gnome-open docs/html/index.html
