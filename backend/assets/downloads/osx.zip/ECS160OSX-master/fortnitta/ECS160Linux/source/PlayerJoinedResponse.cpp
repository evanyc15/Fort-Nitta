#include "PlayerJoinedResponse.h"

void CPlayerJoinedResponse::Process(CApplicationData *game){
    game->DPlayers.push_back(DUsername);
}
