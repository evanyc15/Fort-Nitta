#ifndef PLAYER_LEFT_RESPONSE_H
#define PLAYER_LEFT_RESPONSE_H

#include "ApplicationData.h"
#include "NetworkResponse.h"

#include <string>

class CPlayerLeftResponse : public CNetworkResponse{
    public:
        CPlayerLeftResponse(std::string username):
            CNetworkResponse(1), DUsername(username){
        }

        void Process(CApplicationData* game);

    protected:
        std::string DUsername;

};

#endif
