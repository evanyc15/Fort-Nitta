#ifndef ROOM_H
#define ROOM_H

#include <string>

class CRoom{
    public:
        CRoom(int id, std::string name, int player_count)
            : DID(id), DName(name), DPlayerCount(player_count)
        { }

        std::string Name() { return DName; }
        int PlayerCount() { return DPlayerCount; }
        int ID() { return DID; }
    protected:
        int DID;
        std::string DName;
        int DPlayerCount;
};


#endif
