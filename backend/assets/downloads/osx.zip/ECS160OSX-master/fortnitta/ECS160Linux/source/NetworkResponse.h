#ifndef NETWORK_RESPONSE_H
#define NETWORK_RESPONSE_H

class CApplicationData;

class CNetworkResponse{
    public:
        CNetworkResponse(int result){
            DResult = result;
        }

        virtual void Process(CApplicationData* game) = 0;

        int DResult;
};

#endif
