#ifndef PLAYER_JOINED_RESPONSE_H
#define PLAYER_JOINED_RESPONSE_H

#include "ApplicationData.h"
#include "NetworkResponse.h"

#include <string>

class CPlayerJoinedResponse : public CNetworkResponse{
    public:
        CPlayerJoinedResponse(std::string username):
            CNetworkResponse(1), DUsername(username){
        }

        void Process(CApplicationData* game);

    protected:
        std::string DUsername;

};

#endif
