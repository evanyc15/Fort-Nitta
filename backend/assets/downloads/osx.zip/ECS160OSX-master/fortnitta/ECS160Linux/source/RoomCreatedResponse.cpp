#include "RoomCreatedResponse.h"

void CRoomCreatedResponse::Process(CApplicationData *game){
    game->DIsRoomOwner = true;
    game->ChangeMode(CApplicationData::gmRoom);
}
