#ifndef NETWORK_H
#define NETWORK_H

#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>
#include "unistd.h"
#include "stdio.h"
#include "errno.h"

#include <string>
#include <deque>
#include <cstdlib>
#include <vector>
#include <sstream>
#include <iostream>

#include "NetworkResponse.h"

class CApplicationData;

class CNetwork{
    public:
        CNetwork();
        void LogIn(std::string username, std::string password);
        void GetRoomsAvailable();
        void JoinRoom(int id);
        void CreateRoom(std::string name, std::string username, int player_count);
        void StartRoom(std::string map);
        void Update(CApplicationData* game);
        const std::string GetConnectionString();
        void SetConnectionString(const std::string &connection_string);
	int TcpConnect(char * host,  int    port);
        void SendHttpMessage(int mysocket, char *request_template, const char *username, const char *password);
        int RecvHttpMessage(int mysocket, char *message_buffer, int buffer_size);
    private:
        std::deque<CNetworkResponse*> DEvents;
        std::string DConnectionString;
};

#endif
