#ifndef APPLICATION_DATA_H
#define APPLICATION_DATA_H

#include "Network.h"
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <sys/time.h>
#include <list>
#include <sstream>
#include <map>
#include <dirent.h>
#include "GraphicTileset.h"
#include "FontTileset.h"
#include "TerrainMap.h"
#include "WallShape.h"
#include "SoundLibraryMixer.h"
#include "RandomNumberGenerator.h"
#include "Room.h"
#include <iostream>

//for lua config
#include <vector>
#include <fstream>
#include <sstream>
#include <cstddef>
#include <lua5.2/lua.hpp>
#include "LuaBridge/LuaBridge.h"



//using namespace std;
#define INITIAL_MAP_WIDTH       480
#define INITIAL_MAP_HEIGHT      288
#define TIMEOUT_INTERVAL        50
#define ANIMATION_TIMESTEPS     4
#define WINDDIRECTION_COUNT     9
#define WINDSPEED_COUNT         8
#define STANDARD_GRAVITY        9.80665
#define TIMESTEP_PERIOD         ((double)TIMEOUT_INTERVAL / 500.0)
#define REBUILD_TIME            15
#define BATTLE_TIME             15
#define PLACEMENT_TIME          10
#define SELECT_TIME             15
#define DEBUG                   1
#define RANDOM_NUMBER_MAX       1000000






typedef struct{
    int DXIndex;
    int DYIndex;
} SMapLocation, *SMapLocationRef;

typedef struct{
    double DXPosition;
    double DYPosition;
    double DZPosition;
    double DXVelocity;
    double DYVelocity;
    double DZVelocity;
    EPlayerColor DOwner;
    int DCannon;
} SCannonballTrajectory, *SCannonballTrajectoryRef;

typedef struct{
  int DXIndex;
  int DYIndex;
  int DXOffset;
  int DYOffset;
  int DSpriteIndex;
  int DStep;
} SSpriteState, *SSpriteStateRef;
//int NextPiece = 0;
class CApplicationData{

    public:
        typedef enum{
            gmMainMenu,
            gmSelectMap,
            gmOptionsMenu,
            gmSoundOptions,
            gmNetworkOptions,
            gmLoginMenu,
            gmMultiplayerMenu,
            gmSelectMultiplayerMap,
            gmRoom,
            gmTransitionSelectCastle,
            gmSelectCastle,
            gmTransitionRebuild,
            gmRebuild,
            gmTransitionCannonPlacement,
            gmCannonPlacement,
            gmTransitionBattle,
            gmBattle,
            gmGameOver,
            gmSelectWind
        } EGameMode, *EGameModeRef;

        typedef enum{
            cttNone,
            cttBlueFloor,
            cttBlueWall,
            cttBlueWallDamaged,
            cttRedFloor,
            cttRedWall,
            cttRedWallDamaged,
            cttYellowFloor,
            cttYellowWall,
            cttYellowWallDamaged,
            cttGroundDamaged,
            cttBlueFloorDamaged,
            cttRedFloorDamaged,
            cttYellowFloorDamaged
        } EConstructionTileType, *EConstructionTileTypeRef;

        typedef enum{
            etWallExplosion0 = 0,
            etWallExplosion1,
            etWaterExplosion0,
            etWaterExplosion1,
            etGroundExplosion0,
            etGroundExplosion1,
            etMax
        } EExplosionType, *EExplosionTypeRef;

        typedef enum{
            btRubbleBurn0 = 0,
            btRubbleBurn1,
            btHoleBurn0,
            btHoleBurn1,
            btMax
        } EBurnType, *EBurnTypeRef;

        typedef enum{
            dNorth = 0,
            dNorthEast,
            dEast,
            dSouthEast,
            dSouth,
            dSouthWest,
            dWest,
            dNorthWest,
            dMax
        } EDirection, *EDirectionRef;

        typedef enum{
            sctTick = 0,
            sctTock,
            sctCannon0,
            sctCannon1,
            sctPlace,
            sctTriumph,
            sctExplosion0,
            sctExplosion1,
            sctExplosion2,
            sctExplosion3,
            sctGroundExplosion0,
            sctGroundExplosion1,
            sctWaterExplosion0,
            sctWaterExplosion1,
            sctWaterExplosion2,
            sctWaterExplosion3,
            sctReady,
            sctAim,
            sctFire,
            sctCeasefire,
            sctTransition,
            sctMax
        } ESoundClipType, *ESoundClipTypeRef;

        typedef enum{
            stMenu,
            stLoss,
            stWin,
            stPlace,
            stRebuild,
            stMax
        } ESongType, *ESongTypeRef;

        typedef enum{
            bbtTopCenter = 0,
            bbtTopRight,
            bbtRight0,
            bbtRight1,
            bbtBottomRight,
            bbtBottomCenter,
            bbtBottomLeft,
            bbtLeft0,
            bbtLeft1,
            bbtTopLeft,
            bbtSingle,
            bbtMax
        } EBorderBrickType, *EBorderBrickTypeRef;

        typedef enum{
            bmtTopLeft0 = 0,
            bmtTopLeft1,
            bmtTopLeft2,
            bmtTopCenter,
            bmtTopRight0,
            bmtTopRight1,
            bmtTopRight2,
            bmtRightTop0,
            bmtRightTop1,
            bmtRightTop2,
            bmtRightCenter,
            bmtRightBottom0,
            bmtRightBottom1,
            bmtRightBottom2,
            bmtBottomRight0,
            bmtBottomRight1,
            bmtBottomRight2,
            bmtBottomCenter,
            bmtBottomLeft0,
            bmtBottomLeft1,
            bmtBottomLeft2,
            bmtLeftTop0,
            bmtLeftTop1,
            bmtLeftTop2,
            bmtLeftCenter,
            bmtLeftBottom0,
            bmtLeftBottom1,
            bmtLeftBottom2,
            bmtMax
        } EBorderMotarType, *EBorderMortarTypeRef;

        typedef enum{
            wtNone,
            wtMild,
            wtModerate,
            wtErratic
        } EWindType, *EWindTypeRef;

        typedef enum{
            bmsReady,
            bmsAim,
            bmsBattle
        } EBattleModeStage, *EBattleModeStageRef;

        GtkWidget *DMainWindow;
        GtkWidget *DDrawingArea;
        GdkCursor* DBlankCursor;
        GdkGC     *DDrawingContext;
        GdkPixmap *DDoubleBufferPixmap;
        GdkPixmap *DPreviousWorkingBufferPixmap;
        GdkPixmap *DWorkingBufferPixmap;
        GdkPixmap *D2DTerrainPixmap;
        GdkPixmap *DBannerPixmap;
        GdkPixmap *DMessagePixmap;
        GdkPixbuf *DWorkingPixbuf;
        std::vector< GdkPixmap * > D3DTerrainPixmaps;
        CGraphicTileset D2DTerrainTileset;
        CGraphicTileset D3DTerrainTileset;
        CGraphicTileset D3DFloorTileset;
        CGraphicTileset D3DWallTileset;
        CGraphicTileset D3DCannonTileset;
        CGraphicTileset D3DCastleTileset;
        CGraphicTileset D3DCannonballTileset;
        CGraphicTileset D3DExplosionTileset;
        CGraphicTileset D3DBurnTileset;
        CGraphicTileset D3DCannonPlumeTileset;
        CGraphicTileset D2DCastleCannonTileset;
        CGraphicTileset D2DCastleSelectTileset;
        CGraphicTileset D2DWallFloorTileset;
        CGraphicTileset DDigitTileset;
        CGraphicTileset DBrickTileset;
        CGraphicTileset DMortarTileset;
        CGraphicTileset DTargetTileset;
        CFontTileset DBlackFont;
        CFontTileset DWhiteFont;
        CNetwork* DNetwork;
        std::string DServerConnectionString;
        std::vector< CTerrainMap > DTerrainMaps;
        CTerrainMap DTerrainMap;
        CSoundLibraryMixer DSoundMixer;
        CRandomNumberGenerator DRandomNumberGenerator;
        int DScaling;
        int DMapWidth, DMapHeight;
        int DTileWidth, DTileHeight;
        int DCanvasWidth, DCanvasHeight;
        gint DBannerLocation;
        struct timeval DNextExpectedTimeout;
        struct timeval DCurrentStageTimeout;
        struct timeval DLastTickTockTime;
        int DAnimationTimestep;
        EWindType DWindType;
        int DWindSpeed, DWindDirection;
        EGameMode DGameMode;
        EGameMode DNextGameMode;
        std::string DTextInput;
        EPlayerColor DPlayerColor;
        EAIDifficulty DAIDifficulty;
        int DPlayerCount;
        bool DPlayerIsAI[pcMax];
        bool DPlayerIsAlive[pcMax];
        bool DPlayerIsConquered[pcMax];
        int DSurroundedCastleCounts[pcMax];
        std::vector< double > DInitialVelocities;
        std::vector< std::vector< EConstructionTileType > > DConstructionTiles;
        std::vector< std::vector< int > > DHitsTaken;
        std::vector< bool > DSurroundedCastles[pcMax];
        std::vector< SMapLocation > DCastleLocations[pcMax];
        std::vector< SMapLocation > DCannonLocations[pcMax];
        std::vector< int > DCannonballToneIDs[pcMax];
        std::list< SCannonballTrajectory > DCannonballTrajectories;
        std::list< int > DCannonsReady[pcMax];
        std::list< SSpriteState > DExplosionStates;
        std::list< SSpriteState > DBurnStates;
        std::list< SSpriteState > DPlumeStates;
        std::vector< std::string > DMenuItems;
        std::string DMenuTitle;
        std::vector<CRoom> DRoomsAvailable;
        std::vector<std::string> DPlayers;
        bool DIsRoomOwner;
        std::string DUsername;
        int DSelectedMenuItem;
        int DLastSelectedMenuItem;
        int DCurrentX[pcMax];
        int DCurrentY[pcMax];
        bool DLeftClick[pcMax];
        bool DRightClick[pcMax];
        int DCannonsToPlace[pcMax];
        CWallShape DWallShape[pcMax];
        bool DCanPlaceWallCannon[pcMax];
        bool DCompletedStage[pcMax];
        int DAITargetX[pcMax];
        int DAITargetY[pcMax];
        int DAITargetCastle[pcMax];
        int D2DCastleIndices[pcMax];
        int D2DFloorIndices[pcMax];
        int D2DWallIndices[pcMax+2];
        int D2DCannonIndices[pcMax];
        int D2DSelectColorIndices[pcMax];
        int D2DDamagedGroundIndex;
        int D3DFloorIndices[pcMax];
        int D3DTargetIndices[pcMax];
        int D3DWallIndices[pcMax][16];
        int D3DDamagedWallIndices[pcMax];
        int D3DCastleIndices[pcMax];
        int D3DDamagedGroundIndex;
        int D3DExplosionIndices[etMax];
        int D3DBurnIndices[btMax];
        int D3DCannonPlumeIndices[dMax];
        int DSoundClipIndices[sctMax];
        int DSongIndices[stMax];
        int DBrickIndices[bbtMax];
        int DMortarIndices[bmtMax];
        int DVoiceClipID;
        EBattleModeStage DBattleModeStage;
        int DExplosionSteps;
        int DBurnSteps;
        int DCannonPlumeSteps;
        float DSoundEffectVolume;
        float DMusicVolume;
	bool DPause;
        bool DNetworkGame;

        static bool TileTypeIsFloor(EConstructionTileType type){
            return (cttBlueFloor == type)||(cttRedFloor == type)||(cttYellowFloor == type);
        };

        static bool TileTypeIsFloorDamaged(EConstructionTileType type){
            return (cttBlueFloorDamaged == type)||(cttRedFloorDamaged == type) || (cttYellowFloorDamaged == type);
        };

        static bool TileTypeIsWall(EConstructionTileType type){
            return (cttBlueWall == type)||(cttRedWall == type)||(cttYellowWall == type);
        };

        static bool TileTypeIsWallDamaged(EConstructionTileType type){
            return (cttBlueWallDamaged == type)||(cttRedWallDamaged == type)||(cttYellowWallDamaged == type);
        };

        static bool TileTypeIsFloorGroundDamaged(EConstructionTileType type){
            return (cttGroundDamaged == type)||(cttBlueFloorDamaged == type)||(cttRedFloorDamaged == type) || (cttYellowFloorDamaged == type);
        };

        // Code from http://www.codecodex.com/wiki/Calculate_an_integer_square_root
        static unsigned int IntegerSquareRoot(unsigned int x){
            register unsigned int Op, Result, One;

            Op = x;
            Result = 0;

            One = 1 << (sizeof(unsigned int) * 8 - 2);
            while(One > Op){
                One >>= 2;
            }
            while(0 != One){
                if(Op >= Result + One){
                    Op -= Result + One;
                    Result += One << 1;  // <-- faster than 2 * one
                }
                Result >>= 1;
                One >>= 2;
            }
            return Result;
        };

        static bool TrajectoryCompare(const SCannonballTrajectory &first, const SCannonballTrajectory &second){
            if(first.DZPosition < second.DZPosition){
                return true;
            }
            if(first.DZPosition > second.DZPosition){
                return false;
            }
            if(first.DYPosition < second.DYPosition){
                return true;
            }
            if(first.DYPosition > second.DYPosition){
                return false;
            }
            if(first.DXPosition < second.DXPosition){
                return true;
            }
            return false;
        };

        static bool SpriteCompare(const SSpriteState &first, const SSpriteState &second){
            if(first.DYIndex < second.DYIndex){
                return true;
            }
            if(first.DYIndex > second.DYIndex){
                return false;
            }
            if(first.DXIndex < second.DXIndex){
                return true;
            }
            return false;
        };

        static int SecondsUntilDeadline(struct timeval deadline){
            struct timeval CurrentTime;

            gettimeofday(&CurrentTime, NULL);

            return ((deadline.tv_sec * 1000 + deadline.tv_usec / 1000) - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000)) / 1000;
        };

        static int SecondsPaused(struct timeval past, struct timeval present){
            return present.tv_sec - past.tv_sec;            
        }

        static int MicroSecondsPaused(struct timeval past, struct timeval present){
            return present.tv_usec - past.tv_usec;            
        }

        static int MiliSecondsUntilDeadline(struct timeval deadline){
            struct timeval CurrentTime;

            gettimeofday(&CurrentTime, NULL);

            return ((deadline.tv_sec * 1000 + deadline.tv_usec / 1000) - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000));
        };
        // calcuates the direction of the cannon ball and returns an int to show angle due North
        static int CalculateDirection(int x1, int y1, int x2, int y2){
            int XDistance = x2 - x1;
            int YDistance = y2 - y1;
            bool NegativeX = XDistance < 0;
            bool NegativeY = YDistance > 0; // Top of screen is 0
            double SinSquared;

            XDistance *= XDistance;
            YDistance *= YDistance;

            if(0 == (XDistance + YDistance)){
                return dNorth;
            }
            SinSquared = (double)YDistance / (XDistance + YDistance);

            if(0.1464466094 > SinSquared){
                // East or West
                if(NegativeX){
                    return dWest; // West
                }
                else{
                    return dEast; // East
                }
            }
            else if(0.85355339059 > SinSquared){
                // NE, SE, SW, NW
                if(NegativeY){
                    if(NegativeX){
                        return dSouthWest; // SW
                    }
                    else{
                        return dSouthEast; // SE
                    }
                }
                else{
                    if(NegativeX){
                        return dNorthWest; // NW
                    }
                    else{
                        return dNorthEast; // NE
                    }
                }
            }
            else{
                // North or South
                if(NegativeY){
                    return dSouth; // South
                }
                else{
                    return dNorth; // North
                }
            }

        };

        // calculate the size of the cannon ball according to it's distance from origin = z.
        static int CalculateCannonballSize(double z){
            if(100.1499064 < z){
                return 11;
            }
            if(97.5217589  < z){
                return 10;
            }
            if(95.41127261 < z){
                return 9;
            }
            if(92.81657303 < z){
                return 8;
            }
            if(89.55578929 < z){
                return 7;
            }
            if(85.34315122 < z){
                return 6;
            }
            if(79.70240953 < z){
                return 5;
            }
            if(71.77635988 < z){
                return 4;
            }
            if(59.85065264 < z){
                return 3;
            }
            /*if(39.92522189 < z){
                return 2;
            }*/
            return 2;
        };

        static gboolean TimeoutCallback(gpointer data);
        static gboolean MainWindowDeleteEventCallback(GtkWidget *widget, GdkEvent *event, gpointer data);
        static void MainWindowDestroyCallback(GtkWidget *widget, gpointer data);
        static gboolean MainWindowKeyPressEventCallback(GtkWidget *widget, GdkEventKey *event, gpointer data);
        static gboolean DrawingAreaExposeCallback(GtkWidget *widget, GdkEventExpose *event, gpointer data);
        static gboolean DrawingAreaButtonPressEventCallback(GtkWidget *widget, GdkEventButton *event, gpointer data);
        static gboolean DrawingAreaMotionNotifyEventCallback(GtkWidget *widget, GdkEventMotion *event, gpointer data);


        gboolean Timeout();
        gboolean MainWindowDeleteEvent(GtkWidget *widget, GdkEvent *event);
        void MainWindowDestroy(GtkWidget *widget);
        gboolean MainWindowKeyPressEvent(GtkWidget *widget, GdkEventKey *event);
        gboolean DrawingAreaExpose(GtkWidget *widget, GdkEventExpose *event);
        gboolean DrawingAreaButtonPressEvent(GtkWidget *widget, GdkEventButton *event);
        gboolean DrawingAreaMotionNotifyEvent(GtkWidget *widget, GdkEventMotion *event);

        void DrawMenu();
        void DrawLoginMenu();
        void DrawMultiplayerMenu();
        void DrawSelectMap();
        void DrawMultiplayerSelectMap();
        void DrawRoom();
        void DrawSelectMultiplayerMap();
        void DrawSoundOptions();
        void DrawNetworkOptions();
        void DrawSelectWind();
        void Draw2DFrame();
        void Draw3DFrame();
        void DrawBanner(const std::string &message);
        void DrawMessage(const std::string &message);
        void DrawMenuBackground(GdkPixmap *buffer, gint width, gint height);
        void DrawTextFrame(GdkPixmap *buffer, gint width, gint height);
        void DrawBrickFrame(GdkPixmap *buffer, gint xoff, gint yoff, gint width, gint height);

        void GameOverMode();
        void TransitionMode();
        void MainMenuMode();
        void LoginMenuMode();
        void MultiplayerMenuMode();
        void RoomMode();
        void SelectMapMode();
        void SelectMultiplayerMapMode();
        void SelectWindMode();
        void OptionsMenuMode();
        void SoundOptionsMode();
        void NetworkOptionsMode();
        void SelectCastleMode();
        void CannonPlacementMode();
        void RebuildMode();
        void BattleMode();
        void ChangeMode(EGameMode nextmode);
        void InitializeBanner(const std::string &message);

        void MoveAI(int colorindex);
        void SelectCastleAI();
        void CannonPlacementAI();
        void RebuildAI();
        void BattleAI();

        void CheckSurroundedCastles();
        bool CannonCastleInterfere(int xindex, int yindex, int width, int height);
        bool ValidCannonPlacement(int colorindex, int xindex, int yindex);
        bool ValidWallPlacement(int colorindex, int xindex, int yindex);
        void ExpandUnclaimed(int xpos, int ypos);
        bool CleanUpWallEdges();
        bool BoundsCheck(int &xindex, int &yindex);
        void PlayTickTockSound();
        int DetermineConquered();
        void LoadTerrainMap(int index);
        void ResetMap();
        void ResizeCanvases();


    public:
        CApplicationData();
        ~CApplicationData();

        int Init(int argc, char *argv[]);
	
	
	int isWall(int x, int y);
	int getWallType(int x, int y);
	bool isValidCannonLoc(int colorindex, int xindex, int yindex);
	void setDAITarget(int colorindex, int xval, int yval);
	int getDAITargetX(int colorindex);
	int getWallShapeHeight(int ColorIndex);
	int getWallShapeWidth(int ColorIndex);
	bool getWallShapeIsBlock(int ColorIndex, int WallXPos, int WallYPos);
	bool getValidWallPlacement(int ColorIndex, int TargetX, int TargetY);
	void rotateWallShape(int ColorIndex);
};

#endif
