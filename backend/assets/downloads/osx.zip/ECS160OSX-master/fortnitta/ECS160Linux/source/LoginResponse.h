#ifndef LOGIN_RESPONSE_H
#define LOGIN_RESPONSE_H

#include "ApplicationData.h"
#include "NetworkResponse.h"

class CLoginResponse: public CNetworkResponse{
    public:
        CLoginResponse(int result):
            CNetworkResponse(result){
        }

        void Process(CApplicationData* game);
};

#endif
