#include "Network.h"
#include "LoginResponse.h"

#define FAKE_NETWORK

#ifdef FAKE_NETWORK
#include "Room.h"
#include "RoomsAvailableResponse.h"
#include "RoomJoinedResponse.h"
#include "RoomCreatedResponse.h"
#include "PlayerJoinedResponse.h"
#include "PlayerLeftResponse.h"
#endif

static char * request_template  = "POST / HTTP/1.0\r\nUser-Agent:EKRClient\r\n{\"username\": \"%s\", \"password\": \"%s\"}\r\n\r\n";

static char* username;
static int password;
int mysocket;
#define ACCEPTED 1;
#define DENIED 0;

CNetwork::CNetwork(){
    DConnectionString = "localhost:8000";
}

void CNetwork::LogIn(std::string username, std::string password){
#ifdef FAKE_NETWORK
    DEvents.push_back(new CLoginResponse(1));
    return;
#endif

    std::cout << "Username: " << username << " Password: " << password << "\n";
    char *host = "optical.cs.ucdavis.edu";
    int port = 49999;
    int buffer_size = 1024;
    char message_buffer[buffer_size];
    
    mysocket = TcpConnect(host, port);
    
    SendHttpMessage(mysocket,request_template,username.c_str(), password.c_str());
           
    RecvHttpMessage(mysocket, message_buffer,buffer_size);
  
    std::cout << "Got:\n" << message_buffer;

    //TODO logic to verify we're logged in or not. If yes, we put
    //CLoginResponse(1), else, we don't. 
    
    DEvents.push_back(new CLoginResponse(1));
}

void CNetwork::GetRoomsAvailable(){
#ifdef FAKE_NETWORK
    std::vector<CRoom> Rooms;
    Rooms.push_back(CRoom(1, "fred's game", 2));
    Rooms.push_back(CRoom(2, "bob's game", 2));
    Rooms.push_back(CRoom(3, "nitta's game", 2));
    DEvents.push_back(new CRoomsAvailableResponse(Rooms));
#endif
}

void CNetwork::JoinRoom(int id){
#ifdef FAKE_NETWORK
    std::vector<std::string> Players;
    switch(id){
        case 1:
            Players.push_back("fred");
            break;
        case 2:
            Players.push_back("bob");
            break;
        case 3:
            Players.push_back("The Professor");
            break;
    }
    DEvents.push_back(new CRoomJoinedResponse(Players));
#endif
}

void CNetwork::CreateRoom(std::string name, std::string username, int player_count){
#ifdef FAKE_NETWORK
    DEvents.push_back(new CRoomCreatedResponse());
    DEvents.push_back(new CPlayerJoinedResponse("bob"));
    DEvents.push_back(new CPlayerJoinedResponse("dave"));
    DEvents.push_back(new CPlayerLeftResponse("dave"));
    DEvents.push_back(new CPlayerJoinedResponse("fred"));
    DEvents.push_back(new CPlayerLeftResponse("fred"));
#endif
}

void CNetwork::Update(CApplicationData *game){
    while(DEvents.size()){
        CNetworkResponse* Response = DEvents.front();
        Response->Process(game);
        DEvents.pop_front();
        delete Response;
    }
}

//Provided by Ricardo
const std::string CNetwork::GetConnectionString(){
    return DConnectionString;
}

//Provided by Ricardo.
void CNetwork::SetConnectionString(const std::string &connection_string){
    // maybe reconnect
    DConnectionString = connection_string;
}


int CNetwork::TcpConnect(char * host,  int    port){
    struct hostent *ServerAddress;
    struct sockaddr_in addr;
    int sock;

    if (!(ServerAddress = gethostbyname(host))) {
        //TODO, create exception class
        std::cout << strerror(errno)<< "\n";
    }
    memset(&addr, 0, sizeof(addr));
    addr.sin_addr   = *(struct in_addr*) ServerAddress -> h_addr_list[0];
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(port);

    if ((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        //TODO create exception
        std::cout << strerror(errno) << "\n";
    }
    if (connect(sock, (struct sockaddr*) &addr, sizeof(addr)) < 0) {
        //TODO create exception
       std::cout << strerror(errno) << "\n";
    }
    std::cout << "Created socket successfully\n";
    return sock;
}

void CNetwork::SendHttpMessage(int mysocket, char *request_template, const char *username,const char *password){

    uint32_t packet_length;
    std::string sendingString;                        // assign buffered data to a string

    //Let's get the size of the template.
    packet_length = strlen(request_template) + strlen(username) +strlen(password);
    //Allocate buffer for finished packet.
    char buffer[packet_length+1];
    //Setup finished packet
    snprintf(buffer, packet_length, request_template, username, password);

    packet_length = htonl(packet_length); // Ensure network byte order
                                                // when sending the data length
    //TODO deal with different error messages.
    int result = send(mysocket,&packet_length ,sizeof(uint32_t) ,MSG_CONFIRM);

    //TODO deal with different error messages.
    send(mysocket,buffer,packet_length,MSG_CONFIRM); // Send the string

}


int CNetwork::RecvHttpMessage(int mysocket, char *message_buffer, int buffer_size){

    uint32_t packet_length;

    recv(mysocket,&packet_length,sizeof(uint32_t),0); // Receive the message length
    //TODO Deal with errors.
    if(packet_length > buffer_size){
        std::cout << "Error, packet is too large: " << packet_length << "\n";
    }
    
    packet_length = ntohl(packet_length ); // Ensure host system byte order

    std::string receivedString(packet_length,0);                        // assign buffered data to a string
    recv(mysocket,message_buffer,buffer_size,0); // Receive the string data       
    std::cout << message_buffer;
    return packet_length;

}
