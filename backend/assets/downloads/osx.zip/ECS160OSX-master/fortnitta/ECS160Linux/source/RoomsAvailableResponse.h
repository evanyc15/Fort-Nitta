#ifndef ROOMS_AVAILABLE_RESPONSE_H
#define ROOMS_AVAILABLE_RESPONSE_H

#include "ApplicationData.h"
#include "NetworkResponse.h"
#include "Room.h"


class CRoomsAvailableResponse: public CNetworkResponse{
    public:
        CRoomsAvailableResponse(std::vector<CRoom> rooms):
            CNetworkResponse(1), DRooms(rooms){
        }

        void Process(CApplicationData* game);
    protected:
       std::vector<CRoom> DRooms;
};

#endif
