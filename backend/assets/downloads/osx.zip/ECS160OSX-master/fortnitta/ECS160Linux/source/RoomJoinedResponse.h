#ifndef ROOM_JOINED_RESPONSE_H
#define ROOM_JOINED_RESPONSE_H

#include <string>
#include <vector>

#include "ApplicationData.h"
#include "NetworkResponse.h"

class CRoomJoinedResponse : public CNetworkResponse{
    public:
        CRoomJoinedResponse(std::vector<std::string> players):
            CNetworkResponse(1), DPlayers(players){
        }

        void Process(CApplicationData* game);
    protected:
        std::vector<std::string> DPlayers;
};

#endif
