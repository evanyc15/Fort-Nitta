#include "LoginResponse.h"

#include "ApplicationData.h"

void CLoginResponse::Process(CApplicationData *game){
    // TODO check if login was success and do something else if not
    game->ChangeMode(CApplicationData::gmMultiplayerMenu);
}
