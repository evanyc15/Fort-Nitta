#include "RoomJoinedResponse.h"

void CRoomJoinedResponse::Process(CApplicationData *game){
    game->DPlayers = DPlayers;
    game->DPlayers.push_back(game->DUsername);
    game->DIsRoomOwner = false;
    game->ChangeMode(CApplicationData::gmRoom);
}
