#include "PlayerLeftResponse.h"

void CPlayerLeftResponse::Process(CApplicationData *game){
    for(std::vector<std::string>::iterator it = game->DPlayers.begin();
        it != game->DPlayers.end(); it++){
        if (*it == DUsername){
            game->DPlayers.erase(it);
            break;
        }
    }
}
