#ifndef ROOM_CREATED_RESPONSE_H
#define ROOM_CREATED_RESPONSE_H

#include "ApplicationData.h"
#include "NetworkResponse.h"


class CRoomCreatedResponse : public CNetworkResponse{
    public:
        CRoomCreatedResponse():
            CNetworkResponse(1){
        }

        void Process(CApplicationData* game);
};

#endif
