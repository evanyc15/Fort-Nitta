#include "RoomsAvailableResponse.h"

void CRoomsAvailableResponse::Process(CApplicationData *game){
    game->DRoomsAvailable = DRooms;
}
