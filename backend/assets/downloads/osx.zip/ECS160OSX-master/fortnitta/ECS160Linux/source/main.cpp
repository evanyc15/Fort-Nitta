/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.
    
    All source material (source code, images, sounds, etc.) have been provided to 
    University of California, Davis students of course ECS 160 for educational 
    purposes. It may not be distributed beyond those enrolled in the course without 
    prior permission from the copyright holder. 
    
    Some sound files, sound fonts, and midi files have been included that were 
    freely available via internet sources. They have been included in this 
    distribution for educational purposes only and this copyright notice does not 
    attempt to claim any ownership of this material.
*/
#include "ApplicationData.h"
using namespace std;
using namespace luabridge;

//global Lua State
lua_State* L = luaL_newstate();
void init_lua();

//Lua Functions
LuaRef getxy(L);
LuaRef getCannonLocs(L);
LuaRef findBestPlacement(L);

//AI Fuctions
int getWallType(int x, int y);
bool isValidCannonLoc(int colorindex, int xindex, int yindex);
void setDAITarget(int colorindex, int xval, int yval);
int getDAITargetX(int colorindex);
int getWallShapeHeight(int ColorIndex);
int getWallShapeWidth(int ColorIndex);
bool getWallShapeIsBlock(int ColorIndex, int WallXPos, int WallYPos);
bool getValidWallPlacement(int ColorIndex, int TargetX, int TargetY);
void rotateWallShape(int ColorIndex);
int getshotat(int x, int y);
void setshotat(int x, int y);
void resetshotat();

//AI DataStructures & variabfles
int difficultyLevel;
int DTileWidth_rebuild;
int DTileHeight_rebuild;
int DMapHeight_rebuild;
int DMapWidth_rebuild;
int shotatrecord[40][24];

CApplicationData::CApplicationData(){
    DNetwork = new CNetwork();

    DGameMode = DNextGameMode = gmMainMenu;
    DPlayerColor = pcBlue;
    DAIDifficulty = aiEasy;
    
    DMainWindow = NULL;
    DDrawingArea = NULL;
    DBlankCursor = NULL;
    DDrawingContext = NULL;
    DDoubleBufferPixmap = NULL;
    DPreviousWorkingBufferPixmap = NULL;
    DWorkingBufferPixmap = NULL;
    D2DTerrainPixmap = NULL;
    DBannerPixmap = NULL;
    DMessagePixmap = NULL;
    DWorkingPixbuf = NULL;
    
    DSelectedMenuItem = 0;
    DAnimationTimestep = 0;
    DWindDirection = 0;
    DWindSpeed = 1;
    DWindType = wtNone;
    DScaling = 1;
    
    DSoundEffectVolume = 1.0;
    DMusicVolume = 1.0;

    for(int Index = 0; Index < pcMax; Index++){
       DCanPlaceWallCannon[Index] = false;
       DCannonsToPlace[Index] = 0;
       DCurrentX[Index] = 0;
       DCurrentY[Index] = 0;
       DLeftClick[Index] = false;
       DRightClick[Index] = false;
    }

    init_lua();
}

CApplicationData::~CApplicationData(){
    delete DNetwork;
}


gboolean CApplicationData::TimeoutCallback(gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    if(AppData->Timeout()){
        struct timeval CurrentTime;
        int64_t TimeDelta;
        
        gettimeofday(&CurrentTime, NULL);
        do{
            AppData->DNextExpectedTimeout.tv_usec += TIMEOUT_INTERVAL * 1000;
            if(1000000 <= AppData->DNextExpectedTimeout.tv_usec){
                AppData->DNextExpectedTimeout.tv_usec %= 1000000;
                AppData->DNextExpectedTimeout.tv_sec++;
            }
            TimeDelta = (AppData->DNextExpectedTimeout.tv_sec * 1000 + AppData->DNextExpectedTimeout.tv_usec / 1000) - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000);
        }while(0 >= TimeDelta);
        g_timeout_add(TimeDelta, TimeoutCallback, data);
    }
    return FALSE;
}

/*
 * This is a callback function to signify that the delete windows has been called.
 * If you return FALSE in the "delete-event" signal handler, GTK will emit the 
 * "destroy" signal. Returning TRUE means you don't want the window to be 
 * destroyed. This is useful for popping up 'are you sure you want to quit?'
 * type dialogs.
 */
gboolean CApplicationData::MainWindowDeleteEventCallback(GtkWidget *widget, GdkEvent *event, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    return AppData->MainWindowDeleteEvent(widget, event);
}
/* 
 * The following prodecures draw different windows according to their names.
 * The destroy window callback
 */
void CApplicationData::MainWindowDestroyCallback(GtkWidget *widget, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    AppData->MainWindowDestroy(widget);
}
gboolean CApplicationData::MainWindowKeyPressEventCallback(GtkWidget *widget, GdkEventKey *event, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    return AppData->MainWindowKeyPressEvent(widget, event);
}

gboolean CApplicationData::DrawingAreaExposeCallback(GtkWidget *widget, GdkEventExpose *event, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    return AppData->DrawingAreaExpose(widget, event);
}

gboolean CApplicationData::DrawingAreaButtonPressEventCallback(GtkWidget *widget, GdkEventButton *event, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    return AppData->DrawingAreaButtonPressEvent(widget, event);
}

gboolean CApplicationData::DrawingAreaMotionNotifyEventCallback(GtkWidget *widget, GdkEventMotion *event, gpointer data){
    CApplicationData *AppData = (CApplicationData *)data;

    return AppData->DrawingAreaMotionNotifyEvent(widget, event);
}

gboolean CApplicationData::Timeout(){
    
    DNetwork->Update(this);

    switch(DGameMode){
        case gmMainMenu:                    MainMenuMode();
                                            DrawMenu();
                                            break;
        case gmLoginMenu:                   LoginMenuMode();
                                            DrawLoginMenu();
                                            break;
        case gmMultiplayerMenu:             MultiplayerMenuMode();
                                            DrawMultiplayerMenu();
                                            break;
        case gmSelectMultiplayerMap:        SelectMultiplayerMapMode();
                                            DrawSelectMap();
                                            break;
        case gmRoom:                        RoomMode();
                                            DrawRoom();
                                            break;
        case gmSelectMap:                   SelectMapMode();
                                            DrawSelectMap();
                                            break;
        case gmSelectWind:                  SelectWindMode();
                                            DrawSelectWind();
                                            break;
        case gmOptionsMenu:                 OptionsMenuMode();
                                            DrawMenu();
                                            break;
        case gmSoundOptions:                SoundOptionsMode();
                                            DrawSoundOptions();
                                            break;
        case gmNetworkOptions:              NetworkOptionsMode();
                                            DrawNetworkOptions();
                                            break;
        case gmSelectCastle:                SelectCastleAI();
                                            SelectCastleMode();
                                            Draw2DFrame();                                        
                                            break;
        case gmRebuild:                     RebuildAI();
                                            RebuildMode();
                                            Draw2DFrame();
                                            break;
        case gmCannonPlacement:             CannonPlacementAI();
                                            CannonPlacementMode();
                                            Draw2DFrame();
                                            break;                         
        case gmBattle:                      BattleAI();
                                            BattleMode();
                                            Draw3DFrame();
                                            break;
        case gmTransitionBattle:            TransitionMode();
                                            Draw3DFrame();
                                            break;
        case gmTransitionRebuild:                 
        case gmTransitionSelectCastle:
        case gmTransitionCannonPlacement:   TransitionMode();
                                            Draw2DFrame();
                                            break;
        case gmGameOver:                    GameOverMode();
                                            Draw2DFrame();
                                            break;
        
    }
    for(int Index = 0; Index < pcMax; Index++){
        DLeftClick[Index] = false;
        DRightClick[Index] = false;
    }
    if(DNextGameMode != DGameMode){
        gdk_draw_pixmap(DPreviousWorkingBufferPixmap, DDrawingContext, DWorkingBufferPixmap, 0, 0, 0, 0, -1, -1);  
        
        if(gmRebuild == DGameMode){
            // Clean up edges
            while(CleanUpWallEdges());   
        }
        if(gmTransitionRebuild == DNextGameMode){
            CheckSurroundedCastles();
        }
    }
    
    if((NULL != DBannerPixmap)&&(DBannerLocation < DCanvasHeight)){
        if(0 > DBannerLocation){
            gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, DPreviousWorkingBufferPixmap, 0, 0, 0, 0, -1, -1);
        }
        else{
            gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, DPreviousWorkingBufferPixmap, 0, DBannerLocation, 0, DBannerLocation, -1, DCanvasHeight - DBannerLocation);
        }
        gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, DBannerPixmap, 0, 0, 0, DBannerLocation, -1, -1);
    }
    if(gmGameOver == DGameMode){
        gint MessageWidth, MessageHeight;
        
        gdk_pixmap_get_size(DMessagePixmap, &MessageWidth, &MessageHeight); 
        gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, DMessagePixmap, 0, 0, (DCanvasWidth/2) - (MessageWidth/2), (DCanvasHeight/2) - (MessageHeight/2), -1, -1);
    }
    DWorkingPixbuf = gdk_pixbuf_get_from_drawable(DWorkingPixbuf, DWorkingBufferPixmap, NULL, 0, 0, 0, 0, -1, -1);
    if(1 < DScaling){
        GdkPixbuf *ScaledPixbuf = gdk_pixbuf_scale_simple(DWorkingPixbuf, DCanvasWidth * DScaling, DCanvasHeight * DScaling, GDK_INTERP_BILINEAR);
        gdk_draw_pixbuf(DDoubleBufferPixmap, DDrawingContext, ScaledPixbuf, 0, 0, 0, 0, -1, -1, GDK_RGB_DITHER_NONE, 0, 0);
        g_object_unref(ScaledPixbuf);
    }
    else{
        gdk_draw_pixbuf(DDoubleBufferPixmap, DDrawingContext, DWorkingPixbuf, 0, 0, 0, 0, -1, -1, GDK_RGB_DITHER_NONE, 0, 0);
    }
    gdk_draw_pixmap(DDrawingArea->window, DDrawingContext, DDoubleBufferPixmap, 0, 0, 0, 0, -1, -1);
    DGameMode = DNextGameMode;
    return TRUE;
}

gboolean CApplicationData::MainWindowDeleteEvent(GtkWidget *widget, GdkEvent *event){
    g_print("Delete event occurred\n");    
    return FALSE;    
}



// Draws the wind options menu.
void CApplicationData::DrawSelectWind(){
    gint TextX, TextY, TextWidth, TextHeight, MaxWidth, MaxHeight;
    gint RequiredWidth, RequiredHeight;
    std::string TempString;
    std::vector< std::string > TempItems = DMenuItems;
    std::stringstream TempStringStream;

    TempString = DMenuTitle;
    DMenuTitle = "GAME SELECTION";
    DMenuItems.clear();
    DrawMenu();
    DMenuTitle = TempString;
    DMenuItems = TempItems;

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);
    DBlackFont.MeasureText("Moderate", MaxWidth, MaxHeight);
    
    RequiredWidth = TextWidth + DBrickTileset.TileWidth()/2; 
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    TextX = DCanvasWidth / 2;
    TextY = RequiredHeight + TextHeight / 2;

    TempString = "WIND TYPE ";   
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    if(2 > DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    
    TempString = "  - ";   
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    if(0 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + MaxWidth;
    switch(DWindType){
        case wtNone:    TempStringStream<<"None";
                        break;
        case wtMild:    TempStringStream<<"Mild";
                        break;
        case wtModerate:TempStringStream<<"Moderate";
                        break;
        case wtErratic: TempStringStream<<"Erratic";
                        break;
    }
    TempString = TempStringStream.str();
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth + ((MaxWidth - TextWidth)/2);
    if(2 > DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + ((MaxWidth - TextWidth)/2);
    TempString = "  +";   
    if(1 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    
    TextY += TextHeight;
    
    TempString = "PLAYER COLOR ";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    TextX -= TextWidth;
    if((2 <= DSelectedMenuItem)&&(4 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TempString = "  - ";   
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    if(2 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + MaxWidth;
    TempStringStream.str("");
    switch(DPlayerColor){
        case pcBlue:   TempStringStream<<"Blue";
                       break;
        case pcRed:    TempStringStream<<"Red";
                       break;
        case pcYellow: TempStringStream<<"Yellow";
                       break;
    }
    TempString = TempStringStream.str();
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth + ((MaxWidth - TextWidth)/2);
    if((2 <= DSelectedMenuItem)&&(4 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + ((MaxWidth - TextWidth)/2);
    TempString = "  +";   
    if(3 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextY += TextHeight;
    
    TempString = "AI DIFFICULTY";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    TextX -= TextWidth;
    if((4 <= DSelectedMenuItem)&&(6 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TempString = "  - ";   
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    if(4 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + MaxWidth;
    TempStringStream.str("");
    switch(DAIDifficulty){
        case aiEasy:   TempStringStream<<"Easy";
                        break;
        case aiNormal: TempStringStream<<"Normal";
                        break;
        case aiHard:   TempStringStream<<"Hard";
                        break;
        case aiInsane: TempStringStream<<"Insane";
                        break;
    }
    TempString = TempStringStream.str();
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth + ((MaxWidth - TextWidth)/2);
    if((4 <= DSelectedMenuItem)&&(6 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + ((MaxWidth - TextWidth)/2);
    TempString = "  +";   
    if(5 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "CONTINUE";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(6 < DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 31.5) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(6 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
}




void CApplicationData::MainWindowDestroy(GtkWidget *widget){
    gtk_main_quit();
}

gboolean CApplicationData::MainWindowKeyPressEvent(GtkWidget *widget, GdkEventKey *event){
    std::string* text = NULL;
    if(DGameMode == gmLoginMenu){
        if(DSelectedMenuItem == 0) {
            text = &DMenuItems[1];
        } else if(DSelectedMenuItem == 2){
            text = &DMenuItems[3];
        }
    }else if(DGameMode == gmNetworkOptions){
        text = &DServerConnectionString;
    }else if(event->keyval == GDK_KEY_F12){
        DPause = !DPause;
    }
    if(text != NULL){
        if(event->keyval == GDK_BackSpace){
            if(text->size() > 0){
                text->resize(text->size() - 1);
            }
        }else if(isprint(event->keyval)){
            *text += event->keyval;
        }
    }else{
        if(('1' == event->keyval)&&(1 != DScaling)){
            DScaling = 1;

            ResizeCanvases();
            DWorkingPixbuf = gdk_pixbuf_get_from_drawable(DWorkingPixbuf, DWorkingBufferPixmap, NULL, 0, 0, 0, 0, -1, -1);
            gdk_draw_pixbuf(DDoubleBufferPixmap, DDrawingContext, DWorkingPixbuf, 0, 0, 0, 0, -1, -1, GDK_RGB_DITHER_NONE, 0, 0);
        }
        else if(('2' == event->keyval)&&(2 != DScaling)){
            DScaling = 2;

            ResizeCanvases();
            DWorkingPixbuf = gdk_pixbuf_get_from_drawable(DWorkingPixbuf, DWorkingBufferPixmap, NULL, 0, 0, 0, 0, -1, -1);
            GdkPixbuf *ScaledPixbuf = gdk_pixbuf_scale_simple(DWorkingPixbuf, DCanvasWidth * DScaling, DCanvasHeight * DScaling, GDK_INTERP_BILINEAR);
            gdk_draw_pixbuf(DDoubleBufferPixmap, DDrawingContext, ScaledPixbuf, 0, 0, 0, 0, -1, -1, GDK_RGB_DITHER_NONE, 0, 0);
            g_object_unref(ScaledPixbuf);
        }
    }
    return TRUE;
}

/**
 * Redraws window after refocusing on it.
 * If another window is placed on top of the game window, this redraws that game window.
 *
 * @param widget GTK Widget object
 * @param event Event object to indicate location of redrawing
 * @return Boolean changed to false to indicate it has finished drawing
 */
gboolean CApplicationData::DrawingAreaExpose(GtkWidget *widget, GdkEventExpose *event){
    gdk_draw_pixmap(widget->window, widget->style->fg_gc[gtk_widget_get_state (widget)], DDoubleBufferPixmap, event->area.x, event->area.y, event->area.x, event->area.y, event->area.width, event->area.height);
    return FALSE;
}

/**
 * Checks if a mouse button is clicked, and sets DRightClick for player and pcNone to true.
 *
 * @param widget GTK Widget object
 * @param event Button object to indicate when clicked
 * @return Boolean changed to true
 */
gboolean CApplicationData::DrawingAreaButtonPressEvent(GtkWidget *widget, GdkEventButton *event){
    if(1 == event->button){
        if(GDK_CONTROL_MASK & event->state){
            DRightClick[pcNone] = DRightClick[DPlayerColor] = true;
        }
        else{
            DLeftClick[pcNone] = DLeftClick[DPlayerColor] = true;   
        }
    }
    if(3 == event->button){
        DRightClick[pcNone] = DRightClick[DPlayerColor] = true;
    }
    return TRUE;
}

/**
 * Checks if the window is moved, and sets the events to scale properly for drawing.
 *
 * @param widget GTK Widget object
 * @param event Event of motion object
 * @return Boolean changed to true
 */
gboolean CApplicationData::DrawingAreaMotionNotifyEvent(GtkWidget *widget, GdkEventMotion *event){
    int EventX, EventY;
    EventX = event->x;
    EventY = event->y;
    if(EventX > DCanvasWidth * DScaling){
        EventX = DCanvasWidth * DScaling - 1;
    }
    if(0 > EventX){
        EventX = 0;   
    }
    if(EventY > DCanvasHeight * DScaling){
        EventY = DCanvasHeight * DScaling - 1;
    }
    if(0 > EventY){
        EventY = 0;   
    }

    DCurrentX[pcNone] = DCurrentX[DPlayerColor] = EventX/DScaling;
    DCurrentY[pcNone] = DCurrentY[DPlayerColor] = EventY/DScaling;    
    return TRUE;
}


// Draws the main menu.

void CApplicationData::DrawMenu(){
    gint TotalTextHeight, TextX, TextY, TextWidth, TextHeight;
    gint RequiredWidth, RequiredHeight;

    DrawMenuBackground(DWorkingBufferPixmap, DCanvasWidth, DCanvasHeight);

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);

    RequiredWidth = TextWidth + (DBrickTileset.TileWidth() * 3) / 2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    for(gint TopPosition = 0, XOffset = (DCanvasWidth/2) - (RequiredWidth/2) - 1; TopPosition + D2DWallFloorTileset.TileHeight() <= RequiredHeight; TopPosition += D2DWallFloorTileset.TileHeight()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset, TopPosition, D2DFloorIndices[pcNone]);
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset + RequiredWidth + 2 - D2DWallFloorTileset.TileWidth(), TopPosition, D2DFloorIndices[pcNone]);
    }
    for(gint LeftPosition = (DCanvasWidth/2) - (RequiredWidth/2) - 1, YOffset = RequiredHeight - D2DWallFloorTileset.TileHeight() + 1; LeftPosition + D2DWallFloorTileset.TileWidth() <= (DCanvasWidth/2) + (RequiredWidth/2) + 1; LeftPosition += D2DWallFloorTileset.TileWidth()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, LeftPosition, YOffset, D2DFloorIndices[pcNone]);
    }
    D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (DCanvasWidth/2) + (RequiredWidth/2) + 1 - D2DWallFloorTileset.TileWidth(), RequiredHeight - D2DWallFloorTileset.TileHeight() + 1, D2DFloorIndices[pcNone]);

    DrawBrickFrame(DWorkingBufferPixmap, (DCanvasWidth/2) - (RequiredWidth/2), 0, RequiredWidth, RequiredHeight);
    TextX = (DCanvasWidth/2) - (TextWidth/2);
    TextY = (RequiredHeight/2) - (TextHeight/2);
    DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuTitle);
    DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuTitle);

    TotalTextHeight = DMenuItems.size() * DBlackFont.TileHeight() + (DMenuItems.size() - 1) * DBlackFont.TileHeight() / 2;
    TextY = RequiredHeight + ((DCanvasHeight - RequiredHeight)/2) - (TotalTextHeight/2);
    for(int Index = 0; Index < DMenuItems.size(); Index++){
        gint TextHeight, TextWidth;

        DBlackFont.MeasureText(DMenuItems[Index], TextWidth, TextHeight);
        TextX = (DCanvasWidth/2) - (TextWidth/2);
        if(DSelectedMenuItem == Index){
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuItems[Index]);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuItems[Index]);
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuItems[Index]);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuItems[Index]);
        }
        TextY += TextHeight + TextHeight/2;
    }

}


// Draws the login menu

void CApplicationData::DrawLoginMenu(){
    gint TotalTextHeight, TextX, TextY, TextWidth, TextHeight;
    gint RequiredWidth, RequiredHeight;

    DrawMenuBackground(DWorkingBufferPixmap, DCanvasWidth, DCanvasHeight);

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);

    RequiredWidth = TextWidth + (DBrickTileset.TileWidth() * 3) / 2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    for(gint TopPosition = 0, XOffset = (DCanvasWidth/2) - (RequiredWidth/2) - 1; TopPosition + D2DWallFloorTileset.TileHeight() <= RequiredHeight; TopPosition += D2DWallFloorTileset.TileHeight()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset, TopPosition, D2DFloorIndices[pcNone]);
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset + RequiredWidth + 2 - D2DWallFloorTileset.TileWidth(), TopPosition, D2DFloorIndices[pcNone]);
    }
    for(gint LeftPosition = (DCanvasWidth/2) - (RequiredWidth/2) - 1, YOffset = RequiredHeight - D2DWallFloorTileset.TileHeight() + 1; LeftPosition + D2DWallFloorTileset.TileWidth() <= (DCanvasWidth/2) + (RequiredWidth/2) + 1; LeftPosition += D2DWallFloorTileset.TileWidth()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, LeftPosition, YOffset, D2DFloorIndices[pcNone]);
    }
    D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (DCanvasWidth/2) + (RequiredWidth/2) + 1 - D2DWallFloorTileset.TileWidth(), RequiredHeight - D2DWallFloorTileset.TileHeight() + 1, D2DFloorIndices[pcNone]);

    DrawBrickFrame(DWorkingBufferPixmap, (DCanvasWidth/2) - (RequiredWidth/2), 0, RequiredWidth, RequiredHeight);
    TextX = (DCanvasWidth/2) - (TextWidth/2);
    TextY = (RequiredHeight/2) - (TextHeight/2);
    DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuTitle);
    DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuTitle);

    TotalTextHeight = DMenuItems.size() * DBlackFont.TileHeight() + (DMenuItems.size() - 1) * DBlackFont.TileHeight() / 2;
    TextY = RequiredHeight + ((DCanvasHeight - RequiredHeight)/2) - (TotalTextHeight/2);
    for(int Index = 0; Index < DMenuItems.size(); Index++){
        gint TextHeight, TextWidth;

        std::string Text;
        if(Index == 3) {
            for(int i = 0; i < DMenuItems[3].size(); i++){
                Text.push_back('*');
            }
        }else{
            Text = DMenuItems[Index];
        }

        DBlackFont.MeasureText(Text, TextWidth, TextHeight);
        TextX = (DCanvasWidth/2) - (TextWidth/2);
        if(DSelectedMenuItem == Index
                && DSelectedMenuItem != 1
                && DSelectedMenuItem != 3){
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        TextY += TextHeight + TextHeight/2;
    }


    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    std::string TempString = "LOG IN";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(DSelectedMenuItem == DMenuItems.size() - 1){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextX = (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextY -= TextHeight;
    if(DSelectedMenuItem >= DMenuItems.size()){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

}

void CApplicationData::DrawMultiplayerMenu(){
    gint TotalTextHeight, TextX, TextY, TextWidth, TextHeight;
    gint RequiredWidth, RequiredHeight;

    DrawMenuBackground(DWorkingBufferPixmap, DCanvasWidth, DCanvasHeight);

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);

    RequiredWidth = TextWidth + (DBrickTileset.TileWidth() * 3) / 2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    for(gint TopPosition = 0, XOffset = (DCanvasWidth/2) - (RequiredWidth/2) - 1; TopPosition + D2DWallFloorTileset.TileHeight() <= RequiredHeight; TopPosition += D2DWallFloorTileset.TileHeight()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset, TopPosition, D2DFloorIndices[pcNone]);
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset + RequiredWidth + 2 - D2DWallFloorTileset.TileWidth(), TopPosition, D2DFloorIndices[pcNone]);
    }
    for(gint LeftPosition = (DCanvasWidth/2) - (RequiredWidth/2) - 1, YOffset = RequiredHeight - D2DWallFloorTileset.TileHeight() + 1; LeftPosition + D2DWallFloorTileset.TileWidth() <= (DCanvasWidth/2) + (RequiredWidth/2) + 1; LeftPosition += D2DWallFloorTileset.TileWidth()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, LeftPosition, YOffset, D2DFloorIndices[pcNone]);
    }
    D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (DCanvasWidth/2) + (RequiredWidth/2) + 1 - D2DWallFloorTileset.TileWidth(), RequiredHeight - D2DWallFloorTileset.TileHeight() + 1, D2DFloorIndices[pcNone]);

    DrawBrickFrame(DWorkingBufferPixmap, (DCanvasWidth/2) - (RequiredWidth/2), 0, RequiredWidth, RequiredHeight);
    TextX = (DCanvasWidth/2) - (TextWidth/2);
    TextY = (RequiredHeight/2) - (TextHeight/2);
    DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuTitle);
    DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuTitle);

    TotalTextHeight = DRoomsAvailable.size() * DBlackFont.TileHeight() + (DRoomsAvailable.size() - 1) * DBlackFont.TileHeight() / 2;
    TextY = RequiredHeight + ((DCanvasHeight - RequiredHeight)/2) - (TotalTextHeight/2);
    for(int Index = 0; Index < DRoomsAvailable.size(); Index++){
        gint TextHeight, TextWidth;

        std::string Text;
        Text = DRoomsAvailable.at(Index).Name();

        DBlackFont.MeasureText(Text, TextWidth, TextHeight);
        TextX = (DCanvasWidth/2) - (TextWidth/2);
        if(DSelectedMenuItem == Index){
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        TextY += TextHeight + TextHeight/2;
    }


    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    std::string TempString = "CREATE GAME";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(DSelectedMenuItem == DRoomsAvailable.size()){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextX = (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextY -= TextHeight;
    if(DSelectedMenuItem > DRoomsAvailable.size()){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

}
void CApplicationData::DrawRoom(){
    gint TotalTextHeight, TextX, TextY, TextWidth, TextHeight;
    gint RequiredWidth, RequiredHeight;

    DrawMenuBackground(DWorkingBufferPixmap, DCanvasWidth, DCanvasHeight);

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);

    RequiredWidth = TextWidth + (DBrickTileset.TileWidth() * 3) / 2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    for(gint TopPosition = 0, XOffset = (DCanvasWidth/2) - (RequiredWidth/2) - 1; TopPosition + D2DWallFloorTileset.TileHeight() <= RequiredHeight; TopPosition += D2DWallFloorTileset.TileHeight()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset, TopPosition, D2DFloorIndices[pcNone]);
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XOffset + RequiredWidth + 2 - D2DWallFloorTileset.TileWidth(), TopPosition, D2DFloorIndices[pcNone]);
    }
    for(gint LeftPosition = (DCanvasWidth/2) - (RequiredWidth/2) - 1, YOffset = RequiredHeight - D2DWallFloorTileset.TileHeight() + 1; LeftPosition + D2DWallFloorTileset.TileWidth() <= (DCanvasWidth/2) + (RequiredWidth/2) + 1; LeftPosition += D2DWallFloorTileset.TileWidth()){
        D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, LeftPosition, YOffset, D2DFloorIndices[pcNone]);
    }
    D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (DCanvasWidth/2) + (RequiredWidth/2) + 1 - D2DWallFloorTileset.TileWidth(), RequiredHeight - D2DWallFloorTileset.TileHeight() + 1, D2DFloorIndices[pcNone]);

    DrawBrickFrame(DWorkingBufferPixmap, (DCanvasWidth/2) - (RequiredWidth/2), 0, RequiredWidth, RequiredHeight);
    TextX = (DCanvasWidth/2) - (TextWidth/2);
    TextY = (RequiredHeight/2) - (TextHeight/2);
    DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DMenuTitle);
    DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DMenuTitle);

    TotalTextHeight = DPlayers.size() * DBlackFont.TileHeight() + (DPlayers.size() - 1) * DBlackFont.TileHeight() / 2;
    TextY = RequiredHeight + ((DCanvasHeight - RequiredHeight)/2) - (TotalTextHeight/2);
    for(int Index = 0; Index < DPlayers.size(); Index++){
        gint TextHeight, TextWidth;

        std::string Text;
        Text = DPlayers.at(Index);

        DBlackFont.MeasureText(Text, TextWidth, TextHeight);
        TextX = (DCanvasWidth/2) - (TextWidth/2);
        if(DSelectedMenuItem == Index){
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, Text);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, Text);
        }
        TextY += TextHeight + TextHeight/2;
    }

    std::string TempString = "START GAME";
    if(DIsRoomOwner){
        TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
        TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
        DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
        TextX -= TextWidth;
        TextY -= TextHeight;
        if(DSelectedMenuItem == DPlayers.size()){
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
        }
    }

    TextX = (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextY -= TextHeight;
    if(DSelectedMenuItem > DPlayers.size()){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

}

// Draws the sound options menu.

void CApplicationData::DrawSoundOptions(){
    gint TextX, TextY, TextWidth, TextHeight, MaxWidth, MaxHeight;
    gint RequiredWidth, RequiredHeight;
    std::string TempString;
    std::vector< std::string > TempItems = DMenuItems;
    std::stringstream TempStringStream;

    TempString = DMenuTitle;
    DMenuTitle = "SOUND OPTIONS";
    DMenuItems.clear();
    DrawMenu();
    DMenuTitle = TempString;
    DMenuItems = TempItems;

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);
    DBlackFont.MeasureText("100%", MaxWidth, MaxHeight);

    RequiredWidth = TextWidth + DBrickTileset.TileWidth()/2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    TextX = DCanvasWidth / 2;
    TextY = RequiredHeight + TextHeight / 2;

    TempString = "SOUND FX ";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    if(2 > DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TempString = "  - ";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    if(0 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + MaxWidth;
    TempStringStream<<(int)round(100.0 * DSoundEffectVolume)<<"%";
    TempString = TempStringStream.str();
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    if(2 > DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth;
    TempString = "  +";
    if(1 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextY += TextHeight;

    TempString = "MUSIC ";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    TextX -= TextWidth;
    if((2 <= DSelectedMenuItem)&&(4 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TempString = "  - ";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX = DCanvasWidth / 2;
    if(2 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth + MaxWidth;
    TempStringStream.str("");
    TempStringStream<<(int)round(100.0 * DMusicVolume)<<"%";
    TempString = TempStringStream.str();
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    if((2 <= DSelectedMenuItem)&&(4 > DSelectedMenuItem)){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextX += TextWidth;
    TempString = "  +";
    if(3 == DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }

    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(4 <= DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
}


// Draws the network options menu.

void CApplicationData::DrawNetworkOptions(){
    gint TextX, TextY, TextWidth, TextHeight, MaxWidth, MaxHeight;
    gint RequiredWidth, RequiredHeight;
    std::string TempString;
    std::vector< std::string > TempItems = DMenuItems;

    TempString = DMenuTitle;
    DMenuTitle = "NETWORK OPTIONS";
    DMenuItems.clear();
    DrawMenu();
    DMenuTitle = TempString;
    DMenuItems = TempItems;

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);
    DBlackFont.MeasureText("100%", MaxWidth, MaxHeight);

    RequiredWidth = TextWidth + DBrickTileset.TileWidth()/2;
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    TextX = DCanvasWidth / 2;
    TextY = RequiredHeight + TextHeight / 2;

    TempString = "SERVER";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth/2;
    if(2 > DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    TextY += TextHeight;

    DBlackFont.MeasureText(DServerConnectionString, TextWidth, TextHeight);
    TextX = (DCanvasWidth/2) - (TextWidth/2);

    DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, DServerConnectionString);
    DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, DServerConnectionString);

    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(4 <= DSelectedMenuItem){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
}


// Draws the map selection menu.

void CApplicationData::DrawSelectMap(){
    gint TextX, TextY, TextWidth, TextHeight;
    gint RequiredWidth, RequiredHeight;
    gint MiniX, MiniY;
    std::string TempString;
    std::vector< std::string > TempItems = DMenuItems;

    TempString = DMenuTitle;
    DMenuTitle = "SELECT MAP";
    DMenuItems.clear();
    DrawMenu();
    DMenuTitle = TempString;
    DMenuItems = TempItems;

    DBlackFont.MeasureText(DMenuTitle, TextWidth, TextHeight);
    
    RequiredWidth = TextWidth + DBrickTileset.TileWidth()/2; 
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1)/DBrickTileset.TileWidth()) * DBrickTileset.TileWidth();
    RequiredHeight = TextHeight + 1;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();

    TextX = (DBrickTileset.TileWidth() * 3) / 2;
    TextY = RequiredHeight + TextHeight / 2;
    MiniY = TextY;
    for(int Index = 0; Index < DTerrainMaps.size(); Index++){
        TempString = DTerrainMaps[Index].MapName();
        
        DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
        if(DSelectedMenuItem == Index){
            std::stringstream TempStringStream;
            gint InfoWidth, InfoHeight;
            
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
            MiniX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
            MiniX -= DTerrainMaps[Index].Width() * 2;
            DTerrainMaps[Index].DrawPreviewMap(DWorkingBufferPixmap, DDrawingContext, MiniX, MiniY);
            
            MiniX += DTerrainMaps[Index].Width();
            MiniY += DTerrainMaps[Index].Height() * 2 + TextHeight/2;
            
            TempStringStream<<DTerrainMaps[Index].PlayerCount()<<" PLAYERS";
            DBlackFont.MeasureText(TempStringStream.str(), InfoWidth, InfoHeight);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, MiniX-(InfoWidth/2) + 1, MiniY + 1, TempStringStream.str());
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, MiniX-(InfoWidth/2), MiniY, TempStringStream.str());
            MiniY += InfoHeight + 2;
            TempStringStream.str("");
            TempStringStream<<DTerrainMaps[Index].Width()<<" x "<<DTerrainMaps[Index].Height();
            DBlackFont.MeasureText(TempStringStream.str(), InfoWidth, InfoHeight);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, MiniX-(InfoWidth/2) + 1, MiniY + 1, TempStringStream.str());
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, MiniX-(InfoWidth/2), MiniY, TempStringStream.str());
            
        }
        else{
            DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
            DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);            
        }
        TextY += TextHeight + TextHeight/2;
    }
    TextX = DCanvasWidth - (DBrickTileset.TileWidth() * 3) / 2;
    TextY = DCanvasHeight - (DBrickTileset.TileHeight() * 3) / 2;
    TempString = "BACK";
    DBlackFont.MeasureText(TempString, TextWidth, TextHeight);
    TextX -= TextWidth;
    TextY -= TextHeight;
    if(DSelectedMenuItem >= DTerrainMaps.size()){
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
    else{
        DWhiteFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX + 1, TextY + 1, TempString);
        DBlackFont.DrawText(DWorkingBufferPixmap, DDrawingContext, TextX, TextY, TempString);
    }
}


// Draws a 2D frame on the screen.
void CApplicationData::Draw2DFrame(){
    
    gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, D2DTerrainPixmap, 0, 0, 0, 0, -1, -1);


    for(int YIndex = 0, YPos = 0; YIndex < DConstructionTiles.size(); YIndex++, YPos += DTileHeight){
        for(int XIndex = 0, XPos = 0; XIndex < DConstructionTiles[YIndex].size(); XIndex++, XPos+= DTileWidth){
            bool IsEven = ((YIndex + XIndex) & 0x1) ? false : true;
            int WallType = 0xF;
            if(TileTypeIsWall(DConstructionTiles[YIndex][XIndex])){
                if(YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex]))){
                    WallType &= 0xE;
                }
                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex][XIndex+1]))){
                    WallType &= 0xD;
                }
                if((YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex]))){
                    WallType &= 0xB;
                }
                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex][XIndex-1]))){
                    WallType &= 0x7;
                }
            }
            
            switch(DConstructionTiles[YIndex][XIndex]){
                case cttBlueWall:           D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D2DWallIndices[pcBlue] + WallType);
                                            break;
                case cttRedWall:            D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D2DWallIndices[pcRed] + WallType);
                                            break;
                case cttYellowWall:         D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D2DWallIndices[pcYellow] + WallType);
                                            break;
                case cttBlueFloor:          
                case cttBlueFloorDamaged:   D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, IsEven ? D2DFloorIndices[pcNone] : D2DFloorIndices[pcBlue]);
                                            break;
                case cttRedFloor:
                case cttRedFloorDamaged:    D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, IsEven ? D2DFloorIndices[pcNone] : D2DFloorIndices[pcRed]);
                                            break;
                case cttYellowFloor:    
                case cttYellowFloorDamaged: D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, IsEven ? D2DFloorIndices[pcNone] : D2DFloorIndices[pcYellow]);
                                            break;
                default:                break;
            }
            if(TileTypeIsFloorGroundDamaged(DConstructionTiles[YIndex][XIndex])){
                D2DTerrainTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D2DDamagedGroundIndex);
            }
        }
    }
    for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
        std::vector< bool >::iterator SurroundedIterator;
        std::vector< SMapLocation >::iterator LocationIterator;
        
        SurroundedIterator = DSurroundedCastles[ColorIndex].begin();
        LocationIterator = DCastleLocations[ColorIndex].begin();
        while(DSurroundedCastles[ColorIndex].end() != SurroundedIterator){
            int XPos, YPos;
            XPos = LocationIterator->DXIndex;
            YPos = LocationIterator->DYIndex;
            if(*SurroundedIterator){
                int SelectColorIndex = 0;
                
                SelectColorIndex = D2DSelectColorIndices[ColorIndex];  
                D2DCastleCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos * DTileWidth, YPos * DTileHeight, D2DCastleIndices[ColorIndex]);
                if((gmSelectCastle == DGameMode)&&(!DCompletedStage[ColorIndex])&&(DGameMode == DNextGameMode)){
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos * DTileWidth, (YPos - 1) * DTileHeight, SelectColorIndex);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 1) * DTileWidth, (YPos - 1) * DTileHeight, SelectColorIndex);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 2) * DTileWidth, (YPos - 1) * DTileHeight, SelectColorIndex + 1);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 2) * DTileWidth, YPos * DTileHeight, SelectColorIndex + 2);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 2) * DTileWidth, (YPos + 1) * DTileHeight, SelectColorIndex + 2);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 2) * DTileWidth, (YPos + 2) * DTileHeight, SelectColorIndex + 3);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos + 1) * DTileWidth, (YPos + 2) * DTileHeight, SelectColorIndex + 4);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos * DTileWidth, (YPos + 2) * DTileHeight, SelectColorIndex + 4);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos - 1) * DTileWidth, (YPos + 2) * DTileHeight, SelectColorIndex + 5);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos - 1) * DTileWidth, (YPos + 1) * DTileHeight, SelectColorIndex + 6);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos - 1) * DTileWidth, YPos * DTileHeight, SelectColorIndex + 6);
                    D2DCastleSelectTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XPos - 1) * DTileWidth, (YPos - 1) * DTileHeight, SelectColorIndex + 7);
                }
            }
            else{
                D2DCastleCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos * DTileWidth, YPos * DTileHeight, D2DCastleIndices[pcNone]);
            }
            SurroundedIterator++;
            LocationIterator++;
        }
    }


    //For each active player, draws cannons which that player has placed.
    for(int Index = pcBlue; Index < pcMax; Index++){
        std::vector< SMapLocation >::iterator Iterator = DCannonLocations[Index].begin();
        
        while(DCannonLocations[Index].end() != Iterator){
            D2DCastleCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, Iterator->DXIndex * DTileWidth, Iterator->DYIndex * DTileHeight, D2DCannonIndices[pcNone]);
            Iterator++;
        }
    }

    /**
     * If the current game mode is Cannon placement, then for each player draw cannons
     * which that player has just placed.
     */
    if(gmCannonPlacement == DGameMode){
        for(int Index = pcBlue; Index < pcBlue + DPlayerCount; Index++){
            if((DCannonsToPlace[Index])&&(DGameMode == DNextGameMode)){
                int XTile, YTile;
                XTile = DCurrentX[Index] / DTileWidth;
                YTile = DCurrentY[Index] / DTileHeight;
                D2DCastleCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XTile * DTileWidth, YTile * DTileHeight, D2DCannonIndices[Index] + DCannonsToPlace[Index] - 1);
            }
        }
    }

    //If the current game mode is Rebuild, then draw tile currently held by each player.
    else if(gmRebuild == DGameMode){
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            if((!DCompletedStage[ColorIndex])&&(DGameMode == DNextGameMode)){
                int XTile, YTile;
                int WallIndexEven, WallIndexOdd;
                
                XTile = DCurrentX[ColorIndex] / DTileWidth;
                YTile = DCurrentY[ColorIndex] / DTileHeight;
                if(XTile + DWallShape[ColorIndex].Width() >= DMapWidth){
                    XTile = DMapWidth - DWallShape[ColorIndex].Width();
                }
                if(YTile + DWallShape[ColorIndex].Height() >= DMapHeight){
                    YTile = DMapHeight - DWallShape[ColorIndex].Height();
                }
                if(DCanPlaceWallCannon[ColorIndex]){
                    struct timeval CurrentTime;
                    
                    gettimeofday(&CurrentTime, NULL);
                    if(CurrentTime.tv_usec < 500000){               //Appears useless, never true.
                        WallIndexEven = D2DWallIndices[pcMax]; 
                        WallIndexOdd = D2DWallIndices[pcMax + 1];
                    }
                    else{
                        WallIndexEven = D2DWallIndices[pcMax + 1];
                        WallIndexOdd = D2DWallIndices[pcMax];
                    }
                }
                else{
                    WallIndexEven = WallIndexOdd = D2DWallIndices[pcNone];       
                }

                //Determine whether there is a block at the given position.
                for(int WallYPos = 0; WallYPos < DWallShape[ColorIndex].Height(); WallYPos++){
                    for(int WallXPos = 0; WallXPos < DWallShape[ColorIndex].Width(); WallXPos++){
                        if(DWallShape[ColorIndex].IsBlock(WallXPos, WallYPos)){
                            int WallType = 0xF;
                            bool IsEven = (WallYPos + WallXPos) & 0x1 ? false : true;
                            
                            if(WallYPos && DWallShape[ColorIndex].IsBlock(WallXPos, WallYPos-1)){
                                WallType &= 0xE;
                            }
                            if((WallXPos + 1 < DWallShape[ColorIndex].Width()) && DWallShape[ColorIndex].IsBlock(WallXPos+1, WallYPos)){
                                WallType &= 0xD;
                            }
                            if((WallYPos + 1 < DWallShape[ColorIndex].Height()) && DWallShape[ColorIndex].IsBlock(WallXPos, WallYPos+1)){
                                WallType &= 0xB;
                            }
                            if(WallXPos && DWallShape[ColorIndex].IsBlock(WallXPos-1, WallYPos)){
                                WallType &= 0x7;
                            }
                            D2DWallFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (XTile + WallXPos) * DTileWidth, (YTile + WallYPos) * DTileHeight, (IsEven ? WallIndexEven : WallIndexOdd) + WallType);
                        }
                    }
                }
            }
        }
    }

    /**
     * If the current game mode is either cannon placement or rebuild, determine if there is time left,
     * and, if so, update the counter display.
     */
    if((gmCannonPlacement == DGameMode)||(gmRebuild == DGameMode)){
        int SecondsLeft = SecondsUntilDeadline(DCurrentStageTimeout);
        
        if(0 > SecondsLeft){
            SecondsLeft = 0;    
        }
        DDigitTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, 0, 0, (SecondsLeft/10) % 10);
        DDigitTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, DDigitTileset.TileWidth(), 0, SecondsLeft % 10);    
    }
} 

/**
 * @brief CApplicationData::Draw3DFrame
 * No parameters, draws frames during combat phase.
 */
void CApplicationData::Draw3DFrame(){
    std::vector< SMapLocation >::iterator CannonPositions[pcMax];
    std::vector< SMapLocation >::iterator CastlePositions[pcMax];
    std::vector< bool >::iterator CastleSurroundedPositions[pcMax];      
    std::list< SSpriteState >::iterator ExplosionPosition;
    std::list< SSpriteState >::iterator BurnPosition;
    std::list< SSpriteState >::iterator PlumePosition;
    int CurrentAnimationTimestep = (DAnimationTimestep/4) % ANIMATION_TIMESTEPS;

        
    //Sets cannons to draw
    for(int Index = 0; Index < pcMax; Index++){
        CannonPositions[Index] = DCannonLocations[Index].begin();
    }

    //Sets castles to draw
    for(int Index = 0; Index < pcMax; Index++){
        CastlePositions[Index] = DCastleLocations[Index].begin();
        CastleSurroundedPositions[Index] = DSurroundedCastles[Index].begin();
    }    

    //Sets Explosions/Flames/Smoke to draw
    ExplosionPosition = DExplosionStates.begin();
    BurnPosition = DBurnStates.begin();
    PlumePosition = DPlumeStates.begin();
    
    //Draws frame
    gdk_draw_pixmap(DWorkingBufferPixmap, DDrawingContext, D3DTerrainPixmaps[CurrentAnimationTimestep], 0, 0, 0, 0, -1, -1);
    
    /**
     * For each tile, check whether tile should be a wall or floor, and if they are damaged,
     * then draw that tile.
     */
    for(int YIndex = 0, YPos = 0; YIndex < DConstructionTiles.size(); YIndex++, YPos += DTileHeight){
        for(int XIndex = 0, XPos = 0; XIndex < DConstructionTiles[YIndex].size(); XIndex++, XPos += DTileWidth){
            switch(DConstructionTiles[YIndex][XIndex]){
                case cttBlueWall:
                case cttBlueWallDamaged:
                case cttRedWall:
                case cttRedWallDamaged:
                case cttYellowWall:
                case cttYellowWallDamaged:  if(YIndex + 1 < DConstructionTiles.size()){
                                                if(!TileTypeIsFloor(DConstructionTiles[YIndex+1][XIndex])){
                                                    break;
                                                }
                                            }
                                            else{
                                                break;   
                                            }
                case cttBlueFloor:
                case cttBlueFloorDamaged:
                case cttRedFloor:       
                case cttRedFloorDamaged:
                case cttYellowFloor:
                case cttYellowFloorDamaged: D3DFloorTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DFloorIndices[DTerrainMap.TileType(XIndex, YIndex)]);
                                        break;
                default:                break;
            }
        }
    }
    /**
     * For each tile, determine WallType, and WallOffset, and call appropriate draw function, if
     * the tile is not part of a fortress/castle, then draw the appropriate tile, i.e. grass/water/
     * smoke, etc.
     * Uncertain of reason previous loop pair also needed.
     */
    for(int YIndex = 0, YPos = -DTileHeight; YIndex < DConstructionTiles.size(); YIndex++, YPos += DTileHeight){
        for(int XIndex = 0, XPos = 0; XIndex < DConstructionTiles[YIndex].size(); XIndex++, XPos += DTileWidth){
            int WallType = 0xF;
            int WallOffset = 0x0;
            if(TileTypeIsWall(DConstructionTiles[YIndex][XIndex])){
                if(YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex]))){
                    WallType &= 0xE;
                }
                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex][XIndex+1]))){
                    WallType &= 0xD;
                }
                if((YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex]))){
                    WallType &= 0xB;
                }
                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex][XIndex-1]))){
                    WallType &= 0x7;
                }
                switch(WallType){
                    case 0: WallOffset = 0xF;
                            if(YIndex){
                                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex+1]))){
                                    WallOffset &= 0xE;   
                                }
                                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex-1]))){
                                    WallOffset &= 0x7;
                                }
                            }
                            if(YIndex + 1 < DConstructionTiles.size()){
                                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex+1]))){
                                    WallOffset &= 0xD;   
                                }
                                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex-1]))){
                                    WallOffset &= 0xB;
                                } 
                            }
                            break;
                    case 1: WallOffset = 0x3;
                            if(YIndex + 1 < DConstructionTiles.size()){
                                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex+1]))){
                                    WallOffset &= 0x2;   
                                }
                                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex-1]))){
                                    WallOffset &= 0x1;
                                } 
                            }
                            break;
                    case 2: WallOffset = 0x3;
                            if(XIndex){
                                if((YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex-1]))){
                                    WallOffset &= 0x2;   
                                }
                                if(YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex-1]))){
                                    WallOffset &= 0x1;
                                } 
                            }
                            break;
                    case 3: WallOffset = 1;
                            if(XIndex && (YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex-1]))){
                                WallOffset = 0;
                            }
                            break;
                    case 4: WallOffset = 0x3;
                            if(YIndex){
                                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex+1]))){
                                    WallOffset &= 0x2;   
                                }
                                if(XIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex-1]))){
                                    WallOffset &= 0x1;
                                }
                            }
                            break;
                    case 6: WallOffset = 1;
                            if(XIndex && YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex-1]))){
                                WallOffset = 0;
                            }
                            break;
                    case 8: WallOffset = 0x3;
                            if(XIndex + 1 < DConstructionTiles[YIndex].size()){
                                if(YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex+1]))){
                                    WallOffset &= 0x2;
                                }
                                if((YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex+1]))){
                                    WallOffset &= 0x1;   
                                }
                            }
                            break;
                    case 9: WallOffset = 1;
                            if((XIndex + 1 < DConstructionTiles[YIndex].size()) && (YIndex + 1 < DConstructionTiles.size()) && (TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex+1][XIndex+1]))){
                                WallOffset = 0;
                            }
                            break;
                    case 12:WallOffset = 1;
                            if((XIndex + 1 < DConstructionTiles[YIndex].size()) && YIndex && (TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DConstructionTiles[YIndex-1][XIndex+1]))){
                                WallOffset = 0;
                            }
                            break;
                    default:WallOffset = 0;
                            break;
                }
            
                switch(DConstructionTiles[YIndex][XIndex]){
                    case cttBlueWall:       D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DWallIndices[pcBlue][WallType] + WallOffset);
                                            break;
                    case cttRedWall:        D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DWallIndices[pcRed][WallType] + WallOffset);
                                            break;
                    case cttYellowWall:     D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DWallIndices[pcYellow][WallType] + WallOffset);
                                            break;
                    default:                break;
                }
            }
            else if(TileTypeIsWallDamaged(DConstructionTiles[YIndex][XIndex])){
                if(YIndex && TileTypeIsWall(DConstructionTiles[YIndex-1][XIndex])){
                    WallType &= 0xE;
                }
                if((XIndex + 1 < DConstructionTiles[YIndex].size()) && TileTypeIsWall(DConstructionTiles[YIndex][XIndex+1])){
                    WallType &= 0xD;
                }
                if((YIndex + 1 < DConstructionTiles.size()) && TileTypeIsWall(DConstructionTiles[YIndex+1][XIndex])){
                    WallType &= 0xB;
                }
                if(XIndex && TileTypeIsWall(DConstructionTiles[YIndex][XIndex-1])){
                    WallType &= 0x7;
                }
                switch(DConstructionTiles[YIndex][XIndex]){
                    case cttBlueWallDamaged:    D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DDamagedWallIndices[pcBlue]+ WallType);
                                                break;
                    case cttRedWallDamaged:     D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DDamagedWallIndices[pcRed] + WallType);
                                                break;
                    case cttYellowWallDamaged:  D3DWallTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DDamagedWallIndices[pcYellow] + WallType);
                                                break;
                    default:                    break;
                }
            }
            else if(TileTypeIsFloorGroundDamaged(DConstructionTiles[YIndex][XIndex])){
                D3DTerrainTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos + DTileHeight, D3DDamagedGroundIndex);    
            }
            else{
                for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
                    if(DCannonLocations[ColorIndex].end() != CannonPositions[ColorIndex]){
                        if((CannonPositions[ColorIndex]->DXIndex == XIndex)&&(CannonPositions[ColorIndex]->DYIndex == YIndex)){
                            if(TileTypeIsFloor(DConstructionTiles[YIndex][XIndex])){
                                int CenterX, CenterY;
                                int CannonDirection;
                                
                                CenterX = (CannonPositions[ColorIndex]->DXIndex + 1) * DTileWidth;
                                CenterY = (CannonPositions[ColorIndex]->DYIndex + 1) * DTileHeight;
                                CannonDirection = CalculateDirection(CenterX, CenterY, DCurrentX[ColorIndex], DCurrentY[ColorIndex]);
                                
                                D3DCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos + DTileHeight, CannonDirection);
                            }
                            else{
                                D3DCannonTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos + DTileHeight, 4);
                            }
                            CannonPositions[ColorIndex]++;
                        }
                    }
                }
                for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
                    if(DCastleLocations[ColorIndex].end() != CastlePositions[ColorIndex]){
                        if((XIndex == CastlePositions[ColorIndex]->DXIndex)&&(YIndex == CastlePositions[ColorIndex]->DYIndex)){
                            if(*CastleSurroundedPositions[ColorIndex]){
                        
                                if(pcNone == ColorIndex){
                                    D3DCastleTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DCastleIndices[pcNone]);
                                }
                                else{
                                    D3DCastleTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DCastleIndices[ColorIndex] + (DWindDirection * ANIMATION_TIMESTEPS) + CurrentAnimationTimestep);
                                }
                            }
                            else{
                                D3DCastleTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, D3DCastleIndices[pcNone]);
                            }
                            CastleSurroundedPositions[ColorIndex]++;
                            CastlePositions[ColorIndex]++;
                        }
                    }
                }
            }

            //draw next frame of burn animation
            while(BurnPosition != DBurnStates.end()){
                if((BurnPosition->DXIndex == XIndex)&&(BurnPosition->DYIndex == YIndex)){
                    D3DBurnTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos + DTileHeight, BurnPosition->DSpriteIndex + BurnPosition->DStep);   
                    BurnPosition++;    
                }
                else{
                    break;    
                }
            }

            //draw next frame of explosion animation
            while(ExplosionPosition != DExplosionStates.end()){
                if((ExplosionPosition->DXIndex == XIndex)&&(ExplosionPosition->DYIndex == YIndex)){
                    D3DExplosionTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos - DTileWidth/2 + ExplosionPosition->DXOffset, YPos - DTileHeight + ExplosionPosition->DYOffset, ExplosionPosition->DSpriteIndex + ExplosionPosition->DStep);   
                    ExplosionPosition++;    
                }
                else{
                    break;
                }
            }

            //draw next frame of smoke animation
            while(PlumePosition != DPlumeStates.end()){
                if((PlumePosition->DXIndex == XIndex)&&(PlumePosition->DYIndex == YIndex)){
                    D3DCannonPlumeTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos + DTileWidth - D3DCannonPlumeTileset.TileWidth()/2, YPos, PlumePosition->DSpriteIndex + PlumePosition->DStep);   
                    PlumePosition++;    
                }
                else{
                    break;
                }
                   
            }
        }
    }

    //Work through all burns/explosions/plumes
    while((BurnPosition != DBurnStates.end())||(ExplosionPosition != DExplosionStates.end())||(PlumePosition != DPlumeStates.end())){
        if(BurnPosition != DBurnStates.end()){
            D3DBurnTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, BurnPosition->DXIndex * DTileWidth, BurnPosition->DYIndex * DTileHeight, BurnPosition->DSpriteIndex + BurnPosition->DStep);   
            BurnPosition++;
        }
        else if(ExplosionPosition != DExplosionStates.end()){
            D3DExplosionTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, ExplosionPosition->DXIndex * DTileWidth - DTileWidth/2 + ExplosionPosition->DXOffset, (ExplosionPosition->DYIndex - 2) * DTileHeight + ExplosionPosition->DYOffset, ExplosionPosition->DSpriteIndex + ExplosionPosition->DStep);   
            ExplosionPosition++;
        }
        else if(PlumePosition != DPlumeStates.end()){
            D3DCannonPlumeTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, (PlumePosition->DXIndex + 1) * DTileWidth - D3DCannonPlumeTileset.TileWidth()/2, (PlumePosition->DYIndex - 1) * DTileHeight, PlumePosition->DSpriteIndex + PlumePosition->DStep);   
            PlumePosition++; 
        }
    }
    
    //For loop to move each cannonball forward by one frame
    for(std::list< SCannonballTrajectory >::iterator Cannonball = DCannonballTrajectories.begin(); Cannonball != DCannonballTrajectories.end(); Cannonball++){
        int XPos = Cannonball->DXPosition;
        int YPos = Cannonball->DYPosition;
        
        XPos -= D3DCannonballTileset.TileWidth() / 2;
        YPos -= D3DCannonballTileset.TileHeight() / 2;
        YPos -= Cannonball->DZPosition;
        
        D3DCannonballTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, XPos, YPos, CalculateCannonballSize(Cannonball->DZPosition));
    }
    
    //If game mode is battle, draw targeting reticule for each player.
    if((gmBattle == DGameMode)&&(gmBattle == DNextGameMode)){
        for(int Index = pcBlue; Index < pcBlue + DPlayerCount; Index++){
            DTargetTileset.DrawTile(DWorkingBufferPixmap, DDrawingContext, DCurrentX[Index] - DTargetTileset.TileWidth() / 2, DCurrentY[Index] - DTargetTileset.TileHeight() / 2, D3DTargetIndices[Index]);
        }
    }
    
    DAnimationTimestep += DWindSpeed;
}


void CApplicationData::DrawBanner(const std::string &message){
    gint BannerWidth = 0; 
    gint BannerHeight = 0; 
    gint RequiredWidth, RequiredHeight; 
    gint TextRequiredWidth, TextRequiredHeight;
    gint TextX, TextY;
    
    //If pause flag is true, pause until pause key is pressed again.
    if(!DNetworkGame){
        while(DPause){
            gtk_main_iteration_do(false);
        }
    }
    
    DBlackFont.MeasureText(message, TextRequiredWidth, TextRequiredHeight); 
    RequiredHeight = TextRequiredHeight + 1;
    RequiredWidth = DCanvasWidth;
    RequiredHeight += DBrickTileset.TileHeight() * 2;
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight();
    if(NULL != DBannerPixmap){
        gdk_pixmap_get_size(DBannerPixmap, &BannerWidth, &BannerHeight); 
    }
    
    // Creates Bannerpixmap if banner's dimensions don't mix
    if((BannerWidth != RequiredWidth)||(BannerHeight != RequiredHeight)){
        if(NULL != DBannerPixmap){
             g_object_unref(DBannerPixmap);
        }
        DBannerPixmap = gdk_pixmap_new(DDrawingArea->window, RequiredWidth, RequiredHeight, -1);
    }

    DrawTextFrame(DBannerPixmap, RequiredWidth, RequiredHeight); // Draws text frame 
    TextX = (DCanvasWidth / 2) - (TextRequiredWidth / 2); // Determines textX 
    TextY = (RequiredHeight / 2) - (TextRequiredHeight / 2); // Determines textY 
    DBlackFont.DrawText(DBannerPixmap, DDrawingContext, TextX + 1, TextY + 1, message); // Draws text in black font 
    DWhiteFont.DrawText(DBannerPixmap, DDrawingContext, TextX, TextY, message); // Draws text in white font 
}

// Draws message 
void CApplicationData::DrawMessage(const std::string &message){
    gint MessageWidth = 0; // Message's width 
    gint MessageHeight = 0; // Message's height 
    gint RequiredWidth, RequiredHeight; // Required height and weight 
    gint TextRequiredWidth = 0, TextRequiredHeight = 0; // Required width for text and height for text 
    gint TextX, TextY; // Text x and text y 
    std::list< std::string > Lines; // String of lines 
    std::size_t Anchor = 0; // Sets Anchor to 0 
    
    // Uses while loop to draw message while pushing back each letter
    while(Anchor < message.length()){
        std::size_t NewPos = message.find("\n",Anchor);
        if(std::string::npos == NewPos){
            Lines.push_back(message.substr(Anchor));
            Anchor = message.length();
        }
        else{
            Lines.push_back(message.substr(Anchor, NewPos - Anchor));
            Anchor = NewPos + 1;
        }
    }
    
    // For loop ensures the required width/height of text of current line  
    for(std::list< std::string >::iterator CurLine = Lines.begin(); CurLine != Lines.end(); CurLine++){
        gint LineHeight, LineWidth;
        DBlackFont.MeasureText(*CurLine, LineWidth, LineHeight); 
        if(TextRequiredWidth < LineWidth){
            TextRequiredWidth = LineWidth;
        }
        TextRequiredHeight += LineHeight + 2;
    }
    
    RequiredWidth = TextRequiredWidth + 1; // Required width 
    RequiredWidth += DBrickTileset.TileWidth(); // Add brick tile width to req width 
    RequiredWidth = ((RequiredWidth + DBrickTileset.TileWidth() - 1) / DBrickTileset.TileWidth()) * DBrickTileset.TileWidth(); // Sets the required width 
    RequiredHeight = TextRequiredHeight; // Required height 
    RequiredHeight += DBrickTileset.TileHeight() * 2; // Add brick tile height to req height 
    RequiredHeight = ((RequiredHeight + DBrickTileset.TileHeight() - 1) / DBrickTileset.TileHeight()) * DBrickTileset.TileHeight(); // Sets required height
    
    // Instantiates a messagepixmap
    if(NULL != DMessagePixmap){
        gdk_pixmap_get_size(DMessagePixmap, &MessageWidth, &MessageHeight); 
    }
    if((MessageWidth != RequiredWidth)||(MessageHeight != RequiredHeight)){
        if(NULL != DMessagePixmap){
             g_object_unref(DMessagePixmap);
        }
        DMessagePixmap = gdk_pixmap_new(DDrawingArea->window, RequiredWidth, RequiredHeight, -1);
    }
    
    DrawTextFrame(DMessagePixmap, RequiredWidth, RequiredHeight); // Draws text frame 
    TextY = DBrickTileset.TileHeight() + 1; // Sets textY 
    // Draws message in black font and white font
    for(std::list< std::string >::iterator CurLine = Lines.begin(); CurLine != Lines.end(); CurLine++){
        gint LineHeight, LineWidth;
        DBlackFont.MeasureText(*CurLine, LineWidth, LineHeight); 
        TextX = (RequiredWidth / 2) - (LineWidth / 2);
        DBlackFont.DrawText(DMessagePixmap, DDrawingContext, TextX + 1, TextY + 1, *CurLine);
        DWhiteFont.DrawText(DMessagePixmap, DDrawingContext, TextX, TextY, *CurLine);    
        TextY += LineHeight + 2;
    }
    
}


// Draws background of menu
void CApplicationData::DrawMenuBackground(GdkPixmap *buffer, gint width, gint height){
    /**
     * Draws tile according to height width
     * HeightOffset = height of indiv tile
     * WidthOffset = width of indiv tile
     */
    for(gint HeightOffset = 0; HeightOffset < height; HeightOffset += 8){
        if(HeightOffset & 0x8){
            for(gint WidthOffset = -(DBrickTileset.TileWidth()/2); WidthOffset < width; WidthOffset += DBrickTileset.TileWidth()){
                DBrickTileset.DrawTile(buffer, DDrawingContext, WidthOffset, HeightOffset, DBrickIndices[bbtSingle]);
            }
        }
        else{
            for(gint WidthOffset = 0; WidthOffset < width; WidthOffset += DBrickTileset.TileWidth()){
                DBrickTileset.DrawTile(buffer, DDrawingContext, WidthOffset, HeightOffset, DBrickIndices[bbtSingle]);
            }            
        }
    }
    DrawBrickFrame(buffer, 0, 0, width, height);    
}

// Draws text frame
void CApplicationData::DrawTextFrame(GdkPixmap *buffer, gint width, gint height){
    
    // Fills up tiles as long as collective height/width of tiles is less than height/width of frame
    for(gint HeightOffset = 0; HeightOffset < height; HeightOffset += D2DWallFloorTileset.TileHeight()){
        for(gint WidthOffset = 0; WidthOffset < width; WidthOffset += D2DWallFloorTileset.TileWidth()){
            D2DWallFloorTileset.DrawTile(buffer, DDrawingContext, WidthOffset, HeightOffset, D2DFloorIndices[DPlayerColor]);
        }
    }
    DrawBrickFrame(buffer, 0, 0, width, height);
}

// Draws brick frame
void CApplicationData::DrawBrickFrame(GdkPixmap *buffer, gint xoff, gint yoff, gint width, gint height){
    gint BrickType = 0;
    // Draws brick frame as long as cumulative width offset is less than width
    for(gint WidthOffset = 0; WidthOffset < width; WidthOffset += DBrickTileset.TileWidth()){
        DBrickTileset.DrawTile(buffer, DDrawingContext, xoff + WidthOffset, yoff, DBrickIndices[bbtTopCenter]);
        DBrickTileset.DrawTile(buffer, DDrawingContext, xoff + WidthOffset, yoff + height - DBrickTileset.TileHeight(), DBrickIndices[bbtBottomCenter]);
    }
    // Draws brick frame as long as cumulative height is less than frame height
    for(gint HeightOffset = 0; HeightOffset < height; HeightOffset += DBrickTileset.TileHeight()){
        DBrickTileset.DrawTile(buffer, DDrawingContext, xoff, yoff + HeightOffset, BrickType ? DBrickIndices[bbtLeft1] : DBrickIndices[bbtLeft0]);
        DBrickTileset.DrawTile(buffer, DDrawingContext, xoff + width - DBrickTileset.TileWidth(), yoff + HeightOffset, BrickType ? DBrickIndices[bbtRight1] : DBrickIndices[bbtRight0]);
        BrickType++;
        BrickType &= 0x1;
    }
    
    // Draws the 4 corner tiles 
    DBrickTileset.DrawTile(buffer, DDrawingContext, xoff, 0, DBrickIndices[bbtTopLeft]);
    DBrickTileset.DrawTile(buffer, DDrawingContext, xoff + width - DBrickTileset.TileWidth(), yoff, DBrickIndices[bbtTopRight]);
    DBrickTileset.DrawTile(buffer, DDrawingContext, xoff + width - DBrickTileset.TileWidth(), yoff + height - DBrickTileset.TileHeight(), DBrickIndices[bbtBottomRight]);
    DBrickTileset.DrawTile(buffer, DDrawingContext, xoff, yoff + height - DBrickTileset.TileHeight(), DBrickIndices[bbtBottomLeft]);
    // Draws the corner mortar tiles
    DMortarTileset.DrawTile(buffer, DDrawingContext, xoff, yoff - 5, DMortarIndices[bmtLeftTop2]);
    DMortarTileset.DrawTile(buffer, DDrawingContext, xoff + width - DMortarTileset.TileWidth(), yoff - 5, DMortarIndices[bmtRightTop2]);
    DMortarTileset.DrawTile(buffer, DDrawingContext, xoff,  yoff + height -DMortarTileset.TileHeight() + 5, DMortarIndices[bmtLeftBottom2]);
    DMortarTileset.DrawTile(buffer, DDrawingContext, xoff + width - DMortarTileset.TileWidth(), yoff + height -DMortarTileset.TileHeight() + 5, DMortarIndices[bmtRightBottom2]);
    /**
     * Draws mortar tiles according to frame's width
     * Sets index according to index of mortars where center = 0
     */
    for(gint WidthOffset = 0; WidthOffset < width; WidthOffset += DMortarTileset.TileWidth()){
        int TopIndex, BottomIndex; // Top index and bottom index of width 
        int CenterPoint = WidthOffset + DMortarTileset.TileWidth() / 2; // Center point = middle of width 
        int BrickDistance = (width / 2 - CenterPoint) / DMortarTileset.TileWidth(); // Distance of bricks  
        
        if(-3 >= BrickDistance){
            TopIndex = DMortarIndices[bmtTopRight2];
            BottomIndex = DMortarIndices[bmtBottomRight2];
        }
        else if(-2 == BrickDistance){
            TopIndex = DMortarIndices[bmtTopRight1];
            BottomIndex = DMortarIndices[bmtBottomRight1];
        }
        else if(-1 == BrickDistance){
            TopIndex = DMortarIndices[bmtTopRight0];
            BottomIndex = DMortarIndices[bmtBottomRight0];
        }
        else if(0 == BrickDistance){
            TopIndex = DMortarIndices[bmtTopCenter];
            BottomIndex = DMortarIndices[bmtBottomCenter];
        }
        else if(1 == BrickDistance){
            TopIndex = DMortarIndices[bmtTopLeft0];
            BottomIndex = DMortarIndices[bmtBottomLeft0];
        }
        else if(2 == BrickDistance){
            TopIndex = DMortarIndices[bmtTopLeft1];
            BottomIndex = DMortarIndices[bmtBottomLeft1];
        }
        else{
            TopIndex = DMortarIndices[bmtTopLeft2];
            BottomIndex = DMortarIndices[bmtBottomLeft2];
        }
        
        DMortarTileset.DrawTile(buffer, DDrawingContext, xoff + WidthOffset, yoff, TopIndex); // Draws a row of tiles at the top index 
        DMortarTileset.DrawTile(buffer, DDrawingContext, xoff + WidthOffset, yoff + height - DMortarTileset.TileHeight(), BottomIndex); // Draws tiles at bottom 
    }

    // Determines the left index and right index of the frame
    for(gint HeightOffset = 3; HeightOffset < height-DMortarTileset.TileHeight(); HeightOffset += 8){
        int LeftIndex, RightIndex;
        int CenterPoint = HeightOffset + DMortarTileset.TileHeight() / 2;
        int BrickDistance = (height / 2 - CenterPoint) / 8;
        
        if(3 <= BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftTop2];
            RightIndex = DMortarIndices[bmtRightTop2];
        }
        else if(2 == BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftTop1];
            RightIndex = DMortarIndices[bmtRightTop1];
        }
        else if(1 == BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftTop0];
            RightIndex = DMortarIndices[bmtRightTop0];
        }
        else if(0 == BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftCenter];
            RightIndex = DMortarIndices[bmtRightCenter];
        }
        else if(-1 == BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftBottom0];
            RightIndex = DMortarIndices[bmtRightBottom0];
        }
        else if(-2 == BrickDistance){
            LeftIndex = DMortarIndices[bmtLeftBottom1];
            RightIndex = DMortarIndices[bmtRightBottom1];
        }
        else{
            LeftIndex = DMortarIndices[bmtLeftBottom2];
            RightIndex = DMortarIndices[bmtRightBottom2];
        }
        
        DMortarTileset.DrawTile(buffer, DDrawingContext, xoff, yoff + HeightOffset, LeftIndex); // Draws the mortar tiles on left column 
        DMortarTileset.DrawTile(buffer, DDrawingContext, xoff + width - DMortarTileset.TileWidth(), yoff + HeightOffset, RightIndex); // Draws tile on right col 

    }
}

// Lets user end game
void CApplicationData::GameOverMode(){

    if(DLeftClick[DPlayerColor]){

        ChangeMode(gmMainMenu);   // Change mode to main menu if left clicks 
    }
}
// Turns on transition mode 
void CApplicationData::TransitionMode(){
    gint BannerWidth = 0, BannerHeight = 0; // Banner width / height = 0 
    bool LastBannerOffscreen = DBannerLocation < 0;
    // If bannerpixmap exists, get its width/height 
    if(NULL != DBannerPixmap){
        gdk_pixmap_get_size(DBannerPixmap, &BannerWidth, &BannerHeight); 
    }
    DBannerLocation += DCanvasHeight / TIMEOUT_INTERVAL;
    // If banner goes away, play sound clip
    if(LastBannerOffscreen && (0 <= DBannerLocation)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTransition], DSoundEffectVolume, 0.0);   
    }
    // If banner is higher than canvas, do transitions accordingly
    if(DBannerLocation >= DCanvasHeight){
        for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
            DCompletedStage[ColorIndex] = false;
            DAITargetX[ColorIndex] = -1;
            DAITargetY[ColorIndex] = -1;
            DAITargetCastle[ColorIndex] = -1;
        }

        if(gmTransitionCannonPlacement == DGameMode){
            DNextGameMode = gmCannonPlacement;
            gettimeofday(&DCurrentStageTimeout,NULL);
            DCurrentStageTimeout.tv_sec += PLACEMENT_TIME;
            DSoundMixer.PlaySong(DSongIndices[stPlace], DMusicVolume);
        }
        else if(gmTransitionSelectCastle == DGameMode){
            DNextGameMode = gmSelectCastle;
            gettimeofday(&DCurrentStageTimeout,NULL);
            DCurrentStageTimeout.tv_sec += SELECT_TIME;
        }
        else if(gmTransitionBattle == DGameMode){
            DBattleModeStage = bmsReady;
            DNextGameMode = gmBattle;
            gettimeofday(&DCurrentStageTimeout,NULL);
            DCurrentStageTimeout.tv_sec += BATTLE_TIME;
        }
        else if(gmTransitionRebuild == DGameMode){
            DNextGameMode = gmRebuild;
            gettimeofday(&DCurrentStageTimeout,NULL);
            DCurrentStageTimeout.tv_sec += REBUILD_TIME;
            DSoundMixer.PlaySong(DSongIndices[stRebuild], DMusicVolume);
        }
    }
    else if(DBannerLocation + BannerHeight >= DCanvasHeight){
        if(gmTransitionBattle == DGameMode){
            if(0 > DVoiceClipID){
                DVoiceClipID = DSoundMixer.PlayClip(DSoundClipIndices[sctReady], DSoundEffectVolume, 0.0);
                gettimeofday(&DCurrentStageTimeout,NULL);
                DCurrentStageTimeout.tv_sec += 30;
            }
        }
    }
}

// Lets user go back to main menu
void CApplicationData::MainMenuMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  DMenuItems.size());

    if(DLeftClick[pcNone]){
        // Single Player Game
        if(0 == DSelectedMenuItem){
            DNextGameMode = gmSelectMap;
            DLastSelectedMenuItem = -1;
            DSoundMixer.PlayClip(DSoundClipIndices[sctPlace], DSoundEffectVolume, 0.0);
        }
        else if(1 == DSelectedMenuItem){
            ChangeMode(gmLoginMenu);
        }
        else if(2 == DSelectedMenuItem){
            ChangeMode(gmOptionsMenu);
        }
        else{
            gtk_main_quit();
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}
// Lets user log in
void CApplicationData::LoginMenuMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  DMenuItems.size());
    if(DSelectedMenuItem == DMenuItems.size() - 1
            && DCurrentX[pcNone] < DCanvasWidth/2){
        DSelectedMenuItem += 1;
    }

    if(DLeftClick[pcNone]){
        // Login
        if(3 == DSelectedMenuItem){
            DUsername = std::string(DMenuItems[1]);
            DNetwork->LogIn(DMenuItems[1], DMenuItems[3]);
        }else if(4 == DSelectedMenuItem){
            ChangeMode(gmMainMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}

void CApplicationData::MultiplayerMenuMode(){
    int Count = DRoomsAvailable.size() + 1;
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  Count);
    if(DSelectedMenuItem == Count - 1
            && DCurrentX[pcNone] < DCanvasWidth/2){
        DSelectedMenuItem += 1;
    }

    if(DLeftClick[pcNone]){
        if(Count-1 == DSelectedMenuItem){
            ChangeMode(gmSelectMultiplayerMap);
        }else if(Count == DSelectedMenuItem){
            ChangeMode(gmMainMenu);
        }else{
            DNetwork->JoinRoom(DSelectedMenuItem+1);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}
void CApplicationData::RoomMode(){
    int Count = DPlayers.size() + 1;
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  Count);
    if(DSelectedMenuItem == Count - 1
            && DCurrentX[pcNone] < DCanvasWidth/2){
        DSelectedMenuItem += 1;
    }

    if(DLeftClick[pcNone]){
        // Login
        if(Count-1 == DSelectedMenuItem && DIsRoomOwner){
            ChangeMode(gmSelectCastle);
        }else if(Count == DSelectedMenuItem){
            ChangeMode(gmMultiplayerMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}
// Lets user select map
void CApplicationData::SelectMapMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  (DTerrainMaps.size() + 1));

    if(DLeftClick[pcNone]){
        DSoundMixer.PlayClip(DSoundClipIndices[sctPlace], DSoundEffectVolume, 0.0);
        if(DSelectedMenuItem < DTerrainMaps.size()){
            LoadTerrainMap(DSelectedMenuItem);
            ChangeMode(gmSelectWind);
        }
        else{
            ChangeMode(gmMainMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}
// Lets user select map
void CApplicationData::SelectMultiplayerMapMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  (DTerrainMaps.size() + 1));

    if(DLeftClick[pcNone]){
        DSoundMixer.PlayClip(DSoundClipIndices[sctPlace], DSoundEffectVolume, 0.0);
        if(DSelectedMenuItem < DTerrainMaps.size()){
            DNetwork->CreateRoom(DUsername + "'s Room", DUsername, DPlayerCount);
            LoadTerrainMap(DSelectedMenuItem);
            DPlayers.clear();
            DPlayers.push_back(DUsername);
            DNextGameMode = gmSelectMultiplayerMap;
        }
        else{
            ChangeMode(gmMultiplayerMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}

// Lets user go to options menu
void CApplicationData::OptionsMenuMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  DMenuItems.size());
    
    if(DLeftClick[pcNone]){
        if(0 == DSelectedMenuItem){
            ChangeMode(gmSoundOptions);  // Changes mode to sound options 
        }
        else if(1 == DSelectedMenuItem){
            ChangeMode(gmNetworkOptions); // Changes to network options
        }
        else{
            ChangeMode(gmMainMenu);   // Changes to the main menu 
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem; 
}

// Lets user choose wind options
void CApplicationData::SelectWindMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  4); 
    DSelectedMenuItem *= 2;
    if(DCurrentX[pcNone] > (DCanvasWidth/2)){
        DSelectedMenuItem++;
    }
    if(DLeftClick[pcNone]){
        if(0 == DSelectedMenuItem){
            switch(DWindType){
                case wtNone:    DWindType = wtNone;
                                break;
                case wtMild:    DWindType = wtNone;
                                break;
                case wtModerate:DWindType = wtMild;
                                break;
                case wtErratic: DWindType = wtModerate;
                                break;
            }
        }
        else if(1 == DSelectedMenuItem){
            switch(DWindType){
                case wtNone:    DWindType = wtMild;
                                break;
                case wtMild:    DWindType = wtModerate;
                                break;
                case wtModerate:DWindType = wtErratic;
                                break;
                case wtErratic: DWindType = wtErratic;
                                break;
            }
        }
        else if(2 == DSelectedMenuItem){
            if(DPlayerCount <= 2){
                switch(DPlayerColor){
                    case pcBlue:   DPlayerColor = pcRed;
                                   break;
                    case pcRed:    DPlayerColor = pcBlue;
                                   break;
                }    
            }
            else if(DPlayerCount == 3){
                switch(DPlayerColor){
                case pcBlue:   DPlayerColor = pcYellow;
                               break;
                case pcRed:    DPlayerColor = pcBlue;
                               break;
                case pcYellow: DPlayerColor = pcRed;
                               break;
                }
            }
            
        }
        else if(3 == DSelectedMenuItem){
            if(DPlayerCount <= 2){
                switch(DPlayerColor){
                    case pcBlue:   DPlayerColor = pcRed;
                                   break;
                    case pcRed:    DPlayerColor = pcBlue;
                                   break;
                }    
            }
            else if(DPlayerCount == 3){
                switch(DPlayerColor){
                case pcBlue:   DPlayerColor = pcRed;
                               break;
                case pcRed:    DPlayerColor = pcYellow;
                               break;
                case pcYellow: DPlayerColor = pcBlue;
                               break;
                }
            }
        }
        else if(4 == DSelectedMenuItem){
            switch(DAIDifficulty){
            case aiEasy:   DAIDifficulty = aiInsane;
                           difficultyLevel = 1;
                           break;
            case aiNormal: DAIDifficulty = aiEasy;
                           difficultyLevel = 1;
                           break;
            case aiHard:   DAIDifficulty = aiNormal;
                           difficultyLevel = 2;
                           break;
            case aiInsane: DAIDifficulty = aiHard;
                           difficultyLevel = 3;
                           break;
            }
        }
        else if(5 == DSelectedMenuItem){
            switch(DAIDifficulty){
            case aiEasy:   DAIDifficulty = aiNormal;
                           difficultyLevel = 2;
                           break;
            case aiNormal: DAIDifficulty = aiHard;
                           difficultyLevel = 3;
                           break;
            case aiHard:   DAIDifficulty = aiInsane;
                           difficultyLevel = 1;
                           break;
            case aiInsane: DAIDifficulty = aiEasy;
                           difficultyLevel = 1;
                           break;
            }
        }
        else if(6 == DSelectedMenuItem){
            ChangeMode(gmSelectMap);
        }
        else if(7 == DSelectedMenuItem){
            DPlayerIsAI[DPlayerColor] = false;
            ChangeMode(gmSelectCastle);
        }
    }

    DLastSelectedMenuItem = DSelectedMenuItem;
}


// Lets user choose sound options
void CApplicationData::SoundOptionsMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  3);
    DSelectedMenuItem *= 2;
    if(DCurrentX[pcNone] > (DCanvasWidth/2)){
        DSelectedMenuItem++;
    }
    if(DLeftClick[pcNone]){
        if(0 == DSelectedMenuItem){
            DSoundEffectVolume -= 0.05;
            if(0.0 > DSoundEffectVolume){
                DSoundEffectVolume = 0.0;
            }
            DSoundMixer.PlayClip(DSoundClipIndices[sctTock], DSoundEffectVolume, 0.0);
        }
        else if(1 == DSelectedMenuItem){
            DSoundEffectVolume += 0.05;
            if(1.0 < DSoundEffectVolume){
                DSoundEffectVolume = 1.0;
            }
            DSoundMixer.PlayClip(DSoundClipIndices[sctTock], DSoundEffectVolume, 0.0);
        }
        else if(2 == DSelectedMenuItem){
            DMusicVolume -= 0.05;
            if(0.0 > DMusicVolume){
                DMusicVolume = 0.0;
            }
            DSoundMixer.SongVolume(DMusicVolume);
        }
        else if(3 == DSelectedMenuItem){
            DMusicVolume += 0.05;
            if(1.0 < DMusicVolume){
                DMusicVolume = 1.0;
            }
            DSoundMixer.SongVolume(DMusicVolume);
        }
        else{
            ChangeMode(gmMainMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}

// Lets user choose network options

void CApplicationData::NetworkOptionsMode(){
    DSelectedMenuItem = DCurrentY[pcNone] / (DCanvasHeight /  3);
    DSelectedMenuItem *= 2;
    if(DCurrentX[pcNone] > (DCanvasWidth/2)){
        DSelectedMenuItem++;
    }
    if(DLeftClick[pcNone]){
        if(5 == DSelectedMenuItem){
            ChangeMode(gmMainMenu);
        }
    }
    else if((0 <= DLastSelectedMenuItem)&&(DLastSelectedMenuItem != DSelectedMenuItem)){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTick], DSoundEffectVolume, 0.0);
    }
    DLastSelectedMenuItem = DSelectedMenuItem;
}

void CApplicationData::SelectCastleMode(){
    int XTile, YTile;
    int XPos, YPos;
    int BestDistance = 999999;
    int BestCastle[pcMax];
    bool AllPlayersCompleted = true;
    
    //If pause flag is true, pause until pause key is pressed again.
    if(!DNetworkGame){
        while(DPause){
            gtk_main_iteration_do(false);
        }
    }

    for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
        if(!DCompletedStage[ColorIndex]){
	  if(!DPlayerIsAI[ColorIndex]){
            XTile = DCurrentX[ColorIndex] / DTileWidth;
            YTile = DCurrentY[ColorIndex] / DTileHeight;
	  
	  
            BoundsCheck(XTile, YTile);
            BestDistance = 999999;
            BestCastle[ColorIndex] = -1;
            
            for(int Index = 0; Index < DSurroundedCastles[ColorIndex].size(); Index++){
                int Distance;
                XPos = DCastleLocations[ColorIndex][Index].DXIndex;
                YPos = DCastleLocations[ColorIndex][Index].DYIndex;
                
                Distance = (XPos - XTile) * (XPos - XTile) + (YPos - YTile) * (YPos - YTile);
                DSurroundedCastles[ColorIndex][Index] = false;
                if(Distance < BestDistance){
                    BestDistance = Distance;
                    BestCastle[ColorIndex] = Index;
                } 
            }
            if(0 <= BestCastle[ColorIndex]){
               DSurroundedCastles[ColorIndex][BestCastle[ColorIndex]] = true;
            }
	  }
          else{
	    LuaRef n = getGlobal(L, "number");
	    BestCastle[ColorIndex] = n.cast<int>();
	  }
        }
    }
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(DLeftClick[ColorIndex] && !DCompletedStage[ColorIndex]){
            EConstructionTileType ConTileType, WallType;
            double LRRatio;
                
            XPos = DCastleLocations[ColorIndex][BestCastle[ColorIndex]].DXIndex;
            YPos = DCastleLocations[ColorIndex][BestCastle[ColorIndex]].DYIndex;
	    
            if(pcBlue == ColorIndex){
                ConTileType = cttBlueFloor;
                WallType = cttBlueWall;
            }
            else if(pcRed == ColorIndex){
                ConTileType = cttRedFloor;
                WallType = cttRedWall;
            }
            else{
                ConTileType = cttYellowFloor;
                WallType = cttYellowWall;
            }
            
            for(int YOffset = -3; YOffset <= 4; YOffset++){
                int YI = YPos + YOffset;
                for(int XOffset = -3; XOffset <= 4; XOffset++){
                    int XI = XPos + XOffset;
                    char TileType = DTerrainMap.TileType(XI, YI);
    
                    if(TileType == ColorIndex){
                        DConstructionTiles[YI][XI] = ConTileType;       
                    }
                }
            }
            for(int YOffset = -3; YOffset <= 4; YOffset++){
                int YI = YPos + YOffset;
                for(int XOffset = -3; XOffset <= 4; XOffset++){
                    int XI = XPos + XOffset;
                    
                    if(ConTileType == DConstructionTiles[YI][XI]){
                        bool MakeWall = false;
                        if(YI){
                            if(XI && (cttNone == DConstructionTiles[YI-1][XI-1])){
                                MakeWall = true;   
                            }
                            if(cttNone == DConstructionTiles[YI-1][XI]){
                                MakeWall = true;
                            }
                            if((XI + 1 < DConstructionTiles[YI].size()) && (cttNone == DConstructionTiles[YI-1][XI+1])){
                                MakeWall = true;
                            }
                        }
                        else{
                            MakeWall = true;   
                        }
                        if(XI){
                            if(cttNone == DConstructionTiles[YI][XI-1]){
                                MakeWall = true;
                            }
                        }
                        else{
                            MakeWall = true;   
                        }
                        if(XI + 1 < DConstructionTiles[YI].size()){
                            if(cttNone == DConstructionTiles[YI][XI+1]){
                                MakeWall = true;
                            }
                        }
                        else{
                            MakeWall = true;    
                        }
                        if(YI + 1 < DConstructionTiles.size()){
                            if(XI && (cttNone == DConstructionTiles[YI+1][XI-1])){
                                MakeWall = true;
                            }
                            if(cttNone == DConstructionTiles[YI+1][XI]){
                                MakeWall = true;
                            }
                            if((XI + 1 < DConstructionTiles[YI].size()) && (cttNone == DConstructionTiles[YI+1][XI+1])){
                                MakeWall = true;
                            }
                        }
                        else{
                            MakeWall = true;    
                        }
                        if(MakeWall){
                            DConstructionTiles[YI][XI] = WallType;
                        }
                    }
                }
            }
            
            LRRatio = (((double)XPos / (DMapWidth - 1)) - 0.5) * 2.0;
            DSoundMixer.PlayClip(DSoundClipIndices[sctTriumph], DSoundEffectVolume, LRRatio);

            DCompletedStage[ColorIndex] = true;
        }
        if(!DCompletedStage[ColorIndex]){
            AllPlayersCompleted = false;
        }
    }   
    
    //Gets number from RNG to randomize wall shape.
    if(AllPlayersCompleted){
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            DWallShape[ColorIndex].Randomize(DRandomNumberGenerator.Random());
            DCannonsToPlace[ColorIndex] = 3;
        }
        
        ChangeMode(gmCannonPlacement);
    }
}

/**
 * Rebuild mode. Enter this mode at the end of each round.
 * Allows players to rebuild their castles and also checks
 * to see if there is a winner.
 */
void CApplicationData::RebuildMode(){
    int XTile, YTile;
    int XPos, YPos;
    char RequiredTileType;
    EConstructionTileType WallType;
    bool Done, AllPlayersCompleted;
    int SurroundedBefore = 0, SurroundedAfter = 0;
    timeval past, present;
    
    //If pause flag is true, pause until pause key is pressed again, then adjust the round deadline to account for time paused.
    if(DPause && !DNetworkGame){
        gettimeofday(&past, NULL);
        while(DPause){
            gtk_main_iteration_do(false);
        }
        gettimeofday(&present, NULL);
        DCurrentStageTimeout.tv_sec += SecondsPaused(past, present);
        DCurrentStageTimeout.tv_usec += MicroSecondsPaused(past, present);
    }

    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(!DCompletedStage[ColorIndex]){
            XTile = DCurrentX[ColorIndex] / DTileWidth;
            YTile = DCurrentY[ColorIndex] / DTileHeight;
            BoundsCheck(XTile, YTile);
            if(XTile + DWallShape[ColorIndex].Width() >= DMapWidth){
                XTile = DMapWidth - DWallShape[ColorIndex].Width();
            }
            if(YTile + DWallShape[ColorIndex].Height() >= DMapHeight){
                YTile = DMapHeight - DWallShape[ColorIndex].Height();
            }
            if(DRightClick[ColorIndex]){
                DWallShape[ColorIndex].Rotate();
            }
            RequiredTileType = ColorIndex;
            if(pcBlue == ColorIndex){
                WallType = cttBlueWall;
            }
            else if(pcRed == ColorIndex){
                WallType = cttRedWall;
            }
            else{
                WallType = cttYellowWall;
            }
            //Do while loop that allows players to place walls before the timer is up.
            do{
                Done = true;
                DCanPlaceWallCannon[ColorIndex] = ValidWallPlacement(ColorIndex, XTile, YTile);
                if(DCanPlaceWallCannon[ColorIndex] && DLeftClick[ColorIndex]){
                    double LRRatio = (((double)XTile / (DMapWidth - 1)) - 0.5) * 2.0;
                    
                    for(int WallYPos = 0; WallYPos < DWallShape[ColorIndex].Height(); WallYPos++){
                        YPos = YTile + WallYPos;
                        for(int WallXPos = 0; WallXPos < DWallShape[ColorIndex].Width(); WallXPos++){
                            XPos = XTile + WallXPos;
                            if(DWallShape[ColorIndex].IsBlock(WallXPos, WallYPos)){
                                DConstructionTiles[YPos][XPos] = WallType;
                            }
                        }
                    }
                    //If there is still time left then create a random wallshape for player to place
                    if(0 < SecondsUntilDeadline(DCurrentStageTimeout)){
                        DWallShape[ColorIndex].Randomize(DRandomNumberGenerator.Random());
                        Done = false;
                    }
                    else{
                        DCompletedStage[ColorIndex] = true;
                    }
                    DLeftClick[ColorIndex] = false;
                    
                    DSoundMixer.PlayClip(DSoundClipIndices[sctPlace], DSoundEffectVolume, LRRatio);
                }
            }while(!Done);
        }
    }

    for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
        for(int Index = 0; Index < DSurroundedCastles[ColorIndex].size(); Index++){
            if(DSurroundedCastles[ColorIndex][Index]){
                SurroundedBefore++;
            }
        }
    }    
    CheckSurroundedCastles();
    for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
        for(int Index = 0; Index < DSurroundedCastles[ColorIndex].size(); Index++){
            if(DSurroundedCastles[ColorIndex][Index]){
                SurroundedAfter++;
            }
        }
    }
    if(SurroundedBefore != SurroundedAfter){
        DSoundMixer.PlayClip(DSoundClipIndices[sctTriumph], DSoundEffectVolume, 0.0);   
    }
    
    AllPlayersCompleted = true; //All players done rebuilding
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(!DCompletedStage[ColorIndex]){
            AllPlayersCompleted = false;
            break;
        }
    }

    PlayTickTockSound();
    //If time runs out or all players are done rebuilding their castle.
    if((-3 >= SecondsUntilDeadline(DCurrentStageTimeout))||AllPlayersCompleted){
        int LivingPlayers;
        
        LivingPlayers = DetermineConquered();
        //If there is no winner yet then change to cannon placement mode
        if(1 < LivingPlayers){
            for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
                DCannonsToPlace[ColorIndex] = DSurroundedCastleCounts[ColorIndex];
            }
            DSoundMixer.StopSong();
            ChangeMode(gmCannonPlacement);
        }
        //Else if there is only one player left then we have a winner
        else if(1 == LivingPlayers){
            std::string Message;
            // Show winner   
            if(pcBlue == DPlayerColor){
                Message = "BLUE\n";
            }
            else if(pcRed == DPlayerColor){
                Message = "RED\n";                    
            }
            else{
                Message = "YELLOW\n";
            }
            if(DPlayerIsConquered[DPlayerColor]){
                Message += "ARMY\nDEFEATED";
                DSoundMixer.PlaySong(DSongIndices[stLoss], DMusicVolume);
            }
            else{
                Message += "ARMY\nCONQUERS";
                DSoundMixer.PlaySong(DSongIndices[stWin], DMusicVolume * 2.0);
            }
            DrawMessage(Message);
            DNextGameMode = gmGameOver;
        }
        else{
            // Do rebuild because all would die
            gettimeofday(&DCurrentStageTimeout,NULL);
            DCurrentStageTimeout.tv_sec += REBUILD_TIME;
            for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
                DCompletedStage[ColorIndex] = false;
            }
        }
    }
}

/**
 * Cannon placement mode. If game is not over after players rebuild
 * their castle then enter this mode. Players place cannons to prepare
 * for next round of attacks.
 */
void CApplicationData::CannonPlacementMode(){
    int XTile, YTile;
    bool AllPlayersCompleted = true;
    timeval past, present;
    
    //If pause flag is true, pause until pause key is pressed again, then adjust the round deadline to account for time paused.
    if(DPause && !DNetworkGame){
        gettimeofday(&past, NULL);
        while(DPause){
            gtk_main_iteration_do(false);
        }
        gettimeofday(&present, NULL);
        DCurrentStageTimeout.tv_sec += SecondsPaused(past, present);
        DCurrentStageTimeout.tv_usec += MicroSecondsPaused(past, present);
    }

    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        XTile = DCurrentX[ColorIndex] / DTileWidth;
        YTile = DCurrentY[ColorIndex] / DTileHeight;
        //Makes sure cannon placed is within the bound
        BoundsCheck(XTile, YTile);
        
        //Checks for left click to place cannon
        if(DLeftClick[ColorIndex] && DCannonsToPlace[ColorIndex]){
            if(ValidCannonPlacement(ColorIndex, XTile, YTile)){
                SMapLocation TempLocation;
                double LRRatio = (((double)XTile / (DMapWidth - 1)) - 0.5) * 2.0;
                
                TempLocation.DXIndex = XTile;
                TempLocation.DYIndex = YTile;
                
                DCannonLocations[ColorIndex].push_back(TempLocation);
                DCannonballToneIDs[ColorIndex].push_back(-1);
                DCannonsToPlace[ColorIndex]--;
                //If there are no more cannons to place for this player then they're done
                if(0 == DCannonsToPlace[ColorIndex]){
                    DCompletedStage[ColorIndex] = true;
                }
                DSoundMixer.PlayClip(DSoundClipIndices[sctPlace], DSoundEffectVolume, LRRatio);
            }
        }
        if(!DCompletedStage[ColorIndex]){
            AllPlayersCompleted = false;   
        }
    }
    PlayTickTockSound();
    //If time runs out and all players are done placing cannons then change to battle mode
    if(AllPlayersCompleted || (-3 >= SecondsUntilDeadline(DCurrentStageTimeout))){
        DSoundMixer.StopSong();
        ChangeMode(gmBattle);
        
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            bool Done;
            
            DAITargetX[ColorIndex] = -1;
            DAITargetY[ColorIndex] = -1;
            
            do{
                Done = true;
                for(int CannonIndex = 1; CannonIndex < DCannonLocations[ColorIndex].size(); CannonIndex++){
                    bool Swap = false;
                    if(DCannonLocations[ColorIndex][CannonIndex].DYIndex < DCannonLocations[ColorIndex][CannonIndex-1].DYIndex){
                        Swap = true;
                    }
                    else if((DCannonLocations[ColorIndex][CannonIndex].DYIndex == DCannonLocations[ColorIndex][CannonIndex-1].DYIndex)&&(DCannonLocations[ColorIndex][CannonIndex].DXIndex < DCannonLocations[ColorIndex][CannonIndex-1].DXIndex)){
                        Swap = true;
                    }
                    if(Swap){
                        SMapLocation TempLocation = DCannonLocations[ColorIndex][CannonIndex];
                        
                        DCannonLocations[ColorIndex][CannonIndex] = DCannonLocations[ColorIndex][CannonIndex-1];
                        DCannonLocations[ColorIndex][CannonIndex-1] = TempLocation;
                        Done = false;
                    }
                }
            }while(!Done);
            DCannonsReady[ColorIndex].clear();
            for(int CannonIndex = 0; CannonIndex < DCannonLocations[ColorIndex].size(); CannonIndex++){
                if(TileTypeIsFloor(DConstructionTiles[DCannonLocations[ColorIndex][CannonIndex].DYIndex][DCannonLocations[ColorIndex][CannonIndex].DXIndex])){
                    DCannonsReady[ColorIndex].push_back(CannonIndex);
                    DCannonballToneIDs[ColorIndex][CannonIndex] = -1;
                }
            }            
        }
    }
}

void CApplicationData::BattleMode(){
    bool WindDirectionChange = false;
    double WindX = 0, WindY = 0;    
    timeval past, present;
    
    //If pause flag is true, pause until pause key is pressed again, then adjust the round deadline to account for time paused.
    if(DPause && !DNetworkGame){
        gettimeofday(&past, NULL);
        while(DPause){
            gtk_main_iteration_do(false);
        }
        gettimeofday(&present, NULL);
        DCurrentStageTimeout.tv_sec += SecondsPaused(past, present);
        DCurrentStageTimeout.tv_usec += MicroSecondsPaused(past, present);
    }
    
    //Switch statement that selects from several different wind speeds    
    switch(DWindDirection){
        case 1:     WindY = -DWindSpeed;
                    break;
        case 2:     WindX = DWindSpeed;
                    WindY = -DWindSpeed;
                    break;
        case 3:     WindX = DWindSpeed;
                    break;    
        case 4:     WindX = DWindSpeed;
                    WindY = DWindSpeed;
                    break;
        case 5:     WindY = DWindSpeed;
                    break;
        case 6:     WindX = -DWindSpeed;
                    WindY = DWindSpeed;
                    break;
        case 7:     WindX = -DWindSpeed;
                    break;
        case 8:     WindX = -DWindSpeed;
                    WindY = -DWindSpeed;
                    break;
        default:    break;
    }
    WindX /= 10;
    WindY /= 10;
    WindX *= TIMESTEP_PERIOD;
    WindY *= TIMESTEP_PERIOD;
    

    if(bmsBattle == DBattleModeStage){
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            //if player left clicks and cannons are ready then shoot cannonball
            if(DLeftClick[ColorIndex] && DCannonsReady[ColorIndex].size() && (0 <= SecondsUntilDeadline(DCurrentStageTimeout))){
                SCannonballTrajectory InitialTrajectory;
                SSpriteState TempPlumeState;
                int CannonIndex = DCannonsReady[ColorIndex].front();
                int CenterX, CenterY;
                int DeltaX, DeltaY;
                int TargetX, TargetY;
                int Distance;
                double LRRatio;
                
                DCannonsReady[ColorIndex].pop_front();
                                    
                CenterX = (DCannonLocations[ColorIndex][CannonIndex].DXIndex + 1) * DTileWidth;
                CenterY = (DCannonLocations[ColorIndex][CannonIndex].DYIndex + 1) * DTileHeight;
                
                TargetX = DCurrentX[ColorIndex];
                TargetY = DCurrentY[ColorIndex] + DTileHeight/2;
                
                DeltaX = TargetX - CenterX;
                DeltaY = TargetY - CenterY;
                Distance = IntegerSquareRoot(DeltaX * DeltaX + DeltaY * DeltaY);
                
                InitialTrajectory.DXPosition = CenterX;
                InitialTrajectory.DYPosition = CenterY;
                InitialTrajectory.DZPosition = 0;
                InitialTrajectory.DZVelocity = DInitialVelocities[Distance];
                InitialTrajectory.DXVelocity = DeltaX * InitialTrajectory.DZVelocity / Distance;
                InitialTrajectory.DYVelocity = DeltaY * InitialTrajectory.DZVelocity / Distance;
                InitialTrajectory.DOwner = (EPlayerColor)ColorIndex;
                InitialTrajectory.DCannon = CannonIndex;
                
                DCannonballTrajectories.push_back(InitialTrajectory);
                
                TempPlumeState.DXIndex = DCannonLocations[ColorIndex][CannonIndex].DXIndex;
                TempPlumeState.DYIndex = DCannonLocations[ColorIndex][CannonIndex].DYIndex;
                TempPlumeState.DXOffset = 0;
                TempPlumeState.DYOffset = 0;
                TempPlumeState.DStep = 0;
                TempPlumeState.DSpriteIndex = D3DCannonPlumeIndices[CalculateDirection(CenterX, CenterY, TargetX, TargetY)];
                DPlumeStates.push_back(TempPlumeState);
                
                LRRatio = (((double)CenterX / (DCanvasWidth - 1)) - 0.5) * 2.0;
                DSoundMixer.PlayClip(DSoundClipIndices[DRandomNumberGenerator.Random() & 0x1 ? sctCannon1 : sctCannon0], DSoundEffectVolume, LRRatio);
            }
        }
    }
    for(std::list< SSpriteState >::iterator Burn = DBurnStates.begin(); Burn != DBurnStates.end(); ){
        bool Advance = true;
        
        Burn->DStep++;
        if(DBurnSteps <= Burn->DStep){
            Burn = DBurnStates.erase(Burn);
            Advance = false;
        }        
        if(Advance){
            Burn++;   
        }
    }

    //A for loop that goes through the different states of explosion for graphics
    for(std::list< SSpriteState >::iterator Explosion = DExplosionStates.begin(); Explosion != DExplosionStates.end(); ){
        bool Advance = true;
        
        Explosion->DStep++;
        if(DExplosionSteps <= Explosion->DStep){
            int TempXTile, TempYTile;
            bool InBounds;
            TempXTile = Explosion->DXIndex;
            TempYTile = Explosion->DYIndex;
            InBounds = BoundsCheck(TempXTile, TempYTile);
            
            //keeps explosion inside the bounds
            if(InBounds){
                if(TileTypeIsWallDamaged(DConstructionTiles[TempYTile][TempXTile])){
                    Explosion->DStep = 0;
                    
                    Explosion->DSpriteIndex = D3DBurnIndices[(DRandomNumberGenerator.Random() & 0x1) ? btRubbleBurn1 : btRubbleBurn0];
                    DBurnStates.push_back(*Explosion);
                }
                if(TileTypeIsFloorGroundDamaged(DConstructionTiles[TempYTile][TempXTile])){
                    Explosion->DStep = 0;
                    Explosion->DSpriteIndex = D3DBurnIndices[(DRandomNumberGenerator.Random() & 0x1) ? btHoleBurn1 : btHoleBurn0];
                    DBurnStates.push_back(*Explosion);
                }
            }
            Explosion = DExplosionStates.erase(Explosion);
            Advance = false;
        }        
        
        //If the explosion is still in bounds, increment the explosion iterator
        if(Advance){
            Explosion++;   
        }
    }

    //A for loop that goes through the different states of Plume for graphics
    for(std::list< SSpriteState >::iterator Plume = DPlumeStates.begin(); Plume != DPlumeStates.end(); ){
        bool Advance = true;
        
        Plume->DStep++;
        if(DCannonPlumeSteps <= Plume->DStep){
            Plume = DPlumeStates.erase(Plume);
            Advance = false;
        }        
        if(Advance){
            Plume++;   
        }
    }

    /**
     * A for loop that goes through the trajectory of the Cannonball for graphics
     * Position of the canonball is affected by wind and velocity of cannonball * time
     */ 
    for(std::list< SCannonballTrajectory >::iterator Cannonball = DCannonballTrajectories.begin(); Cannonball != DCannonballTrajectories.end(); ){
        bool Advance = true;
        Cannonball->DXVelocity += WindX;
        Cannonball->DYVelocity += WindY;
        Cannonball->DXPosition += Cannonball->DXVelocity * TIMESTEP_PERIOD;
        Cannonball->DYPosition += Cannonball->DYVelocity * TIMESTEP_PERIOD;
        Cannonball->DZPosition += Cannonball->DZVelocity * TIMESTEP_PERIOD;
        Cannonball->DZVelocity -= STANDARD_GRAVITY * TIMESTEP_PERIOD;

        //If the cannonball hits the ground
        if(0 > Cannonball->DZVelocity){
            int TempXTile, TempYTile;
            bool Collision = false;
            bool InBounds, AltExplosion;
            SSpriteState TempExplosionState;
            
            if(0 > DCannonballToneIDs[Cannonball->DOwner][Cannonball->DCannon]){
                int CannonBallSize = CalculateCannonballSize(Cannonball->DZPosition);
                DCannonballToneIDs[Cannonball->DOwner][Cannonball->DCannon] = DSoundMixer.PlayTone(2500.0 + (CannonBallSize / 12.0) * 500.0, -500.0, DSoundEffectVolume * CannonBallSize / 36.0, -0.1 * DSoundEffectVolume,  (((double)Cannonball->DXPosition / DCanvasWidth) - 0.5) * 2.0, Cannonball->DXVelocity / (2.0 * DCanvasWidth));
            }
            AltExplosion = DRandomNumberGenerator.Random() & 0x01;
            TempXTile = Cannonball->DXPosition / DTileWidth;
            TempYTile = Cannonball->DYPosition / DTileHeight;
            InBounds = BoundsCheck(TempXTile, TempYTile);
            if(InBounds){
                if((DTileHeight * 2 > Cannonball->DZPosition)&&TileTypeIsWall(DConstructionTiles[TempYTile][TempXTile])){
                    // Hit wall
                    TempExplosionState.DXIndex = TempXTile;
                    TempExplosionState.DYIndex = TempYTile;
                    TempExplosionState.DXOffset = 0;
                    TempExplosionState.DYOffset = 0;
                    TempExplosionState.DStep = 0;
                    
                    TempExplosionState.DSpriteIndex = D3DExplosionIndices[AltExplosion ? etWallExplosion1 : etWallExplosion0];
                    Collision = true;  
                    
                    //Switch statement which denotes which color of wall (color denotes a specific player) is damaged 
                    switch(DTerrainMap.TileType(TempXTile, TempYTile)){
                        case pcBlue:    DConstructionTiles[TempYTile][TempXTile] = cttBlueWallDamaged;
                                        break;
                        case pcRed:     DConstructionTiles[TempYTile][TempXTile] = cttRedWallDamaged;
                                        break;
                        case pcYellow:  DConstructionTiles[TempYTile][TempXTile] = cttYellowWallDamaged;
                                        break;
                        default:        DConstructionTiles[TempYTile][TempXTile] = cttNone;
                                        TempExplosionState.DSpriteIndex = D3DExplosionIndices[AltExplosion ? etWaterExplosion1 : etWaterExplosion0];
                                        break;
                    }
                    DExplosionStates.push_back(TempExplosionState);
                    DSoundMixer.PlayClip(DSoundClipIndices[sctExplosion0 + (DRandomNumberGenerator.Random() % 4)], DSoundEffectVolume, (((double)TempXTile / (DMapWidth - 1)) - 0.5) * 2.0);
                }
                else if(0.0 >= Cannonball->DZPosition){
                    // Hit ground
                    TempExplosionState.DXIndex = TempXTile;
                    TempExplosionState.DYIndex = TempYTile;
                    TempExplosionState.DXOffset = (((int)Cannonball->DXPosition) % DTileWidth) - (DTileWidth/2);
                    TempExplosionState.DYOffset = (((int)Cannonball->DYPosition) % DTileHeight) - (DTileHeight/2);
                    TempExplosionState.DStep = 0;
                    TempExplosionState.DSpriteIndex = D3DExplosionIndices[AltExplosion ? etGroundExplosion1 : etGroundExplosion0];

                    if(pcNone == DTerrainMap.TileType(TempXTile, TempYTile)){
                        TempExplosionState.DSpriteIndex = D3DExplosionIndices[AltExplosion ? etWaterExplosion1 : etWaterExplosion0];
                        DSoundMixer.PlayClip(DSoundClipIndices[sctWaterExplosion0 + (DRandomNumberGenerator.Random() % 4)], DSoundEffectVolume, (((double)TempXTile / (DMapWidth - 1)) - 0.5) * 2.0);
                    }
                    else{
                        DHitsTaken[TempYTile][TempXTile]++;
                        if(TileTypeIsWallDamaged(DConstructionTiles[TempYTile][TempXTile])){
                            TempExplosionState.DXOffset = 0;  
                            TempExplosionState.DYOffset = 0;
                        }
                        DSoundMixer.PlayClip(DSoundClipIndices[sctGroundExplosion0 + (DRandomNumberGenerator.Random() % 2)], DSoundEffectVolume, (((double)TempXTile / (DMapWidth - 1)) - 0.5) * 2.0);
                    }
                    if(5 <= DHitsTaken[TempYTile][TempXTile]){
                        if(TileTypeIsFloor(DConstructionTiles[TempYTile][TempXTile]) && !CannonCastleInterfere(TempXTile, TempYTile, 1, 1)){
                            if(0 == (DRandomNumberGenerator.Random() % 5)){
                                switch(DTerrainMap.TileType(TempXTile, TempYTile)){
                                    case pcBlue:    DConstructionTiles[TempYTile][TempXTile] = cttBlueFloorDamaged;
                                                    break;
                                    case pcRed:     DConstructionTiles[TempYTile][TempXTile] = cttRedFloorDamaged;
                                                    break;
                                    case pcYellow:  DConstructionTiles[TempYTile][TempXTile] = cttYellowFloorDamaged;
                                                    break;
                                    default:        DConstructionTiles[TempYTile][TempXTile] = cttNone;
                                                    break;
                                }
                            }
                        }
                        else if(cttNone == DConstructionTiles[TempYTile][TempXTile]){
                            if(0 == (DRandomNumberGenerator.Random() % 5)){
                                DConstructionTiles[TempYTile][TempXTile] = cttGroundDamaged;
                            }
                        }
                        else if(TileTypeIsWallDamaged(DConstructionTiles[TempYTile][TempXTile])){
                            if(10 <= DHitsTaken[TempYTile][TempXTile]){
                                if(0 == (DRandomNumberGenerator.Random() % 5)){
                                    switch(DTerrainMap.TileType(TempXTile, TempYTile)){
                                        case pcBlue:    DConstructionTiles[TempYTile][TempXTile] = cttBlueFloorDamaged;
                                                        break;
                                        case pcRed:     DConstructionTiles[TempYTile][TempXTile] = cttRedFloorDamaged;
                                                        break;
                                        case pcYellow:  DConstructionTiles[TempYTile][TempXTile] = cttYellowFloorDamaged;
                                                        break;
                                        default:        DConstructionTiles[TempYTile][TempXTile] = cttNone;
                                                        break;
                                    }
                                }   
                            }
                        }
                    }    
                    if(TileTypeIsFloorGroundDamaged(DConstructionTiles[TempYTile][TempXTile])){
                        TempExplosionState.DXOffset = 0;  
                        TempExplosionState.DYOffset = 0;
                    }
                    DExplosionStates.push_back(TempExplosionState);
                    Collision = true;
                }
            }
            else if(0.0 >= Cannonball->DZPosition){
                Collision = true;
            }
            if(Collision || (DTileHeight > Cannonball->DZPosition)){
                DSoundMixer.StopTone(DCannonballToneIDs[Cannonball->DOwner][Cannonball->DCannon]);
                DCannonballToneIDs[Cannonball->DOwner][Cannonball->DCannon] = -1;
            }
            if(Collision){
                DCannonsReady[Cannonball->DOwner].push_back(Cannonball->DCannon);
                Advance = false;
                Cannonball = DCannonballTrajectories.erase(Cannonball);
            }
        }
        // move the cannonball iterator forward to next frame
        if(Advance){
            Cannonball++;    
        }
    }
    DCannonballTrajectories.sort(TrajectoryCompare);
    DExplosionStates.sort(SpriteCompare);
    DBurnStates.sort(SpriteCompare);
    if(DRightClick[DPlayerColor]){
        switch(DWindType){
            case wtNone:    DWindType = wtMild;
                            break;
            case wtMild:    DWindType = wtModerate;
                            break;
            case wtModerate:DWindType = wtErratic;
                            break;
            case wtErratic: DWindType = wtNone;
                            WindDirectionChange = true;
                            break;
        }
    }
    
    if(bmsBattle == DBattleModeStage){
        if((0 > DVoiceClipID)&&(MiliSecondsUntilDeadline(DCurrentStageTimeout) < (DSoundMixer.ClipDurationMS(DSoundClipIndices[sctCeasefire])/2))){
            DVoiceClipID = DSoundMixer.PlayClip(DSoundClipIndices[sctCeasefire], DSoundEffectVolume, 0.0);
        }
        if((0 == DCannonballTrajectories.size()) && (0 == DExplosionStates.size()) && (0 == DBurnStates.size()) && DSoundMixer.ClipCompleted(DVoiceClipID) && (0 > SecondsUntilDeadline(DCurrentStageTimeout))){
            ChangeMode(gmRebuild);
        }
    }
    else if(bmsReady == DBattleModeStage){
        if(DSoundMixer.ClipCompleted(DVoiceClipID)){
            if(1 < SecondsUntilDeadline(DCurrentStageTimeout)){
                gettimeofday(&DCurrentStageTimeout,NULL);
                DCurrentStageTimeout.tv_sec += 1;
            }
            else if(0 >= SecondsUntilDeadline(DCurrentStageTimeout)){
                DBattleModeStage = bmsAim;
                DVoiceClipID = DSoundMixer.PlayClip(DSoundClipIndices[sctAim], DSoundEffectVolume, 0.0);
                gettimeofday(&DCurrentStageTimeout,NULL);
                DCurrentStageTimeout.tv_sec += 30;
            }
        }
    }
    else if(bmsAim == DBattleModeStage){
        if(DSoundMixer.ClipCompleted(DVoiceClipID)){
            if(1 < SecondsUntilDeadline(DCurrentStageTimeout)){
                gettimeofday(&DCurrentStageTimeout,NULL);
                DCurrentStageTimeout.tv_sec += 1;
            }
            else if(0 >= SecondsUntilDeadline(DCurrentStageTimeout)){
                DBattleModeStage = bmsBattle;
                DSoundMixer.PlayClip(DSoundClipIndices[sctFire], DSoundEffectVolume, 0.0);
                gettimeofday(&DCurrentStageTimeout,NULL);
                DCurrentStageTimeout.tv_sec += BATTLE_TIME;
                DVoiceClipID = -1;
            }
        }
    }

    if(wtNone == DWindType){
        DWindDirection = 0;
        DWindSpeed = 1;
    }

     //This code sets probabilities for the wind to change direction/speed and min/max wind speed
    else{
        unsigned int ChangeProbability;
        unsigned int DirectionProbability;
        unsigned int SpeedProbability;
        int MinWindSpeed, MaxWindSpeed;

        if(wtMild == DWindType){
            ChangeProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.01));
            DirectionProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.01));
            SpeedProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.1));
            MinWindSpeed = 1;
            MaxWindSpeed = WINDSPEED_COUNT / 2;
        }
        else if(wtModerate == DWindType){
            ChangeProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.025));
            DirectionProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.025));
            SpeedProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.2));
            MinWindSpeed = 2;
            MaxWindSpeed = WINDSPEED_COUNT - 1;
        }
        else{
            ChangeProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.1));
            DirectionProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.1));
            SpeedProbability = ((unsigned int)(RANDOM_NUMBER_MAX * 0.3));
            MinWindSpeed = WINDSPEED_COUNT / 2;
            MaxWindSpeed = WINDSPEED_COUNT - 1;
        }
       
        //This code deals with changing wind velocity and direction from an RNG
        if((DRandomNumberGenerator.Random() % RANDOM_NUMBER_MAX) < ChangeProbability){
            unsigned int Dirchange = DRandomNumberGenerator.Random() % RANDOM_NUMBER_MAX;
            unsigned int SpeedChange = DRandomNumberGenerator.Random() % RANDOM_NUMBER_MAX;
            
            if(Dirchange < DirectionProbability){
                DWindDirection += WINDDIRECTION_COUNT-1;
                DWindDirection %= WINDDIRECTION_COUNT;
                if(!DWindDirection){
                    DWindDirection = WINDDIRECTION_COUNT-1;
                }
                WindDirectionChange = true;
            }
            else if(Dirchange < DirectionProbability * 2){
                DWindDirection++;
                DWindDirection %= WINDDIRECTION_COUNT; 
                if(!DWindDirection){
                    DWindDirection = 1;
                }
                WindDirectionChange = true;
            }
            if(SpeedChange < DirectionProbability){
                DWindSpeed += WINDSPEED_COUNT-1;
                DWindSpeed %= WINDSPEED_COUNT;
            }
            else if(SpeedChange < DirectionProbability * 2){
                DWindSpeed++;
                DWindSpeed %= WINDSPEED_COUNT;            
            }

        }
        if(!DWindDirection){
            DWindDirection = 1;
            WindDirectionChange = true;
        }
        if(DWindSpeed < MinWindSpeed){
            DWindSpeed = MinWindSpeed;
        }
        if(DWindSpeed > MaxWindSpeed){
            DWindSpeed = MaxWindSpeed;
        }
    }
    if(WindDirectionChange){
        for(int Index = 0; Index < D3DTerrainPixmaps.size(); Index++){
            DTerrainMap.Draw3DMap(D3DTerrainPixmaps[Index], DDrawingContext, DWindDirection, ANIMATION_TIMESTEPS, Index);
        }
    }
}

/**
 * This code deals with the options presented on screen. If the player is on the main menu, then it presents the player with
 * game choices like single player, multiplayer, etc. If they are on the options menu, then it presents different options like
 * sound and network for the player. If the player is in the battle mode it will tell the player to prepare for battle.
 * Etc
 */

void CApplicationData::ChangeMode(EGameMode nextmode){
    if(DGameMode == gmNetworkOptions){
        DNetwork->SetConnectionString(DServerConnectionString);
    }

    if(gmMainMenu == nextmode){
        DMenuTitle = "THE GAME";
        DMenuItems.clear();
        DMenuItems.push_back("SINGLE PLAYER");
        DMenuItems.push_back("MULTIPLAYER");
        DMenuItems.push_back("OPTIONS");
        DMenuItems.push_back("EXIT");
        DLastSelectedMenuItem = -1;
        DSoundMixer.PlaySong(DSongIndices[stMenu], DMusicVolume);
    }
    else if(gmOptionsMenu == nextmode){
        DMenuTitle = "OPTIONS";
        DMenuItems.clear();
        DMenuItems.push_back("SOUND");
        DMenuItems.push_back("NETWORK");
        DMenuItems.push_back("BACK");
        DLastSelectedMenuItem = -1;   
    }
    else if(gmNetworkOptions == nextmode){
        DServerConnectionString = DNetwork->GetConnectionString();
    }
    else if(gmLoginMenu == nextmode){
        DMenuTitle = "LOG IN";
        DMenuItems.clear();
        DMenuItems.push_back("USERNAME");
        DMenuItems.push_back("");
        DMenuItems.push_back("PASSWORD");
        DMenuItems.push_back("");
        DLastSelectedMenuItem = -1;
    }
    else if(gmMultiplayerMenu == nextmode){
        DMenuTitle = "SELECT GAME";
        DMenuItems.clear();
        DMenuItems.push_back("");
        DLastSelectedMenuItem = -1;
        DNetwork->GetRoomsAvailable();
    }
    else if(gmRoom == nextmode){
        DMenuTitle = "ROOM";
        DMenuItems.clear();
        DMenuItems.push_back("");
        DLastSelectedMenuItem = -1;
    }
    else if(gmBattle == nextmode){
        DVoiceClipID = -1;
        InitializeBanner("PREPARE FOR BATTLE");
        nextmode = gmTransitionBattle;
    }
    else if(gmSelectCastle == nextmode){
        InitializeBanner("SELECT CASTLE");
        nextmode = gmTransitionSelectCastle;
        DSoundMixer.StopSong();
    }
    else if(gmRebuild == nextmode){
        InitializeBanner("REBUILD WALLS TO STAY ALIVE");
        nextmode = gmTransitionRebuild;   
    }
    else if(gmCannonPlacement == nextmode){
        InitializeBanner("PLACE CANNONS");
        nextmode = gmTransitionCannonPlacement;
    }
    DNextGameMode = nextmode;
}

// This code will display the banner which is specified by Message
void CApplicationData::InitializeBanner(const std::string &message){
    gint BannerWidth, BannerHeight;
    
    DrawBanner(message);
    gdk_pixmap_get_size(DBannerPixmap, &BannerWidth, &BannerHeight); 
    DBannerLocation = -BannerHeight;
}

#define MAX_DELTAMOVE   3


 // This code will move the AI based on the color of the castle that is passed in as input
void CApplicationData::MoveAI(int colorindex){
    int DeltaX, DeltaY;
    
    DeltaX = DAITargetX[colorindex] - DCurrentX[colorindex];
    DeltaY = DAITargetY[colorindex] - DCurrentY[colorindex];
    if(-MAX_DELTAMOVE > DeltaX){
        DeltaX = -MAX_DELTAMOVE;  
    }
    if(MAX_DELTAMOVE < DeltaX){
        DeltaX = MAX_DELTAMOVE;  
    }
    if(-MAX_DELTAMOVE > DeltaY){
        DeltaY = -MAX_DELTAMOVE;  
    }
    if(MAX_DELTAMOVE < DeltaY){
        DeltaY = MAX_DELTAMOVE;  
    }
    DCurrentX[colorindex] += DeltaX;
    DCurrentY[colorindex] += DeltaY;
}

// This is AI code for the computer to select a castle
void CApplicationData::SelectCastleAI(){
    int SecondsLeft = SecondsUntilDeadline(DCurrentStageTimeout);
    int IncompleteCount = 0;
    
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(!DCompletedStage[ColorIndex]){
            IncompleteCount++;
        }    
    }
    
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(DPlayerIsAI[ColorIndex]){
            if(!DCompletedStage[ColorIndex]){
                if(0 > DAITargetX[ColorIndex]){
                    int TargetCastleIndex = ColorIndex % DCastleLocations[ColorIndex].size();
                    
                    DAITargetX[ColorIndex] = (DCastleLocations[ColorIndex][TargetCastleIndex].DXIndex + 1) * DTileWidth;
                    DAITargetY[ColorIndex] = (DCastleLocations[ColorIndex][TargetCastleIndex].DYIndex + 1) * DTileHeight;
                }
                MoveAI(ColorIndex);
                
                if((20 > SecondsLeft)||(1 == IncompleteCount)||((DAITargetX[ColorIndex] == DCurrentX[ColorIndex])&&(DAITargetY[ColorIndex] == DCurrentY[ColorIndex]))){
                    DLeftClick[ColorIndex] = true;
                }
            }
        }
    }
}

// This function chooses which tile the AI will place the cannon at
void CApplicationData::CannonPlacementAI(){
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(DPlayerIsAI[ColorIndex]){
            if(!DCompletedStage[ColorIndex]){
                if(0 > DAITargetX[ColorIndex]){
                    int XTile, YTile;
                    bool XDir, YDir;
                    XDir = DCannonsToPlace[ColorIndex] & 0x1;
                    YDir = DCannonsToPlace[ColorIndex] & 0x2;
                    XTile = DCurrentX[ColorIndex] / DTileWidth;
                    YTile = DCurrentY[ColorIndex] / DTileHeight;
                    BoundsCheck(XTile, YTile);
		    printf("hello\n");
                    getCannonLocs(ColorIndex, XTile, YTile, XDir, YDir, DMapWidth, DMapHeight);
		 
                }
                MoveAI(ColorIndex);
                if((DAITargetX[ColorIndex] == DCurrentX[ColorIndex])&&(DAITargetY[ColorIndex] == DCurrentY[ColorIndex])){
                    DLeftClick[ColorIndex] = true;
                    DAITargetX[ColorIndex] = -1;
                    DAITargetY[ColorIndex] = -1;
                }
            }
        }
    }
}

/**
 * This is the AI that determines how the computer will rebuild walls after they have
 * been destroyed by the player's cannons
 */
void CApplicationData::RebuildAI(){
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(DPlayerIsAI[ColorIndex]){
            bool DoMove = true;
            if((0 > DAITargetCastle[ColorIndex])||(DSurroundedCastles[ColorIndex][DAITargetCastle[ColorIndex]])){
                int TargetCastle = 0;
                int BestCastle = -1;
                int BestCannons = -1;

                while(TargetCastle < DSurroundedCastles[ColorIndex].size()){
                    if(!DSurroundedCastles[ColorIndex][TargetCastle]){
                        int CannonCount = 0;
                        std::vector< SMapLocation >::iterator Iterator;
    
                        Iterator = DCannonLocations[ColorIndex].begin();
                        while(DCannonLocations[ColorIndex].end() != Iterator){
                            int DeltaX = DCastleLocations[ColorIndex][TargetCastle].DXIndex - Iterator->DXIndex;
                            int DeltaY = DCastleLocations[ColorIndex][TargetCastle].DYIndex - Iterator->DYIndex;
                            
                            if((-2 <= DeltaX)&&(2 >= DeltaX)&&(-2 <= DeltaY)&&(2 >= DeltaY)){
                                CannonCount++;   
                            }
                            Iterator++;
                        }
                        if(BestCannons < CannonCount){
                            BestCastle = TargetCastle;   
                        }
                    }
                    TargetCastle++;
                }
                DAITargetCastle[ColorIndex] = BestCastle;
                DAITargetX[ColorIndex] = -1;
                DAITargetY[ColorIndex] = -1;
            }
            
            if(0 > DAITargetX[ColorIndex]){
                int XTile, YTile;
                int BestX, BestY, BestRotation, BestCoverage, BestInterference;

                if(0 > DAITargetCastle[ColorIndex]){
                    DAITargetX[ColorIndex] = DCastleLocations[ColorIndex][0].DXIndex;
                    DAITargetY[ColorIndex] = DCastleLocations[ColorIndex][0].DYIndex;
                    DAITargetX[ColorIndex] *= DTileWidth;
                    DAITargetX[ColorIndex] += DTileWidth / 2;
                    DAITargetY[ColorIndex] *= DTileHeight;
                    DAITargetY[ColorIndex] += DTileHeight / 2;
                }
                else{
                    XTile = DCastleLocations[ColorIndex][DAITargetCastle[ColorIndex]].DXIndex;
                    YTile = DCastleLocations[ColorIndex][DAITargetCastle[ColorIndex]].DYIndex;
                    
                    DTileWidth_rebuild = DTileWidth;
                    DTileHeight_rebuild = DTileHeight;
                    DMapHeight_rebuild = DMapHeight;
                    DMapWidth_rebuild = DMapWidth;  
                    LuaRef Best = findBestPlacement(ColorIndex, XTile, YTile);
                    BestX = Best["X"].cast<int>();
                    BestY = Best["Y"].cast<int>();
                    BestRotation = Best["Rotation"].cast<int>();
                    BestCoverage = Best["BCoverage"].cast<int>();
                    BestInterference = Best["BInterference"].cast<int>();
		    
                    if(0 > BestX){
                        DoMove = false;
                    }
                    else if(BestRotation){
                        DRightClick[ColorIndex] = true;
                        DoMove = false;
                    }
                    else{
                        DAITargetX[ColorIndex] = BestX;
                        DAITargetY[ColorIndex] = BestY;
                        DAITargetX[ColorIndex] *= DTileWidth;
                        DAITargetX[ColorIndex] += DTileWidth / 2;
                        DAITargetY[ColorIndex] *= DTileHeight;
                        DAITargetY[ColorIndex] += DTileHeight / 2;
                    }
                }
            }
            if(DoMove){
                MoveAI(ColorIndex);
            }
            if(!DRightClick[ColorIndex]&&(DAITargetX[ColorIndex] == DCurrentX[ColorIndex])&&(DAITargetY[ColorIndex] == DCurrentY[ColorIndex])){
                DLeftClick[ColorIndex] = true;
                DAITargetX[ColorIndex] = -1;
                DAITargetY[ColorIndex] = -1;
            }
        }
    }
}

// This is AI for the computer to select a location to fire it's cannon at
void CApplicationData::BattleAI(){
    for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
        if(DPlayerIsAI[ColorIndex]){
            if(DCannonsReady[2].size() > 0){
                if(0 > DAITargetX[ColorIndex]){
                    LuaRef coords = getxy();
                    int x = coords["xpos"].cast<int>();
                    int y = coords["ypos"].cast<int>();
                    //convert from squares to pixels
                    x *=12;
                    y *=12;
                    DAITargetX[ColorIndex] = x+6;
                    DAITargetY[ColorIndex] = y+6;
                }
                MoveAI(ColorIndex);
                if((DAITargetX[ColorIndex] == DCurrentX[ColorIndex])&&(DAITargetY[ColorIndex] == DCurrentY[ColorIndex])){
                    DLeftClick[ColorIndex] = true;
                    DAITargetX[ColorIndex] = -1;
                    DAITargetY[ColorIndex] = -1;
                }
            }
        }
    }
}

/**
 * This function checks which castles have been surrounded
 * If the castle is not surrounded, it is marked as unclaimed
 * If the castle is surrounded, it will color code the castle and surroundings
 * based on the user/computer's color
 */
void CApplicationData::CheckSurroundedCastles(){
    // Check surrounding
    for(int YPos = 0; YPos < DMapHeight; YPos++){
        for(int XPos = 0; XPos < DMapWidth; XPos++){
            if(!TileTypeIsWall(DConstructionTiles[YPos][XPos])){
                if(TileTypeIsFloorGroundDamaged(DConstructionTiles[YPos][XPos])){
                    switch(DTerrainMap.TileType(XPos, YPos)){
                        case pcBlue:    DConstructionTiles[YPos][XPos] = cttBlueFloorDamaged;
                                        break;
                        case pcRed:     DConstructionTiles[YPos][XPos] = cttRedFloorDamaged;
                                        break;
                        case pcYellow:  DConstructionTiles[YPos][XPos] = cttYellowFloorDamaged;
                                        break;
                        default:        DConstructionTiles[YPos][XPos] = cttNone;
                                        break;
                    }
                }
                else{
                    switch(DTerrainMap.TileType(XPos, YPos)){
                        case pcBlue:    DConstructionTiles[YPos][XPos] = cttBlueFloor;
                                        break;
                        case pcRed:     DConstructionTiles[YPos][XPos] = cttRedFloor;
                                        break;
                        case pcYellow:  DConstructionTiles[YPos][XPos] = cttYellowFloor;
                                        break;
                        default:        DConstructionTiles[YPos][XPos] = cttNone;
                                        break;
                    }
                }
            }
        }
    }
    for(int YPos = 0; YPos < DMapHeight; YPos++){
        for(int XPos = 0; XPos < DMapWidth; XPos++){
            if(!TileTypeIsWall(DConstructionTiles[YPos][XPos])){
                if(0 == XPos){
                    ExpandUnclaimed(XPos, YPos);
                }
                else if(0 == YPos){
                    ExpandUnclaimed(XPos, YPos); 
                }
                else if(XPos + 1 == DMapWidth){
                    ExpandUnclaimed(XPos, YPos);   
                }
                else if(YPos + 1 == DMapHeight){
                    ExpandUnclaimed(XPos, YPos);    
                }
                else if(cttNone == DConstructionTiles[YPos][XPos]){
                    ExpandUnclaimed(XPos, YPos);    
                }
            }
        }
    }
    for(int ColorIndex = pcBlue; ColorIndex < pcMax; ColorIndex++){
        for(int Index = 0; Index < DSurroundedCastles[ColorIndex].size(); Index++){
            DSurroundedCastles[ColorIndex][Index] = TileTypeIsFloor(DConstructionTiles[DCastleLocations[ColorIndex][Index].DYIndex][DCastleLocations[ColorIndex][Index].DXIndex]);
        }
    }
}

// This code checks to see if a cannon is placed on top of a castle's location
bool CApplicationData::CannonCastleInterfere(int xindex, int yindex, int width, int height){
    std::vector< SMapLocation >::iterator Iterator;
    
    if((2 == width)&&(2 == height)){
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            Iterator = DCannonLocations[ColorIndex].begin();
            while(DCannonLocations[ColorIndex].end() != Iterator){
                int XDelta, YDelta;
                XDelta = Iterator->DXIndex - xindex;
                XDelta = 0 > XDelta ? -XDelta : XDelta;
                YDelta = Iterator->DYIndex - yindex;
                YDelta = 0 > YDelta ? -YDelta : YDelta;
                if((XDelta < width)&&(YDelta < height)){
                    return true;
                }
                Iterator++;
            }
        
            Iterator = DCastleLocations[ColorIndex].begin();
            while(DCastleLocations[ColorIndex].end() != Iterator){
                int XDelta, YDelta;
                XDelta = Iterator->DXIndex - xindex;
                XDelta = 0 > XDelta ? -XDelta : XDelta;
                YDelta = Iterator->DYIndex - yindex;
                YDelta = 0 > YDelta ? -YDelta : YDelta;
                if((XDelta < width)&&(YDelta < height)){
                    return true;
                }
                Iterator++;
            }
        }
    }
    else{
        for(int ColorIndex = pcBlue; ColorIndex < pcBlue + DPlayerCount; ColorIndex++){
            Iterator = DCannonLocations[ColorIndex].begin();
            while(DCannonLocations[ColorIndex].end() != Iterator){
                if((xindex == Iterator->DXIndex)||(xindex == Iterator->DXIndex + 1)){
                    if((yindex == Iterator->DYIndex)||(yindex == Iterator->DYIndex + 1)){
                        return true;
                    }
                }
                Iterator++;
            }
            
            Iterator = DCastleLocations[ColorIndex].begin();
            while(DCastleLocations[ColorIndex].end() != Iterator){
                if((xindex == Iterator->DXIndex)||(xindex == Iterator->DXIndex + 1)){
                    if((yindex == Iterator->DYIndex)||(yindex == Iterator->DYIndex + 1)){
                        return true;
                    }
                }
                Iterator++;
            }
        }
    }
            
    return false;
}

// This code checks whether or not the cannon is placed in a valid tile
bool CApplicationData::ValidCannonPlacement(int colorindex, int xindex, int yindex){
    EConstructionTileType ConTileType;
    
    if(pcBlue == colorindex){
        ConTileType = cttBlueFloor;
    }
    else if(pcRed == colorindex){
        ConTileType = cttRedFloor;
    }
    else{
        ConTileType = cttYellowFloor;
    }
    if(xindex + 1 >= DMapWidth){
        return false;
    }
    if(yindex + 1 >= DMapHeight){
        return false;
    }
    for(int YOff = 0; YOff < 2; YOff++){
        for(int XOff = 0; XOff < 2; XOff++){
            if(ConTileType != DConstructionTiles[yindex + YOff][xindex + XOff]){
                return false;
            }
        }
    }
    return !CannonCastleInterfere(xindex, yindex, 2, 2);   
}

// This checks if the wall is placed in a valid tile
bool CApplicationData::ValidWallPlacement(int colorindex, int xindex, int yindex){
    int XPos, YPos;
    for(int WallYPos = 0; WallYPos < DWallShape[colorindex].Height(); WallYPos++){
        YPos = yindex + WallYPos;
        if(YPos >= DMapHeight){
            return false;   
        }
        for(int WallXPos = 0; WallXPos < DWallShape[colorindex].Width(); WallXPos++){
            XPos = xindex + WallXPos;
            if(XPos >= DMapWidth){
                return false;   
            }
            if(DWallShape[colorindex].IsBlock(WallXPos, WallYPos)){
                if(colorindex != DTerrainMap.TileType(XPos, YPos)){
                    return false;
                }
                if(TileTypeIsWall(DConstructionTiles[YPos][XPos])){
                    return false;
                }
                if(TileTypeIsFloor(DConstructionTiles[YPos][XPos])){
                    return false;
                }
                if(TileTypeIsFloorGroundDamaged(DConstructionTiles[YPos][XPos])){
                    return false;   
                }
                if(CannonCastleInterfere(XPos, YPos, 1, 1)){
                    return false;
                }
            }
        }
    }
    return true;
}

/**
 * Expands onto unclaimed land
 *
 * @param x,y Coordinates of the position where expansion outward is desired
 */
void CApplicationData::ExpandUnclaimed(int xpos, int ypos){
    bool NValid, EValid, SValid, WValid;
    
    if(TileTypeIsFloorGroundDamaged(DConstructionTiles[ypos][xpos])){
        DConstructionTiles[ypos][xpos] = cttGroundDamaged;
    }
    else{
        DConstructionTiles[ypos][xpos] = cttNone;
    }
    NValid = 0 < ypos;
    WValid = 0 < xpos;
    SValid = ypos + 1 < DMapHeight;
    EValid = xpos + 1 < DMapWidth;
    
    if(NValid){
        if(WValid){
            if(TileTypeIsFloor(DConstructionTiles[ypos-1][xpos-1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos-1][xpos-1])){
                ExpandUnclaimed(xpos-1, ypos-1);
            }
        }
        if(TileTypeIsFloor(DConstructionTiles[ypos-1][xpos])||TileTypeIsFloorDamaged(DConstructionTiles[ypos-1][xpos])){
            ExpandUnclaimed(xpos, ypos-1);
        }
        if(EValid){
            if(TileTypeIsFloor(DConstructionTiles[ypos-1][xpos+1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos-1][xpos+1])){
                ExpandUnclaimed(xpos+1, ypos-1);
            }
        }
    }
    if(WValid){
        if(TileTypeIsFloor(DConstructionTiles[ypos][xpos-1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos][xpos-1])){
            ExpandUnclaimed(xpos-1, ypos);
        }
    }
    if(EValid){
        if(TileTypeIsFloor(DConstructionTiles[ypos][xpos+1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos][xpos+1])){
            ExpandUnclaimed(xpos+1, ypos);
        }
    }
    if(SValid){
        if(WValid){
            if(TileTypeIsFloor(DConstructionTiles[ypos+1][xpos-1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos+1][xpos-1])){
                ExpandUnclaimed(xpos-1, ypos+1);
            }
        }
        if(TileTypeIsFloor(DConstructionTiles[ypos+1][xpos])||TileTypeIsFloorDamaged(DConstructionTiles[ypos+1][xpos])){
            ExpandUnclaimed(xpos, ypos+1);
        }
        if(EValid){
            if(TileTypeIsFloor(DConstructionTiles[ypos+1][xpos+1])||TileTypeIsFloorDamaged(DConstructionTiles[ypos+1][xpos+1])){
                ExpandUnclaimed(xpos+1, ypos+1);
            }
        }
    }

}


// Cleans up the wall edges that have been destroyed

bool CApplicationData::CleanUpWallEdges(){
    bool WallsRemoved = false;
    
    for(int YPos = 1; YPos + 1< DMapHeight; YPos++){
        for(int XPos = 1; XPos + 1 < DMapWidth; XPos++){
            if(TileTypeIsWall(DConstructionTiles[YPos][XPos])){
                int WallCount = 0, FloorCount = 0;
                bool RemoveWall = false;
                for(int YOff = -1; YOff < 2; YOff++){
                    for(int XOff = -1; XOff < 2; XOff++){
                        if(TileTypeIsWall(DConstructionTiles[YPos + YOff][XPos + XOff])){
                            WallCount++;   
                        }
                        else if(TileTypeIsFloor(DConstructionTiles[YPos + YOff][XPos + XOff])){
                            FloorCount++;   
                        }
                    }
                }
                if((1 == WallCount)&&(8 == FloorCount)){
                    RemoveWall = true;    
                }
                if((2 == WallCount)&&(7 == FloorCount)){
                    RemoveWall = true;    
                }
                if((3 == WallCount)&&(6 == FloorCount)){
                    if(!(TileTypeIsWall(DConstructionTiles[YPos - 1][XPos]) && TileTypeIsWall(DConstructionTiles[YPos + 1][XPos])) && !(TileTypeIsWall(DConstructionTiles[YPos][XPos - 1]) && TileTypeIsWall(DConstructionTiles[YPos][XPos + 1]))){
                        RemoveWall = true;    
                    }
                }
                if((4 == WallCount)&&(5 == FloorCount)){
                    if(!(TileTypeIsWall(DConstructionTiles[YPos - 1][XPos]) && TileTypeIsWall(DConstructionTiles[YPos + 1][XPos])) && !(TileTypeIsWall(DConstructionTiles[YPos][XPos - 1]) && TileTypeIsWall(DConstructionTiles[YPos][XPos + 1]))){
                        RemoveWall = true;    
                    }                    
                }
                
                if(RemoveWall){
                    WallsRemoved = true;
                    switch(DTerrainMap.TileType(XPos, YPos)){
                        case pcBlue:    DConstructionTiles[YPos][XPos] = cttBlueFloor;
                                        break;
                        case pcRed:     DConstructionTiles[YPos][XPos] = cttRedFloor;
                                        break;
                        case pcYellow:  DConstructionTiles[YPos][XPos] = cttYellowFloor;
                                        break;
                        default:        DConstructionTiles[YPos][XPos] = cttNone;
                                        break;
                    }
                }
            }
        }
    }
    return WallsRemoved;
}

/**
 * Checks if coordinates given are nonnegative or within the bounds of the map.
 *
 * @param x,y References to x and y coordinates
 * @return If the bounds are valid
 */
bool CApplicationData::BoundsCheck(int &xindex, int &yindex){
    bool ValidBounds = true;
    if(0 > xindex){
        xindex = 0; 
        ValidBounds = false;
    }
    if(DMapWidth <= xindex){
        xindex = DMapWidth - 1;
        ValidBounds = false;
    }
    if(0 > yindex){
        yindex = 0;
        ValidBounds = false;
    }
    if(DMapHeight <= yindex){
        yindex = DMapHeight - 1;
        ValidBounds = false;
    }
    return ValidBounds;
}

// Plays tick-tock sound if within threshold of stage timeout.

void CApplicationData::PlayTickTockSound(){
    int MSUntilDeadline = MiliSecondsUntilDeadline(DCurrentStageTimeout);
    int LastTickTockMS = -MiliSecondsUntilDeadline(DLastTickTockTime);
    bool PlaySound = false;
    bool PlayTick = true;
    
    if(5000 <= MSUntilDeadline){
        if((MSUntilDeadline/1000) != ((MSUntilDeadline + LastTickTockMS)/1000)){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/1000) & 0x01;
        }
    }
    else if(0 <= MSUntilDeadline){
        if((5000 < MSUntilDeadline + LastTickTockMS)||((MSUntilDeadline/500) != ((MSUntilDeadline + LastTickTockMS)/500))){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/500) & 0x01;
        }
    }
    else{
        if((0 < MSUntilDeadline + LastTickTockMS) ||((MSUntilDeadline/250) != ((MSUntilDeadline + LastTickTockMS)/250))){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/500) & 0x01;
        }
    }
    if(PlaySound){
        DSoundMixer.PlayClip(DSoundClipIndices[PlayTick ? sctTick : sctTock], DSoundEffectVolume, 0.0);
        gettimeofday(&DLastTickTockTime, NULL);
    }    
}

/**
 * Determines if a player has been conquered (lost the game).
 * Determines by examining how many surrounded castles still exist.
 * If there are no more castles for the player, the player is conquered.
 * @return Number of living players
 */
int CApplicationData::DetermineConquered(){
    int LivingPlayers = 0;
    
    for(int ColorIndex = 0; ColorIndex < pcMax; ColorIndex++){
        std::vector< bool >::iterator SurroundedIterator;
        int CurrentCastles = 0;
        
        SurroundedIterator = DSurroundedCastles[ColorIndex].begin();
        while(DSurroundedCastles[ColorIndex].end() != SurroundedIterator){
            if(*SurroundedIterator){
                CurrentCastles++;
            }
            SurroundedIterator++;
        }
        DSurroundedCastleCounts[ColorIndex] = CurrentCastles;
        if(CurrentCastles){
            DPlayerIsConquered[ColorIndex] = false;
            LivingPlayers++;
        }
        else{
            DPlayerIsConquered[ColorIndex] = true;       
        }
    }
    return LivingPlayers;
}


// Resets the map

void CApplicationData::ResetMap(){
    for(int Index = 0; Index < DConstructionTiles.size(); Index++){
        std::vector< EConstructionTileType >::iterator Iterator;
        std::vector< int >::iterator HitIterator;
        
        DConstructionTiles[Index].resize(DMapWidth);
        Iterator = DConstructionTiles[Index].begin();
        while(DConstructionTiles[Index].end() != Iterator){
            *Iterator = cttNone;
            Iterator++;
        }
        
        DHitsTaken[Index].resize(DMapWidth);
        HitIterator = DHitsTaken[Index].begin();
        while(DHitsTaken[Index].end() != HitIterator){
            *HitIterator = 0;
            HitIterator++;
        }
    }
    for(int ColorIndex = 0; ColorIndex < pcMax; ColorIndex++){
        DCannonLocations[ColorIndex].clear();
        DPlayerIsAI[ColorIndex] = true;   
        DAITargetX[ColorIndex] = -1;
        DAITargetY[ColorIndex] = -1;
        
        for(std::vector< bool >::iterator SurroundedIterator = DSurroundedCastles[ColorIndex].begin(); DSurroundedCastles[ColorIndex].end() != SurroundedIterator; SurroundedIterator++){
            *SurroundedIterator = false;
        }        
    }
    
    DNextGameMode = gmSelectCastle;
    for(int Index = 0; Index < pcMax; Index++){
        DCompletedStage[Index] = false;   
    }
    gettimeofday(&DCurrentStageTimeout,NULL);
    DCurrentStageTimeout.tv_sec += SELECT_TIME;
}

/**
 * Loads the desired map based on the index given.
 *
 * @param index 
 * @returns Exits if the index is negative or the index > terrain maps array size
 */
void CApplicationData::LoadTerrainMap(int index){
    if((0 > index)||(DTerrainMaps.size() <= index)){
        return;   
    }
    DTerrainMap = DTerrainMaps[index];

    DMapWidth = DTerrainMap.Width();
    DMapHeight = DTerrainMap.Height();
    DTileWidth = D2DTerrainTileset.TileWidth();
    DTileHeight = D2DTerrainTileset.TileHeight();
    DCanvasWidth = DMapWidth * DTileWidth;
    DCanvasHeight = DMapHeight * DTileHeight;
    
    ResizeCanvases();

    
    DInitialVelocities.resize(IntegerSquareRoot(DCanvasWidth * DCanvasWidth + DCanvasHeight * DCanvasHeight) + 1);
    for(int Index = 0; Index < DInitialVelocities.size(); Index++){
        DInitialVelocities[Index] = sqrt(STANDARD_GRAVITY * Index / 2);
    }

    DPlayerCount = DTerrainMap.PlayerCount();
    for(int Index = 0; Index < pcMax; Index++){
        DPlayerIsAlive[Index] = Index < DPlayerCount;   
        DSurroundedCastles[Index].clear();
        DCastleLocations[Index].clear();
    }
    for(int Index = 0; Index < DTerrainMap.CastleCount(); Index++){
        SMapLocation TempLocation;
            
        DTerrainMap.CastleLocation(Index, TempLocation.DXIndex, TempLocation.DYIndex);
        DSurroundedCastles[DTerrainMap.TileType(TempLocation.DXIndex, TempLocation.DYIndex)].push_back(false);
        DCastleLocations[DTerrainMap.TileType(TempLocation.DXIndex, TempLocation.DYIndex)].push_back(TempLocation);
    }
    DConstructionTiles.resize(DMapHeight);
    DHitsTaken.resize(DMapHeight);

    ResetMap();
    
    DTerrainMap.Draw2DMap(D2DTerrainPixmap, DDrawingContext);
    for(int Index = 0; Index < D3DTerrainPixmaps.size(); Index++){
        DTerrainMap.Draw3DMap(D3DTerrainPixmaps[Index], DDrawingContext, 0, ANIMATION_TIMESTEPS, Index);
    }
}


// Resizes the canvas

void CApplicationData::ResizeCanvases(){
    gtk_drawing_area_size(GTK_DRAWING_AREA(DDrawingArea), DCanvasWidth * DScaling, DCanvasHeight * DScaling);
    
    if(NULL != DDoubleBufferPixmap){
        gint CurWidth, CurHeight;
        
        gdk_pixmap_get_size(DDoubleBufferPixmap, &CurWidth, &CurHeight); 
        if((DCanvasWidth * DScaling != CurWidth)||(DCanvasHeight * DScaling != CurHeight)){
            g_object_unref(DDoubleBufferPixmap);
            DDoubleBufferPixmap = NULL;
        }
    }
    if(NULL == DDoubleBufferPixmap){
        DDoubleBufferPixmap = gdk_pixmap_new(DDrawingArea->window, DCanvasWidth * DScaling, DCanvasHeight * DScaling, -1);
    }
    if(NULL != DWorkingBufferPixmap){
        gint CurWidth, CurHeight;
        
        gdk_pixmap_get_size(DWorkingBufferPixmap, &CurWidth, &CurHeight); 
        if((DCanvasWidth != CurWidth)||(DCanvasHeight != CurHeight)){
            g_object_unref(DWorkingBufferPixmap);
            DWorkingBufferPixmap = NULL;
        }
    }
    if(NULL == DWorkingBufferPixmap){
        DWorkingBufferPixmap = gdk_pixmap_new(DDrawingArea->window, DCanvasWidth, DCanvasHeight, -1);
    }
    if(NULL != DPreviousWorkingBufferPixmap){
        gint CurWidth, CurHeight;
        
        gdk_pixmap_get_size(DPreviousWorkingBufferPixmap, &CurWidth, &CurHeight); 
        if((DCanvasWidth != CurWidth)||(DCanvasHeight != CurHeight)){
            g_object_unref(DPreviousWorkingBufferPixmap);
            DPreviousWorkingBufferPixmap = NULL;
        }
    }
    if(NULL == DPreviousWorkingBufferPixmap){
        DPreviousWorkingBufferPixmap = gdk_pixmap_new(DDrawingArea->window, DCanvasWidth, DCanvasHeight, -1);
    }
    if(NULL != DWorkingPixbuf){
        g_object_unref(DWorkingPixbuf);
        DWorkingPixbuf = NULL;
    }
    if(NULL != DBannerPixmap){
         g_object_unref(DBannerPixmap);
         DBannerPixmap = NULL;
    }
    if(NULL != DMessagePixmap){
         g_object_unref(DMessagePixmap);
         DMessagePixmap = NULL;
    }
    if(NULL != D2DTerrainPixmap){
        gint CurWidth, CurHeight;
        
        gdk_pixmap_get_size(D2DTerrainPixmap, &CurWidth, &CurHeight); 
        if((DCanvasWidth != CurWidth)||(DCanvasHeight != CurHeight)){
            g_object_unref(D2DTerrainPixmap);
            D2DTerrainPixmap = NULL;
        }
    }
    if(NULL == D2DTerrainPixmap){
        D2DTerrainPixmap = gdk_pixmap_new(DDrawingArea->window, DCanvasWidth, DCanvasHeight, -1);
    }
    while(D3DTerrainPixmaps.size() < ANIMATION_TIMESTEPS){
        D3DTerrainPixmaps.push_back(NULL);
    }
    for(int Index = 0; Index < D3DTerrainPixmaps.size(); Index++){
        if(NULL != D3DTerrainPixmaps[Index]){
            gint CurWidth, CurHeight;
            
            gdk_pixmap_get_size(D3DTerrainPixmaps[Index], &CurWidth, &CurHeight); 
            if((DCanvasWidth != CurWidth)||(DCanvasHeight != CurHeight)){
                g_object_unref(D3DTerrainPixmaps[Index]);
                D3DTerrainPixmaps[Index] = NULL;
            }
        }
        if(NULL == D3DTerrainPixmaps[Index]){
            D3DTerrainPixmaps[Index] = gdk_pixmap_new(DDrawingArea->window, DCanvasWidth, DCanvasHeight, -1);
        }   
    }
}

int CApplicationData::Init(int argc, char *argv[]){
    DIR *MapDirectory;
    struct dirent *DirectoryEntry;
    std::string MapPath = "maps";
    DPause = false;
    DNetworkGame = false;

    /** 
     * This is called in all GTK applications. 
     *
     * Arguments are parsed from the 
     * command line and are returned to the application. All GTK+ specific 
     * arguments are removed from the argc/argv list.
     */
    gtk_init(&argc, &argv);
    
    // Create a new main window.
    DMainWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    
    /** 
     * Allows GTK to know whether or not to keep a window open.
     *
     * See the MainWindowDeleteEventCallback function for more details.
     * When the window is given the "delete-event" signal (this is given by the 
     * window manager, usually by the "close" option, or on the titlebar), we 
     * ask it to call the delete_event () function as defined above. The data 
     * passed to the callback function is NULL and is ignored in the callback 
     * function. 
     */
    g_signal_connect(DMainWindow, "delete-event", G_CALLBACK(MainWindowDeleteEventCallback), this);
    
    /** 
     * Allows GTK to handle closing the main window.
     *
     * See the MainWindowDestroyCallback function for more details.
     * Here we connect the "destroy" event to a signal handler. This event 
     * occurs when we call gtk_widget_destroy() on the window, or if we return 
     * FALSE in the "delete-event" callback. 
     */
    g_signal_connect(DMainWindow, "destroy", G_CALLBACK(MainWindowDestroyCallback), this);
    
    // Allows GTK to handle keyboard inputs.
    g_signal_connect(DMainWindow, "key-press-event", G_CALLBACK(MainWindowKeyPressEventCallback), this);
    
    // Sets the border width of the window. 
    gtk_container_set_border_width(GTK_CONTAINER(DMainWindow), 10);
    
    // Creates a drawing surface.
    DDrawingArea = gtk_drawing_area_new();

    gtk_drawing_area_size(GTK_DRAWING_AREA(DDrawingArea), INITIAL_MAP_WIDTH, INITIAL_MAP_HEIGHT);
    
    // Add drawing surface to main window.
    gtk_container_add(GTK_CONTAINER(DMainWindow), DDrawingArea);
    
    // Signal connections that allow updates on and interactions with the main window.
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "expose_event", G_CALLBACK(DrawingAreaExposeCallback), this);
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "button_press_event", G_CALLBACK(DrawingAreaButtonPressEventCallback), this);
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "motion_notify_event", G_CALLBACK(DrawingAreaMotionNotifyEventCallback), this);

    // Describes what events the main window can receive.
    gtk_widget_set_events(DDrawingArea, GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK | GDK_POINTER_MOTION_MASK);

    // Makes cursor invisible over main window.
    DBlankCursor = gdk_cursor_new(GDK_BLANK_CURSOR);

    // Show all widgets so they are displayed.
    gtk_widget_show(DDrawingArea);
    gtk_widget_show(DMainWindow);
    
    gdk_window_set_cursor(DDrawingArea->window, DBlankCursor); 
    
    // MainData.DDrawingContext = gdk_gc_new(MainData.DDrawingArea->window);
    DDrawingContext = DDrawingArea->style->fg_gc[gtk_widget_get_state(DDrawingArea)];
    
    /**
     * The following if statements checks if all “.dat” files have loaded correctly.
     * Else returns error and ends the program.
     */
    if(!D2DTerrainTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/2DTerrain.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DTerrainTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DTerrain.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DFloorTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DFloor.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DWallTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DWall.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DCannonTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DCannon.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DCannonballTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DCannonball.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DExplosionTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DExplosion.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DBurnTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DBurn.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DCannonPlumeTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DCannonPlume.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D3DCastleTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/3DCastle.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D2DCastleCannonTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/2DCastleCannon.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }    
    if(!D2DCastleSelectTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/2DCastleSelect.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!D2DWallFloorTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/2DWallFloor.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DDigitTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/Digits.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DBrickTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/Bricks.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DMortarTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/Mortar.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DTargetTileset.LoadTileset(DDrawingArea->window, DDrawingContext, "data/Target.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DWhiteFont.LoadFont(DDrawingArea->window, DDrawingContext, "data/FontKingthingsWhite.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DBlackFont.LoadFont(DDrawingArea->window, DDrawingContext, "data/FontKingthingsBlack.dat")){
        printf("Failed to load tileset.\n");
        return -1;
    }
    if(!DSoundMixer.LoadLibrary("data/SoundClips.dat")){
        printf("Failed to load sound clips.\n");
        return -1;
    }

    // Sets the number of frames in certain animations.

    DExplosionSteps = D3DExplosionTileset.TileCount() / etMax;
    DBurnSteps = D3DBurnTileset.TileCount() / btMax;
    DCannonPlumeSteps = D3DCannonPlumeTileset.TileCount() / dMax;
    
    /**
     * The following initializes the D2D and D3D tile indices.
     * This allows GTK to find the right tile to display.
     */
    D2DCastleIndices[pcNone] = D2DCastleCannonTileset.FindTile("castle-none");
    D2DCastleIndices[pcBlue] = D2DCastleCannonTileset.FindTile("castle-blue");
    D2DCastleIndices[pcRed] = D2DCastleCannonTileset.FindTile("castle-red");
    D2DCastleIndices[pcYellow] = D2DCastleCannonTileset.FindTile("castle-yellow");
    D2DFloorIndices[pcNone] = D2DWallFloorTileset.FindTile("floor-even");
    D2DFloorIndices[pcBlue] = D2DWallFloorTileset.FindTile("floor-blue");
    D2DFloorIndices[pcRed] = D2DWallFloorTileset.FindTile("floor-red");
    D2DFloorIndices[pcYellow] = D2DWallFloorTileset.FindTile("floor-yellow");
    D2DWallIndices[pcNone] = D2DWallFloorTileset.FindTile("bad-0");
    D2DWallIndices[pcBlue] = D2DWallFloorTileset.FindTile("blue-0");
    D2DWallIndices[pcRed] = D2DWallFloorTileset.FindTile("red-0");
    D2DWallIndices[pcYellow] = D2DWallFloorTileset.FindTile("yellow-0");
    D2DWallIndices[pcMax] = D2DWallFloorTileset.FindTile("good-0");
    D2DWallIndices[pcMax+1] = D2DWallFloorTileset.FindTile("good-alt-0");
    D2DCannonIndices[pcNone] = D2DCastleCannonTileset.FindTile("cannon");
    D2DCannonIndices[pcBlue] = D2DCastleCannonTileset.FindTile("cannon-blue-1");
    D2DCannonIndices[pcRed] = D2DCastleCannonTileset.FindTile("cannon-red-1");
    D2DCannonIndices[pcYellow] = D2DCastleCannonTileset.FindTile("cannon-yellow-1");
    D2DSelectColorIndices[pcNone] = 0;
    D2DSelectColorIndices[pcBlue] = D2DCastleSelectTileset.FindTile("blue-0");
    D2DSelectColorIndices[pcRed] = D2DCastleSelectTileset.FindTile("red-0");
    D2DSelectColorIndices[pcYellow] = D2DCastleSelectTileset.FindTile("yellow-0");
    D2DDamagedGroundIndex = D2DTerrainTileset.FindTile("hole");
    
    D3DFloorIndices[pcNone] = 0;
    D3DFloorIndices[pcBlue] = D3DFloorTileset.FindTile("floor-blue");
    D3DFloorIndices[pcRed] = D3DFloorTileset.FindTile("floor-red");
    D3DFloorIndices[pcYellow] = D3DFloorTileset.FindTile("floor-yellow");
    
    D3DTargetIndices[pcNone] = 0;
    D3DTargetIndices[pcBlue] = DTargetTileset.FindTile("blue-target");
    D3DTargetIndices[pcRed] = DTargetTileset.FindTile("red-target");
    D3DTargetIndices[pcYellow] = DTargetTileset.FindTile("yellow-target");
    
    D3DCastleIndices[pcNone] = D3DCastleTileset.FindTile("castle-none");
    D3DCastleIndices[pcBlue] = D3DCastleTileset.FindTile("castle-blue-0");
    D3DCastleIndices[pcRed] = D3DCastleTileset.FindTile("castle-red-0");
    D3DCastleIndices[pcYellow] = D3DCastleTileset.FindTile("castle-yellow-0");

    D3DDamagedWallIndices[pcNone] = 0;
    D3DDamagedWallIndices[pcBlue] = D3DWallTileset.FindTile("blue-damaged-0");
    D3DDamagedWallIndices[pcRed] = D3DWallTileset.FindTile("red-damaged-0");
    D3DDamagedWallIndices[pcYellow] = D3DWallTileset.FindTile("yellow-damaged-0");
    for(int Index = 0; Index < 16; Index++){
        char Name[16];
        sprintf(Name,"blue-%d-0",Index);
        D3DWallIndices[pcNone][Index] = D3DWallTileset.FindTile(Name);
        D3DWallIndices[pcBlue][Index] = D3DWallTileset.FindTile(Name);
        sprintf(Name,"red-%d-0",Index);
        D3DWallIndices[pcRed][Index] = D3DWallTileset.FindTile(Name);
        sprintf(Name,"yellow-%d-0",Index);
        D3DWallIndices[pcYellow][Index] = D3DWallTileset.FindTile(Name);
        
    }
    D3DDamagedGroundIndex = D3DTerrainTileset.FindTile("hole-0");
    
    D3DExplosionIndices[etWallExplosion0] = D3DExplosionTileset.FindTile("explosion-0");
    D3DExplosionIndices[etWallExplosion1] = D3DExplosionTileset.FindTile("explosion-alt-0");
    D3DExplosionIndices[etWaterExplosion0] = D3DExplosionTileset.FindTile("water-explosion-0");
    D3DExplosionIndices[etWaterExplosion1] = D3DExplosionTileset.FindTile("water-explosion-alt-0");
    D3DExplosionIndices[etGroundExplosion0] = D3DExplosionTileset.FindTile("ground-explosion-0");
    D3DExplosionIndices[etGroundExplosion1] = D3DExplosionTileset.FindTile("ground-explosion-alt-0");

    D3DBurnIndices[btRubbleBurn0] = D3DBurnTileset.FindTile("rubbleburn-0");
    D3DBurnIndices[btRubbleBurn1] = D3DBurnTileset.FindTile("rubbleburn-alt-0");
    D3DBurnIndices[btHoleBurn0] = D3DBurnTileset.FindTile("holeburn-0");
    D3DBurnIndices[btHoleBurn1] = D3DBurnTileset.FindTile("holeburn-alt-0");
    
    D3DCannonPlumeIndices[dNorth] = D3DCannonPlumeTileset.FindTile("north-0");
    D3DCannonPlumeIndices[dNorthEast] = D3DCannonPlumeTileset.FindTile("northeast-0");
    D3DCannonPlumeIndices[dEast] = D3DCannonPlumeTileset.FindTile("east-0");
    D3DCannonPlumeIndices[dSouthEast] = D3DCannonPlumeTileset.FindTile("southeast-0");
    D3DCannonPlumeIndices[dSouth] = D3DCannonPlumeTileset.FindTile("south-0");
    D3DCannonPlumeIndices[dSouthWest] = D3DCannonPlumeTileset.FindTile("southwest-0");
    D3DCannonPlumeIndices[dWest] = D3DCannonPlumeTileset.FindTile("west-0");
    D3DCannonPlumeIndices[dNorthWest] = D3DCannonPlumeTileset.FindTile("northwest-0");
    
    /**
     * The following initializes the sound indices.
     * This allows GTK to find the right sound to play.
     */
    DSoundClipIndices[sctTick] = DSoundMixer.FindClip("tick");
    DSoundClipIndices[sctTock] = DSoundMixer.FindClip("tock");
    DSoundClipIndices[sctCannon0] = DSoundMixer.FindClip("cannon0");
    DSoundClipIndices[sctCannon1] = DSoundMixer.FindClip("cannon1");
    DSoundClipIndices[sctPlace] = DSoundMixer.FindClip("place");
    DSoundClipIndices[sctTriumph] = DSoundMixer.FindClip("triumph");
    DSoundClipIndices[sctExplosion0] = DSoundMixer.FindClip("explosion0");
    DSoundClipIndices[sctExplosion1] = DSoundMixer.FindClip("explosion1");
    DSoundClipIndices[sctExplosion2] = DSoundMixer.FindClip("explosion2");
    DSoundClipIndices[sctExplosion3] = DSoundMixer.FindClip("explosion3");
    DSoundClipIndices[sctGroundExplosion0] = DSoundMixer.FindClip("groundexplosion0");
    DSoundClipIndices[sctGroundExplosion1] = DSoundMixer.FindClip("groundexplosion1");
    DSoundClipIndices[sctWaterExplosion0] = DSoundMixer.FindClip("waterexplosion0");
    DSoundClipIndices[sctWaterExplosion1] = DSoundMixer.FindClip("waterexplosion1");
    DSoundClipIndices[sctWaterExplosion2] = DSoundMixer.FindClip("waterexplosion2");
    DSoundClipIndices[sctWaterExplosion3] = DSoundMixer.FindClip("waterexplosion3");
    DSoundClipIndices[sctReady] = DSoundMixer.FindClip("ready");
    DSoundClipIndices[sctAim] = DSoundMixer.FindClip("aim");
    DSoundClipIndices[sctFire] = DSoundMixer.FindClip("fire");
    DSoundClipIndices[sctCeasefire] = DSoundMixer.FindClip("ceasefire");
    DSoundClipIndices[sctTransition] = DSoundMixer.FindClip("transition");
    
    DSongIndices[stLoss] = DSoundMixer.FindSong("loss");
    DSongIndices[stWin] = DSoundMixer.FindSong("win");
    DSongIndices[stMenu] = DSoundMixer.FindSong("menu");
    DSongIndices[stRebuild] = DSoundMixer.FindSong("rebuild");
    DSongIndices[stPlace] = DSoundMixer.FindSong("place");
    
    /**
     * The following initializes brick tile indices.
     * This allows the GTK to find the right brick tile to display.
     */
    DBrickIndices[bbtTopCenter] = DBrickTileset.FindTile("brick-tc");
    DBrickIndices[bbtTopRight] = DBrickTileset.FindTile("brick-tr");
    DBrickIndices[bbtRight0] = DBrickTileset.FindTile("brick-r0");
    DBrickIndices[bbtRight1] = DBrickTileset.FindTile("brick-r1");
    DBrickIndices[bbtBottomRight] = DBrickTileset.FindTile("brick-br");
    DBrickIndices[bbtBottomCenter] = DBrickTileset.FindTile("brick-bc");
    DBrickIndices[bbtBottomLeft] = DBrickTileset.FindTile("brick-bl");
    DBrickIndices[bbtLeft0] = DBrickTileset.FindTile("brick-l0");
    DBrickIndices[bbtLeft1] = DBrickTileset.FindTile("brick-l1");
    DBrickIndices[bbtTopLeft] = DBrickTileset.FindTile("brick-tl");
    DBrickIndices[bbtSingle] = DBrickTileset.FindTile("brick-single");
    
    /**
     * The following initializes mortar tile indices.
     * This allows the GTK to find the right mortar tile to display.
     */
    DMortarIndices[bmtTopCenter] = DMortarTileset.FindTile("mortar-tc");
    DMortarIndices[bmtTopRight0] = DMortarTileset.FindTile("mortar-tr0");
    DMortarIndices[bmtTopRight1] = DMortarTileset.FindTile("mortar-tr1");
    DMortarIndices[bmtTopRight2] = DMortarTileset.FindTile("mortar-tr2");
    DMortarIndices[bmtTopLeft0] = DMortarTileset.FindTile("mortar-tl0");
    DMortarIndices[bmtTopLeft1] = DMortarTileset.FindTile("mortar-tl1");
    DMortarIndices[bmtTopLeft2] = DMortarTileset.FindTile("mortar-tl2");
    DMortarIndices[bmtBottomCenter] = DMortarTileset.FindTile("mortar-bc");
    DMortarIndices[bmtBottomRight0] = DMortarTileset.FindTile("mortar-br0");
    DMortarIndices[bmtBottomRight1] = DMortarTileset.FindTile("mortar-br1");
    DMortarIndices[bmtBottomRight2] = DMortarTileset.FindTile("mortar-br2");
    DMortarIndices[bmtBottomLeft0] = DMortarTileset.FindTile("mortar-bl0");
    DMortarIndices[bmtBottomLeft1] = DMortarTileset.FindTile("mortar-bl1");
    DMortarIndices[bmtBottomLeft2] = DMortarTileset.FindTile("mortar-bl2");
    DMortarIndices[bmtRightCenter] = DMortarTileset.FindTile("mortar-rc");
    DMortarIndices[bmtRightBottom0] = DMortarTileset.FindTile("mortar-rb0");
    DMortarIndices[bmtRightBottom1] = DMortarTileset.FindTile("mortar-rb1");
    DMortarIndices[bmtRightBottom2] = DMortarTileset.FindTile("mortar-rb2");
    DMortarIndices[bmtRightTop0] = DMortarTileset.FindTile("mortar-rt0");
    DMortarIndices[bmtRightTop1] = DMortarTileset.FindTile("mortar-rt1");
    DMortarIndices[bmtRightTop2] = DMortarTileset.FindTile("mortar-rt2");
    DMortarIndices[bmtLeftCenter] = DMortarTileset.FindTile("mortar-lc");
    DMortarIndices[bmtLeftBottom0] = DMortarTileset.FindTile("mortar-lb0");
    DMortarIndices[bmtLeftBottom1] = DMortarTileset.FindTile("mortar-lb1");
    DMortarIndices[bmtLeftBottom2] = DMortarTileset.FindTile("mortar-lb2");
    DMortarIndices[bmtLeftTop0] = DMortarTileset.FindTile("mortar-lt0");
    DMortarIndices[bmtLeftTop1] = DMortarTileset.FindTile("mortar-lt1");
    DMortarIndices[bmtLeftTop2] = DMortarTileset.FindTile("mortar-lt2");
    
    // Opens game maps directory.
    MapDirectory = opendir(MapPath.c_str());

    // Checks if game maps directory opened correctly.
    if(NULL == MapDirectory){
        printf("Failed to open directory.\n");
        return -1;
    }

    // While loop to load all map files
    while((DirectoryEntry = readdir( MapDirectory ))){
        std::string Filename = MapPath + "/";
        Filename += DirectoryEntry->d_name;
        if(Filename.rfind(".map") == (Filename.length() - 4)){
            CTerrainMap TempMap;
            
            /**
             * Checks if the map loaded correctly. 
             * If not, go to next map file.
             */
            if(!TempMap.LoadMap(&D2DTerrainTileset, &D3DTerrainTileset, Filename)){
                printf("Failed to load map \"%s\".\n",Filename.c_str());
                continue;
            }
            DTerrainMaps.push_back(TempMap);
        }
    }

    // Close the game maps directory.
    closedir(MapDirectory);

    // If no maps were loaded, exit the app.
    if(0 == DTerrainMaps.size()){
        printf("No maps loaded.\n");
        return 0;
    }

    // Initializes window size scaling to 1.
    DScaling = 1;
    
    // Loads the main menu.
    LoadTerrainMap(0);
    ChangeMode(gmMainMenu);
    DrawMenu();
    
    // gdk draw functions for generating window contents.
    gdk_draw_pixmap(DPreviousWorkingBufferPixmap, DDrawingContext, DWorkingBufferPixmap, 0, 0, 0, 0, -1, -1);
    gdk_draw_pixmap(DDoubleBufferPixmap, DDrawingContext, DWorkingBufferPixmap, 0, 0, 0, 0, -1, -1);
    gdk_draw_pixmap(DDrawingArea->window, DDrawingContext, DDoubleBufferPixmap, 0, 0, 0, 0, -1, -1);

    /**
     * Sets up the amount of time to wait before recalling timeoutCallBack.
     *
     * See https://developer.gnome.org/glib/stable/glib-The-Main-Event-Loop.html#g-timeout-add
     * for more documentation.
     */
    gettimeofday(&DNextExpectedTimeout, NULL);
    DNextExpectedTimeout.tv_usec += TIMEOUT_INTERVAL * 1000;
    if(1000000 <= DNextExpectedTimeout.tv_usec){
        DNextExpectedTimeout.tv_usec %= 1000000;
        DNextExpectedTimeout.tv_sec++;
    }
    g_timeout_add(TIMEOUT_INTERVAL, TimeoutCallback, this);

    /**
     * All GTK applications must have a gtk_main(). Control ends here and waits 
     * for an event to occur (like a key press or mouse event). 
     */
    gtk_main ();
    return 0;
}



CApplicationData MainData;

void init_lua(){
  //load the library
  luaL_openlibs(L);
  
  //load the scripts
  luaL_dofile(L, "castle_select.lua");
  luaL_dofile(L, "battle_ai.lua");
  luaL_dofile(L, "cannon_placement_ai.lua");
  luaL_dofile(L, "rebuild_ai.lua");
  
  //register C++ functions & variables
  
  getGlobalNamespace(L)
    .beginNamespace("test")
	  .addFunction ("getWallType",getWallType)
	  .addFunction("getshotat",getshotat)
	  .addFunction("setshotat",setshotat)
    .addFunction("isValidCannonLoc", isValidCannonLoc)
    .addFunction("setDAITarget", setDAITarget)
    .addFunction("getDAITargetX", getDAITargetX)
    .addFunction("getWallShapeHeight", getWallShapeHeight)
    .addFunction("getWallShapeWidth", getWallShapeWidth)
    .addFunction("getWallShapeIsBlock", getWallShapeIsBlock)
    .addFunction("getValidWallPlacement", getValidWallPlacement)
    .addFunction("rotateWallShape", rotateWallShape) 
    .addVariable("difficultyLevel",&difficultyLevel)
    .addVariable("DTileWidth_rebuild",&DTileWidth_rebuild)
    .addVariable("DTileHeight_rebuild",&DTileHeight_rebuild)
    .addVariable("DMapHeight_rebuild",&DMapHeight_rebuild)
    .addVariable("DMapWidth_rebuild",&DMapWidth_rebuild)
    .endNamespace();
  
  getxy = getGlobal(L, "getxy");
  getCannonLocs = getGlobal(L, "getCannonLocs");
  findBestPlacement = getGlobal(L, "findBestPlacement");
  
}

//AI Function CODE

int CApplicationData::getWallType(int x, int y){
   return DConstructionTiles[y][x];
}
int getWallType(int x, int y){
   return MainData.getWallType(x,y);
}

bool CApplicationData::isValidCannonLoc(int colorindex, int xindex, int yindex) {
   return ValidCannonPlacement(colorindex, xindex, yindex);
}
bool isValidCannonLoc(int colorindex, int xindex, int yindex){
    return MainData.isValidCannonLoc(colorindex, xindex, yindex);
}
    
void CApplicationData::setDAITarget(int colorindex, int xval, int yval) {
   DAITargetX[colorindex] = xval;
   DAITargetY[colorindex] = yval;
}
void setDAITarget(int colorindex, int xval, int yval) {
    MainData.setDAITarget(colorindex, xval, yval);
}
    
int CApplicationData::getDAITargetX(int colorindex) {
   return DAITargetX[colorindex];
}
int getDAITargetX(int colorindex) {
   return MainData.getDAITargetX(colorindex);
}

int CApplicationData::getWallShapeHeight(int ColorIndex) {
   return DWallShape[ColorIndex].Height();
}

int getWallShapeHeight(int colorindex) {
   return MainData.getWallShapeHeight(colorindex);
}

int CApplicationData::getWallShapeWidth(int ColorIndex) {
   return DWallShape[ColorIndex].Width();
}

int getWallShapeWidth(int ColorIndex) {
   return MainData.getWallShapeWidth(ColorIndex);
}

bool CApplicationData::getWallShapeIsBlock(int ColorIndex, int WallXPos, int WallYPos) {
   return DWallShape[ColorIndex].IsBlock(WallXPos, WallYPos);
}

bool getWallShapeIsBlock(int ColorIndex, int WallXPos, int WallYPos) {
   return MainData.getWallShapeIsBlock(ColorIndex, WallXPos, WallYPos);
}

bool CApplicationData::getValidWallPlacement(int ColorIndex, int TargetX, int TargetY) {
   return ValidWallPlacement(ColorIndex, TargetX, TargetY);
}

bool getValidWallPlacement(int ColorIndex, int TargetX, int TargetY) {
   return MainData.getValidWallPlacement(ColorIndex, TargetX, TargetY);
}

void CApplicationData::rotateWallShape(int ColorIndex) {
   DWallShape[ColorIndex].Rotate();
}

void rotateWallShape(int ColorIndex) {
   MainData.rotateWallShape(ColorIndex);
}

int getshotat(int x, int y){
   return shotatrecord[x][y];
}
void setshotat(int x, int y){
   shotatrecord[x][y] = 1;
}

void resetshotat(){
    for(int i = 0 ; i < 40; i++)
      for(int j = 0; j < 24; j++)
	  shotatrecord[i][j]=0;
}


int main(int argc, char *argv[]){

    // Create app object.
    
    difficultyLevel = 3; // 1 = easy, 2 = medium, 3 = hard
  
    int ReturnValue;
    

    printf("Copyright (c) 2015, Christopher Nitta\n");
    printf("All rights reserved.\n\n");
    printf("All source material (source code, images, sounds, etc.) have been provided to\n");
    printf("University of California, Davis students of course ECS 160 for educational\n");
    printf("purposes. It may not be distributed beyond those enrolled in the course without\n"); 
    printf("prior permission from the copyright holder.\n\n");          
    printf("Some sound files, sound fonts, and midi files have been included that were\n");
    printf("freely available via internet sources. They have been included in this\n");
    printf("distribution for educational purposes only and this copyright notice does not\n"); 
    printf("attempt to claim any ownership of this material.\n");
    
    // Initializes and runs the app.
    ReturnValue = MainData.Init(argc, argv);

    return ReturnValue;
}

