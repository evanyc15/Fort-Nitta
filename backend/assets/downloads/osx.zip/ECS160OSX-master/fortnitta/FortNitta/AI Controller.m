//
//  AI Controller.m
//  FortNitta
//
//  Created by Alexander Sergian on 2/25/15.
//  Copyright (c) 2015 OSX Team. All rights reserved.
//

#import "AI Controller.h"
#import "GameScene.h"
#import "RebuildMode.h"
#define tileEdge 24

int xPos;
int yPos;
int aiCheckArray[26][42] = {0};
int aiCastleXCoordinate[] = {5, 8, 6, 15, 25, 37, 36, 36, 26, 18};
int aiCastleYCoordinate[] = {7, 13, 19, 19, 18, 20, 12, 6, 7, 6};
int castleIndex;
BOOL notFilled = 1;

@implementation AI_Controller

- (id) init : (int) AI_difficulty {
    self = [super init];
    if (self) {
        // initialize Lua and load our lua libraries
        L = luaL_newstate(); // create a new state structure for the interpreter
        luaL_openlibs(L); // load all the basic libraries into the interpreter
        difficulty = AI_difficulty;
    }
    return self;
} // init()


-(void)unselectedCastle{;
    
    //Clears unselectedCastle array
    for (int i = 0; i < 5; i++) {
        unselectedCastles[i].DX =  0;
        unselectedCastles[i].DY =  0;
    }
    
    if (aiControllerColor == 3) {
        castleIndex = 5;
    } else if (aiControllerColor == 4){
        castleIndex = 0;
    }
    
    for (int i = 0; i < 5; i++) {
        if (mapTiles[26-aiCastleYCoordinate[i+castleIndex]][aiCastleXCoordinate[i+castleIndex]] != aiControllerColor) {
            unselectedCastles[i].DX =  aiCastleXCoordinate[i+castleIndex];
            unselectedCastles[i].DY =  aiCastleYCoordinate[i+castleIndex];
        } else {
            //If castle is surrounded set x and y of struct == 0
            unselectedCastles[i].DX =  0;
            unselectedCastles[i].DY =  0;
        }
    }
}



-(int) get_AI_castle {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"castle_select" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    
    // put the pointer to the lua function we want on top of the stack
    lua_getglobal(L,"getCastleLocation");
    
    // call the function on top of thestack
    err = lua_pcall(L, 0, 1, 0);
    int number = lua_tonumber(L, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
        return 0;
    } // if: print out errors, if any
    
    return number;
} // get_AI_castle()



//-(void) place_cannons: (int*) number : (int) mapWidth : (int) mapHeight : (int*) x : (int*) y {
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//    [self place_cannon: number: mapWidth: mapHeight: x: y];
//}



-(void) place_cannon: (int*) aiColor : (int) mapWidth : (int) mapHeight : (int*) x : (int*) y {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"cannon_placement_ai" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    
    // put the pointer to the lua function we want on top of the stack
    lua_getglobal(L,"getCannonLocs");
    
    int colorIndex = *aiColor;
    int xTile = 0;
    int yTile = 0;
    int xDir = -1; // scan horizontally to the right (wraps around)
    int yDir = 1; // scan vertically downwards (wraps around)
    
    lua_pushnumber(L, colorIndex);
    lua_pushnumber(L, xTile);
    lua_pushnumber(L, yTile);
    lua_pushnumber(L, xDir);
    lua_pushnumber(L, yDir);
    lua_pushnumber(L, mapWidth);  // 42 (2 are gray border tiles)
    lua_pushnumber(L, mapHeight); // 26 (2 are gray border tiles)
    
    // call the function on top of thestack
    err = lua_pcall(L, 7, 0, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
        return;
    } // if: print out errors, if any
    
    //*number = [self get_AI_castle] + 5;
    *x = xPos;
    *y = yPos;
    
    /*while (*x == 0 && *y == 0) {
        *x = arc4random_uniform(3) - 1;
        *y = arc4random_uniform(3) - 1;
    } */// while: avoid the center (castle center is there)
    
    //*number = arc4random_uniform(5) + 5;
} // place_cannon()



-(void) battle_mode: (int*) x : (int*) y {
    lua_settop(L, 0); // reset stack
    
    NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"battle_ai" ofType:@"lua"];
    int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    lua_getglobal(L,"getxy"); // get LUA function
    
    int colorIndex = 0;
    lua_pushnumber(L, colorIndex);
    lua_pushnumber(L, difficulty);
    
    // call the function you just got
    err = lua_pcall(L, 2, 1, 0);
    
    if (0 != err) {
        luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
    } // if: print out errors, if any
    
    int top = lua_gettop(L);
    int coord[2];
    int index = 0;
    
    /* table is in the stack at index 't' */
    lua_pushnil(L);  /* first key */
    
    /* uses 'key' (at index -2) and 'value' (at index -1) */
    while (lua_next(L, top) != 0) {
        coord[index] = (int) lua_tonumber(L, -1);
        
        lua_pop(L, 1);
        index++;
    } // while: iterate through table and grab the x/y coordinates to fire
    
    
    *x = coord[0];
    *y = coord[1];
} // battle_mode()



-(bool) rebuild: (int) mapWidth : (int) mapHeight : (int*) x : (int*) y {
    int framelimit = 10;
    int framecount = 0;
    
    if(framecount >= framelimit)
    {
        framecount = 0;
        bool DoMove = true;
        [self unselectedCastle];
        struct SInt2 bestpos;
        int mostwalls = 0;
        
        for(int index = 0; index < 5; index++) {
            if (unselectedCastles[index].DX == 0 && unselectedCastles[index].DY == 0)
                continue;
            
            //set the initial wall to check (upper left corner)
            struct SInt2 pos = unselectedCastles[index];
            pos.DX = pos.DX - 3;
            pos.DY = pos.DY - 3;

            int xdir,ydir;
            xdir = 0;
            int wallcount = 0;
            
            //this for loop will check each tiletype in a "radius" of 2 from the given castle
            for(int i=1; i <=4; i++) {
                if(i==1)     {xdir=1; ydir=0;}
                else if(i==2){xdir=0; ydir=1;}
                else if(i==3){xdir=-1; ydir=0;}
                else if(i==4){xdir=0; ydir=-1;}
                for(int j =1; j<=8; j++) {
                    pos.DX = pos.DX + xdir;
                    pos.DY = pos.DY + ydir;

                    if(mapTiles[pos.DY][pos.DX] == 1) {
                        wallcount++;
                    } // if the tile is a wall, add to count
                } // for each tile in the radius
            } // for each direction
            if(wallcount >= mostwalls) {
                bestpos = pos;
                mostwalls = wallcount;
            } // if: update best castle if necessary
        } // for each castle, count number of walls within radius
        
        //DCursorPosition.DX = -1;
        //DCursorPosition.DY = -1;
        
        int xTile, yTile;
        int BestX, BestY, BestRotation, BestCoverage, BestInterference;
        
        
        xTile = bestpos.DX;
        yTile = bestpos.DY;
        
        int mapHeight = 26;
        int mapWidth = 42;
        
        lua_settop(L, 0); // reset stack
        NSString *luaFilePath = [[NSBundle mainBundle] pathForResource:@"rebuild_ai" ofType:@"lua"];
        int err = luaL_dofile(L, [luaFilePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
        lua_getglobal(L,"findBestPlacement"); // get LUA function
        
        int colorIndex = 0;
        
        lua_pushnumber(L, colorIndex);
        lua_pushnumber(L, xTile);
        lua_pushnumber(L, yTile);
        lua_pushnumber(L, difficulty);
        lua_pushnumber(L, mapWidth);
        lua_pushnumber(L, mapHeight);
        
        err = lua_pcall(L, 6, 1, 0);
        
        if (0 != err) {
            luaL_error(L, "cannot run lua file: %s", lua_tostring(L, -1));
        } // if: print out errors, if any
        
        int top = lua_gettop(L);
        int best[5];
        int index = 0;
        
        /* table is in the stack at index 't' */
        lua_pushnil(L);  /* first key */
        
        /* uses 'key' (at index -2) and 'value' (at index -1) */
        while (lua_next(L, top) != 0) {
            best[index] = (int) lua_tonumber(L, -1);
            
            lua_pop(L, 1);
            index++;
        } // while: iterate through table and grab the x/y coordinates to fire

        BestX = best[0];
        BestY = best[1];
        BestRotation = best[2];
        BestCoverage = best[3];
        BestInterference = best[4];

        if(0 > BestX){
            DoMove = false;
        }
//        else if(BestRotation){
//            //RotateWall(game);
//            return false;
//        }
        else {
            /*DCursorPosition.DX = BestX * 40 + 6;
            DCursorPosition.DY = BestY * 24 + 6;
            DCursorTilePosition.DX = BestX;
            DCursorTilePosition.DY = BestY;
         
            return (DWallShape.Place(game, this, DCursorTilePosition));*/
            *x = BestX;
            *y = BestY;
            return 1;
        }
    } // if we haven't waited "10 frames"
    else
        framecount++;
    
    return false;
} // rebuild()



/* DEBUG FUNCTION: Prints out Stack Contents */

-(void) stackdump_g {
    int i;
    int top = lua_gettop(L);
    
    printf("total in stack %d\n",top);
    
    for (i = 1; i <= top; i++)
    {  /* repeat for each level */
        int t = lua_type(L, i);
        switch (t) {
            case LUA_TSTRING:  /* strings */
                printf("string: '%s'\n", lua_tostring(L, i));
                break;
            case LUA_TBOOLEAN:  /* booleans */
                printf("boolean %s\n",lua_toboolean(L, i) ? "true" : "false");
                break;
            case LUA_TNUMBER:  /* numbers */
                printf("number: %g\n", lua_tonumber(L, i));
                break;
            default:  /* other values */
                printf("%s\n", lua_typename(L, t));
                break;
        } // switch(L)
        printf("  ");  /* put a separator */
    } // for each element in the stack
    printf("\n");  /* end the listing */
} // stackdump_g

@end



/*
 * Functions called by LUA file
 * They must be global for LUA to find them
 */

static int numberCastleLocations(lua_State *L){
    int numberCastleLocations = 5;
    lua_pushnumber(L, numberCastleLocations);
    
    return 1;
} // numberCastleLocations()



static int isValidCannonLoc(lua_State *L) {
    int colorIndex = lua_tonumber(L, 1);
    int xAttempt = lua_tonumber(L, 2);
    int yAttempt = lua_tonumber(L, 3);
    
    if(notFilled){
        
        for (int i = 0; i < 10; i++) {
            aiCheckArray[25-aiCastleYCoordinate[i]][aiCastleXCoordinate[i]] = 1;
            aiCheckArray[25-aiCastleYCoordinate[i]][aiCastleXCoordinate[i]-1] = 1;
            aiCheckArray[25-aiCastleYCoordinate[i]+1][aiCastleXCoordinate[i]] = 1;
            aiCheckArray[25-aiCastleYCoordinate[i]+1][aiCastleXCoordinate[i]-1] = 1;
        }
//        printf("mapTiles\n");
//        for(int i = 0;i<26;i++){
//            for(int j = 0; j<42;j++){
//                //NSLog(@"%lu ", (unsigned long)mapTiles[i][j]);
//                printf("%lu ", (unsigned long)aiCheckArray[i][j]);
//                //printf("%lu ", (unsigned long)fillArr[i][j]);
//            }
//            //NSLog(@"\n");
//            printf("\n");
//        }
        notFilled = 0;
    }
    
    if(mapTiles[yAttempt][xAttempt] == colorIndex && mapTiles[yAttempt][xAttempt + 1] == colorIndex &&
       mapTiles[yAttempt + 1][xAttempt] == colorIndex && mapTiles[yAttempt + 1][xAttempt + 1] == colorIndex &&
       aiCheckArray[yAttempt][xAttempt] != 1 && aiCheckArray[yAttempt][xAttempt + 1] != 1 &&
       aiCheckArray[yAttempt + 1][xAttempt] != 1 && aiCheckArray[yAttempt + 1][xAttempt + 1] != 1){
        aiCheckArray[yAttempt][xAttempt] = 1;
        aiCheckArray[yAttempt][xAttempt + 1] = 1;
        aiCheckArray[yAttempt + 1][xAttempt] = 1;
        aiCheckArray[yAttempt + 1][xAttempt + 1] = 1;
        return 1;
    }
    if (xAttempt == 0 && yAttempt == 0) {
        return 1;
    }
    return 0;
} // isValidCannonLoc()



static int setDAITarget(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1);
    xPos = lua_tonumber(L, 2);
    yPos = lua_tonumber(L, 3);
    
    
    return 0;
} // setDAITarget()



static int getDAITargetX(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1);
    
    return 1;
} // getDAITargetX()



static int getWallType(lua_State *L) {
    int x = lua_tonumber(L, 1);
    int y = lua_tonumber(L, 2);
    char checkEnemeyWall;
    
    if (aiControllerColor == 4){
        checkEnemeyWall = 'R';
    } else {
        checkEnemeyWall = 'B';
    }
    
    if (mapTiles[y][x] == 1 && mapArray[y][x] == checkEnemeyWall) {
        lua_pushnumber(L, 2);
    }
    
    return 1;
} // getWallType()



static int getWallShapeHeight(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1); // ignore this. Used for Linux version
    int wallHeight = pieceHeight; 
    lua_pushnumber(L, wallHeight);
    
    return 1;
} // getWallShapeHeight()



static int getWallShapeWidth(lua_State *L) {
    //int colorIndex = lua_tonumber(L, 1); // ignore this. Used for Linux version
    int wallWidth = pieceWidth;
    lua_pushnumber(L, wallWidth);
    
    return 1;
} // getWallShapeWidth()



static int getValidWallPlacement(lua_State *L) {
    int colorIndex = lua_tonumber(L, 1); // 1 is AI. 0 is Player.
    int xAttempt = lua_tonumber(L, 2); // X Coordinate to try to place block
    int yAttempt = lua_tonumber(L, 3); // Y Coordinate to try to place block
    
    // TODO: Return 1 if valid placement of block. Return 0 otherwise.
    
    return 1;
} // getValidWallPlacement()



static int getWallShapeIsBlock(lua_State *L) {
    int colorIndex = lua_tonumber(L, 1); // 1 is AI. 0 is Player.
    int wallXPos = lua_tonumber(L, 2);
    int wallYPos = lua_tonumber(L, 3);
    
    // TODO: Return 1 if is block. Return 0 otherwise.
    
    return 1;
} // getWallShapeIsBlock()



static int rotateWallShape(lua_State *L) {
    int colorIndex = lua_tonumber(L, 1); // 1 is AI. 0 is Player.
    
    return 0;
} // rotateWallShape()



static const struct luaL_Reg castlelib_f [] = {
    {"numberCastleLocations", numberCastleLocations},
    {"isValidCannonLoc", isValidCannonLoc},
    {"setDAITarget", setDAITarget},
    {"getDAITargetX", getDAITargetX},
    {"getWallType", getWallType},
    
    {"getWallShapeHeight", getWallShapeHeight},
    {"getWallShapeWidth", getWallShapeWidth},
    {"getValidWallPlacement", getValidWallPlacement},
    {"getWallShapeIsBlock", getWallShapeIsBlock},
    {"rotateWallShape", rotateWallShape},
    {NULL, NULL}
};



int luaopen_mylib (lua_State *L) {
    luaL_register(L, "test", castlelib_f);
    return 1;
} // luaopen_mylib()