/*
 *  RebuildModeAI.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <Foundation/Foundation.h>

int pieceHeight;
int pieceWidth;

@interface RebuildModeAI : NSObject


+(void)rebuildModeAi: (GameScene *) scene piece: (int *) piece set: (Boolean)hasBeenSet rotate: (Boolean) rightClick type: (int)color;
+(void)combineWalls: (GameScene *) scene sprite:(SKSpriteNode *)piece pos:(CGPoint)oldPosition;
+(SKSpriteNode *)combineWalls2: (GameScene *) scene sprite:(SKSpriteNode *)piece2 pos:(CGPoint)oldPosition;
+(int)rotateAI: (int *) piece;
+(void)printAiWall: (GameScene *) scene sprite:(SKSpriteNode *)piece pos:(CGPoint)location;
+(void)setAICombineColor: (int) color;
@end