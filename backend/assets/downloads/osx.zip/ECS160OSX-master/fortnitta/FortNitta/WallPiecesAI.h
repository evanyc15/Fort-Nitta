/*
 *  WallPieces.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <Foundation/Foundation.h>


@interface WallPiecesAI : NSObject

+(void)setAiColor: (int) color;
+(Boolean)ifPlaceable: (GameScene *)scene pos: (CGPoint)location;


+(void)monomino: (GameScene *) scene;

+(void)domino: (GameScene *) scene;
+(void)dominoAlt: (GameScene *) scene;
+(void)trominoL: (GameScene *) scene;
+(void)trominoLAlt1: (GameScene *) scene;
+(void)trominoLAlt2: (GameScene *) scene;
+(void)trominoLAlt3: (GameScene *) scene;
+(void)trominoI: (GameScene *) scene;
+(void)trominoIAlt: (GameScene *) scene;

+(void)tetrominoZ: (GameScene *) scene;
+(void)tetrominoZAlt: (GameScene *) scene;
+(void)tetrominoI: (GameScene *) scene;
+(void)tetrominoIAlt: (GameScene *) scene;
+(void)tetrominoCube: (GameScene *) scene;
+(void)tetrominoT: (GameScene *) scene;
+(void)tetrominoTAlt1: (GameScene *) scene;
+(void)tetrominoTAlt2: (GameScene *) scene;
+(void)tetrominoTAlt3: (GameScene *) scene;
+(void)tetrominoL: (GameScene *) scene;
+(void)tetrominoLAlt1: (GameScene *) scene;
+(void)tetrominoLAlt2: (GameScene *) scene;
+(void)tetrominoLAlt3: (GameScene *) scene;

+(void)pentominoF: (GameScene *) scene;
+(void)pentominoFAlt1: (GameScene *) scene;
+(void)pentominoFAlt2: (GameScene *) scene;
+(void)pentominoFAlt3: (GameScene *) scene;
+(void)pentominoI: (GameScene *) scene;
+(void)pentominoIAlt: (GameScene *) scene;
+(void)pentominoL: (GameScene *) scene;
+(void)pentominoLAlt1: (GameScene *) scene;
+(void)pentominoLAlt2: (GameScene *) scene;
+(void)pentominoLAlt3: (GameScene *) scene;
+(void)pentominoN: (GameScene *) scene;
+(void)pentominoNAlt1: (GameScene *) scene;
+(void)pentominoNAlt2: (GameScene *) scene;
+(void)pentominoNAlt3: (GameScene *) scene;
+(void)pentominoP: (GameScene *) scene;
+(void)pentominoPAlt1: (GameScene *) scene;
+(void)pentominoPAlt2: (GameScene *) scene;
+(void)pentominoPAlt3: (GameScene *) scene;
+(void)pentominoT: (GameScene *) scene;
+(void)pentominoTAlt1: (GameScene *) scene;
+(void)pentominoTAlt2: (GameScene *) scene;
+(void)pentominoTAlt3: (GameScene *) scene;
+(void)pentominoU: (GameScene *) scene;
+(void)pentominoUAlt1: (GameScene *) scene;
+(void)pentominoUAlt2: (GameScene *) scene;
+(void)pentominoUAlt3: (GameScene *) scene;
+(void)pentominoV: (GameScene *) scene;
+(void)pentominoVAlt1: (GameScene *) scene;
+(void)pentominoVAlt2: (GameScene *) scene;
+(void)pentominoVAlt3: (GameScene *) scene;
+(void)pentominoW: (GameScene *) scene;
+(void)pentominoWAlt1: (GameScene *) scene;
+(void)pentominoWAlt2: (GameScene *) scene;
+(void)pentominoWAlt3: (GameScene *) scene;
+(void)pentominoX: (GameScene *) scene;
+(void)pentominoY: (GameScene *) scene;
+(void)pentominoYAlt1: (GameScene *) scene;
+(void)pentominoYAlt2: (GameScene *) scene;
+(void)pentominoYAlt3: (GameScene *) scene;
+(void)pentominoZ: (GameScene *) scene;
+(void)pentominoZAlt: (GameScene *) scene;


@end
