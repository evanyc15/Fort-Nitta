/*
 *
 *  GameScene.m
 *  FortNitta
 *
 *  Created by Team OSX
 *  Last modified 2/14/2015
 *
 *  Until the main menu is implemented, this class is the starting point for Fort Nitta.  It is
 *  responsible for reading the map file, loading sound, creating the initial game scene/game logic,
 *  and then allowing the user to place cannons.  After three initial cannons are placed, this class
 *  transfers its data to BattleMode to carry out a scene transition.
 */

/* Below are the header file imports from the same package */
#import "GameScene.h"
#include "BattleMode.h"
#include "Sound.h"
#include "CastleHighLight.h"
#include "RebuildMode.h"
#include "RebuildModeAI.h"
#include "WallHoverPieces.h"
#include "WallPieces.h"
#include "MainMenu.h"


/* Below is the AVFoundation import */
#import <AVFoundation/AVFoundation.h>

bool entered = true;

/*----------Castle Colors-------------*/


/* When Calling the function RebuildMode, Pass in a color */

//yellow
int yellow = 2;
//red
int red = 3;
//blue
int blue = 4;


/*-------Cannon/CastleSelect Mode Global Variables-------------*/

Boolean cannonSelect = false; //init as 1, set to 0 later to end mode
Boolean castleSelect = true;
Boolean menuMusic = false;
Boolean aiCannonSelect = false;

CGPoint aiDestination;
CGPoint aiLocation;

int mapCastleCount = 0;
int selectedCannonCount;

//movable cannon array
NSArray *cannonMove;

// used in mouseEntered to keep track of highlighted castle
SKSpriteNode *curHighlight;


/*--------------Battle Mode Global Variables-------------------*/

Boolean battleMode = false;

/* Below are constants pertaining to tiles and wind */
#define tileEdge 24
#define tileScale 2
#define noWind 0
#define windN 1
#define windNE 2
#define windE 3
#define windSE 4
#define windS 5
#define windSW 6
#define windW 7
#define windNW 8
/*---------------Did We Win?----------------------------------*/

Boolean win = false;
Boolean lose = false;

Boolean cannonEverPlaced = false;


/*--------------Rebuild Mode Global Variables------------------*/


Boolean rebuildMode = false;

Boolean initialFlood = false;

//Snap to grid tracking area
NSTrackingArea* mouseOverTrackingArea;

//Make sure that tracking area only initializes once
int trackCheck = 0;

//Tracking the player piece
int piece;

//Tracking the ai Piece
int aiPiece;

//Check Amount of times of click for setting
int clicked = 0;

int aiArrayCount = 0;

int adjacentTargetX;
int adjacentTargetY;

//Check whether to set hover or set a piece
Boolean hasBeenSet = false;

//Check whether there has been a right click
Boolean rightClick = false;

//Saves a backup Location for when placing&connecting pieces happen
CGPoint savedLocation;

/*-------------------------------------------------------------*/


/* Added category to SKView */
@implementation SKView (Right_Mouse)
-(void)rightMouseDown:(NSEvent *)theEvent {
    [self.scene rightMouseDown:theEvent];
}

@end //@implementation SKView


/*-----------FROM HERE TO THE END OF THE FILE:  GameScene implementation--------  */

@implementation GameScene
/* Game scene implementation variables below.  TODO:  Organize these into header  */



/*--------------Timer Global Variables------------------*/
NSMutableArray  * cannonPosArray; //keep track of cannon position

//cannon to add
SKSpriteNode *cannon;

//keep track of time
int countdown = 0;

//time holder
NSTimer *timer;

//holds digit frames
NSArray *timerMove;

//exact frame
SKSpriteNode *timeNow;

//zero frame
SKSpriteNode *putFirstDigit;

/*---------------------Used in LoadMap-----------------------*/

int aiCastle;
int mapWidth;
int wind;
int mapHeight;
int evenTile;
int oddTile;
int tempOddEven;
float y;
int castleXCoordinate[] = {5, 8, 6, 15, 25, 37, 36, 36, 26, 18};
int castleYCoordinate[] = {7, 13, 19, 19, 18, 20, 12, 6, 7, 6};


/*-------------------AI Variables---------------------------*/

AI_Controller *AI;

//Check for seeing whether or not Ai can place cannons
int cantPlace = 1;

//Checking if the first AiCursor
Boolean initialAICursor = true;

/*----------------Tile Arrays/Functions---------------------*/


NSMutableArray *tileTerrainArray;
NSMutableArray *tileWallArray;
NSMutableArray *cannonArr;

/* Used for easy storing value into MapTiles Array */
+(void)mapTilesY:(NSInteger)y X:(NSInteger)x value:(NSInteger)value{
    mapTiles[y][x] = value;
}

/* Used for Retrieving value from MapTiles Array */
+(NSUInteger)mapTilesY:(NSInteger)y X:(NSInteger)x{

    return mapTiles[y][x];
}
//prepare
bool prepareForBattle = false;

/*---------------------------------Creating Map & Tracking-----------------------------------*/

/* Beginning view */
-(void)didMoveToView:(SKView *)view {
    self.userInteractionEnabled = YES;
    /****Wind chosen from game selection menu****/
    NSUserDefaults *sceneInfo = [NSUserDefaults standardUserDefaults];
    wind = (int)[sceneInfo integerForKey:@"wind"];
    
    
    //Set player color
    player = (int)[sceneInfo integerForKey:@"playercolor"];;
    
    battleMode = false;
    
    //Load the map
    NSString *map = [[NSBundle mainBundle] pathForResource:@"NorthSouth" ofType:@"map"];
    [self loadMap:map];
    if (castleSelect) {
        
        
        
        difficulty = (int)[sceneInfo integerForKey:@"aidifficulty"];
        
        AI = [[AI_Controller alloc] init:difficulty];
        cannonAmount = 3;
        aiCannonAmount = 3;
        for (int i = 0; i < 10; i++) {
            if (player == blue) {
                if(i < 5){
                    [self createCastleTracking: i];
                }
            }
            if (player == red) {
                if(i >= 5){
                    [self createCastleTracking: i];
                }
            }
            
        }
        
        if (player == blue) {
            aiCastle = [AI get_AI_castle] + 5;
            aiColor = red;
            [self placeAICastleAtLocation: aiCastle];
        } else {
            aiCastle = [AI get_AI_castle];
            aiColor = blue;
            [self placeAICastleAtLocation: aiCastle];
        }
    }
    
    if (rebuildMode) {
        printf("Hello\n");
        printf("Win is %d and Lose is %d in timer\n",win,lose);
        NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"rebuild" withExtension:@"mid"];
        NewMusicPlayer(&rebuildMidiPlayer);
        MusicSequence sequence = NULL;
        NewMusicSequence(&sequence);
        MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
        MusicPlayerSetSequence(rebuildMidiPlayer, sequence);
        MusicPlayerStart(rebuildMidiPlayer);
        entered = true;

        double delayInSeconds = 3;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            //did we win? Don't start time then.
                [self startTimer];
        });
    }
    
}

/* Load the 2D Map */
-(void)loadMap:(NSString *)theMap{
    
    // fill the array with the tiles in the tile set
    tileTerrainArray = [GameScene fillTileSet:@"2DTerrain copy"];
    tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    cannonArr = [GameScene fillTileSet:@"2DCastleCannon copy"];
    NSUserDefaults *battleInfo = [NSUserDefaults standardUserDefaults];
    

    // Load map
    NSError *error;
    NSString *mapFile = [NSString stringWithContentsOfFile:theMap
                                                  encoding:NSASCIIStringEncoding
                                                     error:&error];
    NSArray * mapLines = [mapFile componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    NSMutableArray *map = [NSMutableArray arrayWithArray:mapLines];
    NSString *mapDimension = map[1];
    // NSString *mapTitle = map[0];
    // reading info from Map File
    mapWidth = [mapDimension intValue] + 2;
    mapHeight = [[mapDimension substringFromIndex:3] intValue] + 2;
    mapCastleCount = [map[mapHeight + 2] intValue];
    initialAICursor = true;
    
    //Ignore map title
    [map removeObjectAtIndex:0];
    //Ignore map dimensions
    [map removeObjectAtIndex:0];
    
    //create map array
    //char mapArray[mapHeight][mapWidth];
    for (int i = 0; i < 26; i++) {
        for (int j = 0; j < 42; j++) {
            mapArray[i][j] = [[map objectAtIndex:i] characterAtIndex:j];
        }
    }
    
    
    selectedCannonCount = (int)[battleInfo integerForKey:@"cannonCount"];

    //int trackTile[mapHeight][mapWidth];
    if (castleSelect) {
        for (int i = 0; i < mapHeight; i++) {
            for (int j = 0; j < mapWidth; j++) {
                [GameScene mapTilesY:i X:j value:0];
                //trackTile[i][j] =0;
            }
        }
        
        for (int i = 0; i < 50; i++) {
            [BattleMode cannonPosX:i value:0];
            [BattleMode cannonPosY:i value:0];
        }
        
        selectedCannonCount = 0;
    }
    
    //Build loaded map
    evenTile = 0;
    oddTile = 1;
    tempOddEven = 0;
    y = 12 + 24 * tileEdge;
    for (int j = 1; j < 25; j++){
        float x = 12 + tileEdge;
        for (int i = 1; i < 41; i++){
            int tileSwitch = i % 2;
        
            
            //Render grass tiles
            if (tileSwitch == evenTile && (mapArray[j][i] == 'B' || mapArray[j][i] == 'R')) {
                SKSpriteNode *grass = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:28]];
                grass.position = CGPointMake(x,y);
                grass.scale = tileScale;
                grass.name = @"grass";
                [self addChild:grass];
            }
            else if (tileSwitch == oddTile && (mapArray[j][i] == 'B' || mapArray[j][i] == 'R')) {
                SKSpriteNode *grass = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:29]];
                grass.position = CGPointMake(x,y);
                grass.scale = tileScale;
                grass.name = @"grass";
                [self addChild:grass];
            }
            
        
            /*CODE BELOW:  Create river tiles in such a way that the river will be accurately drawn,
             regardless of the map
             */
            
            //Mid top river tile
            else if (([GameScene mapTilesY:j X:i-1] == 13 || [GameScene mapTilesY:j X:i-1] == 12 || mapArray[j][i-1] == ' ' ||
                      [GameScene mapTilesY:j X:i-1] == 11 || [GameScene mapTilesY:j X:i-1] == 7 || [GameScene mapTilesY:j X:i-1] == 26) &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R') &&
                     mapArray[j][i+1] == ' ' &&
                     tileSwitch == oddTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:27]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:27];
                [self addChild:river];
            }
            
            else if (([GameScene mapTilesY:j X:i-1] == 13 || [GameScene mapTilesY:j X:i-1] == 12 || mapArray[j][i-1] == ' ' ||
                      [GameScene mapTilesY:j X:i-1] == 27 || [GameScene mapTilesY:j X:i-1] == 11 || [GameScene mapTilesY:j X:i-1] == 7) &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R') && mapArray[j][i+1] == ' ' &&
                     tileSwitch == evenTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:26]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:26];
                [self addChild:river];
            }
            
            //Top right shore river tile
            else if ((mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R') &&
                     tileSwitch == evenTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:25]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:25];
                [self addChild:river];
            }
            
            else if ((mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R') &&
                     tileSwitch == oddTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:24]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:24];
                [self addChild:river];
            }
            
            //Mid right river tile
            else if (([GameScene mapTilesY:j X:i-1] == 14 || [GameScene mapTilesY:j X:i-1] == 5 || [GameScene mapTilesY:j X:i-1] == 8 || [GameScene mapTilesY:j X:i-1] == 9) &&
                     ([GameScene mapTilesY:j-1 X:i] == 24 || [GameScene mapTilesY:j-1 X:i] == 22 || [GameScene mapTilesY:j-1 X:i] == 6 || [GameScene mapTilesY:j-1 X:i] == 10 ||
                      mapArray[j-1][i] == ' ') &&
                     (mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     mapArray[j+1][i] == ' '){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:23]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:23];
                [self addChild:river];
            } 
            else if (([GameScene mapTilesY:j X:i-1] == 15 || [GameScene mapTilesY:j X:i-1] == 5 || [GameScene mapTilesY:j X:i-1] == 8 || [GameScene mapTilesY:j X:i-1] == 9) &&
                     ([GameScene mapTilesY:j-1 X:i] == 25 || [GameScene mapTilesY:j-1 X:i] == 23 || [GameScene mapTilesY:j-1 X:i] == 6 || [GameScene mapTilesY:j-1 X:i] == 10 ||
                      mapArray[j-1][i] == ' ') &&
                     (mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     mapArray[j+1][i] == ' '){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:22]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:22];
                [self addChild:river];
            }
            
            
            //Bottom right shore tile
            else if ((mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R') &&
                     tileSwitch == oddTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:21]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:21];
                [self addChild:river];
            }
            else if ((mapArray[j][i+1] == 'B' || mapArray[j][i+1] == 'R') &&
                     (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R') &&
                     tileSwitch == evenTile){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:20]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:20];
                [self addChild:river];
            }
            
            //Mid bottom river tile
            else if (([GameScene mapTilesY:j-1 X:i] == 26 || [GameScene mapTilesY:j-1 X:i] == 5 ||
                      [GameScene mapTilesY:j-1 X:i] == 8 || [GameScene mapTilesY:j-1 X:i] == 11 ) &&
                     (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R') &&
                     mapArray[j][i+1] == ' ' &&
                     (mapArray[j][i-1] == ' ' || [GameScene mapTilesY:j X:i-1] == 16 ||
                      [GameScene mapTilesY:j X:i-1] == 7 || [GameScene mapTilesY:j X:i-1] == 9)){
                         SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:19]];
                         river.position = CGPointMake(x,y);
                         river.scale = tileScale;
                         [GameScene mapTilesY:j X:i value:19];
                         [self addChild:river];
                     } 
            else if (([GameScene mapTilesY:j-1 X:i] == 27 || [GameScene mapTilesY:j-1 X:i] == 5 ||
                      [GameScene mapTilesY:j-1 X:i] == 8 || [GameScene mapTilesY:j-1 X:i] == 11 ) && (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R') &&
                     mapArray[j][i+1] == ' ' &&
                     (mapArray[j][i-1] == ' ' || [GameScene mapTilesY:j X:i-1] == 17 ||
                      [GameScene mapTilesY:j X:i-1] == 7 || [GameScene mapTilesY:j X:i-1] == 9)){
                         SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:18]];
                         river.position = CGPointMake(x,y);
                         river.scale = tileScale;
                         [GameScene mapTilesY:j X:i value:18];
                         [self addChild:river];
                     }
            
            //Bottom left shore tile
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R') &&
                     tileSwitch == oddTile) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:17]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:17];
                [self addChild:river];
            }
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     (mapArray[j+1][i] == 'B' || mapArray[j+1][i] == 'R' ) &&
                     tileSwitch == evenTile) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:16]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:16];
                [self addChild:river];
            }
            
            //Mid left river tile
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     ([GameScene mapTilesY:j-1 X:i] == 13 || [GameScene mapTilesY:j-1 X:i] == 15 ||
                      [GameScene mapTilesY:j-1 X:i] == 24 || mapArray[j-1][i] == ' ') &&
                     tileSwitch == evenTile &&
                     mapArray[j+1][i] == ' ') {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:14]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:14];
                [self addChild:river];
            }
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     ([GameScene mapTilesY:j-1 X:i] == 12 || [GameScene mapTilesY:j-1 X:i] == 14 ||
                      [GameScene mapTilesY:j-1 X:i] == 25 || mapArray[j-1][i] == ' ') &&
                     tileSwitch == oddTile &&
                     mapArray[j+1][i] == ' ') {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:15]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:15];
                [self addChild:river];
            }
            
            //Top left shore tile
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R') &&
                     tileSwitch == oddTile) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:13]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:13];
                [self addChild:river];
            }
            else if ((mapArray[j][i-1] == 'B' || mapArray[j][i-1] == 'R') &&
                     (mapArray[j-1][i] == 'B' || mapArray[j-1][i] == 'R' ) &&
                     tileSwitch == evenTile) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:12]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:12];
                [self addChild:river];
            }
            
            //Top right corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 5 || [GameScene mapTilesY:j X:i-1] == 14 || [GameScene mapTilesY:j X:i-1] == 15 ||
                      [GameScene mapTilesY:j X:i-1] == 9 || [GameScene mapTilesY:j X:i-1] == 8) &&
                     ([GameScene mapTilesY:j-1 X:i] == 24 || [GameScene mapTilesY:j-1 X:i] == 25 ||
                      [GameScene mapTilesY:j-1 X:i] == 23 || [GameScene mapTilesY:j-1 X:i] == 22) &&
                     (mapArray[j-1][i+1] == 'B' || mapArray[j-1][i+1] == 'R') &&
                     mapArray[j+1][i-1] == ' ') {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:11]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:11];
                [self addChild:river];
            }
            //Bottom right corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 5 || [GameScene mapTilesY:j X:i-1] == 14 || [GameScene mapTilesY:j X:i-1] == 15 ||
                      [GameScene mapTilesY:j X:i-1] == 9 || [GameScene mapTilesY:j X:i-1] == 8) &&
                     ([GameScene mapTilesY:j-1 X:i] == 11 || [GameScene mapTilesY:j-1 X:i] == 8 || mapArray[j-1][i] == ' ' ||
                      [GameScene mapTilesY:j-1 X:i] == 27 || [GameScene mapTilesY:j-1 X:i] == 26 || [GameScene mapTilesY:j-1 X:i] == 5) &&
                     (mapArray[j+1][i+1] == 'B' || mapArray[j+1][i+1] == 'R') &&
                     mapArray[j-1][i-1] == ' ') {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:10]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:10];
                [self addChild:river];
            }
            //Bottom left corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 19 || [GameScene mapTilesY:j X:i-1] == 18 ||
                      [GameScene mapTilesY:j X:i-1] == 17 || [GameScene mapTilesY:j X:i-1] == 16) &&
                     ([GameScene mapTilesY:j-1 X:i] == 11 || [GameScene mapTilesY:j-1 X:i] == 8 || mapArray[j-1][i] == ' ' ||
                      [GameScene mapTilesY:j-1 X:i] == 27 || [GameScene mapTilesY:j-1 X:i] == 26 || [GameScene mapTilesY:j-1 X:i] == 5) &&
                     (mapArray[j+1][i-1] == 'B' || mapArray[j+1][i-1] == 'R') &&
                     mapArray[j-1][i+1] == ' '){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:9]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:9];
                [self addChild:river];
            }
            //Top left corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 27 || [GameScene mapTilesY:j X:i-1] == 26 ||
                      [GameScene mapTilesY:j-1 X:i] == 12 || [GameScene mapTilesY:j-1 X:i] == 13) &&
                     ([GameScene mapTilesY:j-1 X:i] == 12 || [GameScene mapTilesY:j-1 X:i] == 13 ||
                      [GameScene mapTilesY:j-1 X:i] == 14 || [GameScene mapTilesY:j-1 X:i] == 15) &&
                     (mapArray[j-1][i-1] == 'B' || mapArray[j-1][i-1] == 'R') &&
                     mapArray[j+1][i+1] == ' '){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:8]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:8];
                [self addChild:river];
            }
            //Bottom left and top right corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 19 || [GameScene mapTilesY:j X:i-1] == 18 ||
                      [GameScene mapTilesY:j X:i-1] == 17 || [GameScene mapTilesY:j X:i-1] == 16) &&
                     ([GameScene mapTilesY:j-1 X:i] == 27 || [GameScene mapTilesY:j-1 X:i] == 26 ||
                      [GameScene mapTilesY:j-1 X:i] == 25 || [GameScene mapTilesY:j-1 X:i] == 24 || mapArray[j-1][i] == ' ') &&
                     (mapArray[j-1][i-1] == 7 || mapArray[j-1][i-1] == ' ')) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:7]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:7];
                [self addChild:river];
            }
            
            //Top left and bottom right corner tile
            else if (([GameScene mapTilesY:j X:i-1] == 12 || [GameScene mapTilesY:j X:i-1] == 13 ||
                      [GameScene mapTilesY:j X:i-1] == 27 || [GameScene mapTilesY:j X:i-1] == 26) &&
                     ([GameScene mapTilesY:j-1 X:i] == 12 || [GameScene mapTilesY:j-1 X:i] == 13 ||
                      [GameScene mapTilesY:j-1 X:i] == 14 || [GameScene mapTilesY:j-1 X:i] == 15 || mapArray[j-1][i] == ' ') &&
                     ([GameScene mapTilesY:j-1 X:i+1] == 6 || mapArray[j-1][i+1] == ' ' )) {
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:6]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:6];
                [self addChild:river];
            }
            //All blue river tile
            else if (([GameScene mapTilesY:j-1 X:i] == 27 || [GameScene mapTilesY:j-1 X:i] == 26 || [GameScene mapTilesY:j-1 X:i] == 5 || mapArray[j-1][i] == ' ') &&
                     ([GameScene mapTilesY:j X:i-1] == 8 || [GameScene mapTilesY:j X:i-1] == 5 || [GameScene mapTilesY:j X:i-1] == 9 ||
                      [GameScene mapTilesY:j X:i-1] == 14 || [GameScene mapTilesY:j X:i-1] == 15 || mapArray[j][i-1] == ' ') &&
                     mapArray[j+1][i+1] == ' '){
                SKSpriteNode *river = [SKSpriteNode spriteNodeWithTexture:[tileTerrainArray objectAtIndex:5]];
                river.position = CGPointMake(x,y);
                river.scale = tileScale;
                [GameScene mapTilesY:j X:i value:5];
                [self addChild:river];
            }
            
            //New Walls checks which pieces should be placed base on the array
            if(rebuildMode){
//                Sound *menuSound = [[Sound alloc]init];
//                [menuSound playRebuildMidi];
                
                int WallType = 0xF;
                SKSpriteNode *wall = [[SKSpriteNode alloc]init];
                int wallColorOffset;
                //Blue walls
                if (mapArray[j][i] == 'B') {
                    wallColorOffset = 0;
                }
                //Red walls
                else if (mapArray[j][i] == 'R'){
                    wallColorOffset = 16;
                }
                //Yellow walls
                else {
                    wallColorOffset = 32;
                }
                
                if (mapTiles[j][i] == 1) {
                    
                    //north
                    if(mapTiles[j-1][i] == 1){
                        WallType &= 0xE;
                    }
                    //east
                    if(mapTiles[j][i+1] == 1){
                        WallType &= 0xD;
                    }
                    //south
                    if(mapTiles[j+1][i] == 1){
                        WallType &= 0xB;
                    }
                    //west
                    if(mapTiles[j][i-1] == 1){
                        WallType &= 0x7;
                    }
                    wall = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:51-WallType-wallColorOffset]];
                    wall.position = CGPointMake(x,y);
                    wall.scale = tileScale;
                    wall.name = @"wall";
                    wall.zPosition = 1.1;
                    [self addChild:wall];
                }
                
            }
            
            x = x + tileEdge;
        }
        tempOddEven = evenTile;
        evenTile = oddTile;
        oddTile = tempOddEven;
        y = y - tileEdge;
    }
    /*  RIVER COMPLETE */
    SKAction *sound = [SKAction playSoundFileNamed:@"gust2.wav" waitForCompletion:YES];
    
    //Place castles on map
    for (int i = 0; i < 10; i++) {
        [self addChild: [self createCastles:i]];
        
    }//for

    // make border around mapTiles array to account for players not being able to place onto border
    for(int i = 0; i < 26; i++) {
        mapTiles[i][0] = 99;
        mapTiles[i][41] = 99;
    }
    
    for(int i = 0; i < 42; i++) {
        mapTiles[0][i] = 99;
        mapTiles[25][i] = 99;
    }
    
    SKAction *sound2 = [SKAction playSoundFileNamed:@"triumph.wav" waitForCompletion:NO];
    SKAction *sequence = [SKAction sequence:@[sound, sound2]];
    [self runAction: sequence];


    //Build cannons old cannons
    if (rebuildMode) {

        //Floods with player(color)'s wherever an area isn't surrounded with walls,
        //I dont use 9's because the condition in floodFill8Clear only works if mapTiles < 5
        
        [RebuildMode makeFillArr];
        [RebuildMode floodFill8Clear:0 Y:0 newNum:player oldNum:0];
        [RebuildMode floodFill8Clear:0 Y:0 newNum:0 oldNum:player];
        
        initialFlood = true;
        SKSpriteNode *cannon = [[SKSpriteNode alloc]init];
        for (int i = 0; cannonPosX[i] != 0; i++) {
            cannon = [SKSpriteNode spriteNodeWithTexture:[cannonArr objectAtIndex:27]];
            cannon.position = CGPointMake(cannonPosX[i], cannonPosY[i]);
            cannon.name = @"cannon";
            cannon.zPosition = 2;
            cannon.scale = tileScale;
            [self addChild:cannon];
        }
        aiArrayCount = 0;
        [self placeAIPieces];
    }
}

/* Creates castles */
-(SKNode *) createCastles: (int) pos{
    
    NSMutableArray *tileCastleArray = [GameScene fillTileSet:@"2DCastleCannon copy"];
    SKSpriteNode *castle = [SKSpriteNode spriteNodeWithTexture:[tileCastleArray objectAtIndex:31]];
    castle.position = CGPointMake(castleXCoordinate[pos]*tileEdge,castleYCoordinate[pos]*tileEdge);
    castle.scale = tileScale;
    castle.zPosition = 2;
    [castle setName:(NSString *)@"castle"];
    return castle;
}
/* action performed when button clicked for castle Select */

/* Creating a button to Select a Castle */
-(void) createCastleTracking: (int) pos {
    
    //[self phraseCastle];
    //Size of the button for tracking
    int buttonSize = 100;
    
    // coordinates from SKScene are different from coordinates from SKView, so we have to convert
    CGPoint scenePoint = CGPointMake(castleXCoordinate[pos] * tileEdge ,castleYCoordinate[pos] * tileEdge);
    CGPoint viewPoint = [self.view convertPoint:scenePoint fromScene:self.scene];
    
    // make sure button is centered to SKSpritenode (castle)
    NSButton *myButton = [[NSButton alloc] initWithFrame:NSMakeRect(viewPoint.x - (buttonSize/2), viewPoint.y - (buttonSize/2), buttonSize, buttonSize)];
    [[myButton cell] setBackgroundColor:[NSColor redColor]];
    //[myButton setAction:@selector(mouseDown:theEvent:)];
    myButton.tag = pos;
    [myButton setTarget:self];
    [myButton setAction:@selector(buttonAction:)];      // should move to cannon placement when button clicked
    
    [self.view addSubview:myButton];
    
    // Make dictionary to pass on to mouseEntered to know which castle to highlight
    NSDictionary *recordCastleCoordinates = @{
                                              @"x" : [NSNumber numberWithInt:(castleXCoordinate[pos]*tileEdge)],
                                              @"y" : [NSNumber numberWithInt:(castleYCoordinate[pos]*tileEdge)],
                                              };
    
    // Need to add trackingArea to button to track mouseEntered and mouseExited
    NSTrackingArea* trackingArea = [[NSTrackingArea alloc]
                                    initWithRect:[myButton bounds]
                                    options:NSTrackingMouseEnteredAndExited | NSTrackingActiveAlways
                                    owner:self userInfo:recordCastleCoordinates];
    [myButton addTrackingArea:trackingArea];
}

/* Removes(Hides) Castle tracking */
-(void) removeCastleTracking {
    // actually hides the button instead of deleting them (for sake of time)
    for (NSButton *curButton in [self.view subviews]) {
        [curButton setHidden:YES];
    }
    if(!win && !lose){
        [self phrasePlaceCannons]; //"PLACE CANNONS"
    }//did we win? Don't place cannons then.
}

-(IBAction)buttonAction:(id)sender {

    // remove highlight because it is unneeded
    [curHighlight removeFromParent];
    
    // get NSButton that was clicked
    NSButton * curButton = (NSButton *)sender;
    
    // need to convert scene coordinates to view coordinates to get position to place SKSpritenodes
    CGPoint scenePoint = CGPointMake(CGRectGetMidX(curButton.frame), CGRectGetMidY(curButton.frame));
    CGPoint viewPoint = [self.scene convertPointFromView:scenePoint];
    
    // tags 1 and 4 are special cases that need to be accounted for (castle too close to river, etc.)
    if([sender tag] == 1){
        
        [CastleHighLight createCastleWallCorner: self.scene xCord:(int)viewPoint.x yCord:(int)viewPoint.y color:player];
        
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24) X:round(viewPoint.x/24)+i value:1];
            if (i < 2)
                [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)-4 value:1];
            if (i < 6)
                [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)+3 value:1];
        }
        
        [GameScene mapTilesY:22-round(viewPoint.y/24)+5 X:round(viewPoint.x/24)+2 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)+2 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)+1 value:1];
        
    }//if
    else if([sender tag] == 4)
    {

        [CastleHighLight createCastleWallDip:self.scene xCord:(int)viewPoint.x yCord:(int)viewPoint.y color:player];
        
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24) X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = -4; i <= -1; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = 1; i <= 5; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)+3 value:1];
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)-4 value:1];
        }
        
        [GameScene mapTilesY:22-round(viewPoint.y/24)+5 X:round(viewPoint.x/24)+2 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)+2 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)+1 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24)+1 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24) value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24)-1 value:1];
        [GameScene mapTilesY:22-round(viewPoint.y/24)+6 X:round(viewPoint.x/24)-1 value:1];
    }
    else if ([sender tag] == 5)
    {
        
        [CastleHighLight createCastleWallPiece:self.scene xCord:(int)viewPoint.x yCord:(int)viewPoint.y color:player];
        
        /*Store 1's in the location of walls*/
        
        for (int i = -3; i <= 3; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24) X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)+3 value:1];
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)-4 value:1];
        }
        
        [GameScene mapTilesY:22-round(viewPoint.y/24)+1 X:round(viewPoint.x/24)-3 value:1];
    }
    else    // else the default 6x6 tile checkerboard
    {
        
        [CastleHighLight createCastleWall: self.scene xCord:(int)viewPoint.x yCord:(int)viewPoint.y color:player];
        
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24) X:round(viewPoint.x/24)+i value:1];
            [GameScene mapTilesY:22-round(viewPoint.y/24)+7 X:round(viewPoint.x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)+3 value:1];
            [GameScene mapTilesY:22-round(viewPoint.y/24)+i X:round(viewPoint.x/24)-4 value:1];
        }
    }//else
    
    //Calls Floodfill to create the checkerboard for the first selected castle
    [self reFlood];
    
    //Set Castle Select to show to know its finished
    castleSelect = false;
    
    //After Castle has been selected, remove tracking area
    [self removeCastleTracking];

}

/* need mouseOverTrackingArea to implement "snap-to-grid" effect */
-(void)snapToGridTrackingArea{
    
    if(battleMode){
        //Resetting trackCheck to know that tracking area has been removed
        trackCheck = 0;
        
        [self.view removeTrackingArea:mouseOverTrackingArea];
        mouseOverTrackingArea = nil;
    }
    else if(win || lose){
        [self.view removeTrackingArea:mouseOverTrackingArea];
        mouseOverTrackingArea = nil;
    }
    else{
        //Create the snap to grid tracking area for the entire size of the scene
        mouseOverTrackingArea = [[NSTrackingArea alloc]
                                 initWithRect:NSMakeRect(0,0,1008,624)
                                 options:NSTrackingMouseMoved | NSTrackingActiveInActiveApp
                                 owner:self userInfo:nil];
        //Add tracking area
        [self.view addTrackingArea:mouseOverTrackingArea];
        
        //Setting trackCheck to know that tracking area has been created
        trackCheck = 1;
    }
    
}

/*-------------------------------------------Timer-------------------------------------------*/

/* Starting the Timer */
-(void)startTimer{
    printf("Start Timer\n");
    printf("Win is %d and Lose is %d in timer\n",win,lose);
    if(!win && !lose){
        SKAction *sound2 = [SKAction playSoundFileNamed:@"triumph.wav" waitForCompletion:YES];
        [self runAction: sound2];
        CGPoint timerLocation0 = CGPointMake(50.0, 578.0);
        CGPoint timerLocation1 = CGPointMake(100.0, 578.0);
        NSMutableArray *timerFrames = [GameScene fillTileSet:@"Digits copy"];
        timerMove = timerFrames;
        
        SKTexture *firstDigit = [[SKTexture alloc] init];
        SKTexture *secondDigit = [[SKTexture alloc] init];
        
        
        if (cannonSelect) {
            firstDigit = timerMove[9]; //grab zero from the Digits copy png
            secondDigit = timerMove[0];
            if(entered){
                NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"place" withExtension:@"mid"];
                NewMusicPlayer(&placeMidiPlayer);
                MusicSequence sequence = NULL;
                NewMusicSequence(&sequence);
                MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
                MusicPlayerSetSequence(placeMidiPlayer, sequence);
                MusicPlayerStart(placeMidiPlayer);
                entered = false;
            }MusicPlayerStop(rebuildMidiPlayer);
        } else {
            firstDigit = timerMove[8]; //grab one from the Digits copy png
            secondDigit = timerMove[5];
        }
        putFirstDigit = [SKSpriteNode spriteNodeWithTexture:firstDigit]; //set to zero digit png
        putFirstDigit.position = timerLocation0; //location of timer 0 on screen
        putFirstDigit.scale = tileScale;
        putFirstDigit.zPosition = 1000; //above everything else
        putFirstDigit.name = @"digit";
        
        timeNow = [SKSpriteNode spriteNodeWithTexture:secondDigit];
        timeNow.position = timerLocation1; //location of timer on screen
        timeNow.scale = tileScale;
        timeNow.zPosition = 1000; //above everything else
        timeNow.name = @"timer";
        
        
        [self addChild:putFirstDigit];
        [self addChild:timeNow];
        
        
        [timer invalidate];
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    }
    
}

//Countdown for Cannon & Piece Placement
-(void)tick{
    
    if(cannonSelect && !win && !lose){
        

        
        if(countdown == 9 || (aiCannonAmount == 0 && cannonAmount == 0)){

            [timer invalidate];
            countdown = 0; //reset time
            //cannonCount = 0; //reset cannons we've added recently
            [putFirstDigit removeFromParent]; //hide zero
            [timeNow removeFromParent]; //hide time
            
            
            if(lose){
                [self loseScreen];
            }
            if(!lose){
                MusicPlayerStop(placeMidiPlayer);
                [self goToBattleMode];
            }
            
        }
        else{
            SKAction *tick = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:YES];
            [self runAction: tick];
            [timeNow runAction: [SKAction setTexture:timerMove[countdown]]]; //play frame based on what countdown is on
            [putFirstDigit runAction: [SKAction setTexture:timerMove[9]]]; //play zero frame
            
            

            countdown++; //countdown adds by one
            
        }//animate time frames
    }
    if(rebuildMode){
        
        
        if(countdown == 14){
            
            [timer invalidate];
            //NSLog (@"countdown is %i, cannon count is %i,", countdown, cannonCount);
            countdown = 0; //reset time
            //cannonCount = 0; //reset cannons we've added recently
            [putFirstDigit removeFromParent]; //hide zero
            [timeNow removeFromParent]; //hide time
            [self removeAllSprites];
            rebuildMode = false;
            //Calculates how many highlighted castles
            [self figureCannons];
            //Adding timer to map

            [self phrasePlaceCannons];
            
        }
        
        else{
            if(!win && !lose){
                
                
                SKAction *tick = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:YES];
                [self runAction: tick];
                if (countdown >= 5) {
                    [timeNow runAction: [SKAction setTexture:timerMove[countdown-5]]]; //play frame based on what countdown is on
                    [putFirstDigit runAction: [SKAction setTexture:timerMove[9]]]; // play 0 frame
                } else {
                    [timeNow runAction: [SKAction setTexture:timerMove[countdown+5]]]; //play frame based on what countdown is on
                    [putFirstDigit runAction: [SKAction setTexture:timerMove[8]]]; //play 1 frame
                }
                
                
                countdown++; //countdown adds by one
            }
        }//animate time frames
    }
}

/*---------------------------------------Mouse Movements-------------------------------------*/

/* When Left Click */
-(void)mouseDown:(NSEvent *)theEvent {

    //Initializing Cannon Position Array
    if(initArr == 0) {
        initArr++;
        cannonPosArray = [[NSMutableArray alloc] init];
        
        
    }
    if(cannonSelect) {
        //Bound for looking NESW
        int bound = 23.9;
        int cornerCount = 0;
        NSMutableArray *cannonArr = [GameScene fillTileSet:@"2DCastleCannon copy"];
        int cornerTrack[4] = {0};
        
        //define boundaries (4 corners of cannon cursor
        CGPoint p1 = {storedLocation.x + bound, storedLocation.y + bound};
        CGPoint p2 = {storedLocation.x - bound, storedLocation.y + bound};
        CGPoint p3 = {storedLocation.x - bound, storedLocation.y - bound};
        CGPoint p4 = {storedLocation.x + bound, storedLocation.y - bound};
        
        //Check for whether or not the cannon cursor is touching a ground highlight while ignoring the hover
        //Also checks for whether or not it is currently touching a castle or cannon
        for(int i = 0; i < 4; i ++) {
            
            if(i == 0) {
                NSArray *nodes = [self nodesAtPoint:p1];
                for (SKSpriteNode *object in nodes) {
                    // cursor is always touching cannonHover so below is to ignore cannonHover node
                    if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"] ||
                       [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]){
                        cornerCount--;
                        break;
                    }
                    else if([object.name isEqual: @"playerGroundHighLight"]) {
                        cornerCount++;
                    }
                }
            }
            else if(i == 1) {
                NSArray *nodes = [self nodesAtPoint:p2];
                for (SKSpriteNode *object in nodes) {
                    if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"] ||
                       [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]){
                        cornerCount--;
                        break;
                    }
                    // cursor is always touching cannonHover so below is to ignore cannonHover node
                    else if([object.name isEqual: @"playerGroundHighLight"]) {
                        cornerCount++;
                    }
                }
            }
            else if(i == 2) {
                NSArray *nodes = [self nodesAtPoint:p3];
                for (SKSpriteNode *object in nodes) {
                    if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"] ||
                       [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]){
                        cornerCount--;
                        break;
                    }
                    // cursor is always touching cannonHover so below is to ignore cannonHover node
                    else if([object.name isEqual: @"playerGroundHighLight"]) {
                        cornerCount++;
                    }
                }
            }
            else if(i == 3) {
                NSArray *nodes = [self nodesAtPoint:p4];
                for (SKSpriteNode *object in nodes) {
                    if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"] ||
                       [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]){
                        cornerCount--;
                        break;
                    }
                    // cursor is always touching cannonHover so below is to ignore cannonHover node
                    else if([object.name isEqual: @"playerGroundHighLight"]) {
                        cornerCount++;
                    }
                }
            }
            cornerTrack[i] = cornerCount;
        }
        
        
        // if all 4 corners are on playerGroundHighLight
        if((cornerTrack[3]*.25 == cornerTrack[0]) && (cornerTrack[3]*.25 == cornerTrack[0]) &&
           (cornerTrack[3]*.5 == cornerTrack[1]) && (cornerTrack[3]*.75 == cornerTrack[2]) &&
           (cornerTrack[3] > 0)) {
            //[cannonPosArray addObject:[NSValue valueWithPoint:storedLocation]];   // store cannon position
            SKSpriteNode *cannon = [SKSpriteNode spriteNodeWithTexture:[cannonArr objectAtIndex:27]];
            cannon.position = storedLocation;
            
            [BattleMode cannonPosX:selectedCannonCount value:cannon.position.x];
            [BattleMode cannonPosY:selectedCannonCount value:cannon.position.y];
            
            cannon.name = @"cannon";
            cannon.zPosition = 2;
            cannon.scale = tileScale;
            selectedCannonCount++;
            SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
            [self runAction:sound];
            [self addChild:cannon];
            
            
            //Removes the last place Cannon Cursor Hover
            [self removeAllSprites];
            
            //Cannon has been placed, decrement cannon amount
            cannonAmount--;
            if(cannonAmount != 0){
                //Recall for new cannon cursor
                [self addCannonCursor];
                //cannonEverPlaced = true;
            }
        }
    }
    //Uncomment if you want to test rebuildMode in the beginning
    //rebuildMode = true;
    
    //When in Rebuild mode and not any other modes
    if(rebuildMode){
               //[self adjacencyCheck:37 Y:20]; //call to adjacencycheck
        
        //Initialize fillArr for floodfill
        [RebuildMode makeFillArr];
        
        //If Snap-to-Grid tracking area has not been set, set it
        if(trackCheck == 0){
            [self snapToGridTrackingArea];
        }
        
        /*Placing the Piece */
        
        //Letting rebuildMode know it is time to set a piece
        hasBeenSet = true;
        
        // Store the Original positon
        storedLocation = refWallPiece.position;
        
        //Store a backup location for refWallPiece.position
        savedLocation = storedLocation;

        // Remove all the Hover Sprites
        [self removeAllSprites];
        
        //Call Rebuildmode for piece to set
        [RebuildMode rebuildMode: self piece: &piece set:hasBeenSet rotate:rightClick type:player];
        
        //Letting rebuildMode know it is time for hover piece
        hasBeenSet = false;
            
        //Reset refwallpiece back to its original position(Only for connecting wall cases)
        refWallPiece.position = savedLocation;
        
        // Store the Original positon
        storedLocation = refWallPiece.position;
        
        //if a wall could not be placed, don't grab a new piece
        if(!wallEncounter){
            //Give a new piece
             piece = [self giveRandomWallPieceNumber];
        }
        
        //Call for new piece outline
        [RebuildMode rebuildMode: self piece: &piece set:hasBeenSet rotate:rightClick type:player];
        
    }
    if(win || lose){
        [self returnToMain];
    }
    

}

/* When Right Click */
-(void)rightMouseDown:(NSEvent *)theEvent {
    
    
    // for testing printing out mapTiles
//        printf("mapTiles\n");
//        for(int i = 0;i<26;i++){
//            for(int j = 0; j<42;j++){
//                //NSLog(@"%lu ", (unsigned long)mapTiles[i][j]);
//                printf("%lu ", (unsigned long)mapTiles[i][j]);
//                //printf("%lu ", (unsigned long)fillArr[i][j]);
//            }
//            //NSLog(@"\n");
//            printf("\n");
//        }
//        printf("\n\n\n\nfillArr\n");
//        for(int i = 0;i<26;i++){
//            for(int j = 0; j<42;j++){
//                //NSLog(@"%lu ", (unsigned long)mapTiles[i][j]);
//                //printf("%lu ", (unsigned long)mapTiles[i][j]);
//                printf("%lu ", (unsigned long)fillArr[i][j]);
//            }
//            //NSLog(@"\n");
//            printf("\n");
//        }
    

    //When in rebuild mode, right clicking allows for rotation
    if(rebuildMode){
        
        //Set rightClick to be true for rotation
        rightClick = true;
        
        //Save Current Piece position
        storedLocation = refWallPiece.position;
        
        //Remove Hover Sprite
        [self removeAllSprites];
        //Call Rebuild Mode with rightClick = true for new peice
        [RebuildMode rebuildMode: self piece: &piece set:hasBeenSet rotate:rightClick type:blue];
        
        //Reset RightClick to false
        rightClick = false;
        
    }
}

/* When Mouse Cursor enters the button, create and place castle highlight */
- (void)mouseEntered:(NSEvent *)theEvent{
    
    //Create tracking area
    NSTrackingArea *curTrack = theEvent.trackingArea;
    
    //Create and place castle highlight
    SKSpriteNode *highlight = [CastleHighLight createCastleHighlight: player];
    highlight.position = CGPointMake([curTrack.userInfo[@"x"] integerValue], [curTrack.userInfo[@"y"] integerValue]);
    highlight.scale = tileScale;
    highlight.zPosition = 2;
    curHighlight = highlight;
    [self addChild:highlight];
}

/* When Mouse Cursor exits the button, remove castle highlight */
- (void)mouseExited:(NSEvent *)theEvent{
    [curHighlight removeFromParent];
}

/* need mouseMoved to implement "snap-to-grid" effect */
-(void)mouseMoved:(NSEvent *)theEvent {
    
    // Used to hide cursor
    //[NSCursor hide];
    if(cannonSelect && (cannonAmount != 0)) {
        float tileLongestDistFromCenter = 16.97056;
        CGPoint location = [theEvent locationInNode:self];
        NSArray *nodes = [self nodesAtPoint:location];
        SKSpriteNode *spriteTouched;
        for (SKSpriteNode *object in nodes) {
            // cursor is always touching cannonHover so below is to ignore cannonHover node
            if(![object.name isEqual: @"cannonHover"] && ![object.name isEqual: @"cannon"]) {
                spriteTouched = object;
            }
        }
        
        if(!CGPointEqualToPoint(storedLocation, spriteTouched.position)){
            
            // remove cannon hover sprite
            [self removeAllSprites];
            
            float distance = sqrt(pow((location.x - spriteTouched.position.x), 2.0) +
                                  pow((location.y - spriteTouched.position.y), 2.0));
            
            // if distance is less than tileLongestDistFromCenter, snap it to center of node
            if(distance <= tileLongestDistFromCenter){
                location.x = spriteTouched.position.x;
                location.y = spriteTouched.position.y;
            }
            
            location.x += 12;
            location.y -= 12;
            
            // store new location globally
            storedLocation = location;
            
            [self addCannonCursor];
        }
        
    }
    else if(rebuildMode){
        
        [[NSCursor arrowCursor] set];
        // 12x12 tiles, longest dist from center to a corner is about 17
        float tileLongestDistFromCenter = 16.97056;
        CGPoint location = [theEvent locationInNode:self];
        NSArray *nodes = [self nodesAtPoint:location];
        SKSpriteNode *spriteTouched;
        for (SKSpriteNode *object in nodes) {
            // cursor is always touching cannonHover so below is to ignore cannonHover node
            if(![object.name isEqual: @"timer"] && ![object.name isEqual: @"digit"] && ![object.name isEqual: @"cannon"] && ![object.name isEqual: @"castle"]) {
                spriteTouched = object;
            }
        }
        if(!CGPointEqualToPoint(refWallPiece.position, spriteTouched.position)){
            
            // remove wallhover sprites
            [self removeAllSprites];
            
            if( ![spriteTouched.name isEqualToString:@"castle"]){
                // calculate distance from center point of node to cursor location
                float distance = sqrt(pow((location.x - spriteTouched.position.x), 2.0) +
                                  pow((location.y - spriteTouched.position.y), 2.0));
            
                // if distance is less than tileLongestDistFromCenter, snap it to center of node
                if(distance <= tileLongestDistFromCenter){
                    location.x = spriteTouched.position.x;
                    location.y = spriteTouched.position.y;
                }
                
            }
            
            //Store new location globally
            storedLocation = location;
            
            //[self removeAllSprites];
            [RebuildMode rebuildMode: self piece: &piece set:hasBeenSet rotate:rightClick type: 0];
        }
        
    }
}

/*--------------------------Call Battle Mode (Player) Functions------------------------------*/


/* BattleMode */
-(void)goToBattleMode{
    
    /******Send the map data to Battle Mode******/
    NSUserDefaults *sceneInfo = [NSUserDefaults standardUserDefaults];
    [sceneInfo setInteger:wind forKey:@"wind"];
    [sceneInfo setInteger:selectedCannonCount forKey:@"cannonCount"];
    [sceneInfo setInteger:player forKey:@"player"];
    
    battleMode = true;
    
    //Removes the tracking area for snap to grid during Battle mode
    [self snapToGridTrackingArea];
    
    //Transition to Battlemode scene
    BattleMode *battle = [BattleMode sceneWithSize:self.size];
    prepareForBattle = true;
    
    [self transitionBricks:50 :600 :960 :470]; //set up phrase "Prepare for Battle"
    prepareForBattle = FALSE;
    SKTransition* nextScene =[SKTransition revealWithDirection:SKTransitionDirectionDown duration:3 ];
    nextScene.pausesOutgoingScene = FALSE;
    nextScene.pausesIncomingScene = FALSE;

    [self.view presentScene:battle transition:nextScene];
    
    
    //Set cannon select to false
    cannonSelect = false;
    
    //Set rebuildMode to true & wallEncounter to False for wall collisions tracking
    rebuildMode = true;
    wallEncounter = false;
    countdown = 0;
    
    [self performSelector:@selector(doChangeCursorTarget) withObject:nil afterDelay:0];
    //Setting for RebuildMode Flood
}

/* Figures out how many cannons to place */
-(void)figureCannons{
    
    cannonAmount = 0;
    aiCannonAmount = 0;
    for(SKNode * child in self.children) {
        if([child.name isEqualTo:@"playerCastle"]){
            cannonAmount++;
        }
        else if([child.name isEqualTo:@"aiCastle"])
        {
            aiCannonAmount++;
        }
    }
    //ai can not fire any cannons --> they have no secured castles--> we win!
    if(aiCannonAmount == 0){
        //We won
        win = true;
    }
    else if(cannonAmount == 0){
        lose = true;
    }
    
    if(win){
        [self winScreen];
    }
    else if (lose){
        [self loseScreen];
    }
}

/* Changes cursor to the target icon. */
- (void) doChangeCursorTarget{
    //Initialize cursor Color to Yellow
    int cursorColor = 0;
    
    //If Cursor is red
    if(player == red){
        cursorColor = 2;
    }
    //If Cursor is red
    else if(player == blue){
        cursorColor = 4;
    }
    
    //Initialize and creates and image of the Color Target
    NSImage * img = [NSImage imageNamed:@"Target copy"];
    NSImage* target = [[NSImage alloc] initWithSize:NSMakeSize(24, 24)];
    [target lockFocus];
    [img drawAtPoint:NSMakePoint(0, 0) fromRect:NSMakeRect(0, 12*cursorColor, 24, 24) operation:NSCompositeSourceOver fraction:1.0];
    [target setSize: CGSizeMake(tileEdge*1.5, tileEdge*1.5)];
    [target unlockFocus];
    
    //Places the cursor at the center point in the box.
    NSCursor *aimcursor = [[NSCursor alloc] initWithImage:target hotSpot: NSMakePoint(18,18)];
    [aimcursor set];
}

/*------------------------------Rebuild Mode (Player) Functions------------------------------*/

/* Add CannonCursor */
-(void)addCannonCursor{
    
    if(!win && !lose){
        NSMutableArray *cannonArr = [GameScene fillTileSet:@"2DCastleCannon copy"];
        //Cannon Cursor initialize to yellow
        int cannonCursor = 9;
        if(player == red){
            cannonCursor = 18;
        }
        else if(player == blue){
            cannonCursor = 27;
        }
        
        SKSpriteNode * cannonHover = [SKSpriteNode spriteNodeWithTexture:[cannonArr objectAtIndex:cannonCursor-cannonAmount]];
        cannonHover.position = storedLocation;
        cannonHover.scale = tileScale;
        cannonHover.zPosition = 4;
        cannonHover.name = @"cannonHover";
        [self addChild:cannonHover];
    }
    
}

/* Calls Floodfill to create checkerboard*/
-(void)reFlood{
    [RebuildMode makeFillArr];
    [RebuildMode floodFill8:0 Y:0 newNum:9 oldNum:0];
    [RebuildMode fillCheckerBoard:self color: player];
    [RebuildMode floodFill8:0 Y:0 newNum:0 oldNum:9];
    
    //Initial Castle Select
    if(castleSelect){
        cannonAmount = 3;
    }
}

/* Removes all unnecessary sprites */
-(void)removeAllSprites{
    
    if(cannonSelect) {
        for(SKSpriteNode * node in self.children) {
            if([node.name isEqualToString: @"cannonHover"]) {
                [node removeFromParent];
            }
        }
    }
    else if(rebuildMode) {
        //For every sprite node that matches wallHover, remove from the scene
        for(SKSpriteNode * node in self.children) {
            if([node.name isEqualToString: @"wallHover"]) {
                [node removeFromParent];
            }
        }
    }

}

/* Returns number 0-63 to determine a random piece */
- (int)giveRandomWallPieceNumber{
    int r = 0;
    int lowerBound = 0;
    int upperBound = 63;
    r = lowerBound + arc4random() % (upperBound - lowerBound);
    return r;
}



/*-----------------AI Functions(CastlePlacement/CannonPlacement/RebuildMode)-----------------*/


/* Placing Ai Castle */
-(void) placeAICastleAtLocation: (int) indexValue {
    // tags 1 and 4 are special cases that need to be accounted for (castle too close to river, etc.)
    int x = (int)castleXCoordinate[indexValue]*tileEdge;
    int y = (int)castleYCoordinate[indexValue]*tileEdge;

    if(indexValue == 1){
        
        [CastleHighLight createCastleWallCorner: self.scene xCord:x yCord:y color:aiColor];
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(y/24) X:round(x/24)+i value:1];
            if (i < 2)
                [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)-4 value:1];
            if (i < 6)
                [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)+3 value:1];
        }
        
        [GameScene mapTilesY:22-round(y/24)+5 X:round(x/24)+2 value:1];
        [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)+2 value:1];
        [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)+1 value:1];
        
    }//if
    else if(indexValue == 4)
    {
        
        [CastleHighLight createCastleWallDip:self.scene xCord:x yCord:y color:aiColor];
        
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(y/24) X:round(x/24)+i value:1];
        }
        
        for (int i = -4; i <= -1; i++) {
            [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)+i value:1];
        }
        
        for (int i = 1; i <= 5; i++) {
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)+3 value:1];
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)-4 value:1];
        }
        
        [GameScene mapTilesY:22-round(y/24)+5 X:round(x/24)+2 value:1];
        [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)+2 value:1];
        [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)+1 value:1];
        [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24)+1 value:1];
        [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24) value:1];
        [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24)-1 value:1];
        [GameScene mapTilesY:22-round(y/24)+6 X:round(x/24)-1 value:1];
    }
    else if (indexValue == 5)
    {
        
        [CastleHighLight createCastleWallPiece:self.scene xCord:x yCord:y color:aiColor];
        
        /*Store 1's in the location of walls*/
        
        for (int i = -3; i <= 3; i++) {
            [GameScene mapTilesY:22-round(y/24) X:round(x/24)+i value:1];
        }
        
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)+3 value:1];
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)-4 value:1];
        }
        
        [GameScene mapTilesY:22-round(y/24)+1 X:round(x/24)-3 value:1];
    }
    else    // else the default 6x6 tile checkerboard
    {
        
        [CastleHighLight createCastleWall: self.scene xCord:x yCord:y color:aiColor];
        
        /*Store 1's in the location of walls*/
        for (int i = -4; i <= 3; i++) {
            [GameScene mapTilesY:22-round(y/24) X:round(x/24)+i value:1];
            [GameScene mapTilesY:22-round(y/24)+7 X:round(x/24)+i value:1];
        }
        
        for (int i = 1; i <= 6; i++) {
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)+3 value:1];
            [GameScene mapTilesY:22-round(y/24)+i X:round(x/24)-4 value:1];
        }
    }//else
    
    //Calls Floodfill to create the checkerboard for the first selected castle
    [self reFloodAI];
    
}

/* Place an AI cannon at valid positon */
-(void)placeAICannonX:(int)x Y:(int)y{
    
    [BattleMode cannonPosX:selectedCannonCount value:x*tileEdge+24];
    [BattleMode cannonPosY:selectedCannonCount value:(25 - y)*tileEdge];
    
    selectedCannonCount++;
    
    //NSLog(@"%d %d", x, 26-y);
    SKSpriteNode *cannon = [SKSpriteNode spriteNodeWithTexture:[cannonArr objectAtIndex:27]];
    cannon.position = CGPointMake(x*tileEdge+24, (25 - y)*tileEdge);
    cannon.name = @"cannon";
    cannon.zPosition = 2;
    cannon.scale = tileScale;
    SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
    [self runAction: sound];
    [self addChild:cannon];
    
}

/* Place Ai Cannons onto the grid */
-(void) placeAICannons{
    static int x = 0, y = 0;
    
    [AI place_cannon: &aiColor: mapWidth: mapHeight: &x: &y];
    
    if ( x != 0 && y != 0){
        aiDestination.x = x;
        aiDestination.y = y;
        if(!lose){
            [self createAICursorX:x Y:y num:aiCannonAmount];
        }
    }
}

/* Create cursor and cursor route */
-(void)createAICursorX:(int)x Y:(int)y num:(int)n{
    int cannonCursor = 9;
    
    if(aiColor == red){
        cannonCursor = 18;
    }
    else if(aiColor == blue){
        cannonCursor = 27;
    }
    if(initialAICursor){
        aiCursor = [SKSpriteNode spriteNodeWithTexture:[cannonArr objectAtIndex:cannonCursor-n]];
        aiCursor.position = CGPointMake(2*tileEdge, tileEdge*24);
        initialAICursor = false;
    }
    else{
        aiCursor.texture = [cannonArr objectAtIndex:cannonCursor-n];
    }
    aiCursor.scale = tileScale;
    aiCursor.zPosition = 3;
    aiCursor.name = @"aiCannonHover";
    [self runAiSnapToGridCannon];
}

/* Recursive Function for Cursor to move while snapping to grid to destination(Where to place Cannons) 
*/
-(void)runAiSnapToGridCannon{
    
    aiLocation = CGPointMake(aiCursor.position.x,aiCursor.position.y);
    SKAction *followline = [SKAction moveTo:CGPointMake(aiLocation.x, aiLocation.y) duration:0.1];
    [self addChild:aiCursor];
    
    //Runs cursor animation until completion,
    [aiCursor runAction:followline completion:^{
        
        CGPoint check = CGPointMake(tileEdge*aiDestination.x+24,(25-aiDestination.y)*tileEdge);
        CGPoint temp = CGPointMake(aiCursor.position.x, aiCursor.position.y);
        
        if((check.x == aiLocation.x) && (check.y == aiLocation.y)){
            
            [self placeAICannonX:aiDestination.x Y:aiDestination.y];
            aiCannonAmount--;
            //Remove the Ai Cursor
            [aiCursor removeFromParent];
            //Check if there are more aiCannons
            if(aiCannonAmount != 0){
                [self placeAICannons];
            }
            oldCursorPosition = aiCursor.position;
        }
        else{
            [aiCursor removeFromParent];
            if(check.x == aiLocation.x){
                
                if(check.y > aiLocation.y){
                    temp.y += 12;
                }
                else{
                    temp.y -= 12;
                }
                aiCursor.position = temp;
            }
            else if(check.y == aiLocation.y){
                if(check.x > aiLocation.x){
                    temp.x += 12;
                }
                else{
                    temp.x -= 12;
                }
                aiCursor.position = temp;
            }
            else{
                
                if(check.y > aiLocation.y && check.x > aiLocation.x){
                    temp.y += 12;
                    temp.x += 12;
                }
                else if(check.y < aiLocation.y && check.x < aiLocation.x){
                    temp.y -= 12;
                    temp.x -= 12;
                }
                else if(check.y < aiLocation.y && check.x > aiLocation.x){
                    temp.y -= 12;
                    temp.x += 12;
                }
                else{
                    temp.y += 12;
                    temp.x -= 12;
                }
                aiCursor.position = temp;
            }
            [self runAiSnapToGridCannon];
        }
    }];
}

/* Place Ai Pieces Function - Initial Call */
-(void) placeAIPieces{
    //int castleXCoordinate[] = {37, 36, 36, 26, 18};
    //int castleYCoordinate[] = {20, 12, 6, 7, 6};

    
    //Hardcoded for now
    int array6X[] = {32,33,34,35,36,37,38,39,39,39,39,39,39,39,39,39,38,37,36,35,34,33,32,32,32,32,32,32,32,0};
    int array6Y[] = {15,15,15,15,15,15,15,15,16,17,18,19,20,21,22,22,22,22,22,22,22,22,22,21,20,19,18,17,16,0};
    
     //Same Logic as Cannon Cursor
    static int x,y;
    cantPlace = 1;
    
    if(array6X[aiArrayCount] != 0 && array6Y[aiArrayCount] != 0) {
        x = array6X[aiArrayCount];
        y = array6Y[aiArrayCount];
        cantPlace = 0;
  
        //Store the Final Destination of where to place the piece
        aiDestination.x = x;
        aiDestination.y = y;
        
        //Initialize for first piece
        aiPiece = [self giveRandomAiWallPieceNumber]; //
        
        //Call Recursive function to move Ai cursor to where piece needs to be placed
        [self runAiSnapToGridPiece];
    }
    //printf("im out\n");
}


/* Recursive Function for Moving the pieces to its destination. */
-(void)runAiSnapToGridPiece{
    
    /*
     aiLocation - Location of where the next place to move to
     aiRefWallPiece - the main piece of the tetris pieces
     oldCursorPosition - where the cursor of the ai was last at 
     
     Basic idea of this loop
     - It gets a position from function placeAiPieces which checks for where it should place the actual piece at
     - It Calls RunaiSnaptoGridPiece:
        - it stores an aiLocation of the piece
        - it moves to that location while snapping to grid
        - When completed each time, it makes a check for if it has reached the destination.
        - If it hasn't reached the destination, it would increment or decrement by a size of 12
        - Then using that position, it would move to the next point
        - Loop until x and y matches, which calls RebuildModeAI to place the piece.
     */
    

    //Stores the oldCursorPosition(Where the mouse is at) into aiLocation
    aiLocation = CGPointMake(oldCursorPosition.x,oldCursorPosition.y);
    
    //Call RebuildModeAI for the hover piece
    [RebuildModeAI rebuildModeAi:self piece:&aiPiece set:false rotate:false type:aiColor];

    //Go To Location
    SKAction *followline = [SKAction moveTo:CGPointMake(aiLocation.x, aiLocation.y) duration:0.03];
    
    //Move aiWallPiece until finished
    [aiRefWallPiece runAction:followline completion:^{
        
        
        //Used to check if it reached the destination
        CGPoint check = CGPointMake(tileEdge*aiDestination.x+12,(25-aiDestination.y)*tileEdge-12);
        
        CGPoint temp = CGPointMake(aiLocation.x, aiLocation.y);
        
        //checks to see if aiLocation is equal to the destination
        if((check.x == aiLocation.x) && (check.y == aiLocation.y)){
            
            //Call RebuildModeAI to set the piece at the position
            [RebuildModeAI rebuildModeAi:self piece:&aiPiece set:true rotate:false type:aiColor];
            
            //Remove the Ai Piece Hover sprites
            [self removeAiSprites];
            
            //Increment the position of the hardcoded array (Won't need later)
            aiArrayCount++;
            
            //Recall for another place to place a piece
            [self placeAIPieces];
            
            
        }
        //This snaps the cursor to the grid for the next location
        else{
            int snap = 12;
            if(check.x == aiLocation.x){
                
                if(check.y > aiLocation.y){
                    temp.y += snap;
                }
                else{
                    temp.y -= snap;
                }
                aiRefWallPiece.position = temp;
            }
            else if(check.y == aiLocation.y){
                if(check.x > aiLocation.x){
                    temp.x += snap;
                }
                else{
                    temp.x -= snap;
                }
                aiRefWallPiece.position = temp;
            }
            else{
                
                if(check.y > aiLocation.y && check.x > aiLocation.x){
                    temp.y += snap;
                    temp.x += snap;
                }
                else if(check.y < aiLocation.y && check.x < aiLocation.x){
                    temp.y -= snap;
                    temp.x -= snap;
                }
                else if(check.y < aiLocation.y && check.x > aiLocation.x){
                    temp.y -= snap;
                    temp.x += snap;
                }
                else{
                    temp.y += snap;
                    temp.x -= snap;
                }
                aiRefWallPiece.position = temp;
            }
            
            //Store the New position into oldCursorPosition
            oldCursorPosition = aiRefWallPiece.position;

            //Remove the AiSprites
            [self removeAiSprites];
            
            //Recall SnappToGrid
            [self runAiSnapToGridPiece];
        }
    }];
}

-(void)reFloodAI{
    
    [RebuildMode makeFillArr];
    [RebuildMode floodFill8:0 Y:0 newNum:9 oldNum:0];
    [RebuildMode fillCheckerBoard:self color: aiColor];
    [RebuildMode floodFill8:0 Y:0 newNum:0 oldNum:9];
    
    //Initial Castle Select
    if(castleSelect){
        aiCannonAmount = 3;
    }
}
/* Removes all unnecessary sprites */

-(void)removeAiSprites{

    if(rebuildMode) {
        //For every sprite node that matches wallHover, remove from the scene
        for(SKSpriteNode * node in self.children) {
            if([node.name isEqualToString: @"aiWallHover"]) {
                [node removeFromParent];
            }
        }
    }
}

/* Returns number 0-63 to determine a random piece */
- (int)giveRandomAiWallPieceNumber{
    int r = 0;
    int lowerBound = 0;
    int upperBound = 1;
    r = lowerBound + arc4random() % (upperBound - lowerBound);
    return r;
}

/* Checks adjacent locations for AI. */
-(void) adjacencyCheck: (int)xCoord Y: (int)yCoord{ //priya
    //Prints x and y coordinates. currently hard-coded to 37 20
    NSLog(@"\nOriginal coordinates:\nX: %d, Y: %d" ,xCoord, yCoord);
    
    // Top left tile from castle.
    if(fillArr[yCoord + 1][xCoord - 1] == 0)
    {
        adjacentTargetX = xCoord - 1;
        adjacentTargetY = yCoord + 1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Top center tile from castle.
    else if(fillArr[yCoord + 1][xCoord] == 0)
    {
        adjacentTargetX = xCoord;
        adjacentTargetY = yCoord + 1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Top right tile from castle.
    else if(fillArr[yCoord + 1][xCoord + 1] == 0)
    {
        adjacentTargetX = xCoord +1;
        adjacentTargetY = yCoord +1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Left of center tile from castle.
    else if(fillArr[yCoord][xCoord - 1] == 0)
    {
        adjacentTargetX = xCoord - 1;
        adjacentTargetY = yCoord;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Right of center tile from castle.
    else if(fillArr[yCoord][xCoord + 1] == 0)
    {
        adjacentTargetX = xCoord + 1;
        adjacentTargetY = yCoord;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Bottom left corner tile from castle.
    else if(fillArr[yCoord - 1][xCoord - 1] == 0)
    {
        adjacentTargetX = xCoord - 1;
        adjacentTargetY = yCoord - 1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Below center from castle.
    else if(fillArr[yCoord - 1][xCoord] == 0)
    {
        adjacentTargetX = xCoord;
        adjacentTargetY = yCoord - 1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }
    // Bottom right corner tile from castle.
    else if(fillArr[yCoord - 1][xCoord + 1] == 0)
    {
        adjacentTargetX = xCoord - 1;
        adjacentTargetY = yCoord + 1;
        NSLog(@"\nMatch found. adjacent tile at x coordinate %d, y coordinate %d", adjacentTargetX, adjacentTargetY);
    }

}


/*------------------------------------Transitioning Screens----------------------------------*/

+(NSMutableArray*)fillCastleSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

/* places a letter taken from a file at a given location */
-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    
    
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    A.zPosition = 1000;
    if(!win && !lose &&!prepareForBattle){
        SKAction* moveDown = [SKAction moveByX:0 y:-800 duration:3];
        [A runAction:moveDown];
    }//did we win? then don't move banner
    
    [self addChild:A];
}

-(void)letterBlue:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    
    
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    A.zPosition = 800;
    if(!win && !lose &&!prepareForBattle){
        SKAction* moveDown = [SKAction moveByX:0 y:-800 duration:3];
        [A runAction:moveDown];
    }//did we win? then don't move banner
    [self addChild:A];
}//just for blue

/* Phrase for Placing Cannons */
-(void)phrasePlaceCannons{
    
    int level = 525;
    int space = 10;
    NSMutableArray *alphabet = [GameScene fillCastleSet:@"FontKingthingsWhite copy" withTileNumber:95];
    /*
     a = 61, b = 60, c = 59, d = 58, e = 57,f = 56, g = 55, h = 54,
     i = 53, j = 52, k = 51, l = 50, m = 49, n = 48, o = 47, p = 46,
     q = 45, r = 44, s = 43, t = 42, u = 41, v = 40, w = 39,x = 38,
     y = 37,z = 36
     
     */
    
    SKSpriteNode* placeCannons = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];//p
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(space,0)];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(2 *space,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(3 *space,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(4 *space,0)];
    
    SKSpriteNode* C2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C2 setPosition:CGPointMake((5 *space + 10),0)];
    
    SKSpriteNode* A2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A2 setPosition:CGPointMake( (6 *space + 10),0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake((7 *space + 10),0)];
    
    SKSpriteNode* N2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N2 setPosition:CGPointMake((8 *space + 10),0)];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake((9 *space + 10),0)];
    
    
    SKSpriteNode* N3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N3 setPosition:CGPointMake((10 *space + 10),0)];
    
    SKSpriteNode* E2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [E2 setPosition:CGPointMake((11 *space + 10),0)];
    
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake((12 *space),0)];
    
    [placeCannons addChild:L];
    [placeCannons addChild:A];
    [placeCannons addChild:C];
    [placeCannons addChild:E];
    [placeCannons addChild:C2];
    [placeCannons addChild:A2];
    [placeCannons addChild:N];
    [placeCannons addChild:N2];
    [placeCannons addChild:O];
    [placeCannons addChild:N3];
    [placeCannons addChild:S];
    
    placeCannons.scale = 2;
    if(!win && !lose){
        [self transitionBricks:50 :600 :960 :470];
        SKAction* moveDown = [SKAction moveByX:0 y:-800 duration:3];
        
        //Run Banner down, then start cannon placement
        
        [placeCannons runAction:moveDown completion:^{
            cannonSelect = true;
            //Adding Timer to Map
            [self startTimer];
            //AI Places cannons
            [self placeAICannons];
        }];
        placeCannons.position = CGPointMake(380,level);
        placeCannons.zPosition = 1001;
        [self addChild:placeCannons];
    }//did we win?
    
}

/* Phrase for Rebuild Mode */
-(void)phraseBattle{
    NSMutableArray *alphabet = [GameScene fillCastleSet:@"FontKingthingsWhite copy" withTileNumber:95];
    //set up alphabet
    //Spells "REBUILD WALLS TO STAY ALIVE"
    SKNode *battlePhrase= [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];//P
    
    SKSpriteNode* R1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R1 setPosition:CGPointMake(10,0)];//R
    SKSpriteNode* E1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E1 setPosition:CGPointMake(20,0)];//E
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(30,0)];//P
    SKSpriteNode* A1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A1 setPosition:CGPointMake(40,0)];//A
    SKSpriteNode* R2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R2 setPosition:CGPointMake(50,0)];//R
    SKSpriteNode* E2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E2 setPosition:CGPointMake(60,0)];//E
    SKSpriteNode* F = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:56]];
    [F setPosition:CGPointMake(80,0)];//F
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(90,0)];//O
    SKSpriteNode* R3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R3 setPosition:CGPointMake(100,0)];//R
    SKSpriteNode* B = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    [B setPosition:CGPointMake(120,0)];//B
    SKSpriteNode* A2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A2 setPosition:CGPointMake(130,0)];//A
    SKSpriteNode* T1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T1 setPosition:CGPointMake(140,0)];//T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T2 setPosition:CGPointMake(150,0)];//T
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(160,0)];//L
    SKSpriteNode* E3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E3 setPosition:CGPointMake(170,0)];//E
    
    [battlePhrase addChild:R1];
    [battlePhrase addChild:E1];
    [battlePhrase addChild:P];
    [battlePhrase addChild:A1];
    [battlePhrase addChild:R2];
    [battlePhrase addChild:E2];
    [battlePhrase addChild:F];
    [battlePhrase addChild:O];
    [battlePhrase addChild:R3];
    [battlePhrase addChild:B];
    [battlePhrase addChild:A2];
    [battlePhrase addChild:T1];
    [battlePhrase addChild:T2];
    [battlePhrase addChild:L];
    [battlePhrase addChild:E3];
    
    battlePhrase.scale = 2;
    battlePhrase.position = CGPointMake(350,525);
    battlePhrase.zPosition = 1001;
    //SKAction* moveDown = [SKAction moveByX:0 y:-800 duration:3];
    //[battlePhrase runAction:moveDown];
    [self addChild:battlePhrase];
}

-(void)transitionBricks:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [GameScene fillCastleSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [GameScene fillCastleSet:@"Mortar copy" withTileNumber:28];
    NSMutableArray *blue = [GameScene fillCastleSet:@"2DTerrain copy" withTileNumber:30];
    
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightY ; ycount -= 20) {
        
        for (unsigned long int xcount = upperLeftX; xcount <= lowerRightX; xcount+=20) {
            [self letterBlue:(ycount) X:(xcount) alpha:3 file:blue];
        }
        
    }
    
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    
    
    
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
    
    if(battleMode == true){
        [self phraseBattle];
    }//only called if battleMode
}


/*--------------------------------------Win/Lose Screens-------------------------------------*/
/* Show Win Screen */
-(void)winScreen{ //change to main menu on click
    [self transitionBricks:360 :456 :648 :192];
    [self phraseWin];//BLUE ARMY CONQUERS
}

/* Show Lose Screen */
-(void)loseScreen{ //change to main menu on click
    [self transitionBricks:360 :456 :648 :192];
    
    MusicPlayerStop(rebuildMidiPlayer);
    
    [self phraseLose];//BLUE ARMY DEFEATED
}

/* Return to Main Menu */
-(void)returnToMain{
    
    //Remove Tracking area (This was what was messing up the main menu)
    [self snapToGridTrackingArea];
    
    //Reinitialize Needed Variables
    //Some might not be needed - will clean later
    battleMode = false;
    rebuildMode = false;
    castleSelect = true;
    win = false;
    lose = false;
    
    MainMenu *scene = [MainMenu sceneWithSize:self.view.bounds.size];
    CGSize s;
    s.width = 1008;
    s.height = 624;
    scene.size = s;
    scene.scaleMode = SKSceneScaleModeAspectFit;
    [self.view presentScene:scene];
    // [self.view presentScene:[MainMenu sceneWithSize:self.view.bounds.size]];
    //return to main on click
}

/* Print out Win Screen */
-(void)phraseWin{
    NSMutableArray *alphabet = [GameScene fillCastleSet:@"FontKingthingsWhite copy" withTileNumber:95];
    //set up alphabet
    //Spells "BLUE ARMY CONQUERS"
    /*
     a = 61, b = 60, c = 59, d = 58, e = 57,f = 56, g = 55, h = 54,
     i = 53, j = 52, k = 51, l = 50, m = 49, n = 48, o = 47, p = 46,
     q = 45, r = 44, s = 43, t = 42, u = 41, v = 40, w = 39,x = 38,
     y = 37,z = 36
     */
    
    SKNode *winPhrase= [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];//B
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(10,0)];//L
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(20,0)];//U
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(30,0)];//E
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(0,-20)];//A
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(10,-20)];//R
    SKSpriteNode* M = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:49]];
    [M setPosition:CGPointMake(20,-20)];//M
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(30,-20)];//Y
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(-20,-40)];//C
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(-10,-40)];//O
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(0,-40)];//N
    SKSpriteNode* Q = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:45]];
    [Q setPosition:CGPointMake(10,-40)];//Q
    SKSpriteNode* U1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U1 setPosition:CGPointMake(20,-40)];//U
    SKSpriteNode* E1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E1 setPosition:CGPointMake(30,-40)];//E
    SKSpriteNode* R1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R1 setPosition:CGPointMake(40,-40)];//R
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake(50,-40)];//S
    
    [winPhrase addChild:L];
    [winPhrase addChild:U];
    [winPhrase addChild:E];
    
    [winPhrase addChild:A];
    [winPhrase addChild:R];
    [winPhrase addChild:M];
    [winPhrase addChild:Y];
    
    [winPhrase addChild:C];
    [winPhrase addChild:O];
    [winPhrase addChild:N];
    [winPhrase addChild:Q];
    [winPhrase addChild:U1];
    [winPhrase addChild:E1];
    [winPhrase addChild:R1];
    [winPhrase addChild:S];
    
    winPhrase.scale = 2;
    winPhrase.position = CGPointMake(475,364);
    winPhrase.zPosition = 1001;
    [self addChild:winPhrase];
}

/* Print out Lose Screen */
-(void)phraseLose{
    NSMutableArray *alphabet = [GameScene fillCastleSet:@"FontKingthingsWhite copy" withTileNumber:95];
    //set up alphabet
    //Spells "BLUE ARMY CONQUERS"
    /*
     a = 61, b = 60, c = 59, d = 58, e = 57,f = 56, g = 55, h = 54,
     i = 53, j = 52, k = 51, l = 50, m = 49, n = 48, o = 47, p = 46,
     q = 45, r = 44, s = 43, t = 42, u = 41, v = 40, w = 39,x = 38,
     y = 37,z = 36
     */
    
    SKNode *winPhrase= [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];//B
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(10,0)];//L
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(20,0)];//U
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(30,0)];//E
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(0,-20)];//A
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(10,-20)];//R
    SKSpriteNode* M = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:49]];
    [M setPosition:CGPointMake(20,-20)];//M
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(30,-20)];//Y
    SKSpriteNode* D = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:58]];
    [D setPosition:CGPointMake(-20,-40)];//C
    SKSpriteNode* E1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E1 setPosition:CGPointMake(-10,-40)];//O
    SKSpriteNode* F = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:56]];
    [F setPosition:CGPointMake(0,-40)];//N
    SKSpriteNode* E2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E2 setPosition:CGPointMake(10,-40)];//Q
    SKSpriteNode* A1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A1 setPosition:CGPointMake(20,-40)];//U
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(30,-40)];//E
    SKSpriteNode* E3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E3 setPosition:CGPointMake(40,-40)];//R
    SKSpriteNode* D1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:58]];
    [D1 setPosition:CGPointMake(50,-40)];//S
    
    [winPhrase addChild:L];
    [winPhrase addChild:U];
    [winPhrase addChild:E];
    
    [winPhrase addChild:A];
    [winPhrase addChild:R];
    [winPhrase addChild:M];
    [winPhrase addChild:Y];
    
    [winPhrase addChild:D];
    [winPhrase addChild:E1];
    [winPhrase addChild:F];
    [winPhrase addChild:E2];
    [winPhrase addChild:A1];
    [winPhrase addChild:T];
    [winPhrase addChild:E3];
    [winPhrase addChild:D1];
    
    winPhrase.scale = 2;
    winPhrase.position = CGPointMake(475,364);
    winPhrase.zPosition = 1001;
    [self addChild:winPhrase];
}

/*-----------------------------------------Others---------------------------------------------*/

/* Fill an array with a given image */
+(NSMutableArray*)fillTileSet: (NSString*)tileSet{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    //Single target dimensions
    float tileHeight = curTile.size.height;
    float tileWidth = curTile.size.width;
    
    // Calculate number of tiles in the tile set
    NSUInteger tileCount = (tileHeight/tileWidth);
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

/* Calls everytime to handle cursor */
-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
    
    
    //Calls Target Mouse Cursor every frame to handle mouse exiting screen
    if(battleMode){
        //Calls ChangeCursor
        [self performSelector:@selector(doChangeCursorTarget) withObject:nil afterDelay:0];
    }
    //TODO: Add a check to later stop it from reflooding everytime
    else if(rebuildMode && initialFlood){
        [self reFlood];
        [self reFloodAI];
        initialFlood = false;
    }
    
    //[[NSCursor arrowCursor] set];
}










@end //GameScene
