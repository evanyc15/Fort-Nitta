/*
 *  RebuildMode.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <Foundation/Foundation.h>

int pieceHeight;
int pieceWidth;

@interface RebuildMode : NSObject

+(void)rebuildMode: (GameScene *) scene piece: (int *) piece set: (Boolean)hasBeenSet rotate: (Boolean) rightClick type: (int)color;
+(void)combineWalls: (GameScene *) scene sprite:(SKSpriteNode *)piece pos:(CGPoint)oldPosition;
+(SKSpriteNode *)combineWalls2: (GameScene *) scene sprite:(SKSpriteNode *)piece2 pos:(CGPoint)oldPosition;
+(int)rotate: (int *) piece;
+(void)printWall: (GameScene *) scene sprite:(SKSpriteNode *)piece pos:(CGPoint)location;
+(void)fillCheckerBoard: (GameScene*) scene color: (int) playerColor;
+(void)floodFill8:(NSInteger)x Y:(NSInteger)y newNum:(NSInteger)num1 oldNum:(NSInteger)num2;
+(void)floodFill8Clear:(NSInteger)x Y:(NSInteger)y newNum:(NSInteger)num1 oldNum:(NSInteger)num2;
+(void)makeFillArr;
+(void)setCombineColor: (int) color;
@end