/*
 *  WallHoverPiecesAI.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */


#import "GameScene.h"
#import "WallHoverPiecesAI.h"
#import <Foundation/Foundation.h>

#define tileEdge 24
#define tileScale 2

@implementation WallHoverPiecesAI


/* Creates all Wall Hover Pieces */


/*  ___
 |__|
 */


+(void)monominoOutline: (GameScene *) scene curPos:(CGPoint) location{
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:84]];
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
}


/*  ___
 |  |
 |__|
 */
+(void)dominoOutline: (GameScene *) scene curPos:(CGPoint) location{
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode * piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
}


+(void)dominoOutlineAlt: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
}


/*  ___
 | |__
 |____|
 */
+(void)trominoLOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom left piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}


+(void)trominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}


+(void)trominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top left piece
    location.x -= tileEdge;
    location.y += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}


+(void)trominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}


/*  ___
 |  |
 |  |
 |__|
 */
+(void)trominoIOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}

/*
 -- -- --
 |        |
 |__ __ __|
 */

+(void)trominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
}


/*  ___
 |  |__
 |__   |
 |__|
 */
+(void)tetrominoZOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle left piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoZOutlineAlt: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top right piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top left piece
    location.x -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom right piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}

/*  ___
 |  |
 |  |
 |  |
 |__|
 */
+(void)tetrominoIOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


/*  ____
 |   |
 |___|
 */
+(void)tetrominoCubeOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


/*  ________
 |__  __|
 |__|
 */
+(void)tetrominoTOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom middle piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoTOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // left piece sticking out
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top piece
    location.y += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom piece
    location.y -= (2 * tileEdge);
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoTOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // left bottom piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle bottom piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top piece
    location.y += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // right bottom piece
    location.x += tileEdge;
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoTOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // right piece sticking out
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.x -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top piece
    location.y += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom piece
    location.y -= (2 * tileEdge);
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


/*  __
 | |
 | |_
 |___|
 */
+(void)tetrominoLOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}

+(void)tetrominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom piece
    location.x -= (2 * tileEdge);
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


+(void)tetrominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    
    // bottom left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // top piece
    location.y += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
}


/*   ____
 __|  _|
 |__  |
 |_|
 */
+(void)pentominoFOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // middle left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top piece
    location.y += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // top right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.x -= tileEdge;
    location.y -= (2* tileEdge);
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoFOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // right piece
    location.x += (2 * tileEdge);
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoFOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle left piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom left piece
    location.x -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoFOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle left piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle center piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*  ___
 |  |
 |  |
 |  |
 |  |
 |__|
 */
+(void)pentominoIOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // 2nd middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // 3rd middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // 4th middle piece piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*  __
 | |
 | |
 | |_
 |___|
 */
+(void)pentominoLOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.x -= (3 * tileEdge);
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle pieces
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    
    // left bottom piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // right bottom piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // top piece
    location.y += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*     __
 | |
 __| |
 | __|
 |_|
 */
+(void)pentominoNOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    
    // top piece of left column
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom piece of left column
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom piece of right column
    location.y += tileEdge;
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    //  middle piece of right column
    location.y += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // top piece of right column
    location.y += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoNOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    //  bottom middle piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoNOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoNOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*  ____
 |   |
 | __|
 |_|
 */
+(void)pentominoPOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom left piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // extra piece sticking out of cube
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoPOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom left piece
    location.x -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoPOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    
    // top piece sticking out
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoPOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom right piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // piece sticking out
    location.x += (2 * tileEdge);
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*  _______
 |__  __|
 |  |
 |__|
 */
+(void)pentominoTOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoTOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // middle left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // top piece
    location.y += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= (2 * tileEdge);
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoTOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += (2 * tileEdge);
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoTOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle left piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle piece
    location.x += tileEdge;
    location.y += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // middle right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*  __    __
 | |__| |
 |______|
 */
+(void)pentominoUOutline: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += (2 * tileEdge);
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // left bottom piece
    location.x -= (2 * tileEdge);
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle bottom piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // right bottom piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoUOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top right piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top left piece
    location.x -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoUOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // bottom left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top left piece
    location.y += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top middle piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // top right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoUOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom left piece
    location.x -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*
 __
 | |
 | |___
 |_____|
 */
+(void)pentominoVOutline:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoVOutlineAlt1:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top right piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoVOutlineAlt2:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoVOutlineAlt3:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // bottom right piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom middle piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom left piece
    location.x -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*
 ____
 |  |__
 |___  |__
 |_____|
 
 */
+(void)pentominoWOutline:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    //middle left piece
    location.y -= tileEdge;
    //location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle step piece
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    
    // right bottom piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoWOutlineAlt1:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top right piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top left piece
    location.x -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle right piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle left piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoWOutlineAlt2:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle left piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle right piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoWOutlineAlt3:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle left piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    
    // bottom left piece
    location.x -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*
 ___
 __|  |__
 |__    __|
 |__|
 */
+(void)pentominoXOutline:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:99]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle piece
    location.x += tileEdge;
    location.y += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // top right piece
    location.x += tileEdge;
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    //Middle Piece
    location.y += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
    
}


/*
 __
 | |
 | |_
 |  _|
 |_|
 
 */
+(void)pentominoYOutline:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle pieces
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x -= tileEdge;
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoYOutlineAlt1:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.x -= (2 * tileEdge);
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoYOutlineAlt2:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // line-going-down pieces
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.x -= tileEdge;
    location.y += (2 * tileEdge);
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoYOutlineAlt3:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    
    // bottom left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // bottom middle pieces
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    location.x += tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom right
    location.x += tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // piece sticking out on top
    location.x -= tileEdge;
    location.y += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


/*
 ____
 |__  |
 | |__
 |____|
 
 */
+(void)pentominoZOutline:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92]];
    
    // top left piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // top right piece
    location.x += tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle piece
    location.y -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // bottom left piece
    location.y -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom right piece
    location.x += tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


+(void)pentominoZOutlineAlt:(GameScene *)scene curPos:(CGPoint)location {
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88]];
    SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93]];
    SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94]];
    SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90]];
    SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85]];
    
    // top piece
    aiRefWallPiece.position = location;
    aiRefWallPiece.scale = tileScale;
    aiRefWallPiece.zPosition = 3;
    aiRefWallPiece.name = @"aiWallHover";
    [scene addChild:aiRefWallPiece];
    
    // middle right piece
    location.y -= tileEdge;
    piece2.position = location;
    piece2.scale = tileScale;
    piece2.zPosition = 3;
    piece2.name = @"aiWallHover";
    [scene addChild:piece2];
    
    // middle piece
    location.x -= tileEdge;
    piece3.position = location;
    piece3.scale = tileScale;
    piece3.zPosition = 3;
    piece3.name = @"aiWallHover";
    [scene addChild:piece3];
    
    // middle left piece
    location.x -= tileEdge;
    piece4.position = location;
    piece4.scale = tileScale;
    piece4.zPosition = 3;
    piece4.name = @"aiWallHover";
    [scene addChild:piece4];
    
    // bottom piece
    location.y -= tileEdge;
    piece5.position = location;
    piece5.scale = tileScale;
    piece5.zPosition = 3;
    piece5.name = @"aiWallHover";
    [scene addChild:piece5];
}


@end
