/*
 *  WallHoverPiecesAI.h
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import <Foundation/Foundation.h>


@interface WallHoverPiecesAI : NSObject

+(void)monominoOutline: (GameScene *) scene curPos:(CGPoint) location;

+(void)dominoOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)dominoOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;

+(void)trominoLOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)trominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)trominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)trominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)trominoIOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)trominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;

+(void)tetrominoZOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoZOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoIOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoCubeOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoTOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoTOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoTOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoTOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoLOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)tetrominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;

+(void)pentominoFOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoFOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoFOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoFOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoIOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoIOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoLOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoLOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoLOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoLOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoNOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoNOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoNOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoNOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoPOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoPOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoPOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoPOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoTOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoTOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoTOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoTOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoUOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoUOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoUOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoUOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoVOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoVOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoVOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoVOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoWOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoWOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoWOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoWOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoXOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoYOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoYOutlineAlt1: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoYOutlineAlt2: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoYOutlineAlt3: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoZOutline: (GameScene *) scene curPos:(CGPoint) location;
+(void)pentominoZOutlineAlt: (GameScene *) scene curPos:(CGPoint) location;


@end
