/*
 *  SoundOptions.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "SoundOptions.h"
#include "Options.h"

@implementation SoundOptions

// Sprites
SKSpriteNode* Back;
SKSpriteNode* SoundFX;
SKSpriteNode* MusicButton;

// Sound FX Sprites
SKSpriteNode* SoundFXMinus;
SKSpriteNode* SoundFXPlus;
SKSpriteNode* SoundFXPercent;

// Music Sprites
SKSpriteNode* MusicButtonMinus;
SKSpriteNode* MusicButtonPlus;
SKSpriteNode* MusicButtonPercent;

// Flags for sound fx settings
bool isSoundFX100 = true;
bool isSoundFX75 = false;
bool isSoundFX50 = false;
bool isSoundFX25 = false;
bool isSoundFX0 = false;

// Flags for music settings
bool isMusic100 = true;
bool isMusic75 = false;
bool isMusic50 = false;
bool isMusic25 = false;
bool isMusic0 = false;

// Flags for ticking noise
bool soundFxFlag = true;
bool sffMinus = true;
bool sffPlus = true;
bool musicFlag = true;
bool mMinus = true;
bool mPlus = true;
bool backButtonFlag = true;

// View of Sound Options
-(void)didMoveToView:(SKView *)view {
    
    // Initialize text to the screen
    [self backGroundBricks];
    [self soundSelect];
}

-(void)mouseDown:(NSEvent *)theEvent {
    NSPoint mouseDownPos = [theEvent locationInWindow];

    // If user clicks back button, go back to options
    if(mouseDownPos.x >= 72 && mouseDownPos.x <= 131 &&
       mouseDownPos.y >= 121 && mouseDownPos.y <= 139) {
        Options *scene = [Options sceneWithSize:self.view.bounds.size];
        
        //set up main menu size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
    
    // If user clicks on sound minus
    else if(mouseDownPos.x >= 546 && mouseDownPos.x <= 556 && mouseDownPos.y >= 364 && mouseDownPos.y <= 369) {
    
        // If sound is set to 100%, decrement
        if(isSoundFX100 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX75PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX75 = true;
            isSoundFX100 = false;
        }
        else if(isSoundFX75 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX50PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX50 = true;
            isSoundFX75 = false;

        }
        else if(isSoundFX50 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX25PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX25 = true;
            isSoundFX50 = false;

        }
        else if(isSoundFX25 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX0PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX0 = true;
            isSoundFX25 = false;
        }
    }
    
    // If user clicks on sound plus
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 361 && mouseDownPos.y <= 370) {
        
        // If sound is set to 0%, increment
        if(isSoundFX0 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX25PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX0 = false;
            isSoundFX25 = true;
        }
        else if(isSoundFX25 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX50PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX50 = true;
            isSoundFX25 = false;
            
        }
        else if(isSoundFX50 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFX75PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX75 = true;
            isSoundFX50 = false;
            
        }
        else if(isSoundFX75 == true){
            [SoundFXPercent removeFromParent];
            [self SoundFXPercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isSoundFX100 = true;
            isSoundFX75 = false;
        }
    
    }

    
    // If user clicks on music minus
    else if(mouseDownPos.x >= 546 && mouseDownPos.x <= 556 && mouseDownPos.y >= 285 && mouseDownPos.y <= 290) {
        
        // If sound is set to 100%, decrement
        if(isMusic100 == true){
            [MusicButtonPercent removeFromParent];
            [self Music75PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic75 = true;
            isMusic100 = false;
        }
        else if(isMusic75 == true){
            [MusicButtonPercent removeFromParent];
            [self Music50PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic50 = true;
            isMusic75 = false;
            
        }
        else if(isMusic50 == true){
            [MusicButtonPercent removeFromParent];
            [self Music25PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic25 = true;
            isMusic50 = false;
            
        }
        else if(isMusic25 == true){
            [MusicButtonPercent removeFromParent];
            [self Music0PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic0 = true;
            isMusic25 = false;
        }
    }
    
    // If user clicks on music plus
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 280 && mouseDownPos.y <= 291) {
        
        // If sound is set to 0%, increment
        if(isMusic0 == true){
            [MusicButtonPercent removeFromParent];
            [self Music25PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic0 = false;
            isMusic25 = true;
        }
        else if(isMusic25 == true){
            [MusicButtonPercent removeFromParent];
            [self Music50PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic50 = true;
            isMusic25 = false;
            
        }
        else if(isMusic50 == true){
            [MusicButtonPercent removeFromParent];
            [self Music75PercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic75 = true;
            isMusic50 = false;
            
        }
        else if(isMusic75 == true){
            [MusicButtonPercent removeFromParent];
            [self MusicPercentageText:@"FontKingthingsBlack copy"];
            
            // Set proper indicators
            isMusic100 = true;
            isMusic75 = false;
        }
        
    }

}

-(void)mouseMoved:(NSEvent *)theEvent {
    NSPoint mousePos = [theEvent locationInWindow];
 
    
    // If user mouseover 'back', highlight
    if(mousePos.x >= 72 && mousePos.x <= 131 &&
       mousePos.y >= 121 && mousePos.y <= 139) {
        [Back removeFromParent];
        [self backLeft:@"FontKingthingsWhite copy"];
        if(backButtonFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            backButtonFlag = false;
        }
    }
    else{
        [Back removeFromParent];
        [self backLeft: @"FontKingthingsBlack copy"];
        backButtonFlag = true;
    }
    
    // If user mouseover 'soundfx', highlight
    if(mousePos.x >= 70 && mousePos.x <= 745 &&
       mousePos.y >= 354 && mousePos.y <= 380) {
        [SoundFX removeFromParent];
        [self soundFX:@"FontKingthingsWhite copy"];
        if(soundFxFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            soundFxFlag = false;
        }
    }
    else{
        [SoundFX removeFromParent];
        [self soundFX: @"FontKingthingsBlack copy"];
        soundFxFlag = true;
    }
    
    // If user mouseover 'music', highlight
    if(mousePos.x >= 70 && mousePos.x <= 745 &&
       mousePos.y >= 278 && mousePos.y <= 299) {
        [MusicButton removeFromParent];
        [self musicButton:@"FontKingthingsWhite copy"];
        if(musicFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            musicFlag = false;
        }
    }
    else{
        [MusicButton removeFromParent];
        [self musicButton: @"FontKingthingsBlack copy"];
        musicFlag = true;
    }
    
    // If user mouseover sound fx minus, highlight
    if(mousePos.x >= 546 && mousePos.x <= 556 &&
       mousePos.y >= 364 && mousePos.y <= 369) {
        [SoundFXMinus removeFromParent];
        [self SoundFXMinusText:@"FontKingthingsWhite copy"];
        if(sffMinus == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            sffMinus = false;
        }
    }
    else{
        [SoundFXMinus removeFromParent];
        [self SoundFXMinusText: @"FontKingthingsBlack copy"];
        sffMinus = true;
    }
    
    // If user mouseover sound fx plus, highlight
    if(mousePos.x >= 736 && mousePos.x <= 745 &&
       mousePos.y >= 361 && mousePos.y <= 370) {
        [SoundFXPlus removeFromParent];
        [self SoundFXPlusText:@"FontKingthingsWhite copy"];
        if(sffPlus == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            sffPlus = false;
        }
    }
    else{
        [SoundFXPlus removeFromParent];
        [self SoundFXPlusText: @"FontKingthingsBlack copy"];
        sffPlus = true;
    }
    
    // If user mouseover music minus, highlight
    if(mousePos.x >= 546 && mousePos.x <= 556 &&
       mousePos.y >= 285 && mousePos.y <= 290) {
        [MusicButtonMinus removeFromParent];
        [self MusicButtonMinusText:@"FontKingthingsWhite copy"];
        if(mMinus == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            mMinus = false;
        }
    }
    else{
        [MusicButtonMinus removeFromParent];
        [self MusicButtonMinusText: @"FontKingthingsBlack copy"];
        mMinus = true;
    }
    
    // If user mouseover music plus, highlight
    if(mousePos.x >= 736 && mousePos.x <= 745 &&
       mousePos.y >= 280 && mousePos.y <= 291) {
        [MusicButtonPlus removeFromParent];
        [self MusicButtonPlusText:@"FontKingthingsWhite copy"];
        if(mPlus == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            mPlus = false;
        }
    }
    else{
        [MusicButtonPlus removeFromParent];
        [self MusicButtonPlusText: @"FontKingthingsBlack copy"];
        mPlus = true;
    }

}

-(void)soundSelect{
    int horizon = 500;
    int level = 550;
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:@"FontKingthingsWhite copy"withTileNumber:95];
    [self letter:level X:(horizon - 50) alpha:43 file:alphabet];//  S
    [self letter:level X:(horizon - 30) alpha:47 file:alphabet];//  O
    [self letter:level X:(horizon - 10) alpha:41 file:alphabet];//  U
    [self letter:level X:(horizon + 10) alpha:48 file:alphabet];//  N
    [self letter:level X:(horizon + 30) alpha:58 file:alphabet];//  D
    [self letter:level X:(horizon + 50) alpha:43 file:alphabet];//  S
    [self SoundFXMinusText:@"FontKingthingsBlack copy"];
    [self soundFX:@"FontKingthingsBlack copy"];
    [self SoundFXPercentageText:@"FontKingthingsBlack copy"];
    [self SoundFXPlusText:@"FontKingthingsBlack copy"];
    [self MusicButtonMinusText:@"FontKingthingsBlack copy"];
    [self musicButton:@"FontKingthingsBlack copy"];
    [self MusicPercentageText:@"FontKingthingsBlack copy"];
    [self MusicButtonPlusText:@"FontKingthingsBlack copy"];
    [self backLeft:@"FontKingthingsBlack copy"];
}

// The plus selector for Sound FX
-(void)SoundFXPlusText:(NSString *)file{
    int horizon = 940;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPlus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:83]];
    
    SoundFXPlus.scale = 2;
    SoundFXPlus.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPlus];
    
}

// The plus selector for Music
-(void)MusicButtonPlusText:(NSString *)file{
    int horizon = 940;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPlus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:83]];
    
    MusicButtonPlus.scale = 2;
    MusicButtonPlus.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPlus];
    
}

// The minus selector for Music
-(void)MusicButtonMinusText:(NSString *)file{
    int horizon = 700;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonMinus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    
    MusicButtonMinus.scale = 2;
    MusicButtonMinus.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonMinus];
    
}

// The minus selector for Sound FX
-(void)SoundFXMinusText:(NSString *)file{
    int horizon = 700;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXMinus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    
    SoundFXMinus.scale = 2;
    SoundFXMinus.position = CGPointMake(horizon,level);
    [self addChild:SoundFXMinus];
    
}

// The percentage text for Sound FX
-(void)SoundFXPercentageText:(NSString*)file{
    int horizon = 800;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:77]];
    
    SKSpriteNode* zero = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* zero2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero2 setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(30,0)];
    
    [SoundFXPercent addChild:zero];
    [SoundFXPercent addChild:zero2];
    [SoundFXPercent addChild:percent];

    
    SoundFXPercent.scale = 2;
    SoundFXPercent.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPercent];
}

// The 75 percentage text for Sound FX
-(void)SoundFX75PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:71]];
    
    SKSpriteNode* five = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    [five setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [SoundFXPercent addChild:five];
    [SoundFXPercent addChild:percent];
    
    
    SoundFXPercent.scale = 2;
    SoundFXPercent.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPercent];
}

// The 50 percentage text for Sound FX
-(void)SoundFX50PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    
    SKSpriteNode* zero = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [SoundFXPercent addChild:zero];
    [SoundFXPercent addChild:percent];
    
    
    SoundFXPercent.scale = 2;
    SoundFXPercent.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPercent];
}

// The 25 percentage text for Sound FX
-(void)SoundFX25PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:76]];
    
    SKSpriteNode* five = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    [five setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [SoundFXPercent addChild:five];
    [SoundFXPercent addChild:percent];
    
    
    SoundFXPercent.scale = 2;
    SoundFXPercent.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPercent];
}

// The 0 percentage text for Sound FX
-(void)SoundFX0PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 400;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFXPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(10,0)];
    
    [SoundFXPercent addChild:percent];
    
    
    SoundFXPercent.scale = 2;
    SoundFXPercent.position = CGPointMake(horizon,level);
    [self addChild:SoundFXPercent];
}

// The percentage text for music
-(void)MusicPercentageText:(NSString*)file{
    int horizon = 800;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:77]];
    
    SKSpriteNode* zero = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* zero2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero2 setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(30,0)];
    
    [MusicButtonPercent addChild:zero];
    [MusicButtonPercent addChild:zero2];
    [MusicButtonPercent addChild:percent];
    
    
    MusicButtonPercent.scale = 2;
    MusicButtonPercent.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPercent];
}

// The 75 percentage text for music
-(void)Music75PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:71]];
    
    SKSpriteNode* five = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    [five setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [MusicButtonPercent addChild:five];
    [MusicButtonPercent addChild:percent];
    
    
    MusicButtonPercent.scale = 2;
    MusicButtonPercent.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPercent];
}

// The 50 percentage text for music
-(void)Music50PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    
    SKSpriteNode* zero = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    [zero setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [MusicButtonPercent addChild:zero];
    [MusicButtonPercent addChild:percent];
    
    
    MusicButtonPercent.scale = 2;
    MusicButtonPercent.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPercent];
}

// The 25 percentage text for music
-(void)Music25PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:76]];
    
    SKSpriteNode* five = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:73]];
    [five setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(20,0)];
    
    [MusicButtonPercent addChild:five];
    [MusicButtonPercent addChild:percent];
    
    
    MusicButtonPercent.scale = 2;
    MusicButtonPercent.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPercent];
}

// The 0 percentage text for music
-(void)Music0PercentageText:(NSString*)file{
    int horizon = 800;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButtonPercent =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:78]];
    
    SKSpriteNode* percent = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:89]];
    [percent setPosition:CGPointMake(10,0)];
    
    [MusicButtonPercent addChild:percent];
    
    
    MusicButtonPercent.scale = 2;
    MusicButtonPercent.position = CGPointMake(horizon,level);
    [self addChild:MusicButtonPercent];
}

-(void)soundFX:(NSString*)file{
    int horizon = 100;
    int level = 400;
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    SoundFX = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    [N setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* D = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:26]];
    [D setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* F = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:24]];
    [F setPosition:CGPointMake(60,0)];
    
    SKSpriteNode* X = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:6]];
    [X setPosition:CGPointMake(70,0)];
    
    [SoundFX addChild:O];
    [SoundFX addChild:U];
    [SoundFX addChild:N];
    [SoundFX addChild:D];
    [SoundFX addChild:F];
    [SoundFX addChild:X];

    SoundFX.scale = 2;
    SoundFX.position = CGPointMake(horizon,level);
    [self addChild:SoundFX];
}

-(void)musicButton:(NSString *)file{
    int horizon = 100;
    int level = 300;
    
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    
    MusicButton = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:49]];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(20,0)];

    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:21]];
    [I setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:27]];
    [C setPosition:CGPointMake(50,0)];
    
    [MusicButton addChild:U];
    [MusicButton addChild:S];
    [MusicButton addChild:I];
    [MusicButton addChild:C];
    
    MusicButton.scale = 2;
    MusicButton.position = CGPointMake(horizon,level);
    [self addChild:MusicButton];


}



-(void)backLeft:(NSString *)file{
    int level;
    level = 100;
    NSMutableArray *alphabet = [SoundOptions fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:horizon alpha:60 file:alphabet];//backLeft                 B
     [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backLeft          A
     [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backLeft          C
     [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backLeft          K
     */
    
    Back = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:51]];
    [K setPosition:CGPointMake(30,0)];
    
    [Back addChild:A];
    [Back addChild:C];
    [Back addChild:K];
    
    Back.scale = 2;
    Back.position = CGPointMake(100,level);
    [self addChild:Back];
}


+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    [self addChild:A];
}

-(void)number:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2 *1.5;
    A.position = CGPointMake(x,(y +5));
    [self addChild:A];
}

-(void)titleBox:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [SoundOptions fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [SoundOptions fillCastleCSet:@"Mortar copy" withTileNumber:28];
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (unsigned long int ycount = upperLeftX; ycount >= lowerRightY ; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < upperLeftX-20) && (xcount < lowerRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < upperLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < lowerRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(lowerRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightX -25; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +45; xcount <= lowerRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    
    
    
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
    
    
}

-(void)backGroundBricks{
    NSMutableArray *bricks = [SoundOptions fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [SoundOptions fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
            
        }
        
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    [self titleBox:(300) :615: 700 : 500];
    
}

@end
