/*
 *  MainMenu.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "MainMenu.h"
#include "SelectMap.h"

#include "Sound.h"
#include "GameScene.h"
#include "Options.h"
#include "LogIn.h"

SKSpriteNode* SinglePlayer;
SKSpriteNode* MultiPlayer;
SKSpriteNode* OptionsSelect;
SKSpriteNode* Exit;

bool singlePlayerFlag = true;
bool multiPlayerFlag = true;
bool optionsSelectFlag = true;
bool exitFlag = true;

bool enteredAlready = false; //already entered scene once, no need to play main menu midi again

@implementation MainMenu

/* Beginning view; what the main menu should look like */
-(void)didMoveToView:(SKView *)view {
    if(!enteredAlready)
    {
        NSURL *midiUrl = [[NSBundle mainBundle] URLForResource:@"menu" withExtension:@"mid"];
                NewMusicPlayer(&mainMidiPlayer);
                MusicSequence sequence = NULL;
                NewMusicSequence(&sequence);
                MusicSequenceFileLoad(sequence, (__bridge CFURLRef)midiUrl, 0, 0);
                MusicPlayerSetSequence(mainMidiPlayer, sequence);
                MusicPlayerStart(mainMidiPlayer);
        enteredAlready = true;
    }
    
    [self backGroundBricks];
    //[self titleBox:20 :620 :990 :470];
    [self buildMenu];
}

- (MusicPlayer)getMusicPlayer{
    return mainMidiPlayer;
}

-(void)mouseDown:(NSEvent *)theEvent {

    
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    //NSLog(@"x: %f y: %f", mouseDownPos.x,mouseDownPos.y);
    
    if(mouseDownPos.x >= 280 && mouseDownPos.x <= 475 &&
       mouseDownPos.y >= 360 && mouseDownPos.y <= 380) {
        SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
        [self runAction:sound];
    //currently upon left click, it goes straight to SelectMap
    SelectMap *scene = [SelectMap sceneWithSize:self.view.bounds.size];
    
    //set up SelectMap size
    CGSize s;
    s.width = 1008;
    s.height = 624;
    scene.size = s;
    
    scene.scaleMode = SKSceneScaleModeAspectFit;
    [self.view presentScene:scene];
  
    }
    
    // Exits the program if user clicks on exit area
    else if(mouseDownPos.x >= 344 && mouseDownPos.x <= 395 && mouseDownPos.y >= 186 && mouseDownPos.y <= 204) {
        SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
        [self runAction:sound];
        [NSApp terminate:self];
        
    }
    
    else if(mouseDownPos.x >= 324 && mouseDownPos.x <= 421 && mouseDownPos.y >= 248 && mouseDownPos.y <= 268) {

        Options *scene = [Options sceneWithSize:self.view.bounds.size];
        SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
        [self runAction:sound];
        
        //set up SelectMap size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
        
    }
    else if(mouseDownPos.x >= 295 && mouseDownPos.x <= 455 &&
       mouseDownPos.y >= 304 && mouseDownPos.y <= 324) {
        //currently upon left click, it goes straight to SelectMap
        SKAction *sound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
        [self runAction:sound];
        LogIn *scene = [LogIn sceneWithSize:self.view.bounds.size];
        //set up SelectMap size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        scene.scaleMode = SKSceneScaleModeAspectFit;
        [self.view presentScene:scene];
    }
    
}
-(void)mouseMoved:(NSEvent *)theEvent {
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    //NSLog(@"x: %f y: %f", mouseDownPos.x,mouseDownPos.y);
    
    // Highlighting for single player
    if(mouseDownPos.x >= 280 && mouseDownPos.x <= 475 && mouseDownPos.y >= 360 && mouseDownPos.y <= 380) {
     
        [SinglePlayer removeFromParent];
        [self singlePlayer: @"FontKingthingsWhite copy"];
        if(singlePlayerFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            singlePlayerFlag = false;
        }
    }
    else{
        [SinglePlayer removeFromParent];
        [self singlePlayer: @"FontKingthingsBlack copy"];
        singlePlayerFlag = true;
    }
    
    // Highlighting for multiplayer
    if(mouseDownPos.x >= 295 && mouseDownPos.x <= 455 &&
       mouseDownPos.y >= 304 && mouseDownPos.y <= 324) {
        
        [MultiPlayer removeFromParent];
        [self multiPlayer: @"FontKingthingsWhite copy"];
        if(multiPlayerFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            multiPlayerFlag = false;
        }

    }
    else{
        [MultiPlayer removeFromParent];
        [self multiPlayer: @"FontKingthingsBlack copy"];
        multiPlayerFlag = true;
    }
    
    // Highlighting for options
    if(mouseDownPos.x >= 324 && mouseDownPos.x <= 421 &&
       mouseDownPos.y >= 248 && mouseDownPos.y <= 268) {
        
        [OptionsSelect removeFromParent];
        [self options: @"FontKingthingsWhite copy"];
        if(optionsSelectFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            optionsSelectFlag = false;
        }

        
    }
    else{
        [OptionsSelect removeFromParent];
        [self options: @"FontKingthingsBlack copy"];
        optionsSelectFlag = true;
        
    }
    
    // Highlighting for exit
    if(mouseDownPos.x >= 344 && mouseDownPos.x <= 395 &&
       mouseDownPos.y >= 186 && mouseDownPos.y <= 204) {
        
        [Exit removeFromParent];
        [self exit:@"FontKingthingsWhite copy"];
        if(exitFlag == true){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            exitFlag = false;
        }

        
    }
    else{
        [Exit removeFromParent];
        [self exit: @"FontKingthingsBlack copy"];
        exitFlag = true;
        
    }
    
    
}

+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    [self addChild:A];
}

-(void)number:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2 *1.5;
    A.position = CGPointMake(x,(y +5));
    [self addChild:A];
}

-(void)title{
    int level = 550;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:400 alpha:56 file:alphabet];//FORT     F
    [self letter:level X:420 alpha:47 file:alphabet];//FORT     O
    [self letter:level X:440 alpha:44 file:alphabet];//FORT     R
    [self letter:level X:460 alpha:42 file:alphabet];//FORT     T
    [self letter:level X:500 alpha:48 file:alphabet];//NITTA    N
    [self letter:level X:520 alpha:53 file:alphabet];//NITTA    I
    [self letter:level X:530 alpha:42 file:alphabet];//NITTA    T
    [self letter:level X:550 alpha:42 file:alphabet];//NITTA    T
    [self letter:level X:570 alpha:61 file:alphabet];//NITTA    A
}

-(void)singlePlayer:(NSString*)file{
    int level = 400;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
     /*
    [self letter:level X:360 alpha:43 file:alphabet];//SINGLE   S
    [self letter:level X:380 alpha:53 file:alphabet];//SINGLE   I
    [self letter:level X:390 alpha:48 file:alphabet];//SINGLE   N
    [self letter:level X:410 alpha:55 file:alphabet];//SINGLE   G
    [self letter:level X:430 alpha:50 file:alphabet];//SINGLE   L
    [self letter:level X:450 alpha:57 file:alphabet];//SINGLE   E
    [self letter:level X:490 alpha:46 file:alphabet];//SINGLE   P
    [self letter:level X:510 alpha:50 file:alphabet];//SINGLE   L
    [self letter:level X:530 alpha:61 file:alphabet];//SINGLE   A
    [self letter:level X:550 alpha:37 file:alphabet];//SINGLE   Y
    [self letter:level X:570 alpha:57 file:alphabet];//SINGLE   E
    [self letter:level X:590 alpha:44 file:alphabet];//SINGLE   R
    */
    
    SinglePlayer = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
     
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(15,0)];
    
    SKSpriteNode* G = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:55]];
    [G setPosition:CGPointMake(25,0)];

    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(35,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(65,0)];

    SKSpriteNode* L2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L2 setPosition:CGPointMake(75,0)];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(85,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(95,0)];
    
    SKSpriteNode* E2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E2 setPosition:CGPointMake(105,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(115,0)];
    
    [SinglePlayer addChild:I];
    [SinglePlayer addChild:N];
    [SinglePlayer addChild:G];
    [SinglePlayer addChild:L];
    [SinglePlayer addChild:E];
    [SinglePlayer addChild:P];
    [SinglePlayer addChild:L2];
    [SinglePlayer addChild:A];
    [SinglePlayer addChild:Y];
    [SinglePlayer addChild:E2];
    [SinglePlayer addChild:R];
    

     SinglePlayer.scale = 2;
     SinglePlayer.position = CGPointMake(365,level);
     [self addChild:SinglePlayer];
    
}

-(void)multiPlayer:(NSString*)file{
    int level = 330;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:360 alpha:49 file:alphabet];//MULTI    M
    [self letter:level X:390 alpha:41 file:alphabet];//MULTI    U
    [self letter:level X:510 alpha:50 file:alphabet];//MULTI    L
    [self letter:level X:440 alpha:42 file:alphabet];//MULTI    T
    [self letter:level X:460 alpha:53 file:alphabet];//MULTI    I
    [self letter:level X:490 alpha:46 file:alphabet];//MULTI    P
    [self letter:level X:420 alpha:50 file:alphabet];//MULTI    L
    [self letter:level X:530 alpha:61 file:alphabet];//MULTI    A
    [self letter:level X:550 alpha:37 file:alphabet];//MULTI    Y
    [self letter:level X:570 alpha:57 file:alphabet];//MULTI    E
    [self letter:level X:590 alpha:44 file:alphabet];//MULTI    R
    */
    
    MultiPlayer = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:49]];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(15,0)];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(25,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* L2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L2 setPosition:CGPointMake(55,0)];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(65,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(75,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(85,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(95,0)];
    
    [MultiPlayer addChild:U];
    [MultiPlayer addChild:L];
    [MultiPlayer addChild:T];
    [MultiPlayer addChild:I];
    [MultiPlayer addChild:P];
    [MultiPlayer addChild:L2];
    [MultiPlayer addChild:A];
    [MultiPlayer addChild:Y];
    [MultiPlayer addChild:E];
    [MultiPlayer addChild:R];
    
    
    MultiPlayer.scale = 2;
    MultiPlayer.position = CGPointMake(385,level);
    [self addChild:MultiPlayer];

}

-(void)options:(NSString*)file{
    int level = 260;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:420 alpha:47 file:alphabet];//OPTIONS    O
    [self letter:level X:440 alpha:46 file:alphabet];//OPTIONS    P
    [self letter:level X:460 alpha:42 file:alphabet];//OPTIONS    T
    [self letter:level X:480 alpha:53 file:alphabet];//OPTIONS    I
    [self letter:level X:500 alpha:47 file:alphabet];//OPTIONS    O
    [self letter:level X:520 alpha:48 file:alphabet];//OPTIONS    N
    [self letter:level X:540 alpha:43 file:alphabet];//OPTIONS    S
    */
    
    OptionsSelect = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(35,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake(55,0)];
    
    [OptionsSelect addChild:P];
    [OptionsSelect addChild:T];
    [OptionsSelect addChild:I];
    [OptionsSelect addChild:O];
    [OptionsSelect addChild:N];
    [OptionsSelect addChild:S];
    
    
    OptionsSelect.scale = 2;
    OptionsSelect.position = CGPointMake(425,level);
    [self addChild:OptionsSelect];

}

-(void)exit:(NSString*)file{
    int level = 180;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:460 alpha:57 file:alphabet];//EXIT       E
    [self letter:level X:480 alpha:38 file:alphabet];//EXIT       X
    [self letter:level X:500 alpha:53 file:alphabet];//EXIT       I
    [self letter:level X:510 alpha:42 file:alphabet];//EXIT       T
    */
    
    Exit = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    
    SKSpriteNode* X = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:38]];
    [X setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(25,0)];
    
    [Exit addChild:X];
    [Exit addChild:I];
    [Exit addChild:T];
    
    
    Exit.scale = 2;
    Exit.position = CGPointMake(450,level);
    [self addChild:Exit];
}


-(void)backLeft{
    int level, horizon;
    level = 100;
    horizon = 100;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backLeft                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backLeft          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backLeft          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backLeft          K
    
    
    
}

-(void)backLeftHighLight{
    int level, horizon;
    level = 100;
    horizon = 100;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backLeftHighLight                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backLeftHighLight          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backLeftHighLight          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backLeftHighLight          K
}

-(void)backRight{
    int level, horizon;
    level = 100;
    horizon = 850;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backRight                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backRight          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backRight          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backRight          K
    
    
    
}

-(void)backRightHighLight{
    int level, horizon;
    level = 100;
    horizon = 850;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backRightHighLight                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backRightHighLight          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backRightHighLight          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backRightHighLight          K
}

-(void)backCenter{
    int level, horizon;
    level = 100;
    horizon = 450;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backCenter                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backCenter          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backCenter          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backCenter          K
    
    
    
}

-(void)backCenterHighLight{
    int level, horizon;
    level = 100;
    horizon = 450;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:horizon alpha:60 file:alphabet];//backCenterHighLight                 B
    [self letter:level X:(horizon + 20) alpha:61 file:alphabet];//backCenterHighLight          A
    [self letter:level X:(horizon + 45) alpha:59 file:alphabet];//backCenterHighLight          C
    [self letter:level X:(horizon + 65) alpha:51 file:alphabet];//backCenterHighLight          K
}


-(void)continueButton{
    int level, horizon;
    level = 100;
    horizon = 850;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    [self letter:level X:(horizon - 60) alpha:59 file:alphabet];//continueHighLight          C
    [self letter:level X:(horizon - 40) alpha:47 file:alphabet];//continueHighLight          O
    [self letter:level X:(horizon - 20) alpha:48 file:alphabet];//continueHighLight          N
    [self letter:level X:(horizon + 00) alpha:42 file:alphabet];//continueHighLight          T
    [self letter:level X:(horizon + 20) alpha:53 file:alphabet];//continueHighLight          I
    [self letter:level X:(horizon + 30) alpha:48 file:alphabet];//continueHighLight          N
    [self letter:level X:(horizon + 50) alpha:41 file:alphabet];//continueHighLight          U
    [self letter:level X:(horizon + 70) alpha:57 file:alphabet];//continueHighLight          E
}

-(void)continueHighLight{
    int level, horizon;
    level = 100;
    horizon = 850;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:(horizon - 60) alpha:59 file:alphabet];//continueHighLight          C
    [self letter:level X:(horizon - 40) alpha:47 file:alphabet];//continueHighLight          O
    [self letter:level X:(horizon - 20) alpha:48 file:alphabet];//continueHighLight          N
    [self letter:level X:(horizon + 00) alpha:42 file:alphabet];//continueHighLight          T
    [self letter:level X:(horizon + 20) alpha:53 file:alphabet];//continueHighLight          I
    [self letter:level X:(horizon + 30) alpha:59 file:alphabet];//continueHighLight          N
    [self letter:level X:(horizon + 50) alpha:51 file:alphabet];//continueHighLight          U
    [self letter:level X:(horizon + 70) alpha:51 file:alphabet];//continueHighLight          E
    
}




-(void)buildMenu{
    /*
     a = 61, b = 60, c = 59, d = 58, e = 57,f = 56, g = 55, h = 54,
     i = 53, j = 52, k = 51, l = 50, m = 49, n = 48, o = 47, p = 46,
     q = 45, r = 44, s = 43, t = 42, u = 41, v = 40, w = 39,x = 38,
     y = 37,z = 36
     
     
     
     */
    //NSButton *myButton = [[NSButton alloc] initWithFrame:NSMakeRect(280, 360, 195, 20)];
    //[myButton setTitle:@"sample"];
    
    //[self.view addSubview:myButton];
    // Insert code here to initialize your application
    [self title];
    [self singlePlayer: @"FontKingthingsBlack copy"];
    [self multiPlayer:@"FontKingthingsBlack copy"];
    [self options:@"FontKingthingsBlack copy"];
    [self exit:@"FontKingthingsBlack copy"];
    
    
}

-(void)buildSinglePlayerMenu{
    //[self selectMap];
    [self gameSelect];
    
    
}

-(void)gameSelect{
    int horizon = 500;
    int level = 550;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:(horizon - 140) alpha:55 file:alphabet];//gameSelection    G
    [self letter:level X:(horizon - 120) alpha:61 file:alphabet];//gameSelection    A
    [self letter:level X:(horizon - 100) alpha:49 file:alphabet];//gameSelection    M
    [self letter:level X:(horizon - 80) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon - 40) alpha:43 file:alphabet];//gameSelection     S
    [self letter:level X:(horizon - 20) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon + 00) alpha:50 file:alphabet];//gameSelection     L
    [self letter:level X:(horizon + 20) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon + 40) alpha:59 file:alphabet];//gameSelection     C
    [self letter:level X:(horizon + 60) alpha:42 file:alphabet];//gameSelection     T
    [self letter:level X:(horizon + 80) alpha:53 file:alphabet];//gameSelection     I
    [self letter:level X:(horizon + 100) alpha:47 file:alphabet];//gameSelection    O
    [self letter:level X:(horizon + 120) alpha:48 file:alphabet];//gameSelection    N
    [self windType:@"FontKingthingsBlack copy"];
    [self playerColor:@"FontKingthingsBlack copy"];
    [self aiDiff:@"FontKingthingsBlack copy"];
    
    [self continueButton];
    [self backLeft];
    
    
}



-(void)windType:(NSString*)file{
    int horizon = 100;
    int level = 400;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:39 file:alphabet];//wind     W
    [self letter:level X:(horizon + 30) alpha:53 file:alphabet];//wind     I
    [self letter:level X:(horizon + 40) alpha:48 file:alphabet];//wind     N
    [self letter:level X:(horizon + 60) alpha:58 file:alphabet];//wind     D
    [self letter:level X:(horizon + 100) alpha:42 file:alphabet];//wind    T
    [self letter:level X:(horizon + 120) alpha:37 file:alphabet];//wind    Y
    [self letter:level X:(horizon + 140) alpha:46 file:alphabet];//wind    P
    [self letter:level X:(horizon + 160) alpha:57 file:alphabet];//wind    E
    
}

-(void)playerColor:(NSString*)file{
    int horizon = 100;
    int level = 300;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:46 file:alphabet];//Color     P
    [self letter:level X:(horizon + 20) alpha:50 file:alphabet];//Color     L
    [self letter:level X:(horizon + 40) alpha:61 file:alphabet];//Color     A
    [self letter:level X:(horizon + 60) alpha:37 file:alphabet];//Color     Y
    [self letter:level X:(horizon + 80) alpha:57 file:alphabet];//Color     E
    [self letter:level X:(horizon + 100) alpha:44 file:alphabet];//Color    R
    [self letter:level X:(horizon + 140) alpha:59 file:alphabet];//Color    C
    [self letter:level X:(horizon + 160) alpha:47 file:alphabet];//Color    O
    [self letter:level X:(horizon + 180) alpha:50 file:alphabet];//Color    L
    [self letter:level X:(horizon + 200) alpha:47 file:alphabet];//Color    O
    [self letter:level X:(horizon + 220) alpha:44 file:alphabet];//Color    R
    [self playerColorRed: file];
    
}

-(void)aiDiff:(NSString*)file{
    int horizon = 100;
    int level = 200;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:61 file:alphabet];//AI     A
    [self letter:level X:(horizon + 20) alpha:53 file:alphabet];//AI     I
    [self letter:level X:(horizon + 50) alpha:58 file:alphabet];//AI     D
    [self letter:level X:(horizon + 70) alpha:53 file:alphabet];//AI     I
    [self letter:level X:(horizon + 80) alpha:56 file:alphabet];//AI     F
    [self letter:level X:(horizon + 100) alpha:56 file:alphabet];//AI    F
    [self letter:level X:(horizon + 120) alpha:53 file:alphabet];//AI    I
    [self letter:level X:(horizon + 130) alpha:59 file:alphabet];//AI    C
    [self letter:level X:(horizon + 150) alpha:41 file:alphabet];//AI    U
    [self letter:level X:(horizon + 170) alpha:50 file:alphabet];//AI    L
    [self letter:level X:(horizon + 190) alpha:42 file:alphabet];//AI    T
    [self letter:level X:(horizon + 210) alpha:37 file:alphabet];//AI    Y
    
    
}

-(void)playerColorRed:(NSString*)file{
    int horizon = 700;
    int level = 300;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    
    [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
    [self letter:level X:(horizon + 30) alpha:12 file:alphabet];//color    r
    [self letter:level X:(horizon + 50) alpha:25 file:alphabet];//color    e
    [self letter:level X:(horizon + 70) alpha:26 file:alphabet];//color    d
    [self letter:level X:(horizon + 100) alpha:83 file:alphabet];//color   +
    
}

-(void)playerColorBlue:(NSString*)file{
    int horizon = 700;
    int level = 300;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
    [self letter:level X:(horizon + 30) alpha:28 file:alphabet];//color    b
    [self letter:level X:(horizon + 50) alpha:18 file:alphabet];//color    l
    [self letter:level X:(horizon + 70) alpha:9  file:alphabet];//color    u
    [self letter:level X:(horizon + 90) alpha:25 file:alphabet];//color    e
    [self letter:level X:(horizon + 120) alpha:83 file:alphabet];//color   +
    
}




-(void)buildMultiPlayerMenu{
    
    
    
}



-(void)soundMenu{
    int horizon = 400;
    int level = 550;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:43 file:alphabet];//optionsMenu     S
    [self letter:level X:(horizon + 20) alpha:47 file:alphabet];//optionsMenu     O
    [self letter:level X:(horizon + 40) alpha:41 file:alphabet];//optionsMenu     U
    [self letter:level X:(horizon + 60) alpha:48 file:alphabet];//optionsMenu     N
    [self letter:level X:(horizon + 80) alpha:58 file:alphabet];//optionsMenu     D
    [self letter:level X:(horizon + 120) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 140) alpha:46 file:alphabet];//optionsMenu    P
    [self letter:level X:(horizon + 160) alpha:42 file:alphabet];//optionsMenu    T
    [self letter:level X:(horizon + 180) alpha:53 file:alphabet];//optionsMenu    I
    [self letter:level X:(horizon + 190) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 210) alpha:48 file:alphabet];//optionsMenu    N
    [self letter:level X:(horizon + 230) alpha:43 file:alphabet];//optionsMenu    S
    
    
    
}

-(void)soundLine: (NSString*)file{
    int horizon = 440;
    int level = 350;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:43 file:alphabet];//optionsMenu    S
    [self letter:level X:(horizon + 20) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 40) alpha:41 file:alphabet];//optionsMenu    U
    [self letter:level X:(horizon + 60) alpha:48 file:alphabet];//optionsMenu    N
    [self letter:level X:(horizon + 80) alpha:58 file:alphabet];//optionsMenu    D
}
-(void)networkLine: (NSString*)file{
    int horizon = 430;
    int level = 250;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:file withTileNumber:95];
    [self letter:level X:(horizon - 05) alpha:48 file:alphabet];//optionsMenu    N
    [self letter:level X:(horizon + 15) alpha:57 file:alphabet];//optionsMenu    E
    [self letter:level X:(horizon + 30) alpha:42 file:alphabet];//optionsMenu    T
    [self letter:level X:(horizon + 50) alpha:39 file:alphabet];//optionsMenu    W
    [self letter:level X:(horizon + 80) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 100) alpha:44 file:alphabet];//optionsMenu   R
    [self letter:level X:(horizon + 120) alpha:51 file:alphabet];//optionsMenu   K
}


-(void)buildOptionsMenu{
    int horizon = 430;
    int level = 550;
    NSMutableArray *alphabet = [MainMenu fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:(horizon + 00) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 20) alpha:46 file:alphabet];//optionsMenu    P
    [self letter:level X:(horizon + 40) alpha:42 file:alphabet];//optionsMenu    T
    [self letter:level X:(horizon + 60) alpha:53 file:alphabet];//optionsMenu    I
    [self letter:level X:(horizon + 70) alpha:47 file:alphabet];//optionsMenu    O
    [self letter:level X:(horizon + 90) alpha:48 file:alphabet];//optionsMenu    N
    [self letter:level X:(horizon + 110) alpha:43 file:alphabet];//optionsMenu   S
    [self backCenter];
    [self soundLine:@"FontKingthingsBlack copy"];
    [self networkLine:@"FontKingthingsBlack copy"];
    
    
    
}

/* same logic as below in backGroundBricks format of parameters:
 (NSUInteger)upperLeftX
 (NSUInteger)upperLeftY
 (NSUInteger)lowerRightX
 (NSUInteger)lowerRightY
 
 (upperLeftX, upperLeftY)*---------------------------*
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 *---------------------------*(lowerRightX,lowerRightY)
 
 
 
 
 
 
 
 
 */

-(void)titleBox:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [MainMenu fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [MainMenu fillCastleCSet:@"Mortar copy" withTileNumber:28];
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (unsigned long int ycount = upperLeftX; ycount >= lowerRightY ; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < upperLeftX-20) && (xcount < lowerRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < upperLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < lowerRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(lowerRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightX -25; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +45; xcount <= lowerRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    
    
    
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
    
    
}


-(void)backGroundBricks{
    NSMutableArray *bricks = [MainMenu fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [MainMenu fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                  [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                
                }
            }
        }
        
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
            
        }
        
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    [self titleBox:(300) :615: 700 : 500];
    //[self title];
    
}


@end
