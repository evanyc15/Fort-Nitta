/*
 *  GameSelection.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */

#import "GameSelection.h"

#include "GameScene.h"
#include "SelectMap.h"
#include "MainMenu.h"

SKSpriteNode *Back;
SKSpriteNode *Continue;
SKSpriteNode *Wind;
SKSpriteNode *PlayerColor;
SKSpriteNode *AIDifficulty;

// Nodes for Player color selection
SKSpriteNode *playerColorMinus;
SKSpriteNode *playerColorRed;
SKSpriteNode *playerColorPlus;
SKSpriteNode *playerColorBlue;
SKSpriteNode *playerColorYellow;

// Indicators
bool isPlayerBlue = true;
bool isPlayerRed = false;
bool isPlayerYellow = false;

// Nodes for AI Difficulty selection
SKSpriteNode *AIminus;
SKSpriteNode *AIplus;
SKSpriteNode *AIeasy;
SKSpriteNode *AImedium;
SKSpriteNode *AIhard;

// Indicators
bool isAIEasy = true;
bool isAIMedium = false;
bool isAIHard = false;

// Nodes for wind types
SKSpriteNode *WindNone;
SKSpriteNode *WindNorth;
SKSpriteNode *WindNorthEast;
SKSpriteNode *WindEast;
SKSpriteNode *WindSouthEast;
SKSpriteNode *WindSouth;
SKSpriteNode *WindSouthWest;
SKSpriteNode *WindWest;
SKSpriteNode *WindNorthWest;
SKSpriteNode *WindMinus;
SKSpriteNode *WindPlus;

// Indicators for wind
bool isWindNone = true;
bool isWindNorth = false;
bool isWindNorthEast = false;
bool isWindEast = false;
bool isWindSouthEast = false;
bool isWindSouth = false;
bool isWindSouthWest = false;
bool isWindWest = false;
bool isWindNorthWest = false;

// integer for wind
int wind = 0;
int ai_difficulty = 1;
int player_color = 4;

bool contFlag = true;
bool windFlag = true;
bool windpFlag = true;
bool windmFlag = true;
bool playerFlag = true;
bool playerpFlag = true;
bool playermFlag = true;
bool aiFlag = true;
bool aipFlag = true;
bool aimFlag = true;
bool gobackFlag = true;

@implementation GameSelection




/* View of Select Map Menu */
-(void)didMoveToView:(SKView *)view {
    [self backGroundBricks];
    [self gameSelect];
    
}


//int z = 1;
/* Implement map selection */
-(void)mouseDown:(NSEvent *)theEvent {
    
    NSPoint mouseDownPos = [theEvent locationInWindow];
    
    MainMenu *lol = [[MainMenu alloc]init];
    MusicPlayerStop([lol getMusicPlayer]);
    
    // User clicked continue, goes to the game
    if(mouseDownPos.x >= 620 && mouseDownPos.x <= 731 &&
       mouseDownPos.y >= 120 && mouseDownPos.y <= 141){
        
        
        /******Send the wind data to gamescene ******/
        NSUserDefaults *sceneInfo = [NSUserDefaults standardUserDefaults];
        
        if(isWindNone){
            wind = 0;
        }
        else if(isWindNorth){
            wind = 1;
        }
        else if(isWindNorthEast){
            wind = 2;
        }
        else if(isWindEast){
            wind = 3;
        }
        else if(isWindSouthEast){
            wind = 4;
        }
        else if(isWindSouth){
            wind = 5;
        }
        else if(isWindSouthWest){
            wind = 6;
        }
        else if(isWindWest){
            wind = 7;
        }
        else if(isWindNorthWest){
            wind = 8;
        }
        
        // For ai
        if(isAIEasy){
            ai_difficulty = 1;
        }
        else if(isAIMedium){
            ai_difficulty = 2;
        }
        else if(isAIHard){
            ai_difficulty = 3;
        }
        
        // For player color
        if(isPlayerYellow){
            player_color = 2;
        }
        else if(isPlayerRed){
            player_color = 3;
        }
        else if(isPlayerBlue){
            player_color = 4;
        }
        
        
        [sceneInfo setInteger:wind forKey:@"wind"];
        [sceneInfo setInteger:ai_difficulty forKey:@"aidifficulty"];
        [sceneInfo setInteger:player_color forKey:@"playercolor"];

        
        GameScene *scene = [GameScene sceneWithSize:self.view.bounds.size];
        
        
        //set up SelectMap size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        //[self.view presentScene:scene];
        
        [self transitionBricks:30 :590 :980 :470];
        [self phraseCastle];
        
        SKTransition* nextScene =[SKTransition revealWithDirection:SKTransitionDirectionDown duration:3 ];
        nextScene.pausesOutgoingScene = FALSE;
        nextScene.pausesIncomingScene = FALSE;

        [self.view presentScene:scene transition:nextScene];
    
    }
    
    // User clicked back, goes to the Select Map screen
    else if(mouseDownPos.x >= 70 && mouseDownPos.x <= 136 && mouseDownPos.y >= 117 && mouseDownPos.y <= 142) {
        SelectMap *scene = [SelectMap sceneWithSize:self.view.bounds.size];
        
        //set up SelectMap size
        CGSize s;
        s.width = 1008;
        s.height = 624;
        scene.size = s;
        
        scene.scaleMode = SKSceneScaleModeAspectFit;
        
        [self.view presentScene:scene];
    }
    //************************************************************
    // This is for minus
    else if(mouseDownPos.x >= 548 && mouseDownPos.x <= 554 && mouseDownPos.y >= 278 && mouseDownPos.y <= 293) {
        
        if(isPlayerYellow){
            // Removes all the colors from screen
            [playerColorRed removeFromParent];
            [playerColorBlue removeFromParent];
            [playerColorYellow removeFromParent];
            
            // Sets the new text to be blue
            [self playerColorRed:@"FontKingthingsBlack copy"];
            
            // Set indicators
            isPlayerRed = true;
            isPlayerYellow = false;
        }
        else if(isPlayerRed){
            // Removes all the colors from screen
            [playerColorRed removeFromParent];
            [playerColorBlue removeFromParent];
            [playerColorYellow removeFromParent];
            
            // Sets the new text to be blue
            [self playerColorBlue:@"FontKingthingsBlack copy"];
            
            // Set indicators
            isPlayerRed = false;
            isPlayerBlue = true;
        }

        
    }
    
    // This is for plus
    else if(mouseDownPos.x >= 738 && mouseDownPos.x <= 745 && mouseDownPos.y >= 281 && mouseDownPos.y <= 290) {
        
        if(isPlayerBlue){
            // Removes all the colors from screen
            [playerColorRed removeFromParent];
            [playerColorBlue removeFromParent];
            [playerColorYellow removeFromParent];
            
            // Sets the new text to be blue
            [self playerColorRed:@"FontKingthingsBlack copy"];
            
            // Set indicators
            isPlayerBlue = false;
            isPlayerRed = true;
        }
        else if(isPlayerRed){
            // Removes all the colors from screen
            [playerColorRed removeFromParent];
            [playerColorBlue removeFromParent];
            [playerColorYellow removeFromParent];
            
            // Sets the new text to be blue
            [self playerColorYellow:@"FontKingthingsBlack copy"];
            
            // Set indicators
            isPlayerRed = false;
            isPlayerYellow = true;
        }

    }
    //*************************************************************
    else if(mouseDownPos.x >= 545 && mouseDownPos.x <= 555 && mouseDownPos.y >= 200 && mouseDownPos.y <= 210) {
        
        // If the current text is set to hard
        if(isAIHard == true){
            
            // Set indicators
            isAIHard = false;
            isAIMedium = true;
            isAIEasy = false;
            
            // Remove all text from screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to medium
            [self AIMed:@"FontKingthingsBlack copy"];

        }
        
        // If the current text is set to medium
        else if(isAIMedium == true){
            isAIEasy = true;
            isAIMedium = false;
            isAIHard = false;
            
            // Remove all text from screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to easy
            [self AIEasy:@"FontKingthingsBlack copy"];
        }
    }
    
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 202 && mouseDownPos.y <= 212) {
        
        // If the current text is set to easy
        if(isAIEasy == true){
            
            // Set indicators
            isAIMedium = true;
            isAIEasy = false;
            isAIHard = false;
            
            // Remove all text from the screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to medium
            [self AIMed:@"FontKingthingsBlack copy"];
        }
        
        // If the current text is set to medium
        else if(isAIMedium == true){
            
            // Set indicators
            isAIMedium = false;
            isAIHard = true;
            isAIEasy = false;
            
            // Remve all text from the screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to hard
            [self AIHard:@"FontKingthingsBlack copy"];
        }
    
    }
    
    // Wind options plus
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 359 && mouseDownPos.y <= 370) {
        
        if(isWindNone == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = true;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'none' from screen
            [WindNone removeFromParent];
            
            // Set text to 'north'
            [self WindNorth];
        }
        else if(isWindNorth == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = true;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north' from screen
            [WindNorth removeFromParent];
            
            // Set text to 'north east'
            [self WindNorthEast];
        }
        
        else if(isWindNorthEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = true;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north east' from screen
            [WindNorthEast removeFromParent];
            
            // Set text to 'east'
            [self WindEast];
        }
        
        else if(isWindEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = true;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'east' from screen
            [WindEast removeFromParent];
            
            // Set text to 'south east'
            [self WindSouthEast];
        }
        
        else if(isWindSouthEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = true;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'south east' from screen
            [WindSouthEast removeFromParent];
            
            // Set text to 'south'
            [self WindSouth];
        }
        
        else if(isWindSouth == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = true;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'south' from screen
            [WindSouth removeFromParent];
            
            // Set text to 'south west'
            [self WindSouthWest];
        }
        
        else if(isWindSouthWest == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = true;
            isWindNorthWest = false;
            
            // Remove 'south west' from screen
            [WindSouthWest removeFromParent];
            
            // Set text to 'west'
            [self WindWest];
        }
        
        else if(isWindWest == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = true;
            
            // Remove 'west' from screen
            [WindWest removeFromParent];
            
            // Set text to 'north west'
            [self WindNorthWest];
        }

        
    }
    
    // Wind options minus
    else if(mouseDownPos.x >= 545 && mouseDownPos.x <= 555 && mouseDownPos.y >= 361 && mouseDownPos.y <= 368) {
        
       if(isWindNorth == true){
            // Set Indicators
            isWindNone = true;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north' from screen
            [WindNorth removeFromParent];
            
            // Set text to 'none'
            [self WindNone];
       }
        
       else if(isWindNorthEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = true;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'north east' from screen
           [WindNorthEast removeFromParent];
           
           // Set text to 'north'
           [self WindNorth];
       }
        
       else if(isWindEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = true;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'east' from screen
           [WindEast removeFromParent];
           
           // Set text to 'north east'
           [self WindNorthEast];
       }
       else if(isWindSouthEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = true;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south east' from screen
           [WindSouthEast removeFromParent];
           
           // Set text to 'south'
           [self WindSouth];
       }

       else if(isWindSouth == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = true;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south' from screen
           [WindSouth removeFromParent];
           
           // Set text to 'south east'
           [self WindSouthEast];
       }
        
       else if(isWindSouthWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = true;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south west' from screen
           [WindSouthWest removeFromParent];
           
           // Set text to 'south east'
           [self WindSouth];
       }
        
       else if(isWindWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = true;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'west' from screen
           [WindWest removeFromParent];
           
           // Set text to 'south west'
           [self WindSouthWest];
       }
        
       else if(isWindNorthWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = true;
           isWindNorthWest = false;
           
           // Remove 'north west' from screen
           [WindNorthWest removeFromParent];
           
           // Set text to 'west'
           [self WindWest];
       }
        
        
    }

    

    
    // If clicked, change player color option to blue
    else if(mouseDownPos.x >= 548 && mouseDownPos.x <= 554 && mouseDownPos.y >= 278 && mouseDownPos.y <= 293) {
        
        // Removes all the colors from screen
        [playerColorRed removeFromParent];
        [playerColorBlue removeFromParent];
        
        // Sets the new text to be blue
        [self playerColorBlue:@"FontKingthingsBlack copy"];
    }
    
    // If clicked, change player color option to red
    else if(mouseDownPos.x >= 738 && mouseDownPos.x <= 745 && mouseDownPos.y >= 281 && mouseDownPos.y <= 290) {
        
        // Removes all the colors from screen
        [playerColorBlue removeFromParent];
        [playerColorRed removeFromParent];
        
        // Sets the new text to be red
        [self playerColorRed:@"FontKingthingsBlack copy"];
    }
    
    else if(mouseDownPos.x >= 545 && mouseDownPos.x <= 555 && mouseDownPos.y >= 200 && mouseDownPos.y <= 210) {
        
        // If the current text is set to hard
        if(isAIHard == true){
            
            // Set indicators
            isAIHard = false;
            isAIMedium = true;
            isAIEasy = false;
            
            // Remove all text from screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to medium
            [self AIMed:@"FontKingthingsBlack copy"];

        }
        
        // If the current text is set to medium
        else if(isAIMedium){
            isAIEasy = true;
            isAIMedium = false;
            isAIHard = false;
            
            // Remove all text from screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to easy
            [self AIEasy:@"FontKingthingsBlack copy"];
        }
    }
    
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 202 && mouseDownPos.y <= 212) {
        
        // If the current text is set to easy
        if(isAIEasy == true){
            
            // Set indicators
            isAIMedium = true;
            isAIEasy = false;
            isAIHard = false;
            
            // Remove all text from the screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to medium
            [self AIMed:@"FontKingthingsBlack copy"];
        }
        
        // If the current text is set to medium
        else if(isAIMedium == true){
            
            // Set indicators
            isAIMedium = false;
            isAIHard = true;
            isAIEasy = false;
            
            // Remve all text from the screen
            [AIhard removeFromParent];
            [AImedium removeFromParent];
            [AIeasy removeFromParent];
            
            // Set text to hard
            [self AIHard:@"FontKingthingsBlack copy"];
        }
    
    }
    
    // Wind options plus
    else if(mouseDownPos.x >= 736 && mouseDownPos.x <= 745 && mouseDownPos.y >= 359 && mouseDownPos.y <= 370) {
        
        if(isWindNone == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = true;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'none' from screen
            [WindNone removeFromParent];
            
            // Set text to 'north'
            [self WindNorth];
        }
        else if(isWindNorth == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = true;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north' from screen
            [WindNorth removeFromParent];
            
            // Set text to 'north east'
            [self WindNorthEast];
        }
        
        else if(isWindNorthEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = true;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north east' from screen
            [WindNorthEast removeFromParent];
            
            // Set text to 'east'
            [self WindEast];
        }
        
        else if(isWindEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = true;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'east' from screen
            [WindEast removeFromParent];
            
            // Set text to 'south east'
            [self WindSouthEast];
        }
        
        else if(isWindSouthEast == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = true;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'south east' from screen
            [WindSouthEast removeFromParent];
            
            // Set text to 'south'
            [self WindSouth];
        }
        
        else if(isWindSouth == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = true;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'south' from screen
            [WindSouth removeFromParent];
            
            // Set text to 'south west'
            [self WindSouthWest];
        }
        
        else if(isWindSouthWest == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = true;
            isWindNorthWest = false;
            
            // Remove 'south west' from screen
            [WindSouthWest removeFromParent];
            
            // Set text to 'west'
            [self WindWest];
        }
        
        else if(isWindWest == true){
            // Set Indicators
            isWindNone = false;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = true;
            
            // Remove 'west' from screen
            [WindWest removeFromParent];
            
            // Set text to 'north west'
            [self WindNorthWest];
        }


        
    }
    
    // Wind options minus
    else if(mouseDownPos.x >= 545 && mouseDownPos.x <= 555 && mouseDownPos.y >= 361 && mouseDownPos.y <= 368) {
        
       if(isWindNorth == true){
            // Set Indicators
            isWindNone = true;
            isWindNorth = false;
            isWindNorthEast = false;
            isWindEast = false;
            isWindSouthEast = false;
            isWindSouth = false;
            isWindSouthWest = false;
            isWindWest = false;
            isWindNorthWest = false;
            
            // Remove 'north' from screen
            [WindNorth removeFromParent];
            
            // Set text to 'none'
            [self WindNone];
       }
        
       else if(isWindNorthEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = true;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'north east' from screen
           [WindNorthEast removeFromParent];
           
           // Set text to 'north'
           [self WindNorth];
       }
        
       else if(isWindEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = true;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'east' from screen
           [WindEast removeFromParent];
           
           // Set text to 'north east'
           [self WindNorthEast];
       }
        
       else if(isWindSouthEast == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = true;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south east' from screen
           [WindSouthEast removeFromParent];
           
           // Set text to 'east'
           [self WindEast];
       }
        
       else if(isWindSouth == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = true;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south' from screen
           [WindSouth removeFromParent];
           
           // Set text to 'south east'
           [self WindSouthEast];
       }
        
       else if(isWindSouthWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = true;
           isWindSouthWest = false;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'south west' from screen
           [WindSouthWest removeFromParent];
           
           // Set text to 'south east'
           [self WindSouth];
       }
        
       else if(isWindWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = true;
           isWindWest = false;
           isWindNorthWest = false;
           
           // Remove 'west' from screen
           [WindWest removeFromParent];
           
           // Set text to 'south west'
           [self WindSouthWest];
       }
        
       else if(isWindNorthWest == true){
           // Set Indicators
           isWindNone = false;
           isWindNorth = false;
           isWindNorthEast = false;
           isWindEast = false;
           isWindSouthEast = false;
           isWindSouth = false;
           isWindSouthWest = false;
           isWindWest = true;
           isWindNorthWest = false;
           
           // Remove 'north west' from screen
           [WindNorthWest removeFromParent];
           
           // Set text to 'west'
           [self WindWest];
       }
        
        
    }

    

    
}

-(void)mouseMoved:(NSEvent *)theEvent {
    NSPoint mousePos = [theEvent locationInWindow];
    
    //NSLog(@"x: %f y: %f", mousePos.x,mousePos.y);
    
    // Highlighting for wind option
    if(mousePos.x >= 70 && mousePos.x <= 747 &&
       mousePos.y >= 357 && mousePos.y <= 378) {
        
        [Wind removeFromParent];
        [self windType: @"FontKingthingsWhite copy"];
        if(windFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            windFlag = false;
        }
    }
    else{
        [Wind removeFromParent];
        [self windType: @"FontKingthingsBlack copy"];
        windFlag = true;
    }

    // Highlighting for Player Color
    if(mousePos.x >= 70 && mousePos.x <= 747 &&
       mousePos.y >= 279 && mousePos.y <= 299) {
        
        [PlayerColor removeFromParent];
        [self playerColor: @"FontKingthingsWhite copy"];
        if(playerFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            playerFlag = false;
        }
        
    }
    else{
        [PlayerColor removeFromParent];
        [self playerColor: @"FontKingthingsBlack copy"];
        playerFlag = true;
    }
    
    // Highlighting for AI difficulty
    if(mousePos.x >= 71 && mousePos.x <= 747 &&
       mousePos.y >= 201 && mousePos.y <= 221) {
        
        [AIDifficulty removeFromParent];
        [self aiDiff: @"FontKingthingsWhite copy"];
        if(aiFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            aiFlag = false;
        }
        
    }
    else{
        [AIDifficulty removeFromParent];
        [self aiDiff: @"FontKingthingsBlack copy"];
        aiFlag = true;
    }
    
    // Highlighting for back button
    if(mousePos.x >= 70 && mousePos.x <= 130 &&
       mousePos.y >= 121 && mousePos.y <= 142) {
        
        [Back removeFromParent];
        [self backLeftHighLight];
        if(gobackFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            gobackFlag = false;
        }
        
    }
    else{
        gobackFlag = true;
        [Back removeFromParent];
        [self backLeft];
        
    }
    
    // Highlighting for continue button
    if(mousePos.x >= 626 && mousePos.x <= 737 &&
       mousePos.y >= 121 && mousePos.y <= 139) {
        
        [Continue removeFromParent];
        [self continueHighLight];
        if(contFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            contFlag = false;
        }
            
        
    }
    else{
        [Continue removeFromParent];
        [self continueButton];
        contFlag = true;
    }
    
    // Highlighting for player color minus
    if(mousePos.x >= 548 && mousePos.x <= 554 &&
       mousePos.y >= 278 && mousePos.y <= 293) {
        [playerColorMinus removeFromParent];
        [self playerColorMinusHighlight];
        if(playermFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            playermFlag = false;
        }
        
    }
    else{
        [playerColorMinus removeFromParent];
        [self playerColorMinus];
        playermFlag = true;
    }
    
    // Highlighting for player color plus
    if(mousePos.x >= 738 && mousePos.x <= 745 &&
       mousePos.y >= 281 && mousePos.y <= 290) {
        [playerColorPlus removeFromParent];
        [self playerColorPlus:@"FontKingthingsWhite copy"];
        if(playerpFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            playerpFlag = false;
        }
        
    }
    else{
        [playerColorPlus removeFromParent];
        [self playerColorPlus:@"FontKingthingsBlack copy"];
        playerpFlag = true;
    }
    
    // Highlighting for AI difficulty minus
    if(mousePos.x >= 545 && mousePos.x <= 555 &&
       mousePos.y >= 200 && mousePos.y <= 210) {
        [AIminus removeFromParent];
        [self AIDifficultyMinus:@"FontKingthingsWhite copy"];
        if(aimFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            aimFlag = false;
        }
        
    }
    else{
        [AIminus removeFromParent];
        [self AIDifficultyMinus:@"FontKingthingsBlack copy"];
        aimFlag = true;
    }
    
    // Highlighting for AI difficulty plus
    if(mousePos.x >= 736 && mousePos.x <= 745 &&
       mousePos.y >= 202 && mousePos.y <= 212) {
        [AIplus removeFromParent];
        [self AIDifficultyPlus:@"FontKingthingsWhite copy"];
        if(aipFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            aipFlag = false;
        }
        
    }
    else{
        [AIplus removeFromParent];
        [self AIDifficultyPlus:@"FontKingthingsBlack copy"];
        aipFlag = true;
    }
    
    // Highlighting for wind option minus
    if(mousePos.x >= 545 && mousePos.x <= 555 &&
       mousePos.y >= 361 && mousePos.y <= 368) {
        [WindMinus removeFromParent];
        [self WindMinus:@"FontKingthingsWhite copy"];
        if(windmFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            windmFlag = false;
        }
        
    }
    else{
        [WindMinus removeFromParent];
        [self WindMinus:@"FontKingthingsBlack copy"];
        windmFlag = true;
    }
    
    // Highlighting for wind option plus
    if(mousePos.x >= 736 && mousePos.x <= 745 &&
       mousePos.y >= 359 && mousePos.y <= 370) {
        [WindPlus removeFromParent];
        [self WindPlus:@"FontKingthingsWhite copy"];
        if(windpFlag){
            SKAction *sound = [SKAction playSoundFileNamed:@"tick.wav" waitForCompletion:NO];
            [self runAction:sound];
            windpFlag = false;
        }
        
    }
    else{
        [WindPlus removeFromParent];
        [self WindPlus:@"FontKingthingsBlack copy"];
        windpFlag = true;
    }
    
}

+(NSMutableArray*)fillCastleCSet: (NSString*)tileSet withTileNumber: (int)tileCount{
    int fillArray = 0;
    
    SKTexture *curTile = [SKTexture textureWithImageNamed:tileSet];
    curTile.filteringMode = SKTextureFilteringNearest;
    
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:tileCount];
    
    //Fill tileArray with individual tiles
    while (fillArray < tileCount) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0,((float)fillArray/tileCount), 1, (1.0/tileCount)) inTexture:curTile]];
        fillArray++;
    }
    return tileArray;
}

-(void)letter:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    //A.zPosition = z;
    [self addChild:A];
}

-(void)number:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2 *1.5;
    A.position = CGPointMake(x,(y +5));
    [self addChild:A];
}


-(void)continueButton{
    int level;
    level = 100;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    
    Continue = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* N2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N2 setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(55,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(65,0)];
    
    [Continue addChild:O];
    [Continue addChild:N];
    [Continue addChild:T];
    [Continue addChild:I];
    [Continue addChild:N2];
    [Continue addChild:U];
    [Continue addChild:E];
    
    Continue.scale = 2;
    Continue.position = CGPointMake(800,level);
    [self addChild:Continue];
}

-(void)continueHighLight{
    int level;
    level = 100;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    
    Continue = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* N2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N2 setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(55,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(65,0)];
    
    [Continue addChild:O];
    [Continue addChild:N];
    [Continue addChild:T];
    [Continue addChild:I];
    [Continue addChild:N2];
    [Continue addChild:U];
    [Continue addChild:E];
    
    Continue.scale = 2;
    Continue.position = CGPointMake(800,level);
    [self addChild:Continue];
}

-(void)backLeft{
    int level;
    level = 100;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    
    Back = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:51]];
    [K setPosition:CGPointMake(30,0)];
    
    [Back addChild:A];
    [Back addChild:C];
    [Back addChild:K];
    
    Back.scale = 2;
    Back.position = CGPointMake(100,level);
    [self addChild:Back];
}

-(void)backLeftHighLight{
    int level;
    level = 100;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    
    Back = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:60]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* K = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:51]];
    [K setPosition:CGPointMake(30,0)];
    
    [Back addChild:A];
    [Back addChild:C];
    [Back addChild:K];
    
    Back.scale = 2;
    Back.position = CGPointMake(100,level);
    [self addChild:Back];
}

-(void)gameSelect{
    int horizon = 500;
    int level = 550;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    [self letter:level X:(horizon - 140) alpha:55 file:alphabet];//gameSelection    G
    [self letter:level X:(horizon - 120) alpha:61 file:alphabet];//gameSelection    A
    [self letter:level X:(horizon - 100) alpha:49 file:alphabet];//gameSelection    M
    [self letter:level X:(horizon - 80) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon - 40) alpha:43 file:alphabet];//gameSelection     S
    [self letter:level X:(horizon - 20) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon + 00) alpha:50 file:alphabet];//gameSelection     L
    [self letter:level X:(horizon + 20) alpha:57 file:alphabet];//gameSelection     E
    [self letter:level X:(horizon + 40) alpha:59 file:alphabet];//gameSelection     C
    [self letter:level X:(horizon + 60) alpha:42 file:alphabet];//gameSelection     T
    [self letter:level X:(horizon + 80) alpha:53 file:alphabet];//gameSelection     I
    [self letter:level X:(horizon + 100) alpha:47 file:alphabet];//gameSelection    O
    [self letter:level X:(horizon + 120) alpha:48 file:alphabet];//gameSelection    N
    [self windType:@"FontKingthingsBlack copy"];
    [self WindMinus:@"FontKingthingsBlack copy"];
    [self WindNone];
    [self WindPlus:@"FontKingthingsBlack copy"];
    [self playerColor:@"FontKingthingsBlack copy"];
    [self playerColorBlue:@"FontKingthingsBlack copy"];
    [self aiDiff:@"FontKingthingsBlack copy"];
    [self playerColorPlus:@"FontKingthingsBlack copy"];
    [self playerColorMinus];
    [self AIDifficultyMinus:@"FontKingthingsBlack copy"];
    [self AIEasy:@"FontKingthingsBlack copy"];
    [self AIDifficultyPlus:@"FontKingthingsBlack copy"];
    [self continueButton];
    [self backLeft];
    
    
}



-(void)windType:(NSString*)file{
    int horizon = 100;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:(horizon + 00) alpha:39 file:alphabet];//wind     W
    [self letter:level X:(horizon + 30) alpha:53 file:alphabet];//wind     I
    [self letter:level X:(horizon + 40) alpha:48 file:alphabet];//wind     N
    [self letter:level X:(horizon + 60) alpha:58 file:alphabet];//wind     D
    [self letter:level X:(horizon + 100) alpha:42 file:alphabet];//wind    T
    [self letter:level X:(horizon + 120) alpha:37 file:alphabet];//wind    Y
    [self letter:level X:(horizon + 140) alpha:46 file:alphabet];//wind    P
    [self letter:level X:(horizon + 160) alpha:57 file:alphabet];//wind    E*/
    
    Wind = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:39]];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(15,0)];
    
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:48]];
    [N setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* D = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:58]];
    [D setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(45,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(55,0)];
    
    SKSpriteNode* P = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    [P setPosition:CGPointMake(65,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(75,0)];
    
    [Wind addChild:I];
    [Wind addChild:N];
    [Wind addChild:D];
    [Wind addChild:T];
    [Wind addChild:Y];
    [Wind addChild:P];
    [Wind addChild:E];
    
    Wind.scale = 2;
    Wind.position = CGPointMake(horizon,level);
    [self addChild:Wind];
    
    
}

-(void)playerColor:(NSString*)file{
    int horizon = 100;
    int level = 300;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    /*[self letter:level X:(horizon + 00) alpha:46 file:alphabet];//Color     P
     [self letter:level X:(horizon + 20) alpha:50 file:alphabet];//Color     L
     [self letter:level X:(horizon + 40) alpha:61 file:alphabet];//Color     A
     [self letter:level X:(horizon + 60) alpha:37 file:alphabet];//Color     Y
     [self letter:level X:(horizon + 80) alpha:57 file:alphabet];//Color     E
     [self letter:level X:(horizon + 100) alpha:44 file:alphabet];//Color    R
     [self letter:level X:(horizon + 140) alpha:59 file:alphabet];//Color    C
     [self letter:level X:(horizon + 160) alpha:47 file:alphabet];//Color    O
     [self letter:level X:(horizon + 180) alpha:50 file:alphabet];//Color    L
     [self letter:level X:(horizon + 200) alpha:47 file:alphabet];//Color    O
     [self letter:level X:(horizon + 220) alpha:44 file:alphabet];//Color    R
     [self playerColorRed: file];
     */
    
    PlayerColor = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:46]];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(20,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(30,0)];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E setPosition:CGPointMake(40,0)];
    
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R setPosition:CGPointMake(50,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(65,0)];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O setPosition:CGPointMake(75,0)];
    
    SKSpriteNode* L2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L2 setPosition:CGPointMake(85,0)];
    
    SKSpriteNode* O2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:47]];
    [O2 setPosition:CGPointMake(95,0)];
    
    SKSpriteNode* R2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:44]];
    [R2 setPosition:CGPointMake(105,0)];
    
    [PlayerColor addChild:L];
    [PlayerColor addChild:A];
    [PlayerColor addChild:Y];
    [PlayerColor addChild:E];
    [PlayerColor addChild:R];
    [PlayerColor addChild:C];
    [PlayerColor addChild:O];
    [PlayerColor addChild:L2];
    [PlayerColor addChild:O2];
    [PlayerColor addChild:R2];
    
    PlayerColor.scale = 2;
    PlayerColor.position = CGPointMake(horizon,level);
    [self addChild:PlayerColor];
    
}

-(void)aiDiff:(NSString*)file{
   
    int level = 200;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];

    AIDifficulty = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    
    SKSpriteNode* I = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I setPosition:CGPointMake(10,0)];
    
    SKSpriteNode* D = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:58]];
    [D setPosition:CGPointMake(25,0)];
    
    SKSpriteNode* I2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I2 setPosition:CGPointMake(35,0)];
    
    SKSpriteNode* F = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:56]];
    [F setPosition:CGPointMake(42,0)];
    
    SKSpriteNode* F2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:56]];
    [F2 setPosition:CGPointMake(50,0)];
    
    SKSpriteNode* I3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:53]];
    [I3 setPosition:CGPointMake(60,0)];
    
    SKSpriteNode* C = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C setPosition:CGPointMake(67,0)];
    
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:41]];
    [U setPosition:CGPointMake(75,0)];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L setPosition:CGPointMake(85,0)];
    
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T setPosition:CGPointMake(95,0)];
    
    SKSpriteNode* Y = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:37]];
    [Y setPosition:CGPointMake(100,0)];
    
    [AIDifficulty addChild:I];
    [AIDifficulty addChild:D];
    [AIDifficulty addChild:I2];
    [AIDifficulty addChild:F];
    [AIDifficulty addChild:F2];
    [AIDifficulty addChild:I3];
    [AIDifficulty addChild:C];
    [AIDifficulty addChild:U];
    [AIDifficulty addChild:L];
    [AIDifficulty addChild:T];
    [AIDifficulty addChild:Y];
    
    AIDifficulty.scale = 2;
    AIDifficulty.position = CGPointMake(100,level);
    [self addChild:AIDifficulty];
    
    
}

-(void)letterTransition:(NSUInteger)y X:(NSUInteger)x alpha:(NSUInteger)alpha file:(NSMutableArray*)file{
    SKSpriteNode* A;
    A = [SKSpriteNode spriteNodeWithTexture:[file objectAtIndex:alpha]];
    A.scale = 2;
    A.position = CGPointMake(x,y);
    A.zPosition = 1000;
    [self addChild:A];
}



-(void)transitionBricks:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY{
    NSMutableArray *bricks = [GameSelection fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [GameSelection fillCastleCSet:@"Mortar copy" withTileNumber:28];
    NSMutableArray *blue = [GameSelection fillCastleCSet:@"2DTerrain copy" withTileNumber:30];
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightY ; ycount -= 20) {
        
        for (unsigned long int xcount = upperLeftX; xcount <= lowerRightX; xcount+=20) {
            [self letterTransition:(ycount) X:(xcount) alpha:3 file:blue];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letterTransition:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letterTransition:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letterTransition:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letterTransition:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letterTransition:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letterTransition:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letterTransition:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letterTransition:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letterTransition:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letterTransition:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letterTransition:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letterTransition:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letterTransition:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letterTransition:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letterTransition:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letterTransition:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letterTransition:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letterTransition:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letterTransition:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letterTransition:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letterTransition:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letterTransition:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letterTransition:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letterTransition:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letterTransition:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letterTransition:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letterTransition:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letterTransition:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letterTransition:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letterTransition:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letterTransition:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letterTransition:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letterTransition:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letterTransition:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letterTransition:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letterTransition:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letterTransition:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }    
}

// The minus selector for AI difficulty
-(void)AIDifficultyMinus:(NSString *)file{
    //int horizon = 700;
    int level = 200;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    AIminus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    
    AIminus.scale = 2;
    AIminus.position = CGPointMake(700,level);
    [self addChild:AIminus];

}

// The plus selector for AI difficulty
-(void)AIDifficultyPlus:(NSString *)file{
    //int horizon = 700;
    int level = 200;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    AIplus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:83]];
    
    AIplus.scale = 2;
    AIplus.position = CGPointMake(940,level);
    [self addChild:AIplus];
    
}

-(void)AIHard:(NSString*)file{
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    AIhard =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:29]];
    [A setPosition:CGPointMake(30, 0)];
    
    SKSpriteNode* R =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(50, 0)];
    
    SKSpriteNode* D =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:26]];
    [D setPosition:CGPointMake(70, 0)];
    
    
    [AIhard addChild:A];
    [AIhard addChild:R];
    [AIhard addChild:D];
    
    AIhard.scale = 2;
    AIhard.position = CGPointMake(750,200);
    [self addChild:AIhard];

}


-(void)AIMed:(NSString*)file{
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    AImedium =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:17]];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(35, 0)];
    
    SKSpriteNode* D =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:26]];
    [D setPosition:CGPointMake(60, 0)];
    

    [AImedium addChild:E];
    [AImedium addChild:D];

    AImedium.scale = 2;
    AImedium.position = CGPointMake(750,200);
    [self addChild:AImedium];
}



-(void)AIEasy:(NSString*)file{
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    AIeasy =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:29]];
    [A setPosition:CGPointMake(30, 0)];
    
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(50, 0)];
    
    SKSpriteNode* Y =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:5]];
    [Y setPosition:CGPointMake(70, 0)];

    [AIeasy addChild:A];
    [AIeasy addChild:S];
    [AIeasy addChild:Y];

    AIeasy.scale = 2;
    AIeasy.position = CGPointMake(750,200);
    [self addChild:AIeasy];

}

-(void)playerColorRed:(NSString*)file{
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    playerColorRed =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    
    SKSpriteNode* e = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [e setPosition:CGPointMake(35, 0)];
    
    SKSpriteNode* d =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:26]];
    [d setPosition:CGPointMake(60, 0)];

    [playerColorRed addChild:e];
    [playerColorRed addChild:d];

    playerColorRed.scale = 2;
    playerColorRed.position = CGPointMake(750,300);
    [self addChild:playerColorRed];
    
    /*
     NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
     
     [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
     [self letter:level X:(horizon + 30) alpha:12 file:alphabet];//color    r
     [self letter:level X:(horizon + 50) alpha:25 file:alphabet];//color    e
     [self letter:level X:(horizon + 70) alpha:26 file:alphabet];//color    d
     [self letter:level X:(horizon + 100) alpha:83 file:alphabet];//color   +
     */

}

-(void)playerColorMinusHighlight{
    //int horizon = 700;
    int level = 300;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];

    playerColorMinus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];

    playerColorMinus.scale = 2;
    playerColorMinus.position = CGPointMake(700,level);
    [self addChild:playerColorMinus];
    
    /*
     NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
     
     [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
     [self letter:level X:(horizon + 30) alpha:12 file:alphabet];//color    r
     [self letter:level X:(horizon + 50) alpha:25 file:alphabet];//color    e
     [self letter:level X:(horizon + 70) alpha:26 file:alphabet];//color    d
     [self letter:level X:(horizon + 100) alpha:83 file:alphabet];//color   +
     */
}

-(void)playerColorMinus{
    //int horizon = 700;
    int level = 300;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy" withTileNumber:95];
    
    playerColorMinus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    
    playerColorMinus.scale = 2;
    playerColorMinus.position = CGPointMake(700,level);
    [self addChild:playerColorMinus];
    
    /*
     NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
     
     [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
     [self letter:level X:(horizon + 30) alpha:12 file:alphabet];//color    r
     [self letter:level X:(horizon + 50) alpha:25 file:alphabet];//color    e
     [self letter:level X:(horizon + 70) alpha:26 file:alphabet];//color    d
     [self letter:level X:(horizon + 100) alpha:83 file:alphabet];//color   +
     */
}

-(void)playerColorPlus:(NSString *)file{
    //int horizon = 700;
    int level = 300;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    playerColorPlus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:83]];
    
    playerColorPlus.scale = 2;
    playerColorPlus.position = CGPointMake(940,level);
    [self addChild:playerColorPlus];
    
    /*
     NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
     
     [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
     [self letter:level X:(horizon + 30) alpha:12 file:alphabet];//color    r
     [self letter:level X:(horizon + 50) alpha:25 file:alphabet];//color    e
     [self letter:level X:(horizon + 70) alpha:26 file:alphabet];//color    d
     [self letter:level X:(horizon + 100) alpha:83 file:alphabet];//color   +
     */
}

-(void)playerColorBlue:(NSString*)file{
    // int horizon = 700;
    int level = 300;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    playerColorBlue =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:28]];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:18]];
    [L setPosition:CGPointMake(30, 0)];
    
    SKSpriteNode* U =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(50, 0)];
    
    SKSpriteNode* E =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(70, 0)];
    

    [playerColorBlue addChild:L];
    [playerColorBlue addChild:U];
    [playerColorBlue addChild:E];
    
    playerColorBlue.scale = 2;
    playerColorBlue.position = CGPointMake(750,level);
    [self addChild:playerColorBlue];
    /*
     NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
     [self letter:level X:(horizon + 00) alpha:81 file:alphabet];//color    -
     [self letter:level X:(horizon + 30) alpha:28 file:alphabet];//color    b
     [self letter:level X:(horizon + 50) alpha:18 file:alphabet];//color    l
     [self letter:level X:(horizon + 70) alpha:9  file:alphabet];//color    u
     [self letter:level X:(horizon + 90) alpha:25 file:alphabet];//color    e
     [self letter:level X:(horizon + 120) alpha:83 file:alphabet];//color   +
     */
}

-(void)playerColorYellow:(NSString *)file{
    int horizon = 750;
    int level = 300;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    playerColorYellow =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:5]];
    
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(20, 0)];
    
    SKSpriteNode* L = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:18]];
    [L setPosition:CGPointMake(30, 0)];
    
    SKSpriteNode* L2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:18]];
    [L2 setPosition:CGPointMake(40, 0)];
    
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(50, 0)];
    
    SKSpriteNode* W = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:7]];
    [W setPosition:CGPointMake(65, 0)];
    
    [playerColorYellow addChild:E];
    [playerColorYellow addChild:L];
    [playerColorYellow addChild:L2];
    [playerColorYellow addChild:O];
    [playerColorYellow addChild:W];
    
    playerColorYellow.scale = 2;
    playerColorYellow.position = CGPointMake(horizon,level);
    [self addChild:playerColorYellow];
}


// The minus selector for AI difficulty
-(void)WindMinus:(NSString *)file{
    int horizon = 700;
    int level = 400;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    WindMinus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:81]];
    
    WindMinus.scale = 2;
    WindMinus.position = CGPointMake(horizon,level);
    [self addChild:WindMinus];
    
}

// The plus selector for AI difficulty
-(void)WindPlus:(NSString *)file{
    int horizon = 940;
    int level = 400;
    
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:file withTileNumber:95];
    
    WindPlus =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:83]];
    
    WindPlus.scale = 2;
    WindPlus.position = CGPointMake(horizon,level);
    [self addChild:WindPlus];
    
}

// Displays text for no wind
-(void)WindNone{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // N
    WindNone = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(30,0)];
    
    // N
    SKSpriteNode* N = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    [N setPosition:CGPointMake(50,0)];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(70,0)];
    
    [WindNone addChild:O];
    [WindNone addChild:N];
    [WindNone addChild:E];

    WindNone.scale = 2;
    WindNone.position = CGPointMake(horizon,level);
    [self addChild:WindNone];
    
}

-(void)WindNorth{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // N
    WindNorth = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(15,0)];
    
    // R
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(30,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(45,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(60,0)];
    
    
    [WindNorth addChild:O];
    [WindNorth addChild:R];
    [WindNorth addChild:T];
    [WindNorth addChild:H];
    
    WindNorth.scale = 2;
    WindNorth.position = CGPointMake(horizon,level);
    [self addChild:WindNorth];
    
}

-(void)WindNorthEast{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];

    // N
    WindNorthEast = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    // R
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(20,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(30,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(40,0)];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(50,0)];
    
    // A
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:29]];
    [A setPosition:CGPointMake(60, 0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(70, 0)];
    
    // T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(80,0)];
    
    [WindNorthEast addChild:O];
    [WindNorthEast addChild:R];
    [WindNorthEast addChild:T];
    [WindNorthEast addChild:H];
    [WindNorthEast addChild:E];
    [WindNorthEast addChild:A];
    [WindNorthEast addChild:S];
    [WindNorthEast addChild:T2];
    
    WindNorthEast.scale = 2;
    WindNorthEast.position = CGPointMake(horizon,level);
    [self addChild:WindNorthEast];
}





-(void)phraseCastle{
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsWhite copy" withTileNumber:95];
    //set up alphabet
    //Spells "SELECT CASTLE"
    SKNode *castlePhrase = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];//S
    
    SKSpriteNode* E1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E1 setPosition:CGPointMake(10,0)];//E
    SKSpriteNode* L1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L1 setPosition:CGPointMake(20,0)];//L
    SKSpriteNode* E2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E2 setPosition:CGPointMake(30,0)];//E
    SKSpriteNode* C1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C1 setPosition:CGPointMake(40,0)];//C
    SKSpriteNode* T1 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T1 setPosition:CGPointMake(50,0)];//T
    
    SKSpriteNode* C2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:59]];
    [C2 setPosition:CGPointMake(70,0)];//C
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:61]];
    [A setPosition:CGPointMake(80,0)];//A
    SKSpriteNode* S = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:43]];
    [S setPosition:CGPointMake(90,0)];//S
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:42]];
    [T2 setPosition:CGPointMake(100,0)];//T
    SKSpriteNode* L2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:50]];
    [L2 setPosition:CGPointMake(110,0)];//L
    SKSpriteNode* E3 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:57]];
    [E3 setPosition:CGPointMake(120,0)];//E
    
    [castlePhrase addChild:E1];
    [castlePhrase addChild:L1];
    [castlePhrase addChild:E2];
    [castlePhrase addChild:C1];
    [castlePhrase addChild:T1];
    [castlePhrase addChild:C2];
    [castlePhrase addChild:A];
    [castlePhrase addChild:S];
    [castlePhrase addChild:T2];
    [castlePhrase addChild:L2];
    [castlePhrase addChild:E3];
    
    castlePhrase.scale = 2;
    castlePhrase.position = CGPointMake(375,525);
    castlePhrase.zPosition = 1001;
    
    [self addChild:castlePhrase];
}


-(void)WindEast{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // E
    WindEast = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    
    // A
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:29]];
    [A setPosition:CGPointMake(20, 0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(40, 0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(60,0)];
    
    [WindEast addChild:A];
    [WindEast addChild:S];
    [WindEast addChild:T];
    
    WindEast.scale = 2;
    WindEast.position = CGPointMake(horizon,level);
    [self addChild:WindEast];
}

-(void)WindSouthEast{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // S
    WindSouthEast = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    // U
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(20,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(30,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(40,0)];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(50,0)];
    
    // A
    SKSpriteNode* A = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:29]];
    [A setPosition:CGPointMake(60, 0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(70, 0)];
    
    // T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(80,0)];
    
    [WindSouthEast addChild:O];
    [WindSouthEast addChild:U];
    [WindSouthEast addChild:T];
    [WindSouthEast addChild:H];
    [WindSouthEast addChild:E];
    [WindSouthEast addChild:A];
    [WindSouthEast addChild:S];
    [WindSouthEast addChild:T2];
    
    WindSouthEast.scale = 2;
    WindSouthEast.position = CGPointMake(horizon,level);
    [self addChild:WindSouthEast];
}

-(void)WindSouth{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // S
    WindSouth = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(15,0)];
    
    // U
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(30,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(45,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(60,0)];
    
    [WindSouth addChild:O];
    [WindSouth addChild:U];
    [WindSouth addChild:T];
    [WindSouth addChild:H];
    
    WindSouth.scale = 2;
    WindSouth.position = CGPointMake(horizon,level);
    [self addChild:WindSouth];
}

-(void)WindSouthWest{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // S
    WindSouthWest = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    // U
    SKSpriteNode* U = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:9]];
    [U setPosition:CGPointMake(20,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(30,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(40,0)];
   
    // W
    SKSpriteNode* W = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:7]];
    [W setPosition:CGPointMake(50, 0)];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(63,0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(70, 0)];
    
    // T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(80,0)];
    
    [WindSouthWest addChild:O];
    [WindSouthWest addChild:U];
    [WindSouthWest addChild:T];
    [WindSouthWest addChild:H];
    [WindSouthWest addChild:W];
    [WindSouthWest addChild:E];
    [WindSouthWest addChild:S];
    [WindSouthWest addChild:T2];
    
    WindSouthWest.scale = 2;
    WindSouthWest.position = CGPointMake(horizon,level);
    [self addChild:WindSouthWest];
}

-(void)WindWest{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // W
    WindWest = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:7]];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(30,0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(50, 0)];
    
    // T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(70,0)];
    

    [WindWest addChild:E];
    [WindWest addChild:S];
    [WindWest addChild:T2];
    
    WindWest.scale = 2;
    WindWest.position = CGPointMake(horizon,level);
    [self addChild:WindWest];
}


-(void)WindNorthWest{
    int horizon = 750;
    int level = 400;
    NSMutableArray *alphabet = [GameSelection fillCastleCSet:@"FontKingthingsBlack copy"withTileNumber:95];
    
    // N
    WindNorthWest = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:16]];
    
    // O
    SKSpriteNode* O = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:15]];
    [O setPosition:CGPointMake(10,0)];
    
    // R
    SKSpriteNode* R = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:12]];
    [R setPosition:CGPointMake(20,0)];
    
    // T
    SKSpriteNode* T = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T setPosition:CGPointMake(30,0)];
    
    // H
    SKSpriteNode* H = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:22]];
    [H setPosition:CGPointMake(40,0)];
    
    // W
    SKSpriteNode* W = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:7]];
    [W setPosition:CGPointMake(50, 0)];
    
    // E
    SKSpriteNode* E = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:25]];
    [E setPosition:CGPointMake(63,0)];
    
    // S
    SKSpriteNode* S =[SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:11]];
    [S setPosition:CGPointMake(70, 0)];
    
    // T
    SKSpriteNode* T2 = [SKSpriteNode spriteNodeWithTexture:[alphabet objectAtIndex:10]];
    [T2 setPosition:CGPointMake(80,0)];
    
    [WindNorthWest addChild:O];
    [WindNorthWest addChild:R];
    [WindNorthWest addChild:T];
    [WindNorthWest addChild:H];
    [WindNorthWest addChild:W];
    [WindNorthWest addChild:E];
    [WindNorthWest addChild:S];
    [WindNorthWest addChild:T2];
    
    WindNorthWest.scale = 2;
    WindNorthWest.position = CGPointMake(horizon,level);
    [self addChild:WindNorthWest];
}



/* same logic as below in backGroundBricks format of parameters:
 (NSUInteger)upperLeftX
 (NSUInteger)upperLeftY
 (NSUInteger)lowerRightX
 (NSUInteger)lowerRightY
 
 (upperLeftX, upperLeftY)*---------------------------*
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 |                           |
 *---------------------------*(lowerRightX,lowerRightY)
 

 */

-(void)titleBox:(NSUInteger)upperLeftX :(NSUInteger)upperLeftY :(NSUInteger)lowerRightX :(NSUInteger)lowerRightY {
    NSMutableArray *bricks = [GameSelection fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [GameSelection fillCastleCSet:@"Mortar copy" withTileNumber:28];
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    for (unsigned long int ycount = upperLeftX; ycount >= lowerRightY ; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < upperLeftX-20) && (xcount < lowerRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < upperLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < lowerRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(lowerRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    for (unsigned long int ycount = upperLeftY; ycount >= lowerRightX -25; ycount -= 15) {
        for (unsigned long int xcount = upperLeftX +45; xcount <= lowerRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (unsigned long int xcount = upperLeftX +40; xcount <= lowerRightX; xcount+=40) {
        [self letter:(upperLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:lowerRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= (lowerRightX + upperLeftX)/2){
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(upperLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(lowerRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    
    
    
    
    
    for (unsigned long int ycount = lowerRightY+20; ycount <= upperLeftY; ycount += 20) {
        [self letter:(ycount) X:(lowerRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(upperLeftX) alpha:3 file:bricks];//left
        if ((upperLeftY+2 + lowerRightY)/2 > ycount) {
            [self letter:(ycount) X:(lowerRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:9 file:mortar];
        }
        else if ((upperLeftY-2+ lowerRightY)/2 < ycount){
            [self letter:(ycount) X:(lowerRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(lowerRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(upperLeftX ) alpha:20 file:mortar];
            
        }
        [self letter:(ycount) X:(upperLeftX -10) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -23) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -25) alpha:13 file:mortar];
        [self letter:(ycount) X:(upperLeftX -27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +25) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +27) alpha:13 file:mortar];
        [self letter:(ycount) X:(lowerRightX +29) alpha:13 file:mortar];
        
    }
    
    
    [self letter:upperLeftY X:(upperLeftX) alpha:1 file:bricks];//top right
    [self letter:lowerRightY X:upperLeftX alpha:4 file:bricks];//bottom left
    [self letter:(upperLeftY) X:(lowerRightX) alpha:9 file:bricks];//top right
    [self letter:lowerRightY X:(lowerRightX) alpha:6 file:bricks];//bottom right
    [self letter:(upperLeftY -10) X:(upperLeftX) alpha:2 file:mortar];
    [self letter:(upperLeftY -10) X:(lowerRightX) alpha:24 file:mortar];
    [self letter:(lowerRightY +10) X:(upperLeftX) alpha:10 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX) alpha:16 file:mortar];
    [self letter:(lowerRightY +10) X:(lowerRightX ) alpha:17 file:mortar];
    [self letter:(upperLeftY - 5) X:(lowerRightX ) alpha:23 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX ) alpha:9 file:mortar];
    [self letter:(upperLeftY - 10) X:(upperLeftX ) alpha:10 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(upperLeftX -23) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(lowerRightY) X:(lowerRightX +23) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +25) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +27) alpha:13 file:mortar];
    [self letter:(upperLeftY +10) X:(lowerRightX +23) alpha:13 file:mortar];
    
    
    for (unsigned long int xcount = upperLeftX - 25; xcount < lowerRightX+15; xcount +=10) {
        [self letter:(lowerRightY -15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -17) X:(xcount ) alpha:20 file:mortar];
        [self letter:(lowerRightY -19) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +13) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +15) X:(xcount ) alpha:20 file:mortar];
        [self letter:(upperLeftY +17) X:(xcount ) alpha:20 file:mortar];
    }
    
    
}


-(void)backGroundBricks{
    NSMutableArray *bricks = [GameSelection fillCastleCSet:@"Bricks copy" withTileNumber:11];
    NSMutableArray *mortar = [GameSelection fillCastleCSet:@"Mortar copy" withTileNumber:28];
    int topLeftX = 20;
    int topLeftY = 615;
    int bottomRightX = 987;
    int bottomRightY = 10;
    
    
    //[self letter:level X:(horizon + 200) alpha:2 file:bricks];
    //[self letter:(100) X:(700) alpha:8 file:bricks];
    
    
    for (int ycount = topLeftY; ycount >= bottomRightY ; ycount -= 15) {
        for (int xcount = topLeftX +40; xcount <= bottomRightX+35; xcount+=40) {
            if(ycount%2 == 0){
                
                [self letter:(ycount) X:(xcount-25) alpha:1 file:bricks];
                if ((ycount < topLeftY-20) && (xcount < bottomRightX +25)){
                    [self letter:(ycount) X:(xcount-5) alpha:27 file:mortar];
                }
                
                
            }
            else{
                if (ycount < topLeftY) {
                    [self letter:(ycount) X:(xcount - 45) alpha:1 file:bricks];
                    [self letter:(ycount) X:(xcount - 25) alpha:1 file:bricks];
                    //[self letter:(ycount) X:(xcount - 45) alpha:27 file:mortar];
                    if(xcount < bottomRightX+25){
                        [self letter:(ycount) X:(xcount - 25) alpha:27 file:mortar];
                    }
                    else{
                        [self letter:(ycount) X:(bottomRightX) alpha:27 file:mortar];
                    }
                    
                }
            }
        }
        
    }
    
    for (int ycount = topLeftY-20; ycount >= bottomRightY; ycount -= 15) {
        for (int xcount = topLeftX +45; xcount <= bottomRightX+20; xcount+=40) {
            [self letter:(ycount + 10) X:(xcount -25) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount -15) alpha:6 file:mortar];
            [self letter:(ycount + 10) X:(xcount) alpha:6 file:mortar];
            //[self letter:(ycount + 10) X:(xcount +25) alpha:6 file:mortar];
        }
        
    }
    
    //[self letter:(100) X:(700) alpha:1 file:bricks];
    //[self letter:(90) X:(680) alpha:27 file:mortar];
    for (int xcount = topLeftX +40; xcount <= bottomRightX; xcount+=40) {
        [self letter:(topLeftY) X:(xcount) alpha:10 file:bricks];//top
        [self letter:bottomRightY X:(xcount) alpha:5 file:bricks];//bottom
        if(xcount >= bottomRightX/2){
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:24 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:16 file:mortar];
        }
        else{
            [self letter:(topLeftY -10) X:(xcount - 20) alpha:2 file:mortar];
            [self letter:(bottomRightY +10) X:(xcount - 20) alpha:10 file:mortar];
        }
    }
    for (int ycount = bottomRightY+20; ycount <= topLeftY; ycount += 20) {
        [self letter:(ycount) X:(bottomRightX) alpha:7 file:bricks];//right
        [self letter:ycount X:(topLeftX) alpha:3 file:bricks];//left
        if ((topLeftY+2)/2 > ycount) {
            [self letter:(ycount) X:(bottomRightX ) alpha:17 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:9 file:mortar];
        }
        else if ((topLeftY-2)/2 < ycount){
            [self letter:(ycount) X:(bottomRightX ) alpha:23 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:3 file:mortar];
        }
        else{
            [self letter:(ycount) X:(bottomRightX ) alpha:20 file:mortar];
            [self letter:(ycount) X:(topLeftX ) alpha:20 file:mortar];
            
        }
        
    }
    
    [self letter:topLeftY X:(topLeftX) alpha:1 file:bricks];//top right
    [self letter:bottomRightY X:topLeftX alpha:4 file:bricks];//bottom left
    [self letter:(topLeftY) X:(bottomRightX) alpha:9 file:bricks];//top right
    [self letter:bottomRightY X:(bottomRightX) alpha:6 file:bricks];//bottom right
    [self letter:(topLeftY -10) X:(topLeftX) alpha:2 file:mortar];
    [self letter:(topLeftY -10) X:(bottomRightX) alpha:24 file:mortar];
    [self letter:(bottomRightY +10) X:(topLeftX) alpha:10 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX) alpha:16 file:mortar];
    [self letter:(bottomRightY +10) X:(bottomRightX ) alpha:17 file:mortar];
    [self letter:(topLeftY - 5) X:(bottomRightX ) alpha:23 file:mortar];
    [self letter:(bottomRightY) X:(topLeftX ) alpha:9 file:mortar];
    [self letter:(topLeftY - 10) X:(topLeftX ) alpha:10 file:mortar];
    [self titleBox:(300) :615: 700 : 500];
    
}


@end