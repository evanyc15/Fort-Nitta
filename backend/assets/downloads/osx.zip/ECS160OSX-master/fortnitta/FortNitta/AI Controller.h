//
//  AI Controller.h
//  FortNitta
//
//  Created by Alexander Sergian on 2/25/15.
//  Copyright (c) 2015 OSX Team. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
int difficulty;
int aiControllerColor;

@interface AI_Controller : NSObject {
    lua_State *L;
    NSTimer *timer;
}

-(void) unselectedCastle;
-(id) init: (int) AI_difficulty;
-(int) get_AI_castle;
-(void) place_cannon: (int*) number : (int) mapWidth : (int) mapHeight : (int*) x : (int*) y;
-(void) battle_mode: (int*) x : (int*) y;
-(void) stackdump_g;

@end

struct SInt2 {
    int DX;
    int DY;
};

struct SInt2 unselectedCastles[5];