/*
 *  RebuildMode.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */


#import "GameScene.h"
#import "RebuildMode.h"
#import "BattleMode.h"
#import "WallHoverPieces.h"
#import "WallPieces.h"
#import <Foundation/Foundation.h>

#define tileEdge 24
#define tileScale 2

//Set CombineColor
int combineColor;

//Main Castle Name
char cName;

@implementation RebuildMode


/* 
    Rebuild mode:
    Selecting a Hover/Actual Wall piece & Storing Piece in array for later use
    RightClicking Check
    Floodfill - Checkerboard
*/

+(void)rebuildMode: (GameScene *) scene piece: (int *) piece set: (Boolean)hasBeenSet rotate: (Boolean) rightClick type: (int)color{
    //NSLog(@"\n*** Entered Rebuild Mode *** \n");

    if(rightClick){
        (*(piece)) = [self rotate:&((*(piece)))];
    }
    
    //Sets the wall color
    [WallPieces setColor:color];
    
    //Sets the combine color
    [self setCombineColor:color];
    
    //Given a Random Piece Id, Pick out the piece (Outline or Actual Wall)
    switch((*(piece))){
        //Evan:  Set all pieceHeight and pieceWidth variables, based on shapes in WallPieces.m
            //(note that rotation is clockwise)
        case 0:
            if(hasBeenSet) {
                [WallPieces monomino:(scene)];
                pieceHeight = 1;
                pieceWidth = 1;
            }
            else {
                [WallHoverPieces monominoOutline:(scene)  curPos:&storedLocation];
            }
            break;
        case 1:
            if(hasBeenSet){
                [WallPieces domino:(scene)];
                pieceHeight = 2;
                pieceWidth = 1;
            }
            else{
                [WallHoverPieces dominoOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 2:
            if(hasBeenSet){
                [WallPieces dominoAlt:(scene)];
                pieceHeight = 1;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces dominoOutlineAlt:(scene)  curPos:&storedLocation];
            }
            break;
        case 3:
            if(hasBeenSet){
                [WallPieces trominoL:(scene)];
                pieceHeight = 2;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces trominoLOutline:(scene)  curPos:&storedLocation];
            }
            break;
        case 4:
            if(hasBeenSet){
                [WallPieces trominoLAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces trominoLOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 5:
            if(hasBeenSet){
                [WallPieces trominoLAlt2:(scene)];
                pieceHeight = 2;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces trominoLOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 6:
            if(hasBeenSet){
                [WallPieces trominoLAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces trominoLOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 7:
            if(hasBeenSet){
                [WallPieces trominoI:(scene)];
                pieceHeight = 3;
                pieceWidth = 1;
            }
            else{
                [WallHoverPieces trominoIOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 8:
            if(hasBeenSet){
                [WallPieces trominoIAlt:(scene)];
                pieceHeight = 1;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces trominoIOutlineAlt:(scene) curPos:&storedLocation];
            }
            break;
        case 9:
            if(hasBeenSet){
                [WallPieces tetrominoZ:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoZOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 10:
            if(hasBeenSet){
                [WallPieces tetrominoZAlt:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces tetrominoZOutlineAlt:(scene) curPos:&storedLocation];
            }
            break;
        case 11:
            if(hasBeenSet){
                [WallPieces tetrominoI:(scene)];
                pieceHeight = 4;
                pieceWidth = 1;
            }
            else{
                [WallHoverPieces tetrominoIOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 12:
            if(hasBeenSet){
                [WallPieces tetrominoIAlt:(scene)];
                pieceHeight = 1;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces tetrominoIOutlineAlt:(scene) curPos:&storedLocation];
            }
            break;
        case 13:
            if(hasBeenSet){
                [WallPieces tetrominoCube:(scene)];
                pieceHeight = 2;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoCubeOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 14:
            if(hasBeenSet){
                [WallPieces tetrominoT:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces tetrominoTOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 15:
            if(hasBeenSet){
                [WallPieces tetrominoTAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoTOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 16:
            if(hasBeenSet){
                [WallPieces tetrominoTAlt2:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces tetrominoTOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 17:
            if(hasBeenSet){
                [WallPieces tetrominoTAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoTOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 18:
            if(hasBeenSet){
                [WallPieces tetrominoL:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoLOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 19:
            if(hasBeenSet){
                [WallPieces tetrominoLAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces tetrominoLOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 20:
            if(hasBeenSet){
                [WallPieces tetrominoLAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces tetrominoLOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 21:
            if(hasBeenSet){
                [WallPieces tetrominoLAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces tetrominoLOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 22:
            if(hasBeenSet){
                [WallPieces pentominoF:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoFOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 23:
            if(hasBeenSet){
                [WallPieces pentominoFAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoFOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 24:
            if(hasBeenSet){
                [WallPieces pentominoFAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoFOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 25:
            if(hasBeenSet){
                [WallPieces pentominoFAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoFOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 26:
            if(hasBeenSet){
                [WallPieces pentominoI:(scene)];
                pieceHeight = 5;
                pieceWidth = 1;
            }
            else{
                [WallHoverPieces pentominoIOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 27:
            if(hasBeenSet){
                [WallPieces pentominoIAlt:(scene)];
                pieceHeight = 1;
                pieceWidth = 5;
            }
            else{
                [WallHoverPieces pentominoIOutlineAlt:(scene) curPos:&storedLocation];
            }
            break;
        case 28:
            if(hasBeenSet){
                [WallPieces pentominoL:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoLOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 29:
            if(hasBeenSet){
                [WallPieces pentominoLAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoLOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 30:
            if(hasBeenSet){
                [WallPieces pentominoLAlt2:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoLOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 31:
            if(hasBeenSet){
                [WallPieces pentominoLAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoLOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 32:
            if(hasBeenSet){
                [WallPieces pentominoN:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoNOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 33:
            if(hasBeenSet){
                [WallPieces pentominoNAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoNOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 34:
            if(hasBeenSet){
                [WallPieces pentominoNAlt2:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoNOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 35:
            if(hasBeenSet){
                [WallPieces pentominoNAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoNOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 36:
            if(hasBeenSet){
                [WallPieces pentominoP:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoPOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 37:
            if(hasBeenSet){
                [WallPieces pentominoPAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoPOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 38:
            if(hasBeenSet){
                [WallPieces pentominoPAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoPOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 39:
            if(hasBeenSet){
                [WallPieces pentominoPAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoPOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 40:
            if(hasBeenSet){
                [WallPieces pentominoT:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoTOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 41:
            if(hasBeenSet){
                [WallPieces pentominoTAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoTOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 42:
            if(hasBeenSet){
                [WallPieces pentominoTAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoTOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 43:
            if(hasBeenSet){
                [WallPieces pentominoTAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoTOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 44:
            if(hasBeenSet){
                [WallPieces pentominoU:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoUOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 45:
            if(hasBeenSet){
                [WallPieces pentominoUAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoUOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 46:
            if(hasBeenSet){
                [WallPieces pentominoUAlt2:(scene)];
                pieceHeight = 2;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoUOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 47:
            if(hasBeenSet){
                [WallPieces pentominoUAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoUOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 48:
            if(hasBeenSet){
                [WallPieces pentominoV:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoVOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 49:
            if(hasBeenSet){
                [WallPieces pentominoVAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoVOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 50:
            if(hasBeenSet){
                [WallPieces pentominoVAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoVOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 51:
            if(hasBeenSet){
                [WallPieces pentominoVAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoVOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 52:
            if(hasBeenSet){
                [WallPieces pentominoW:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoWOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 53:
            if(hasBeenSet){
                [WallPieces pentominoWAlt1:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoWOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 54:
            if(hasBeenSet){
                [WallPieces pentominoWAlt2:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoWOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 55:
            if(hasBeenSet){
                [WallPieces pentominoWAlt3:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoWOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 56:
            if(hasBeenSet){
                [WallPieces pentominoX:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoXOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 57:
            if(hasBeenSet){
                [WallPieces pentominoY:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoYOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 58:
            if(hasBeenSet){
                [WallPieces pentominoYAlt1:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoYOutlineAlt1:(scene) curPos:&storedLocation];
            }
            break;
        case 59:
            if(hasBeenSet){
                [WallPieces pentominoYAlt2:(scene)];
                pieceHeight = 4;
                pieceWidth = 2;
            }
            else{
                [WallHoverPieces pentominoYOutlineAlt2:(scene) curPos:&storedLocation];
            }
            break;
        case 60:
            if(hasBeenSet){
                [WallPieces pentominoYAlt3:(scene)];
                pieceHeight = 2;
                pieceWidth = 4;
            }
            else{
                [WallHoverPieces pentominoYOutlineAlt3:(scene) curPos:&storedLocation];
            }
            break;
        case 61:
            if(hasBeenSet){
                [WallPieces pentominoZ:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoZOutline:(scene) curPos:&storedLocation];
            }
            break;
        case 62:
            if(hasBeenSet){
                [WallPieces pentominoZAlt:(scene)];
                pieceHeight = 3;
                pieceWidth = 3;
            }
            else{
                [WallHoverPieces pentominoZOutlineAlt:(scene) curPos:&storedLocation];
            }
            break;
        default:
            break;
    }
    
    //if the piece has been set, then attempt floodfill
    if(hasBeenSet){
        SKAction *placeSound = [SKAction playSoundFileNamed:@"place.wav" waitForCompletion:NO];
        [scene runAction: placeSound];
        
        [RebuildMode floodFill8:0 Y:0 newNum:9 oldNum:0];
        [RebuildMode fillCheckerBoard:scene color: color];
        [RebuildMode floodFill8:0 Y:0 newNum:0 oldNum:9];
    }
    return;
}


/* Function used to combine individual sprite pieces that were placed */
+(void)combineWalls: (GameScene *) scene sprite:(SKSpriteNode *)piece1 pos:(CGPoint)oldPosition{
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    //Initialize NESW Counters
    int north = 0;
    int east = 0;
    int south = 0;
    int west = 0;
    
    //Initialize storedLocation Points that will be modified
    CGPoint northPos = oldPosition;
    CGPoint southPos = oldPosition;
    CGPoint westPos = oldPosition;
    CGPoint eastPos = oldPosition;
    
    //Set Position to NESW
    northPos.y += tileEdge;
    southPos.y -= tileEdge;
    westPos.x -= tileEdge;
    eastPos.x += tileEdge;
    
    //Iniatilize NESW Sprites
    SKSpriteNode *northSprite = (SKSpriteNode*)[scene nodeAtPoint:northPos];
    SKSpriteNode *southSprite = (SKSpriteNode*)[scene nodeAtPoint:southPos];
    SKSpriteNode *westSprite = (SKSpriteNode*)[scene nodeAtPoint:westPos];
    SKSpriteNode *eastSprite = (SKSpriteNode*)[scene nodeAtPoint:eastPos];
    
    //If Exist a Piece in North,East,South,West and its a wall, keep check
    NSArray *nodes = [scene nodesAtPoint:northPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            northSprite = object;
            north = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:southPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            southSprite = object;
            south = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:westPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            westSprite = object;
            west = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:eastPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            eastSprite = object;
            east = 1;
            break;
        }
    }
    if(!north && !south && !west && !east){
        [self printWall:scene sprite:piece1 pos:oldPosition];
        return;
    }
    

    //If Exist a Piece in NESW
    if(north == 1 && east == 1 && west == 1 && south == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:51-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in NES
    else if(north == 1 && east == 1 && south == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:43-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
    }
    //Else if Exist a Piece in NEW
    else if(north == 1 && east == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:47-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in NSW
    else if(north == 1 && south == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:49-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
    }
    //Else if Exist a Piece in ESW
    else if(east == 1 && south == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:50-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in NS
    else if(north == 1 && south == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
    }
    //Else if Exist a Piece in NW
    else if(north == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in NE
    else if(north == 1 && east == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
    }
    //Else if Exist a Piece in ES
    else if(east == 1 && south == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
    }
    //Else if Exist a Piece in EW
    else if(east == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in SW
    else if(south == 1 && west == 1){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for South piece
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
        //Search for West Piece
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    //Else if Exist a Piece in N
    else if(north){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:37-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for North Piece
        northSprite = [self combineWalls2:scene sprite:northSprite pos:northPos];
        [self printWall:scene sprite:northSprite pos:northPos];
        
    }
    //Else if Exist a Piece in E
    else if(east){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:38-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for East Piece
        eastSprite = [self combineWalls2:scene sprite:eastSprite pos:eastPos];
        [self printWall:scene sprite:eastSprite pos:eastPos];
    }
    //Else if Exist a Piece in S
    else if(south){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:40-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for South Sprite
        southSprite = [self combineWalls2:scene sprite:southSprite pos:southPos];
        [self printWall:scene sprite:southSprite pos:southPos];
        
    }
    //Else if Exist a Piece in W
    else if(west){
        
        piece1 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:44-combineColor]];
        [self printWall:scene sprite:piece1 pos:oldPosition];
        
        //Search for West Sprite
        westSprite = [self combineWalls2:scene sprite:westSprite pos:westPos];
        [self printWall:scene sprite:westSprite pos:westPos];
        
    }
    return;
}

/* Checking the adjacent pieces for each piece place */
+(SKSpriteNode *)combineWalls2: (GameScene *) scene sprite:(SKSpriteNode *)piece2 pos:(CGPoint)oldPosition{
    NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
    //Initialize NESW Counters
    int north = 0;
    int east = 0;
    int south = 0;
    int west = 0;
    
    //Initialize storedLocation Points that will be modified
    CGPoint northPos = oldPosition;
    CGPoint southPos = oldPosition;
    CGPoint westPos = oldPosition;
    CGPoint eastPos = oldPosition;
    
    //Set position to NESW
    northPos.y += tileEdge;
    southPos.y -= tileEdge;
    westPos.x -= tileEdge;
    eastPos.x += tileEdge;
    
    //If Exist a Piece in North,East,South,West and its a wall, keep check
    NSArray *nodes = [scene nodesAtPoint:northPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            north = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:southPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            south = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:westPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            west = 1;
            break;
        }
    }
    
    nodes = [scene nodesAtPoint:eastPos];
    for (SKSpriteNode *object in nodes) {
        if([object.name isEqual: @"wall"] ) {
            east = 1;
            break;
        }
    }

    //if Exist a Piece in NESW
    if(north == 1 && east == 1 && west == 1 && south == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:51-combineColor]];
        
    }
    //Else if Exist a Piece in NES
    else if(north == 1 && east == 1 && south == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:43-combineColor]];
        
    }
    //Else if Exist a Piece in NEW
    else if(north == 1 && east == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:47-combineColor]];
        
    }
    //Else if Exist a Piece in NSW
    else if(north == 1 && south == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:49-combineColor]];
    }
    //Else if Exist a Piece in ESW
    else if(east == 1 && south == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:50-combineColor]];
        
    }
    //Else if Exist a Piece in NS
    else if(north == 1 && south == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:41-combineColor]];
        
    }
    //Else if Exist a Piece in NW
    else if(north == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:45-combineColor]];
        
    }
    //Else if Exist a Piece in NE
    else if(north == 1 && east == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:39-combineColor]];
    }
    //Else if Exist a Piece in ES
    else if(east == 1 && south == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:42-combineColor]];
        
    }
    //Else if Exist a Piece in EW
    else if(east == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:46-combineColor]];
        
    }
    //Else if Exist a Piece in SW
    else if(south == 1 && west == 1){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:48-combineColor]];
        
    }
    //Else if Exist a Piece in N
    else if(north){
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:37-combineColor]];
        
        
    }
    //Else if Exist a Piece in E
    else if(east){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:38-combineColor]];
        
    }
    //Else if Exist a Piece in S
    else if(south){
        
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:40-combineColor]];
        
    }
    //Else if Exist a Piece in W
    else if(west){
        piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:44-combineColor]];
    }
    
    return(piece2);
    
}

/* Used for calculating which rotation piece to switch to */
+(int)rotate: (int *) piece{
    
    //domino
    if( (*(piece) == 1) || (*(piece) == 2)){
        if(*(piece) == 2){
            (*(piece)) = 1;
        }
        else{
            (*(piece)) = 2;
        }
    }
    
    //trominoL
    else if( (*(piece) >= 3) && (*(piece) <= 6)){
        if(*(piece) == 6){
            (*(piece)) = 3;
        }
        else{
            (*(piece))++;
        }
        
    }
    //trominoI
    else if( (*(piece) == 7) || (*(piece) == 8)){
        if(*(piece) == 7){
            *(piece) = 8;
        }
        else{
            (*(piece)) = 7;
        }
    }
    //tetrominoZ
    else if( (*(piece) == 9) || (*(piece) == 10)){
        if(*(piece) == 9){
            (*(piece)) = 10;
        }
        else{
            (*(piece)) = 9;
        }
        
    }
    //tetrominoI
    else if( ((*(piece)) == 11) || ((*(piece)) == 12)){
        if((*(piece)) == 11){
            (*(piece)) = 12;
        }
        else{
            (*(piece)) = 11;
        }
        
    }
    //tetrominoT
    else if( ((*(piece)) >= 14) && ((*(piece)) <= 17)){
        if((*(piece)) == 17){
            (*(piece)) = 14;
        }
        else{
            (*(piece))++;
        }
        
    }
    //tetrominoL
    else if( ((*(piece)) >= 18) && ((*(piece)) <= 21)){
        if((*(piece)) == 21){
            (*(piece)) = 18;
        }
        else{
            (*(piece))++;
        }
        
    }
    //pentominoF
    else if( ((*(piece)) >= 22) && ((*(piece)) <= 25)){
        if((*(piece)) == 25){
            (*(piece)) = 22;
        }
        else{
            (*(piece))++;
        }
        
    }
    //pentominoI
    else if( ((*(piece)) == 26) || ((*(piece)) == 27)){
        if((*(piece)) == 26){
            (*(piece)) = 27;
        }
        else{
            (*(piece)) = 26;
        }
    }
    //pentominoL
    else if( ((*(piece)) >= 28) && ((*(piece)) <= 31)){
        if((*(piece)) == 31){
            (*(piece)) = 28;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoN
    else if( ((*(piece)) >= 32) && ((*(piece)) <= 35)){
        if((*(piece)) == 35){
            (*(piece)) = 32;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoP
    else if( ((*(piece)) >= 36) && ((*(piece)) <= 39)){
        if((*(piece)) == 39){
            (*(piece)) = 36;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoT
    else if( ((*(piece)) >= 40) && ((*(piece)) <= 43)){
        if((*(piece)) == 43){
            (*(piece)) = 40;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoU
    else if( ((*(piece)) >= 44) && ((*(piece)) <= 47)){
        if((*(piece)) == 47){
            (*(piece)) = 44;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoV
    else if( ((*(piece)) >= 48) && ((*(piece)) <= 51)){
        if((*(piece)) == 51){
            (*(piece)) = 48;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoW
    else if( ((*(piece)) >= 52) && ((*(piece)) <= 55)){
        if((*(piece)) == 55){
            (*(piece)) = 52;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoY
    else if( ((*(piece)) >= 57) && ((*(piece)) <= 60)){
        if((*(piece)) == 60){
            (*(piece)) = 57;
        }
        else{
            (*(piece))++;
        }
    }
    //pentominoZ
    else if( ((*(piece)) == 61) || ((*(piece)) == 62)){
        if((*(piece)) == 61){
            (*(piece)) = 62;
        }
        else{
            (*(piece)) = 61;
        }
    }
    return((*(piece)));
}


/* Used to print each wall piece */
+(void)printWall: (GameScene *) scene sprite:(SKSpriteNode *)piece pos:(CGPoint)location{
    
    [GameScene mapTilesY:26 - round(location.y/24) X:round(location.x/24) - 1 value:1];
    fillArr[(NSInteger)(26 - round(location.y/24))][(NSInteger)round(location.x/24) - 1] = 1;
    piece.position = location;
    piece.scale = tileScale;
    piece.name = @"wall";
    piece.zPosition = 2;
    [scene addChild:piece];
    
}

/* Filling the checkerboard with a specific player color */
+(void)fillCheckerBoard: (GameScene*) scene color:(int)playerColor{
    NSMutableArray *wallArr = [GameScene fillTileSet:@"2DWalls copy"];
    NSMutableArray *castleArr = [GameScene fillTileSet:@"2DCastleCannon copy"];
    

    if(playerColor == player){
        //Reset CannonAmount
        cannonAmount = 0;
    }
    else{
        //Reset aiCannonAmount
        aiCannonAmount = 0;
    }

    
    //Main Color to place
    int fillColor = 0;
    //Main Castle Color
    int castle = 0;
    //Main Color GroundHighlight
    NSString *charGroundHighLight;
    if(playerColor == player){
        charGroundHighLight = @"playerGroundHighLight";
    }
    else{
        charGroundHighLight = @"aiGroundHighLight";
    }
    
    switch(playerColor){
        case 2:
            fillColor = 2; //Yellow Color
            castle = 28; //Yellow Castle
            cName = 'Y';
            break;
        case 3:
            fillColor = 3; //Red Color
            castle = 29; //Red Castle
            cName = 'R';
            break;
        case 4:
            fillColor = 4; //Blue Color
            castle = 30; //Blue Castle
            cName = 'B';
            break;
    }

    
    // loop through mapTiles to check for 0s (probably needs to be changed to something non zero)
    for (int i = 0; i < 26; i++) {
        for (int j = 0; j < 42; j++) {

            if( (fillArr[i][j] == 0 && mapArray[i][j] == cName) || (fillArr[i][j] == playerColor && mapArray[i][j] == cName) ){
                
                // change checkerboard tile to 2
                //Yellow - 2
                //Red - 3
                //Blue - 4
                mapTiles[i][j] = fillColor;
                fillArr[i][j] = fillColor;
                
                // if even tile
                if (((i + j) % 2 == 0)) {
                    // convert array coordinates back to view coordinates
                    CGPoint tilePos = CGPointMake((j + 1) * 24, 24 * (26 - i-1));
                    // get the node at the calculated view position
                    // since we rounded view coordinates to begin with, we need to get the exact location at the node
                    // also need to account for castle node that is overlayed on top of grass nodes
                    NSArray *nodes = [scene nodesAtPoint:tilePos];
                    SKSpriteNode *spriteTouched;
                    for (SKSpriteNode *object in nodes) {
                        // if grass node assign object to spriteTouched so we can get its position
                        if([object.name isEqual: @"grass"]) {
                            spriteTouched = object;
                        }
                        else if([object.name isEqual: @"castle"] || [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]) {
                            
                            //Castle found with player color, name the castle
                            if(playerColor == player){
                                object.name = @"playerCastle";
                            }
                            //Castle found with aiPlayer Color
                            else if(playerColor == aiColor){
                                object.name = @"aiCastle";
                            }
                            
                            // make castle a color
                            object.texture = [castleArr objectAtIndex:castle];
                            
                        }
                    }
                    //Place color checkerboard sprite
                    SKSpriteNode * sprite = [SKSpriteNode spriteNodeWithTexture:[wallArr objectAtIndex:fillColor - 2]];
                    CGPoint posAdjust = spriteTouched.position;
                    // to adjust for x being 1 off in mapTiles array
                    posAdjust.x -= tileEdge;
                    sprite.position = posAdjust;
                    sprite.scale = tileScale;
                    sprite.zPosition = 1;
                    sprite.name = charGroundHighLight;
                    [scene addChild:sprite];
                }
                else if (((i + j) % 2 == 1)) {  // else if odd tile
                    // convert array coordinates back to view coordinates
                    CGPoint tilePos = CGPointMake((j + 1) * 24, 24 * (26 - i-1));
                    // get the node at the calculated view position
                    // since we rounded view coordinates to begin with, we need to get the exact location at the node
                    // also need to account for castle node that is overlayed on top of grass nodes
                    NSArray *nodes = [scene nodesAtPoint:tilePos];
                    SKSpriteNode *spriteTouched;
                    for (SKSpriteNode *object in nodes) {
                        // if grass node assign object to spriteTouched so we can get its position
                        if([object.name isEqual: @"grass"]) {
                            spriteTouched = object;
                        }
                        else if([object.name isEqual: @"castle"] || [object.name isEqual: @"aiCastle"] || [object.name isEqual: @"playerCastle"]) {
                            
                            //Castle found with player color, set castle name
                            if(playerColor == player){
                                object.name = @"playerCastle";
                            }
                            //Castle found with aiPlayer Color
                            else if(playerColor == aiColor){
                                object.name = @"aiCastle";
                            }

                            // make castle a color
                            object.texture = [castleArr objectAtIndex:castle];
                            
                        }
                    }
                    //Place out black checkerboard sprite
                    SKSpriteNode * sprite = [SKSpriteNode spriteNodeWithTexture:[wallArr objectAtIndex:3]];
                    CGPoint posAdjust = spriteTouched.position;
                    // to adjust for x being 1 off in mapTiles array
                    posAdjust.x -= tileEdge;
                    sprite.position = posAdjust;
                    sprite.scale = tileScale;
                    sprite.zPosition = 1;
                    sprite.name = charGroundHighLight;
                    [scene addChild:sprite];
                }
            }
        }
    }
}


/* 
 floodfill that checks 8 directions
 TODO: modify floodFill8 to clear checkerboard 2s when transitioning from battlemode to rebuild mode
*/
+(void)floodFill8:(NSInteger)x Y:(NSInteger)y newNum:(NSInteger)num1 oldNum:(NSInteger)num2 {
    if(x >= 0 && x < 42 && y >= 0 && y < 26 && fillArr[y][x] == num2 && fillArr[y][x] != num1) {
        
            fillArr[y][x] = num1;
            [RebuildMode floodFill8:x+1 Y:y   newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x-1 Y:y   newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x   Y:y+1 newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x   Y:y-1 newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x+1 Y:y+1 newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x-1 Y:y-1 newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x-1 Y:y+1 newNum:num1 oldNum:num2];
            [RebuildMode floodFill8:x+1 Y:y-1 newNum:num1 oldNum:num2];
    }
}

+(void)floodFill8Clear:(NSInteger)x Y:(NSInteger)y newNum:(NSInteger)num1 oldNum:(NSInteger)num2 {
    if(x >= 0 && x < 42 && y >= 0 && y < 26 && fillArr[y][x] != 1 && fillArr[y][x] != num1 && fillArr[y][x] < 5) {
        
        if(mapTiles[y][x] < 5){
            mapTiles[y][x] = num1;
        }
        fillArr[y][x] = num1;
        
        [RebuildMode floodFill8Clear:x+1 Y:y   newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x-1 Y:y   newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x   Y:y+1 newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x   Y:y-1 newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x+1 Y:y+1 newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x-1 Y:y-1 newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x-1 Y:y+1 newNum:num1 oldNum:num2];
        [RebuildMode floodFill8Clear:x+1 Y:y-1 newNum:num1 oldNum:num2];
    }
}

/* Transfering Only Wall data to FillArray */
+(void)makeFillArr {
    for(int i = 0; i < 26; i++) {
        for(int j = 0; j < 42; j++) {
            if(mapTiles[i][j] >=5) {
                fillArr[i][j] = 0;
            }
            else {
                fillArr[i][j] = mapTiles[i][j];
            }
        }
    }
}

+(void)setCombineColor: (int) color{
    if(color == 2){
        //Set Color to Yellow
        combineColor = 32;
    }
    else if(color == 3){
        //Set Color to Red
        combineColor = 16;
    }
    else if(color == 4){
        //Set color to Blue
        combineColor = 0;
    }
}

@end
