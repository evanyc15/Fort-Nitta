/*
 *  WallPiecesAI.m
 *  FortNitta
 *  ECS160 OSX Team
 *  Copyright (c) 2015 OSX Team. All rights reserved.
 */


#import "GameScene.h"
#import "RebuildModeAI.h"
#import "WallPiecesAI.h"
#import <Foundation/Foundation.h>

#define tileEdge 24
#define tileScale 2

@implementation WallPiecesAI
// Blue starts at 48
//Red Starts at 32 , so color = 62
//Yello Starts at 16, so color = 78

int aiMainColor = 0;

//Used to store the color char
char aiColorName;

+(void)setAiColor: (int) color{
    if(color == 2){
        //Set Color to Yellow
        aiMainColor = 80;
        aiColorName = 'Y';
    }
    else if(color == 3){
        //Set Color to Red
        aiMainColor = 64;
        aiColorName = 'R';
    }
    else if(color == 4){
        //Set color to Blue
        aiMainColor = 48;
        aiColorName = 'B';
    }
}




+(Boolean)ifPlaceable: (GameScene *)scene pos: (CGPoint)location{
    
    NSArray *nodes = [scene nodesAtPoint:location];
    for (SKSpriteNode *object in nodes) {
        // cursor is always touching cannonHover so below is to ignore cannonHover node
        if([object.name isEqual: @"castle"] || [object.name isEqual: @"cannon"]){
            return false;
            break;
        }
    }
    return true;
}


/*
 Creating individual sprite nodes to create each piece
 Since hover pieces started at 84, a certain # to get individual colors
 
 */

/*  ___
 |__|
 */
+(void)monomino: (GameScene *) scene {
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && [self ifPlaceable:scene pos: oldCursorPosition] &&
       mapArray[yPosArr][xPosArr] == aiColorName){
        NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
        aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:84 - aiMainColor]];
        [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
        
        aiWallEncounter = false;
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ___
 |  |
 |__|
 */
+(void)domino: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode * piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
        
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)dominoAlt: (GameScene *) scene {
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName){
        
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ___
 | |__
 |____|
 */
+(void)trominoL: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName) {
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)trominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y -= tileEdge;
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)trominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr - 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)trominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ___
 |  |
 |  |
 |__|
 */
+(void)trominoI: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)trominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ___
 |  |__
 |__   |
 |__|
 */
+(void)tetrominoZ: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
        
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoZAlt: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr - 1] == aiColorName && mapArray[yPosArr + 1][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}

/*  ___
 |  |
 |  |
 |  |
 |__|
 */
+(void)tetrominoI: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr] == aiColorName && mapArray[yPosArr + 3][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr][xPosArr + 2] == aiColorName && mapArray[yPosArr][xPosArr + 3] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ____
 |   |
 |___|
 */
+(void)tetrominoCube: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ________
 |__  __|
 |__|
 */
+(void)tetrominoT: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoTAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // left piece sticking out
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoTAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // left bottom piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoTAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr - 1] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // right piece sticking out
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  __
 | |
 | |_
 |___|
 */
+(void)tetrominoL: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}

+(void)tetrominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= (2 * tileEdge);
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)tetrominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapArray[yPosArr][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr][xPosArr + 2] == aiColorName && mapArray[yPosArr - 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*    ____
 __|  _|
 |__ |
 |_|
 */
+(void)pentominoF: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr - 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoFAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += (2 * tileEdge);
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // left middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoFAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr - 1] == aiColorName) {
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoFAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName) {
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle center piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ___
 |  |
 |  |
 |  |
 |  |
 |__|
 */
+(void)pentominoI: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 4][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 3][xPosArr] == aiColorName && mapArray[yPosArr + 4][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // 2nd middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // 3rd middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // 4th middle piece piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoIAlt: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr][xPosArr + 4] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr][xPosArr + 3] == aiColorName && mapArray[yPosArr][xPosArr + 4] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  __
 | |
 | |
 | |_
 |___|
 */
+(void)pentominoL: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 3][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 3][xPosArr] == aiColorName && mapArray[yPosArr + 3][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoLAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= (3 * tileEdge);
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr][xPosArr + 3] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoLAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 3][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoLAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr][xPosArr + 3] == aiColorName && mapArray[yPosArr - 1][xPosArr + 3] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            
            // left bottom piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // right bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*     __
 | |
 __| |
 | __|
 |_|
 */
+(void)pentominoN: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y += tileEdge;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr - 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == aiColorName && mapArray[yPosArr - 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            
            // top piece of left column
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom piece of left column
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece of right column
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            //  middle piece of right column
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // top piece of right column
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoNAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr + 3] == aiColorName) {
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            //  bottom middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoNAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 3][xPosArr - 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoNAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 3] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr + 3] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  ____
 |   |
 | __|
 |_|
 */
+(void)pentominoP: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // extra piece sticking out of cube
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoPAlt1: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoPAlt2: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            
            // top piece sticking out
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoPAlt3: (GameScene *) scene{
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // piece sticking out
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  _______
 |__  __|
 |  |
 |__|
 */
+(void)pentominoT: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoTAlt1: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoTAlt2: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += (2 * tileEdge);
    
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoTAlt3: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    piece4Location.y += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*  __    __
 | |__| |
 |______|
 */
+(void)pentominoU: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += (2 * tileEdge);
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= (2 * tileEdge);
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 1][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 2] == aiColorName && mapArray[yPosArr + 1][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // left bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoUAlt1: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr - 1] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoUAlt2: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr - 1][xPosArr] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 1] == 0 && mapTiles[yPosArr - 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr] == aiColorName && mapArray[yPosArr - 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 2] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoUAlt3: (GameScene *) scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*
 __
 | |
 | |___
 |_____|
 */
+(void)pentominoV:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoVAlt1:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr][xPosArr - 2] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr - 1] == aiColorName && mapArray[yPosArr][xPosArr - 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == aiColorName && mapArray[yPosArr + 2][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoVAlt2:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 2][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoVAlt3:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 2][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom middle piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*
 ____
 |  |__
 |___  |__
 |_____|
 
 */
+(void)pentominoW:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            //middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle step piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // right bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoWAlt1:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr - 1] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == aiColorName && mapArray[yPosArr + 2][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoWAlt2:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 1][xPosArr + 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 2] == aiColorName && mapArray[yPosArr + 2][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoWAlt3:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 2][xPosArr - 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr - 1] == aiColorName && mapArray[yPosArr + 2][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*
 ___
 __|  |__
 |__   __|
 |__|
 */
+(void)pentominoX:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    piece2Location.y += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr - 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr + 1][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr - 1][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:99 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            //Middle Piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*
 __
 | |
 | |_
 |  _|
 |_|
 
 */
+(void)pentominoY:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 3][xPosArr] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 3][xPosArr] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:91 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoYAlt1:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= (2 * tileEdge);
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr][xPosArr + 3] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:98 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoYAlt2:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y += (2 * tileEdge);
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 2][xPosArr] == 0 && mapTiles[yPosArr + 3][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 2][xPosArr] == aiColorName &&
       mapArray[yPosArr + 3][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:97 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // line-going-down pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoYAlt3:(GameScene *)scene {
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x += tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x += tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x -= tileEdge;
    piece5Location.y += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr][xPosArr + 2] == 0 && mapTiles[yPosArr][xPosArr + 3] == 0 &&
       mapTiles[yPosArr - 1][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr][xPosArr + 2] == aiColorName &&
       mapArray[yPosArr][xPosArr + 3] == aiColorName && mapArray[yPosArr - 1][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:95 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // bottom middle pieces
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom right
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // piece sticking out on top
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


/*
 ____
 |__ |
 | |__
 |____|
 
 */
+(void)pentominoZ:(GameScene *)scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.x += tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.y -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.y -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.x += tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 1][xPosArr + 1] == 0 && mapTiles[yPosArr + 2][xPosArr + 1] == 0 &&
       mapTiles[yPosArr + 2][xPosArr + 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr][xPosArr + 1] == aiColorName && mapArray[yPosArr + 1][xPosArr + 1] == aiColorName &&
       mapArray[yPosArr + 2][xPosArr + 1] == aiColorName && mapArray[yPosArr + 2][xPosArr + 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:86 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:96 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:89 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:87 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:92 - aiMainColor]];
            
            // top left piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // top right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // bottom left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom right piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}


+(void)pentominoZAlt:(GameScene *)scene{
    
    NSInteger xPosArr = round(oldCursorPosition.x / 24) - 1;
    NSInteger yPosArr = 26 - round(oldCursorPosition.y/24);
    
    //Initialize CGPoints for castle/cannon check
    CGPoint piece2Location = oldCursorPosition;
    piece2Location.y -= tileEdge;
    CGPoint piece3Location = piece2Location;
    piece3Location.x -= tileEdge;
    CGPoint piece4Location = piece3Location;
    piece4Location.x -= tileEdge;
    CGPoint piece5Location = piece4Location;
    piece5Location.y -= tileEdge;
    
    if(mapTiles[yPosArr][xPosArr] == 0 && mapTiles[yPosArr + 1][xPosArr] == 0 &&
       mapTiles[yPosArr + 1][xPosArr - 1] == 0 && mapTiles[yPosArr + 1][xPosArr - 2] == 0 &&
       mapTiles[yPosArr + 2][xPosArr - 2] == 0 && mapArray[yPosArr][xPosArr] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr] == aiColorName && mapArray[yPosArr + 1][xPosArr - 1] == aiColorName &&
       mapArray[yPosArr + 1][xPosArr - 2] == aiColorName && mapArray[yPosArr + 2][xPosArr - 2] == aiColorName){
        
        if([self ifPlaceable:scene pos:oldCursorPosition] && [self ifPlaceable:scene pos:piece2Location] && [self ifPlaceable:scene pos:piece3Location] && [self ifPlaceable:scene pos:piece4Location] && [self ifPlaceable:scene pos:piece5Location]){
            
            NSMutableArray * tileWallArray = [GameScene fillTileSet:@"2DWalls copy"];
            aiRefWallPiece = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:88 - aiMainColor]];
            SKSpriteNode *piece2 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:93 - aiMainColor]];
            SKSpriteNode *piece3 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:94 - aiMainColor]];
            SKSpriteNode *piece4 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:90 - aiMainColor]];
            SKSpriteNode *piece5 = [SKSpriteNode spriteNodeWithTexture:[tileWallArray objectAtIndex:85 - aiMainColor]];
            // top piece
            [RebuildModeAI combineWalls:scene sprite:aiRefWallPiece pos:oldCursorPosition];
            
            // middle right piece
            [RebuildModeAI combineWalls:scene sprite:piece2 pos:piece2Location];
            
            // middle piece
            [RebuildModeAI combineWalls:scene sprite:piece3 pos:piece3Location];
            
            // middle left piece
            [RebuildModeAI combineWalls:scene sprite:piece4 pos:piece4Location];
            
            // bottom piece
            [RebuildModeAI combineWalls:scene sprite:piece5 pos:piece5Location];
            aiWallEncounter = false;
        }
        else{
            aiWallEncounter = true;
        }
    }
    else{
        aiWallEncounter = true;
    }
}



@end
