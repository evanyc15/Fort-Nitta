iOS:

Find FortNitta.xcodeproj file inside Source folder to run game