//
//  Grid.m
//  FortNitta
//
//  Created by Raul Cano
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#import "Grid.h"


@implementation gridNode



-(void)setNodeForTestingDFSX:(gridNode *)node :(char)newDFSX {
    node->testingDFSX = newDFSX;

}


-(char)getNodeForTestingDFSX:(gridNode *)node {
    return node->testingDFSX;

}






-(char)getNodeBRWater:(gridNode *)node {
    return node->bRWater;
}

-(void)setNodeBRWater:(gridNode *)node :(char)newBRWater {
    node->bRWater = newBRWater;
}


-(void)setNodeIsWall:(gridNode *)node {
    node->wall = 1;
}


-(bool)getNodeIsWall:(gridNode *)node {
    
    if(node->wall == 1)
        return 1;
    else
        return 0;

}





-(void)setNodeIsCastle:(gridNode *)node {
    node->castle = 1;
}


-(bool)getNodeIsCastle:(gridNode *)node {

    if(node->castle == 1)
        return 1;
    else
        return 0;

}






-(void)setNodeIsGrass:(gridNode *)node {
    node->grass = 1;
}


-(bool)getNodeIsGrass:(gridNode *)node {

    if(node->grass == 1)
        return 1;
    else
        return 0;

}






-(void)setNodeIsVisited:(gridNode *)node {
    node->visited = 1;
}


-(bool)getNodeIsVisited:(gridNode *)node {

    if(node->visited == 1)
        return 1;
    else
        return 0;
    
}



-(void)setNodeCheckeredFloor:(gridNode *)node {
    node->checkeredFloor = 1;
}


-(bool)getNodeCheckeredFloor:(gridNode *)node {

    if(node->checkeredFloor == 1)
        return 1;
    else
        return 0;

}





-(void)resetNodeIsVisited:(gridNode *)node {
    node->visited = 0;
}




@end

