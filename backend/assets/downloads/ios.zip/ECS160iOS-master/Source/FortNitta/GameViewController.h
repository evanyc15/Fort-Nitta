//
//  GameViewController.h
//  FortNitta
//

//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import "MainMenu.h"
#import "GameScene.h"
#import "MapSelect.h"
#import "GameSelection.h"
#import "SoundOptions.h"

@interface GameViewController : UIViewController{
    IBOutlet UIButton *exampleButtonDrag;
    SKView *skView;
    MainMenu *MainMenuObj;
    SoundOptions *SoundOptionsObj;
}
@end
