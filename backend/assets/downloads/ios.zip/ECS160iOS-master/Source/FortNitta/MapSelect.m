#import "MapSelect.h"
#import "AudioToolbox/MusicPlayer.h"
#import <Foundation/Foundation.h>
#include <stdlib.h>

@implementation MapSelect

@synthesize MainMenuObj;
@synthesize GameSelectionObj;

-(void)didMoveToView:(SKView *)view{}

-(MapSelect *)initWithSize:(CGSize)size{
    if (self = [super initWithSize:size]) {
        asciiBlackImages = [self extractRectangleTiles:@"FontKingthingsBlack" NumberOfTiles:95];
        asciiWhiteImages = [self extractRectangleTiles:@"FontKingthingsWhite" NumberOfTiles:95];
        fontCharDim = ((SKTexture*)[asciiBlackImages objectAtIndex:1]).size;
        [self CreateMenuText];
        [self SetBrickBackground];
    }
    return self;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint touchLocation = [touch locationInNode:self.scene];
    pointTouched = touchLocation;
    
    SKSpriteNode *nodeTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    NSMutableArray *textImages;
    int imageIndex;
    
    if ([nodeTouched.name isEqual: @"BackButton"]) {
        textImages = BackImages;
    }
    else if ([nodeTouched.name isEqual: @"ContinueButton"]) {
        textImages = ContinueImages;
    }
    
    for (SKSpriteNode *charImage in textImages) {
        imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }
    
}

-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    //UITouch *touch = [touches anyObject];
    //CGPoint touchLocation = [touch locationInNode:self.scene];
    
    //SKScene *scene;
    
    SKSpriteNode *nodeTouched = (SKSpriteNode*)[self nodeAtPoint:pointTouched];
    NSMutableArray *textImages;
    int imageIndex;
    
    if ([nodeTouched.name isEqual: @"BackButton"]) {
        // code for single player
        // FIXME: need to add back button funtionality
        //SKViewFortNitta *currentView = self.view;
        [self.view presentScene:MainMenuObj];
        textImages = BackImages;
    }
    else if ([nodeTouched.name isEqual: @"ContinueButton"]) {
        // code for multiplayer
        [self.view presentScene:GameSelectionObj];
        textImages = ContinueImages;
    }
    
    for (SKSpriteNode *charImage in textImages) {
        imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
    }
}


// DS,AM (3/1/15): creates menu options using images
-(void)CreateMenuText {
    // AM (3/1/15): point calculation (origin is top left):
    //              x = (half of scene width) - (half the size of the message * width of each character image according to scene dimmension)
    //              y = height from top
    CGPoint titlePoint = CGPointMake((self.frame.size.width/2) - (5*(self.frame.size.width/fontCharDim.width)), self.frame.size.height-(fontCharDim.height));
    // TODO: these CGpoints need to be changed
    CGPoint NorthSouthPoint = CGPointMake((self.frame.size.width/2) - (11*(self.frame.size.width/fontCharDim.width)), titlePoint.y - fontCharDim.height*3);
    CGPoint TwoPlayersPoint = CGPointMake((self.frame.size.width) - (7*(self.frame.size.width/fontCharDim.width)), NorthSouthPoint.y - fontCharDim.height*3);
    CGPoint MapDimensionsPoint = CGPointMake((self.frame.size.width) - (6*(self.frame.size.width/fontCharDim.width)), TwoPlayersPoint.y - fontCharDim.height);
    CGPoint BackPoint = CGPointMake((self.frame.size.width/2) - (11*(self.frame.size.width/fontCharDim.width)), 2*fontCharDim.height);
    CGPoint ContinuePoint = CGPointMake((self.frame.size.width) - (6*(self.frame.size.width/fontCharDim.width)), 2*fontCharDim.height);

    
    TitleImage = [self MakeTextImages:@"SELECT MAP" AtPoint:titlePoint];
    NorthSouthImages = [self MakeTextImages:@"NORTH-SOUTH" AtPoint:NorthSouthPoint];
    TwoPlayersImages = [self MakeTextImages:@"2 PLAYERS" AtPoint:TwoPlayersPoint];
    MapDimensionsImages = [self MakeTextImages:@"40 x 24" AtPoint:MapDimensionsPoint];
    BackImages = [self MakeTextImages:@"BACK" AtPoint:BackPoint];
    ContinueImages = [self MakeTextImages:@"CONTINUE" AtPoint:ContinuePoint];
    
    // initializing buttons
    BackButton = [SKSpriteNode spriteNodeWithColor: [UIColor clearColor] size: CGSizeMake(3*fontCharDim.width, 1.5*fontCharDim.height)];
    BackButton.position = CGPointMake(BackPoint.x + 0.5*(fontCharDim.width), BackPoint.y);
    BackButton.name = @"BackButton";
    BackButton.zPosition = 8;

    ContinueButton = [SKSpriteNode spriteNodeWithColor: [UIColor clearColor] size: CGSizeMake(6*fontCharDim.width, 1.5*fontCharDim.height)];
    ContinueButton.position = CGPointMake(ContinuePoint.x + 2*(fontCharDim.width), ContinuePoint.y);
    ContinueButton.name = @"ContinueButton";
    ContinueButton.zPosition = 8;
    
    [self addChild:BackButton];
    [self addChild:ContinueButton];
}

-(NSMutableArray*)MakeTextImages:(NSString *)textStr AtPoint:(CGPoint) startPos {
    
    NSMutableArray* textImages = [[NSMutableArray alloc] init];
    NSMutableArray* asciiImages;
    
    if ([textStr isEqual: @"BACK"] || [textStr isEqual: @"CONTINUE"]) {
        asciiImages = asciiBlackImages;
    }
    else {
        asciiImages = asciiWhiteImages;
    }
    
    // offset is 126 - char to get proper char image
    int xincrement = 30; // space between characters
    int xpos = startPos.x;
    for ( int charCount = 0; charCount < textStr.length; charCount++) {
        int imageInd = 126 - [textStr characterAtIndex:charCount];
        SKSpriteNode* character = [SKSpriteNode spriteNodeWithTexture:[asciiImages objectAtIndex:imageInd]];
        character.zPosition = 7;
        character.position = CGPointMake(xpos, startPos.y);
        // assign name to identify charater
        character.name = [textStr substringWithRange: NSMakeRange(charCount, 1)];
        [textImages addObject:character];
        xpos += xincrement;
        if ([textStr isEqual: @"SELECT MAP"]) {
            character.scale = MAP_SCALE;
        }
        else {
            xpos -= 15;
        }
    }
    
    for (SKSpriteNode* image in textImages) {
        //        image.speed = 1;
        [self addChild:image];
    }
    
    return textImages;
}

// DS,AM (2/7/15): Function to extract rectangular tile from passed in tileset (.png file) (modified version of function above)
-(NSMutableArray *)extractRectangleTiles:(NSString *)fileName  NumberOfTiles:(NSInteger)numTiles{
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:fileName];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate tile height
    //NSInteger TileHeight = ImageTexture.size.height / numTiles;
    NSMutableArray *TileArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array
    for (int i = 0; i < numTiles; i++) {
        [TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:ImageTexture]];
    }
    
    return TileArray;
}

-(void) SetBrickBackground {
    [self extractBrickTiles];
    /*SKSpriteNode* testBrick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:1]];
     testBrick.position = CGPointMake(100, 100);
     testBrick.scale = MAP_SCALE;
     [self addChild:testBrick];*/
    for (int i = 0; i < self.frame.size.height; i += (self.frame.size.height/((SKTexture *)[brickTiles objectAtIndex:0]).size.height) / 2.5) {
        for (int j = 0; j < self.frame.size.width; j += self.frame.size.width/((SKTexture *)[brickTiles objectAtIndex:0]).size.width) {
            SKSpriteNode* brick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:0]];
            brick.position = CGPointMake(j, i);
            brick.scale = MAP_SCALE;
            [self addChild:brick];
        }
    }
}

// NOTE: cannot use other extract methods since brick tiles have different dimmensions
-(void) extractBrickTiles {
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:@"Bricks"];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // 9 brick tiles
    brickTiles = [NSMutableArray arrayWithCapacity:9];
    
    // put each tile from tileset into array
    
    /*[TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
     inTexture:ImageTexture]];*/
    
    // NOTE: all CGRectMake values are in percent
    //       CGRectMake(x position from left, y position from left, width in respect to whole image, height in respect to whole image)
    
    //NOTE: bottom of png has white space, so starting at 4/132%
    //brick 1
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)4/132, 1, (float)8/132)
                                           inTexture:ImageTexture]];
    
    //brick 2 (top left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)12/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 3 (left piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)24/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    //brick 4 (bottom left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)48/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 5 (bottom piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)60/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 6 (bottom right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)72/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 7 (right piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0.5, (float)84/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 8 (top right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)108/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 9 (top piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)120/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
}


@end