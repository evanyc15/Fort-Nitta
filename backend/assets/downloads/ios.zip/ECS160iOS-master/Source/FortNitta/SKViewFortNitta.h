/*#import <SpriteKit/SpriteKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import "MainMenu.h"
#import "GameScene.h"
#import "MapSelect.h"
#import "GameSelection.h"

@interface SKViewFortNitta : SKView{
    
}
@property MainMenu *MainMenuObj;
@property GameScene *GameSceneObj;
@property MapSelect *MapSelectObj;
@property GameSelection *GameSelectionObj;
@end*/