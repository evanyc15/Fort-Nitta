#import "GameSelection.h"
#import "AudioToolbox/MusicPlayer.h"
#import <Foundation/Foundation.h>
#include <stdlib.h>

@implementation GameSelection

@synthesize MapSelectObj;
@synthesize GameSceneObj;

-(void)didMoveToView:(SKView *)view{}

-(GameSelection *)initWithSize:(CGSize)size{
    if (self = [super initWithSize:size]) {
        asciiBlackImages = [self extractRectangleTiles:@"FontKingthingsBlack" NumberOfTiles:95];
        asciiWhiteImages = [self extractRectangleTiles:@"FontKingthingsWhite" NumberOfTiles:95];
        fontCharDim = ((SKTexture*)[asciiBlackImages objectAtIndex:1]).size;
        [self CreateMenuText];
        [self SetBrickBackground];
        GameSceneObj.WindType = 0;
        GameSceneObj.PlayerColor = 0;
        GameSceneObj.AIDifficulty = 0;
    }
    return self;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint touchLocation = [touch locationInNode:self.scene];
    pointTouched = touchLocation;
    
    SKSpriteNode *nodeTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    // arrays to store character images for both labels on one line (e.g. wind type, none)
    NSMutableArray *textImagesW1;
    NSMutableArray *textImagesW2;
    // arrays for labels not selected (will change to black)
    NSMutableArray *textImagesB1;
    NSMutableArray *textImagesB2;
    NSMutableArray *textImagesB3;
    NSMutableArray *textImagesB4;
    
    if ([nodeTouched.name isEqual: @"BackButton"]) {
        textImagesW1 = BackImages;
        // TODO: handle/initialize textImages2
    }
    else if ([nodeTouched.name isEqual: @"ContinueButton"]) {
        textImagesW1 = ContinueImages;
        // TODO: handle/initialize textImages2
    }
    else if ([nodeTouched.name isEqual: @"WindTypePlusButton"]) {
        WindTypePlusButton.texture = [asciiWhiteImages objectAtIndex:83];
        WindTypeMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        PlayerColorPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        PlayerColorMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        AIDifficultyPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        AIDifficultyMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = WindTypeImages;
        textImagesW2 = WindChoiceImages;
        textImagesB1 = PlayerColorImages;
        textImagesB2 = ColorChoiceImages;
        textImagesB3 = AIDifficultyImages;
        textImagesB4 = DifficultyImages;
        [self ChangeWind:WindChoiceImages WithSign:@"+"];
    }
    else if ([nodeTouched.name isEqual: @"WindTypeMinusButton"]) {
        WindTypeMinusButton.texture = [asciiWhiteImages objectAtIndex:81];
        WindTypePlusButton.texture = [asciiBlackImages objectAtIndex:83];
        PlayerColorPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        PlayerColorMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        AIDifficultyPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        AIDifficultyMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = WindTypeImages;
        textImagesW2 = WindChoiceImages;
        textImagesB1 = PlayerColorImages;
        textImagesB2 = ColorChoiceImages;
        textImagesB3 = AIDifficultyImages;
        textImagesB4 = DifficultyImages;
        [self ChangeWind:WindChoiceImages WithSign:@"-"];

    }
    else if ([nodeTouched.name isEqual: @"PlayerColorPlusButton"]) {
        PlayerColorPlusButton.texture = [asciiWhiteImages objectAtIndex:83];
        PlayerColorMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        WindTypePlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypeMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        AIDifficultyPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        AIDifficultyMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = PlayerColorImages;
        textImagesW2 = ColorChoiceImages;
        textImagesB1 = WindTypeImages;
        textImagesB2 = WindChoiceImages;
        textImagesB3 = AIDifficultyImages;
        textImagesB4 = DifficultyImages;
        [self ChangePlayerColor:ColorChoiceImages WithSign:@"+"];
    }
    else if ([nodeTouched.name isEqual: @"PlayerColorMinusButton"]) {
        PlayerColorMinusButton.texture = [asciiWhiteImages objectAtIndex:81];
        PlayerColorPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypePlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypeMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        AIDifficultyPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        AIDifficultyMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = PlayerColorImages;
        textImagesW2 = ColorChoiceImages;
        textImagesB1 = WindTypeImages;
        textImagesB2 = WindChoiceImages;
        textImagesB3 = AIDifficultyImages;
        textImagesB4 = DifficultyImages;
        [self ChangePlayerColor:ColorChoiceImages WithSign:@"-"];
    }
    else if ([nodeTouched.name isEqual: @"AIDifficultyPlusButton"]) {
        AIDifficultyPlusButton.texture = [asciiWhiteImages objectAtIndex:83];
        AIDifficultyMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        WindTypePlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypeMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        PlayerColorPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        PlayerColorMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = AIDifficultyImages;
        textImagesW2 = DifficultyImages;
        textImagesB1 = PlayerColorImages;
        textImagesB2 = ColorChoiceImages;
        textImagesB3 = WindTypeImages;
        textImagesB4 = WindChoiceImages;
        [self ChangeDifficulty:DifficultyImages WithSign:@"+"];
        
    }
    else if ([nodeTouched.name isEqual: @"AIDifficultyMinusButton"]) {
        AIDifficultyMinusButton.texture = [asciiWhiteImages objectAtIndex:81];
        AIDifficultyPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypePlusButton.texture = [asciiBlackImages objectAtIndex:83];
        WindTypeMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        PlayerColorPlusButton.texture = [asciiBlackImages objectAtIndex:83];
        PlayerColorMinusButton.texture = [asciiBlackImages objectAtIndex:81];
        textImagesW1 = AIDifficultyImages;
        textImagesW2 = DifficultyImages;
        textImagesB1 = PlayerColorImages;
        textImagesB2 = ColorChoiceImages;
        textImagesB3 = WindTypeImages;
        textImagesB4 = WindChoiceImages;
        [self ChangeDifficulty:DifficultyImages WithSign:@"-"];
    }
    
    // changing label colors
    [self MakeWhiteImages: textImagesW1 AndImages: textImagesW2];
    [self MakeBlackImages:textImagesB1 AndImages:textImagesB2 AndMoreImages:textImagesB3 AndEvenMoreImages:textImagesB4];
}

-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    //UITouch *touch = [touches anyObject];
    //CGPoint touchLocation = [touch locationInNode:self.scene];
    
    //SKScene *scene;
    
    SKSpriteNode *nodeTouched = (SKSpriteNode*)[self nodeAtPoint:pointTouched];
    NSMutableArray *textImages1;
    NSMutableArray *textImages2;
    int imageIndex;
    
    if ([nodeTouched.name isEqual: @"BackButton"]) {
        [self.view presentScene:MapSelectObj];
        textImages1 = BackImages;
    }
    else if ([nodeTouched.name isEqual: @"ContinueButton"]) {
        [self.view presentScene:GameSceneObj];
        textImages1 = ContinueImages;
    }
    else if ([nodeTouched.name isEqual: @"WindTypePlusButton"]) {
        WindTypePlusButton.texture = [asciiWhiteImages objectAtIndex:83];
        textImages1 = WindTypeImages;
        textImages2 = WindChoiceImages;
    }
    else if ([nodeTouched.name isEqual: @"WindTypeMinusButton"]) {
        
    }
    else if ([nodeTouched.name isEqual: @"PlayerColorPlusButton"]) {
        
    }
    else if ([nodeTouched.name isEqual: @"PlayerColorMinusButton"]) {
        
    }
    else if ([nodeTouched.name isEqual: @"AIDifficultyPlusButton"]) {
        
    }
    else if ([nodeTouched.name isEqual: @"AIDifficultyMinusButton"]) {
        
    }
    
    
    /*for (SKSpriteNode *charImage in textImages1) {
     imageIndex = 126 - [charImage.name characterAtIndex:0];
     charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
     }*/
}


-(void) MakeWhiteImages: (NSMutableArray *)images1 AndImages: (NSMutableArray *)images2{
    for (SKSpriteNode *charImage in images1) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }
    
    for (SKSpriteNode *charImage in images2) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }
}

-(void) MakeBlackImages: (NSMutableArray *)images1 AndImages: (NSMutableArray *)images2
          AndMoreImages: (NSMutableArray *)images3 AndEvenMoreImages: (NSMutableArray *)images4{
    
    for (SKSpriteNode *charImage in images1) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
    }
    
    for (SKSpriteNode *charImage in images2) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
    }
    
    for (SKSpriteNode *charImage in images3) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
    }
    
    for (SKSpriteNode *charImage in images4) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiBlackImages objectAtIndex:imageIndex];
    }
}

/*
    LAST TIME ON DRAGONBALL: GOKU WAS TRYING TO MAKE CARROT CAKE HAPPEN. we changed options for wind but still need to center the label and make it white
                            while switching thru them.
 */

-(void) ChangeWind:(NSMutableArray *) choiceImages WithSign:(NSString *)sign {
    CGPoint WindChoicePoint = ((SKSpriteNode *)[choiceImages objectAtIndex:0]).position;
    // get the third letter of label so we can tell what the current choice is
    NSString *choiceChar = ((SKSpriteNode *)[choiceImages objectAtIndex:2]).name;
    
    if((![choiceChar isEqual:@"R"] && [sign isEqual:@"+"]) || (![choiceChar isEqual:@"N"] && [sign isEqual:@"-"])) {
        for (SKSpriteNode *charImage in choiceImages) {
            [charImage removeFromParent];
        }
    }
    
    if ([sign isEqual:@"+"]) {
        // current choice is none, changing to mild
        if ([choiceChar isEqual:@"N"]) {
            WindChoiceImages = [self MakeTextImages:@"MILD" AtPoint:WindChoicePoint];
            GameSceneObj.WindType = 1;
        }
        // current choice is mild, changing to moderate
        else if ([choiceChar isEqual:@"L"]) {
            WindChoicePoint.x -= fontCharDim.width;
            WindChoiceImages = [self MakeTextImages:@"MODERATE" AtPoint:WindChoicePoint];
             GameSceneObj.WindType = 2;
        }
        // current choice is moderate, changing to erratic
        else if ([choiceChar isEqual:@"D"]) {
            WindChoicePoint.x += 0.25*fontCharDim.width;
            WindChoiceImages = [self MakeTextImages:@"ERRATIC" AtPoint:WindChoicePoint];
            GameSceneObj.WindType = 3;
        }
    }
    // when the minus is clicked
    else {
        // current choice is erratic, changing to moderate
        if ([choiceChar isEqual:@"R"]) {
            WindChoicePoint.x -= 0.25*fontCharDim.width;
            WindChoiceImages = [self MakeTextImages:@"MODERATE" AtPoint:WindChoicePoint];
            GameSceneObj.WindType = 2;
        }
        // current choice is moderate, changing to mild
        else if ([choiceChar isEqual:@"D"]) {
            WindChoicePoint.x += fontCharDim.width;
            WindChoiceImages = [self MakeTextImages:@"MILD" AtPoint:WindChoicePoint];
            GameSceneObj.WindType = 1;
        }
        // current choice is mild, changing to none
        else if ([choiceChar isEqual:@"L"]) {
            WindChoiceImages = [self MakeTextImages:@"NONE" AtPoint:WindChoicePoint];
            GameSceneObj.WindType = 0;
        }
    }
    
    for (SKSpriteNode *charImage in WindChoiceImages) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }
}


-(void) ChangePlayerColor:(NSMutableArray *) choiceImages WithSign:(NSString *)sign {
    CGPoint ColorChoicePoint = ((SKSpriteNode *)[choiceImages objectAtIndex:0]).position;
    // get the first letter of label so we can tell what the current choice is
    NSString *choiceChar = ((SKSpriteNode *)[choiceImages objectAtIndex:0]).name;
    
    if((![choiceChar isEqual:@"Y"] && [sign isEqual:@"+"]) || (![choiceChar isEqual:@"B"] && [sign isEqual:@"-"])) {
        for (SKSpriteNode *charImage in choiceImages) {
            [charImage removeFromParent];
        }
    }
    
    if ([sign isEqual:@"+"]) {
        // current choice is blue, changing to red
        if ([choiceChar isEqual:@"B"]) {
            ColorChoicePoint.x += 0.25*fontCharDim.width;
            ColorChoiceImages = [self MakeTextImages:@"RED" AtPoint:ColorChoicePoint];
            GameSceneObj.PlayerColor = 1;
        }
        // current choice is red, changing to yellow
        else if ([choiceChar isEqual:@"R"]) {
            ColorChoicePoint.x -= fontCharDim.width;
            ColorChoiceImages = [self MakeTextImages:@"YELLOW" AtPoint:ColorChoicePoint];
            GameSceneObj.PlayerColor = 2;
        }
    }
    // when the minus is clicked
    else {
        // current choice is yellow, changing to red
        if ([choiceChar isEqual:@"Y"]) {
            ColorChoicePoint.x += fontCharDim.width;
            ColorChoiceImages = [self MakeTextImages:@"RED" AtPoint:ColorChoicePoint];
            GameSceneObj.PlayerColor = 1;
        }
        // current choice is red, changing to blue
        else if ([choiceChar isEqual:@"R"]) {
            ColorChoicePoint.x -= 0.25*fontCharDim.width;
            ColorChoiceImages = [self MakeTextImages:@"BLUE" AtPoint:ColorChoicePoint];
            GameSceneObj.PlayerColor = 0;
        }
    }
    
    for (SKSpriteNode *charImage in ColorChoiceImages) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }
}

// FIXME: need to center the labels for difficulty
//        option shift to the left a bit every time we switch between them
-(void) ChangeDifficulty:(NSMutableArray *) choiceImages WithSign:(NSString *)sign {
    CGPoint DifficultyChoicePoint = ((SKSpriteNode *)[choiceImages objectAtIndex:0]).position;
    // get the first letter of label so we can tell what the current choice is
    NSString *choiceChar = ((SKSpriteNode *)[choiceImages objectAtIndex:0]).name;
    
    if((![choiceChar isEqual:@"I"] && [sign isEqual:@"+"]) || (![choiceChar isEqual:@"E"] && [sign isEqual:@"-"])) {
        for (SKSpriteNode *charImage in choiceImages) {
            [charImage removeFromParent];
        }
    }
    
    if ([sign isEqual:@"+"]) {
        // current choice is easy, changing to normal
        if ([choiceChar isEqual:@"E"]) {
            DifficultyChoicePoint.x -= 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"NORMAL" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 1;
        }
        // current choice is normal, changing to hard
        else if ([choiceChar isEqual:@"N"]) {
            DifficultyChoicePoint.x += 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"HARD" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 2;
        }
        // current choice is hard, changing to insane
        else if ([choiceChar isEqual:@"H"]) {
            DifficultyChoicePoint.x -= 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"INSANE" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 3;
        }
    }
    // when the minus is clicked
    else {
        // current choice is insane, changing to hard
        if ([choiceChar isEqual:@"I"]) {
            DifficultyChoicePoint.x += 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"HARD" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 2;
        }
        // current choice is hard, changing to normal
        else if ([choiceChar isEqual:@"H"]) {
            DifficultyChoicePoint.x -= 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"NORMAL" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 1;
        }
        // current choice is normal, changing to easy
        else if ([choiceChar isEqual:@"N"]) {
            DifficultyChoicePoint.x += 0.5*fontCharDim.width;
            DifficultyImages = [self MakeTextImages:@"EASY" AtPoint:DifficultyChoicePoint];
            GameSceneObj.AIDifficulty = 0;
        }
    }
    
    for (SKSpriteNode *charImage in DifficultyImages) {
        int imageIndex = 126 - [charImage.name characterAtIndex:0];
        charImage.texture = [asciiWhiteImages objectAtIndex:imageIndex];
    }


}

// DS,AM (3/1/15): creates menu options using images
-(void)CreateMenuText {
    // AM (3/1/15): point calculation (origin is top left):
    //              x = (half of scene width) - (half the size of the message * width of each character image according to scene dimmension)
    //              y = height from top
    CGPoint titlePoint = CGPointMake((self.frame.size.width/2) - (7*(self.frame.size.width/fontCharDim.width)), self.frame.size.height-(fontCharDim.height));
    // TODO: these CGpoints need to be changed
    CGPoint WindTypePoint = CGPointMake((7*(self.frame.size.width/fontCharDim.width)), titlePoint.y - fontCharDim.height*3);
    CGPoint PlayerColorPoint = CGPointMake((5*(self.frame.size.width/fontCharDim.width)), WindTypePoint.y - fontCharDim.height*2);
    CGPoint AIDifficultyPoint = CGPointMake((4*(self.frame.size.width/fontCharDim.width)), PlayerColorPoint.y - fontCharDim.height*2);
    CGPoint BackPoint = CGPointMake((self.frame.size.width/2) - (11*(self.frame.size.width/fontCharDim.width)), 2*fontCharDim.height);
    CGPoint ContinuePoint = CGPointMake((self.frame.size.width) - (6*(self.frame.size.width/fontCharDim.width)), 2*fontCharDim.height);
    
    // TODO: these CGpoints need to be changed
    CGPoint WindTypePlusPoint = CGPointMake((self.frame.size.width/2), titlePoint.y - fontCharDim.height*3);
    CGPoint WindTypeMinusPoint = CGPointMake((self.frame.size.width/2) - (6.5*(self.frame.size.width/fontCharDim.width)), titlePoint.y - fontCharDim.height*3);
    CGPoint PlayerColorPlusPoint = CGPointMake((self.frame.size.width/2), WindTypePoint.y - fontCharDim.height*2);
    CGPoint PlayerColorMinusPoint = CGPointMake((self.frame.size.width/2) - (6.5*(self.frame.size.width/fontCharDim.width)), WindTypePoint.y - fontCharDim.height*2);
    CGPoint AIDifficultyPlusPoint = CGPointMake((self.frame.size.width/2), PlayerColorPoint.y - fontCharDim.height*2);
    CGPoint AIDifficultyMinusPoint = CGPointMake((self.frame.size.width/2) - (6.5*(self.frame.size.width/fontCharDim.width)), PlayerColorPoint.y - fontCharDim.height*2);
    
    CGPoint WindChoicePoint = CGPointMake((self.frame.size.width/2) + (3*(self.frame.size.width/fontCharDim.width)), titlePoint.y - fontCharDim.height*3);
    CGPoint ColorChoicePoint = CGPointMake((self.frame.size.width/2) + (3*(self.frame.size.width/fontCharDim.width)),  WindTypePoint.y - fontCharDim.height*2);
    CGPoint DifficultyPoint = CGPointMake((self.frame.size.width/2) + (3*(self.frame.size.width/fontCharDim.width)), PlayerColorPoint.y - fontCharDim.height*2);

    TitleImage = [self MakeTextImages:@"GAME SELECTION" AtPoint:titlePoint];
    WindTypeImages = [self MakeTextImages:@"WIND TYPE" AtPoint:WindTypePoint];
    PlayerColorImages = [self MakeTextImages:@"PLAYER COLOR" AtPoint:PlayerColorPoint];
    AIDifficultyImages = [self MakeTextImages:@"AI DIFFICULTY" AtPoint:AIDifficultyPoint];
    BackImages = [self MakeTextImages:@"BACK" AtPoint:BackPoint];
    ContinueImages = [self MakeTextImages:@"CONTINUE" AtPoint:ContinuePoint];
    WindChoiceImages = [self MakeTextImages:@"NONE" AtPoint:WindChoicePoint];  // none, mild, moderate, erratic
    ColorChoiceImages = [self MakeTextImages:@"BLUE" AtPoint:ColorChoicePoint];  // blue, red, yellow
    DifficultyImages = [self MakeTextImages:@"EASY" AtPoint:DifficultyPoint]; // easy, normal, hard, insane
    
    // initializing menu buttons
    WindTypePlusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:83]];
    WindTypePlusButton.position = CGPointMake(WindTypePlusPoint.x + 6.5*(fontCharDim.width), WindTypePlusPoint.y);
    WindTypePlusButton.name = @"WindTypePlusButton";
    WindTypePlusButton.zPosition = 8;
    
    WindTypeMinusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:81]];
    WindTypeMinusButton.position = CGPointMake(WindTypeMinusPoint.x + 6.5*(fontCharDim.width), WindTypeMinusPoint.y);
    WindTypeMinusButton.name = @"WindTypeMinusButton";
    WindTypeMinusButton.zPosition = 8;
    
    PlayerColorPlusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:83]];
    PlayerColorPlusButton.position = CGPointMake(PlayerColorPlusPoint.x + 6.5*(fontCharDim.width), PlayerColorPlusPoint.y);
    PlayerColorPlusButton.name = @"PlayerColorPlusButton";
    PlayerColorPlusButton.zPosition = 8;
    
    PlayerColorMinusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:81]];
    PlayerColorMinusButton.position = CGPointMake(PlayerColorMinusPoint.x + 6.5*(fontCharDim.width), PlayerColorMinusPoint.y);
    PlayerColorMinusButton.name = @"PlayerColorMinusButton";
    PlayerColorMinusButton.zPosition = 8;
    
    AIDifficultyPlusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:83]];
    AIDifficultyPlusButton.position = CGPointMake(AIDifficultyPlusPoint.x + 6.5*(fontCharDim.width), AIDifficultyPlusPoint.y);
    AIDifficultyPlusButton.name = @"AIDifficultyPlusButton";
    AIDifficultyPlusButton.zPosition = 8;
    
    AIDifficultyMinusButton = [SKSpriteNode spriteNodeWithTexture:[asciiBlackImages objectAtIndex:81]];
    AIDifficultyMinusButton.position = CGPointMake(AIDifficultyMinusPoint.x + 6.5*(fontCharDim.width), AIDifficultyMinusPoint.y);
    AIDifficultyMinusButton.name = @"AIDifficultyMinusButton";
    AIDifficultyMinusButton.zPosition = 8;
    
    BackButton = [SKSpriteNode spriteNodeWithColor: [UIColor clearColor] size: CGSizeMake(3*fontCharDim.width, 1.5*fontCharDim.height)];
    BackButton.position = CGPointMake(BackPoint.x + 0.5*(fontCharDim.width), BackPoint.y);
    BackButton.name = @"BackButton";
    BackButton.zPosition = 8;
    
    ContinueButton = [SKSpriteNode spriteNodeWithColor: [UIColor clearColor] size: CGSizeMake(6*fontCharDim.width, 1.5*fontCharDim.height)];
    ContinueButton.position = CGPointMake(ContinuePoint.x + 2*(fontCharDim.width), ContinuePoint.y);
    ContinueButton.name = @"ContinueButton";
    ContinueButton.zPosition = 8;
    
    [self addChild:WindTypePlusButton];
    [self addChild:WindTypeMinusButton];
    [self addChild:PlayerColorPlusButton];
    [self addChild:PlayerColorMinusButton];
    [self addChild:AIDifficultyPlusButton];
    [self addChild:AIDifficultyMinusButton];
    [self addChild:BackButton];
    [self addChild:ContinueButton];
    
}


-(NSMutableArray*)MakeTextImages:(NSString *)textStr AtPoint:(CGPoint) startPos {
    
    NSMutableArray* textImages = [[NSMutableArray alloc] init];
    NSMutableArray* asciiImages;
    
    if ([textStr isEqual: @"GAME SELECTION"]) {
        asciiImages = asciiWhiteImages;
    }
    else {
        asciiImages = asciiBlackImages;
    }
    
    // offset is 126 - char to get proper char image
    int xincrement = 30; // space between characters
    int xpos = startPos.x;
    for ( int charCount = 0; charCount < textStr.length; charCount++) {
        int imageInd = 126 - [textStr characterAtIndex:charCount];
        SKSpriteNode* character = [SKSpriteNode spriteNodeWithTexture:[asciiImages objectAtIndex:imageInd]];
        character.zPosition = 7;
        character.position = CGPointMake(xpos, startPos.y);
        // assign name to identify charater
        character.name = [textStr substringWithRange: NSMakeRange(charCount, 1)];
        [textImages addObject:character];
        xpos += xincrement;
        if ([textStr isEqual: @"GAME SELECTION"]) {
            character.scale = MAP_SCALE;
        }
        else {
            xpos -= 15;
        }
    }
    
    for (SKSpriteNode* image in textImages) {
        //        image.speed = 1;
        [self addChild:image];
    }
    
    return textImages;
}

// DS,AM (2/7/15): Function to extract rectangular tile from passed in tileset (.png file) (modified version of function above)
-(NSMutableArray *)extractRectangleTiles:(NSString *)fileName  NumberOfTiles:(NSInteger)numTiles{
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:fileName];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate tile height
    //NSInteger TileHeight = ImageTexture.size.height / numTiles;
    NSMutableArray *TileArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array
    for (int i = 0; i < numTiles; i++) {
        [TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:ImageTexture]];
    }
    
    return TileArray;
}

-(void) SetBrickBackground {
    [self extractBrickTiles];
    /*SKSpriteNode* testBrick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:1]];
     testBrick.position = CGPointMake(100, 100);
     testBrick.scale = MAP_SCALE;
     [self addChild:testBrick];*/
    for (int i = 0; i < self.frame.size.height; i += (self.frame.size.height/((SKTexture *)[brickTiles objectAtIndex:0]).size.height) / 2.5) {
        for (int j = 0; j < self.frame.size.width; j += self.frame.size.width/((SKTexture *)[brickTiles objectAtIndex:0]).size.width) {
            SKSpriteNode* brick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:0]];
            brick.position = CGPointMake(j, i);
            brick.scale = MAP_SCALE;
            [self addChild:brick];
        }
    }
}

// NOTE: cannot use other extract methods since brick tiles have different dimmensions
-(void) extractBrickTiles {
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:@"Bricks"];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // 9 brick tiles
    brickTiles = [NSMutableArray arrayWithCapacity:9];
    
    // put each tile from tileset into array
    
    /*[TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
     inTexture:ImageTexture]];*/
    
    // NOTE: all CGRectMake values are in percent
    //       CGRectMake(x position from left, y position from left, width in respect to whole image, height in respect to whole image)
    
    //NOTE: bottom of png has white space, so starting at 4/132%
    //brick 1
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)4/132, 1, (float)8/132)
                                           inTexture:ImageTexture]];
    
    //brick 2 (top left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)12/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 3 (left piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)24/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    //brick 4 (bottom left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)48/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 5 (bottom piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)60/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 6 (bottom right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)72/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 7 (right piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0.5, (float)84/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 8 (top right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)108/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 9 (top piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)120/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
}

@end