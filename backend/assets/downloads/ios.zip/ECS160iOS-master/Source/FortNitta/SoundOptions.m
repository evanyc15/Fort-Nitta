#import "SoundOptions.h"
#import "AudioToolbox/MusicPlayer.h"
#import <Foundation/Foundation.h>
#include <stdlib.h>

@implementation SoundOptions

-(void)didMoveToView:(SKView *)view {
    
}

-(SoundOptions *)initWithSize:(CGSize)size{
    if (self = [super initWithSize:size]) {
        asciiBlackImages = [self extractRectangleTiles:@"FontKingthingsBlack" NumberOfTiles:95];
        asciiWhiteImages = [self extractRectangleTiles:@"FontKingthingsWhite" NumberOfTiles:95];
        fontCharDim = ((SKTexture*)[asciiBlackImages objectAtIndex:1]).size;
        [self CreateMenuText];
        [self SetBrickBackground];
    }
    return self;
}


-(void)CreateMenuText {
    // AM (3/1/15): point calculation (origin is top left):
    //              x = (half of scene width) - (half the size of the message * width of each character image according to scene dimmension)
    //              y = (scene height) - (height of character image)
    CGPoint titlePoint = CGPointMake((self.frame.size.width/2) - (5*(self.frame.size.width/fontCharDim.width)), self.frame.size.height-(fontCharDim.height));
    CGPoint MasterPoint = CGPointMake((self.frame.size.width/2) - (6.5*(self.frame.size.width/fontCharDim.width)), titlePoint.y - fontCharDim.height*3);
    CGPoint FXPoint = CGPointMake((self.frame.size.width/2) - (5.5*(self.frame.size.width/fontCharDim.width)), MasterPoint.y - fontCharDim.height*2);
    CGPoint BackPoint = CGPointMake((self.frame.size.width/2) - (11*(self.frame.size.width/fontCharDim.width)), 2*fontCharDim.height);
    
    TitleImages = [self MakeTextImages:@"SOUND" AtPoint:titlePoint];
    MasterImages = [self MakeTextImages:@"MASTER VOLUME" AtPoint:MasterPoint];
    FXImages = [self MakeTextImages:@"FX VOLUME" AtPoint:FXPoint];

    // initializing button
    BackButton = [SKSpriteNode spriteNodeWithColor: [UIColor clearColor] size: CGSizeMake(3*fontCharDim.width, 1.5*fontCharDim.height)];
    BackButton.position = CGPointMake(BackPoint.x + 0.5*(fontCharDim.width), BackPoint.y);
    BackButton.name = @"BackButton";
    BackButton.zPosition = 8;
    
    [self addChild:BackButton];
}



-(NSMutableArray*)MakeTextImages:(NSString *)textStr AtPoint:(CGPoint) startPos {
    
    NSMutableArray* textImages = [[NSMutableArray alloc] init];
    NSMutableArray* asciiImages;
    
    if ([textStr isEqual: @"SOUND OPTIONS"]) {
        asciiImages = asciiWhiteImages;
    }
    else {
        asciiImages = asciiBlackImages;
    }
    
    // offset is 126 - char to get proper char image
    int xincrement = 30; // space between characters
    int xpos = startPos.x;
    for ( int charCount = 0; charCount < textStr.length; charCount++) {
        int imageInd = 126 - [textStr characterAtIndex:charCount];
        SKSpriteNode* character = [SKSpriteNode spriteNodeWithTexture:[asciiImages objectAtIndex:imageInd]];
        character.scale = MAP_SCALE;
        character.zPosition = 7;
        character.position = CGPointMake(xpos, startPos.y);
        // assign name to identify charater
        character.name = [textStr substringWithRange: NSMakeRange(charCount, 1)];
        [textImages addObject:character];
        xpos += xincrement;
    }
    
    for (SKSpriteNode* image in textImages) {
        //        image.speed = 1;
        [self addChild:image];
    }
    
    return textImages;
}


-(void) SetBrickBackground {
    [self extractBrickTiles];
    /*SKSpriteNode* testBrick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:1]];
     testBrick.position = CGPointMake(100, 100);
     testBrick.scale = MAP_SCALE;
     [self addChild:testBrick];*/
    for (int i = 0; i < self.frame.size.height; i += (self.frame.size.height/((SKTexture *)[brickTiles objectAtIndex:0]).size.height) / 2.5) {
        for (int j = 0; j < self.frame.size.width; j += self.frame.size.width/((SKTexture *)[brickTiles objectAtIndex:0]).size.width) {
            SKSpriteNode* brick = [SKSpriteNode spriteNodeWithTexture:[brickTiles objectAtIndex:0]];
            brick.position = CGPointMake(j, i);
            brick.scale = MAP_SCALE;
            [self addChild:brick];
        }
    }
}



-(void) extractBrickTiles {
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:@"Bricks"];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // 9 brick tiles
    brickTiles = [NSMutableArray arrayWithCapacity:9];
    
    // put each tile from tileset into array
    
    /*[TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
     inTexture:ImageTexture]];*/
    
    // NOTE: all CGRectMake values are in percent
    //       CGRectMake(x position from left, y position from left, width in respect to whole image, height in respect to whole image)
    
    //NOTE: bottom of png has white space, so starting at 4/132%
    //brick 1
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)4/132, 1, (float)8/132)
                                           inTexture:ImageTexture]];
    
    //brick 2 (top left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)12/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 3 (left piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)24/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    //brick 4 (bottom left corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)48/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 5 (bottom piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)60/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 6 (bottom right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)72/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 7 (right piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0.5, (float)84/132, 0.5, (float)24/132)
                                           inTexture:ImageTexture]];
    
    
    //brick 8 (top right corner piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)108/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
    
    //brick 9 (top piece)
    [brickTiles addObject:[SKTexture textureWithRect:CGRectMake(0, (float)120/132, 1, (float)12/132)
                                           inTexture:ImageTexture]];
}

-(NSMutableArray *)extractRectangleTiles:(NSString *)fileName  NumberOfTiles:(NSInteger)numTiles{
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:fileName];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate tile height
    //NSInteger TileHeight = ImageTexture.size.height / numTiles;
    NSMutableArray *TileArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array
    for (int i = 0; i < numTiles; i++) {
        [TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:ImageTexture]];
    }
    
    return TileArray;
}

@end