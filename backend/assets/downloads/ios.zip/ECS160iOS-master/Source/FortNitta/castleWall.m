//
//  castleWall.m
//  FortNitta
//
//  Created by Ricky Cheung on 2/7/15.
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "castleWall.h"


@implementation castleWallChoices

-(id)init{
    self = [super init];

    //NSMutableArray *castleWallArray = [self extractTiles:@"2DWalls"];
    SKTexture *imageTexture = [SKTexture textureWithImageNamed:@"2DWalls"];
    imageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate num of square tiles
    NSUInteger numTiles = imageTexture.size.height / imageTexture.size.width;
    castleBuildWallArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array (do math to calculate CGRect to use to extract tile from tileset)
    for (int i = 0; i < numTiles; i++) {
        [castleBuildWallArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:imageTexture]];
    }
    
    return self;
}

-(NSMutableArray*)setThings:(CGPoint)touchLocation{
    currentBuildWall = [[NSMutableArray alloc] init];
    componentWallLocations = [[NSMutableArray alloc] init];
    
    CGPoint newPosition;
    SKSpriteNode *tileImage = [SKSpriteNode spriteNodeWithTexture:[castleBuildWallArray objectAtIndex:40]];
    SKSpriteNode *tileImageUP = [SKSpriteNode spriteNodeWithTexture:[castleBuildWallArray objectAtIndex:40]];
    
    tileImage.position = touchLocation;
    tileImage.scale = MAP_SCALE;
    tileImage.name = @"0";
    [componentWallLocations addObject:[NSValue valueWithCGPoint:touchLocation]];
    [currentBuildWall addObject:tileImage];
    
    newPosition.x = touchLocation.x - 24;
    NSLog(@"%f",touchLocation.x);
    newPosition.y = touchLocation.y;
    tileImageUP.position = newPosition;
    tileImageUP.scale = MAP_SCALE;
    tileImageUP.name = @"24";
    [currentBuildWall addObject:tileImageUP];

    return currentBuildWall;
};

-(NSMutableArray*)AlterLocation:(NSMutableArray*)oldArray secondValue:(CGPoint)touchLocation{
    
    for(SKSpriteNode* obj in currentBuildWall){
        CGPoint newPosition;
        newPosition.x = touchLocation.x - [obj.name floatValue];
        newPosition.y = touchLocation.y;
        obj.position = newPosition;
        //[currentBuildWall addObject:obj];
        
    }
    
    return oldArray;
}


@end