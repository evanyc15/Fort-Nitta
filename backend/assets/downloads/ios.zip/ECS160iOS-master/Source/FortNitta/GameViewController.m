//
//  GameViewController.m
//  FortNitta
//
//  Created by Ali Minty on 1/18/15.
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#import "GameViewController.h"
#import "GameScene.h"
#import "MainMenu.h"
#import "AudioToolbox/MusicPlayer.h"
#import <SpriteKit/SpriteKit.h>
@implementation SKScene (Unarchive)

+ (instancetype)unarchiveFromFile:(NSString *)file
{
    /* Retrieve scene file path from the application bundle */
    NSString *nodePath = [[NSBundle mainBundle] pathForResource:file ofType:@"sks"];
    /* Unarchive the file to an SKScene object */
    NSData *data = [NSData dataWithContentsOfFile:nodePath
                                          options:NSDataReadingMappedIfSafe
                                            error:nil];
    NSKeyedUnarchiver *arch = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    [arch setClass:self forClassName:@"SKScene"];
    SKScene *scene = [arch decodeObjectForKey:NSKeyedArchiveRootObjectKey];
    [arch finishDecoding];
    
    return scene;
}

@end

@implementation GameViewController

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touchInter = [[event allTouches]anyObject];
    exampleButtonDrag.center =[touchInter locationInView:self.view];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];

    if(skView == nil){
    // Configure the view.
    skView = (SKView *)self.view;
    skView.showsFPS = YES;
    skView.showsNodeCount = YES;
    /* Sprite Kit applies additional optimizations to improve rendering performance */
    skView.ignoresSiblingOrder = YES;
    
    // Create and configure the scene.
    
    MainMenuObj = [[MainMenu alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    //GameSceneObj = [[GameScene alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    //GameSceneObj = [GameScene unarchiveFromFile:@"GameScene"];
    //GameSceneObj.scaleMode = SKSceneScaleModeAspectFill;
    //MainMenuObj.GameSceneObj = GameSceneObj;
    MainMenuObj.MapSelectObj = [[MapSelect alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    // scenes for MapSelect continue and back buttons
    MainMenuObj.MapSelectObj.GameSelectionObj = [[GameSelection alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    MainMenuObj.MapSelectObj.MainMenuObj = MainMenuObj;
    
    // scenes for GameSelection continue and back buttons
    MainMenuObj.MapSelectObj.GameSelectionObj.GameSceneObj = [GameScene unarchiveFromFile:@"GameScene"];
    MainMenuObj.MapSelectObj.GameSelectionObj.GameSceneObj.scaleMode = SKSceneScaleModeAspectFill;
    MainMenuObj.MapSelectObj.GameSelectionObj.MapSelectObj = MainMenuObj.MapSelectObj;
    
    MainMenuObj.OptionsObj = [[Options alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    MainMenuObj.OptionsObj.MainMenuObj = MainMenuObj;
    //NSLog(@"width: %f", skView.bounds.size.width);
    //NSLog(@"height: %f", skView.bounds.size.height);

    
    // Present the scene.
    [skView presentScene:MainMenuObj];
    
    /**Music Player Code**/
    //create a new music seq
    MusicSequence seq;
    MusicPlayer player;
    //instantiate music seq and player
    NewMusicSequence(&seq);
    NewMusicPlayer(&player);
    
    
    NSString *midFilePath = [[NSBundle mainBundle]
                             pathForResource:@"menu"
                             ofType:@"mid"];
    
    //url which points to the mid file
    NSURL * midFileURL = [NSURL fileURLWithPath:midFilePath];
    MusicSequenceFileLoad(seq, (__bridge CFURLRef)(midFileURL), 0, 0);
    UInt32 tracks;
    
    MusicSequenceGetTrackCount(seq, &tracks);
    
    
    for (UInt32 i = 0; i < tracks; i++) {
        MusicTrack track = NULL;
        MusicTimeStamp trackLen = 0;
        
        UInt32 trackLenLen = sizeof(trackLen);
        
        MusicSequenceGetIndTrack(seq, i, &track);
        
        MusicTrackGetProperty(track, kSequenceTrackProperty_TrackLength, &trackLen, &trackLenLen);
        MusicTrackLoopInfo loopInfo = {trackLen, 4 };
        MusicTrackSetProperty(track, kSequenceTrackProperty_LoopInfo, &loopInfo, sizeof(loopInfo));
        NSLog(@"track length is %f", trackLen);
    }
    
    
    MusicPlayerSetSequence(player, seq);
    MusicPlayerPreroll(player);
    MusicPlayerStart(player);
    
    }
    // Do any additional setup after loading the view.
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    }
    else
    {
        return UIInterfaceOrientationMaskAll;
    }
}

-(IBAction)dragOut: (id)sender withEvent: (UIEvent *) event
{
    UIButton *selected = (UIButton *)sender;
    selected.center = [[[event allTouches] anyObject] locationInView:self.view];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}


@end
