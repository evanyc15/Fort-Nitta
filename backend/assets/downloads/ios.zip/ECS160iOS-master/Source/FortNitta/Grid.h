//
//  Grid.h
//  FortNitta
//
//  Created by Raul Cano
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#ifndef FortNitta_Grid_h
#define FortNitta_Grid_h
#import <Foundation/Foundation.h>
#import <SpriteKit/SpriteKit.h>

// INTERFACE
@interface gridNode : NSObject {
    char bRWater; // 'B' or 'R' or ' ' water
    bool grass, wall, visited, checkeredFloor, castle; //need bool water? because water already marked as ' '
    char testingDFSX;

}


-(void)setNodeForTestingDFSX:(gridNode *)node :(char)newDFSX;
-(char)getNodeForTestingDFSX:(gridNode *)node;




-(char)getNodeBRWater:(gridNode *)node;
-(void)setNodeBRWater:(gridNode *)node :(char)newBRWater;

-(void)setNodeIsWall:(gridNode *)node;
-(bool)getNodeIsWall:(gridNode *)node;

-(void)setNodeIsCastle:(gridNode *)node;
-(bool)getNodeIsCastle:(gridNode *)node;

-(void)setNodeIsGrass:(gridNode *)node;
-(bool)getNodeIsGrass:(gridNode *)node;

-(void)setNodeIsVisited:(gridNode *)node;
-(bool)getNodeIsVisited:(gridNode *)node;

-(void)setNodeCheckeredFloor:(gridNode *)node;
-(bool)getNodeCheckeredFloor:(gridNode *)node;



-(void)resetNodeIsVisited:(gridNode *)node;




@end




#endif
