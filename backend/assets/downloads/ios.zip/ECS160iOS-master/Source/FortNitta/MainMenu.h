#import <SpriteKit/SpriteKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import "GameScene.h"
#import "MapSelect.h"
#import "Options.h"
#define MAP_SCALE 2.0

@interface MainMenu : SKScene{
    NSMutableArray* TitleImages;
    NSMutableArray* SinglePlayerImages;
    NSMutableArray* MultiplayerImages;
    NSMutableArray* OptionsImages;
    NSMutableArray* ExitImages;
    NSMutableArray* brickTiles;
    
    SKSpriteNode* SinglePlayerButton;
    SKSpriteNode* MultiplayerButton;
    SKSpriteNode* OptionsButton;
    SKSpriteNode* ExitButton;
    
    NSMutableArray* asciiBlackImages;
    NSMutableArray* asciiWhiteImages;
    // dimmensions for each character image
    CGSize fontCharDim;
    
    CGPoint pointTouched;
}

@property MapSelect* MapSelectObj;
@property Options* OptionsObj;

@end