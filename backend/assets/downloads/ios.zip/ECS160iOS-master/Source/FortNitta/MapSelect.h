#import <SpriteKit/SpriteKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import "GameSelection.h"

#define MAP_SCALE 2.0

@interface MapSelect : SKScene{
    
    NSMutableArray* TitleImage;
    NSMutableArray* NorthSouthImages;
    NSMutableArray* TwoPlayersImages;
    NSMutableArray* MapDimensionsImages;
    NSMutableArray* BackImages;
    NSMutableArray* ContinueImages;
    NSMutableArray* brickTiles;
    
    SKSpriteNode* NorthSouthButton;
    SKSpriteNode* BackButton;
    SKSpriteNode* ContinueButton;
    
    NSMutableArray* asciiBlackImages;
    NSMutableArray* asciiWhiteImages;
    // dimmensions for each character image
    CGSize fontCharDim;
    
    CGPoint pointTouched;
}

@property SKScene *MainMenuObj;
@property GameSelection *GameSelectionObj;

@end
