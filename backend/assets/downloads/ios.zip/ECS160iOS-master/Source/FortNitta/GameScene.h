//
//  GameScene.h
//  FortNitta
//

//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>


#define MAP_SCALE 2.0

#define lengthOfSprite 24;
#define widthOfSprite 24;

//Game modes
#define CASTLE_MODE 1
#define CANNON_MODE 2
#define BATTLE_MODE 3
#define REBUILD_MODE 4

//Time intervals (currently arbitrary timer values)
#define CASTLE_TIME 15.0
#define CANNON_TIME 15.0
#define BATTLE_TIME 10.0
#define REBUILD_TIME 25.0

//Keeping track of which team player chooses.
#define BLUE_TEAM 1
#define RED_TEAM 0

//Explosion Types
#define WALL_EXPLOSION 1
#define WATER_EXPLOSION 2
#define GROUND_EXPLOSION 3

//Physics Body Types
#define WALL2D_BODY 1
#define WALL3D_BODY 2
#define CANNONBALL_BODY 3

//Physics Body Bitmasks
#define WALL2D_MASK 0x1
#define WALL3D_MASK 0x2
#define CANNONBALL_MASK 0x4

//Wall height (must be 0-11)
#define WALL_HEIGHT 3

//Wind Types
#define WIND_NONE 0
#define WIND_MILD 1
#define WIND_MODERATE 2
#define WIND_ERRATIC 3

//AI Difficulty
#define AI_EASY 0
#define AI_MEDIUM 1
#define AI_HARD 2
#define AI_INSANE 3

//Player Color
#define PLAYER_BLUE 0
#define PLAYER_RED 1
#define PLAYER_YELLOW 2


#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
@interface GameScene : SKScene{
    AVAudioPlayer *soundEffects;
    int count;
    char mapArray[26][42];
    bool firstClick;
    SKSpriteNode *cannonCountImage;
    SKSpriteNode *oppCannonCountImage;
    NSTimer *CastleTimer;
    NSTimer *CannonTimer;
    NSTimer *BattleTimer;
    NSTimer *RebuildTimer;
    //timer
    SKLabelNode *timerRemaining;
    NSTimer *startTimer;
    bool isClickedOnce;
    int secondLeft;
    int GameMode;
    int teamChoice;
    // arrays for explosion png's
    NSArray *WallExplosion1;
    NSArray *WallExplosion2;
    NSArray *WaterExplosion1;
    NSArray *WaterExplosion2;
    NSArray *GroundExplosion1;
    NSArray *GroundExplosion2;
    // arrays for cannonball animation
    NSMutableArray * cannonballTileArray;
    NSMutableArray* reversedcannonballTileArray;
    // says if player has max number of cannons in all castles
    bool maxCannons;
}
@property int WindType;
@property int PlayerColor;
@property int AIDifficulty;
@end