//
//  GameScene.m
//  FortNitta
//
//  Created by Ali Minty on 1/18/15.
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//

//STATUS: Background appears.
//        Castle plays sound when selected.

#import "GameScene.h"
#import "AudioToolbox/MusicPlayer.h"
#import <AudioToolbox/AudioToolbox.h>
#import "Grid.h" // R
#import <Foundation/Foundation.h>
#include <stdlib.h> // for random num


@interface GameScene () <SKPhysicsContactDelegate>
@end

@implementation GameScene

@synthesize WindType;
@synthesize PlayerColor;
@synthesize AIDifficulty;

// NSMutableArray that keeps track of castles that have not been used
NSMutableArray *unusedCastles;
// NSMutableArray that keeps track of the temp castle
NSMutableArray *selectedCastle;
// NSMutableArray that keeps track of castles that have been used
NSMutableArray *usedCastles;
// NSMutableArray that keeps track of select tiles around a castle
NSMutableArray *selectCastleTiles;
// NSMutableArray that keeps track of cannons
NSMutableArray *cannons;
// NSMutableArray that keeps track of opponents cannons
NSMutableArray *oppCannons;
// NSMutableArray that has random CGPoints to shoot at
NSMutableArray *targetPosition;
//keeps track of walls
NSMutableArray *castleWallArray;
//Keep track count of cannons;
NSMutableArray *Terrain3D;
// NSMutableArray that keeps track of castleFloorTiles
NSMutableArray *castleFloorTiles;
//Keeps track of 3D walls
NSMutableArray* Walls3D;

NSMutableArray *destroyedWalls;
NSMutableArray *burningWalls;

int CannonCount = 0;
int topCannons = 3;
int windDirection;
CGPoint oppCannonPosition;
CGVector globalWindSpeed;


int NUM_CASTLES;
bool FIRST_SELECT_CASTLE_STAGE;

NSMutableArray *wallsOnGrid; // walls placed on Grid
NSMutableArray *outlineWallsOnGrid; // wall outlines placed on Grid
NSMutableArray *castlesOnGrid; // castles placed on Grid
NSMutableArray *tempWallShapeNodes; //multiple wall nodes that make up 1 shape

gridNode *gridLayout[25][41]; // HEIGHT: 26 WIDTH: 42
int twoDWallType [25][41];

NSMutableArray *walls2DPNG; // holds 2DWalls pngs

// Variables related to playing sounds
AVAudioPlayer *_player[40];
int currentAudioChannel = 0;
int MAX_AUDIO_CHANNELS = 40;
// related to cannon landing sounds in function SetExplosion
int _currentCount = 0;

// Variables needed for the placement of the walls
NSMutableArray* componentWallArray;
NSMutableArray* wallLocations;
bool secondTap = false;
NSMutableArray *tempCurrentWallComponents;

typedef enum {
    single = 0,
    twoLTile,
    tTile,
    threeLTile,
    lessTTile,
    threeLTileWithTwo,
    zTile,
    fourLTile,
    fourActualLTile,
    squareTile
}Shapes;

typedef enum {
    North = 0,
    East,
    South,
    West
}Direction;

int currentTile = 0;

int dir = 0;
int countTileRotation=0;

// these bool variables resets dir to 0 when entering a new wall shape
bool firstTTile=true;
bool firstThreeLTile=true;
bool firstLessTTile=true;
bool firstThreeLTileWithTwo=true;
bool firstZTile=true;
bool firstFourLTile=true;
bool firstFourActualLTile=true;
bool firstSquareTile=true;


//function to add two vectors
static inline CGVector rwAdd(CGVector a, CGVector b) {
    return CGVectorMake(a.dx + b.dx, a.dy + b.dy);
}
//function to subtract two vectors
static inline CGVector rwSub(CGVector a, CGVector b) {
    return CGVectorMake(a.dx - b.dx, a.dy - b.dy);
}
//function to multiply two vectors
static inline CGVector rwMult(CGVector a, float b) {
    return CGVectorMake(a.dx * b, a.dy * b);
}
//function to get the magnitude of a vector
static inline long rwLength(CGVector a) {
    return sqrtf(a.dx * a.dx + a.dy * a.dy);
}
// Makes a vector have a length of 1
static inline CGVector rwNormalize(CGVector a) {
    float length = rwLength(a);
    return CGVectorMake(a.dx / length, a.dy / length);
}


// Function to extract tile from passed in tileset (.png file)
-(NSMutableArray *)extractTiles:(NSString *)fileName {
    SKTexture *imageTexture = [SKTexture textureWithImageNamed:fileName];
    imageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate num of square tiles
    NSUInteger numTiles = imageTexture.size.height / imageTexture.size.width;
    NSMutableArray *tileArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array (do math to calculate CGRect to use to extract tile from tileset)
    for (int i = 0; i < numTiles; i++) {
        [tileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:imageTexture]];
    }
    
    return tileArray;
}

// DS,AM (2/7/15): Function to extract rectangular tile from passed in tileset (.png file) (modified version of function above)
-(NSMutableArray *)extractRectangleTiles:(NSString *)fileName  NumberOfTiles:(NSInteger)numTiles{
    SKTexture *ImageTexture = [SKTexture textureWithImageNamed:fileName];
    ImageTexture.filteringMode = SKTextureFilteringNearest;
    
    // calculate tile height
    //NSInteger TileHeight = ImageTexture.size.height / numTiles;
    NSMutableArray *TileArray = [NSMutableArray arrayWithCapacity:numTiles];
    
    // put each tile from tileset into array
    for (int i = 0; i < numTiles; i++) {
        [TileArray addObject:[SKTexture textureWithRect:CGRectMake(0, (float)i / numTiles, 1, 1.0 / numTiles)
                                              inTexture:ImageTexture]];
    }
    
    return TileArray;
}

//Genearetes wind a wind speed between 0 and 10 and moving in one of the 8 orthogonal directions
static CGVector generateWindDirection() {
    CGVector wind;
    CGVector temp;
    int ratio = 100;
    //generate the wind speed
    float s = rand() % 10 + 1;
    //generate the direction where 0 = no wind, 1 = north, 2 = northeast, 3 = east...
    int d = rand() % 9 - 1;
    switch (d) {
        case 0:
            wind = CGVectorMake(0.0, 0.0);
            break;
        case 1:
            wind = CGVectorMake(0.0, s / ratio);
            break;
        case 2:
            temp = rwNormalize(CGVectorMake(1, 1));
            temp.dx = temp.dx * s / ratio;
            temp.dy = temp.dy * s / ratio;
            wind = temp;
            break;
        case 3:
            wind = CGVectorMake(s / ratio, 0.0);
            break;
        case 4:
            temp = rwNormalize(CGVectorMake(1, 1));
            temp.dx = temp.dx * s / ratio;
            temp.dy = temp.dy * s / ratio * -1.0;
            wind = temp;
            break;
        case 5:
            wind = CGVectorMake(0.0, s / ratio * -1);
            break;
        case 6:
            temp = rwNormalize(CGVectorMake(1, 1));
            temp.dx = temp.dx * s / ratio * -1.0;
            temp.dy = temp.dy * s / ratio * -1.0;
            wind = temp;
            break;
        case 7:
            wind = CGVectorMake(s / ratio * -1, 0.0);
            break;
        case 8:
            temp = rwNormalize(CGVectorMake(1, 1));
            temp.dx = temp.dx * s / ratio * -1.0;
            temp.dy = temp.dy * s / ratio;
            wind = temp;
            break;
        default:
            wind = CGVectorMake(0.0, 0.0);
            break;
    }
    windDirection = d;
    return wind;
}



-(void)didMoveToView:(SKView *)view{
    /* Setup your scene here */
    walls2DPNG = [self extractTiles:@"2DWalls"];
    
    [self initVar];
    [self setupMap:@"NorthSouth" withExtension:@"map"];
    
    GameMode = CASTLE_MODE;  //initializing game mode variable
    
    // DS,AM (2/22/2015): added timer for initial castle select
    CastleTimer = [NSTimer scheduledTimerWithTimeInterval:CASTLE_TIME
                                                   target:self
                                                 selector:@selector(timerFireMethod:)
                                                 userInfo:nil
                                                  repeats:NO];
    
    
    // DS,AM (2/7/15): extracting explosion tiles
    // NOTE: NSRange takes starting index and size of range (not start and end of range)
    NSArray *allExplosions = [self extractRectangleTiles:@"3DExplosions.png" NumberOfTiles:54];
    WallExplosion1 = [allExplosions subarrayWithRange:NSMakeRange(0, 9)];
    WallExplosion2 = [allExplosions subarrayWithRange:NSMakeRange(9, 9)];   //FIXME: these explosions are not split up properly, height of each tile too large
    WaterExplosion1 = [allExplosions subarrayWithRange:NSMakeRange(18, 9)];
    WaterExplosion2 = [allExplosions subarrayWithRange:NSMakeRange(27, 9)];
    GroundExplosion1 = [allExplosions subarrayWithRange:NSMakeRange(36, 9)];
    GroundExplosion2 = [allExplosions subarrayWithRange:NSMakeRange(45, 9)];
    //sets the wind direction at random
    globalWindSpeed = generateWindDirection();
    self.physicsWorld.gravity = globalWindSpeed;
    self.physicsWorld.contactDelegate = self;

    self.physicsWorld.gravity = CGVectorMake(0,0);
    self.physicsWorld.contactDelegate = self;
    
    // initializing cannonball animation arrays (12 cannonball sizes)
    cannonballTileArray = [self extractTiles:@"3DCannonball.png"];
    reversedcannonballTileArray = (NSMutableArray *)[[cannonballTileArray reverseObjectEnumerator] allObjects];
    
    maxCannons = false;
    
    // DS,AM (2/24/15): moved here to keep track of 3D walls across all battle modes
    Walls3D = [[NSMutableArray alloc] init];
    
}

-(int)getXRowNum:(CGPoint)position {
    int x = floor(position.x/(12*MAP_SCALE));
    return x;
}
-(int)getYInvertedColNum:(CGPoint)position {
    int y = 27 - floor(position.y/(12*MAP_SCALE));
    
    // NON-INVERTED col number
    //int y = floor((position.y/(12*MAP_SCALE))) - 4;
    return y;
}
-(CGPoint)getXYCoord:(int)x :(int)y {
    CGPoint newPoint;
    newPoint.x = (x * 12*MAP_SCALE) + 12;
    newPoint.y = ((27 - y) * 12*MAP_SCALE) + 12;
    
    // NON-INVERTED y
    //newPoint.y = ((y + 4) * 12*MAP_SCALE) + 12;
    
    return newPoint;
}

-(void)printGridLayout {
    gridNode *temp = [[gridNode alloc]init];
    
    for (int i = 0; i < 24; i++) {
        for (int j = 0; j < 40; j++) {
            //printf("%c", [temp getNodeBRWater:gridLayout[i][j]]);//gridLayout[i][j]->bRWater );
            if ([temp getNodeIsWall:gridLayout[i][j]]) {
                printf("1");
            }
            else {
                printf("%c", [temp getNodeForTestingDFSX:gridLayout[i][j]]);
            }
        }
        printf("\n");
    }
    printf("\n");
    
}
-(void)resetGridLayoutVisited {
    gridNode *temp = [[gridNode alloc]init];
    
    for (int i = 0; i < 24; i++) {
        for (int j = 0; j < 40; j++) {
            [temp setNodeForTestingDFSX:gridLayout[i][j]  :'-'];
            [temp resetNodeIsVisited:gridLayout[i][j]];
        }
    }
}



-(void)colorInFloorPattern {
    gridNode *temp = [[gridNode alloc]init];
    NSMutableArray *walls2D = [self extractTiles:@"2DWalls"];
    
    for (int i = 0; i < 24; i++) {
        for (int j = 0; j < 40; j++) {
            if (![temp getNodeIsVisited:gridLayout[i][j]] && ![temp getNodeIsWall:gridLayout[i][j]] &&
                [temp getNodeCheckeredFloor:gridLayout[i][j]] != true) { // if floor ok
                
                [temp setNodeCheckeredFloor:gridLayout[i][j]];
                if (((i + j) % 2 == 0)) {
                    SKSpriteNode *nodeTouched = [[SKSpriteNode alloc] init];
                    NSArray *nodes = [self nodesAtPoint:[self getXYCoord:j :i]];
                    
                    for (SKNode *object in nodes) {
                        if (object.zPosition == 0) {
                            nodeTouched = (SKSpriteNode*) object;
                        }
                    }
                    //nodeTouched.zPosition = 10;
                    if(teamChoice == BLUE_TEAM)
                        [nodeTouched setTexture:[walls2D objectAtIndex:2]];
                    else
                        [nodeTouched setTexture:[walls2D objectAtIndex:1]];
                }
                
                else if (((i + j) % 2 == 1)) {
                    SKSpriteNode *nodeTouched = [[SKSpriteNode alloc] init];
                    NSArray *nodes = [self nodesAtPoint:[self getXYCoord:j :i]];
                    
                    for (SKNode *object in nodes) {
                        if (object.zPosition == 0) {
                            nodeTouched = (SKSpriteNode*) object;
                        }
                    }
                    //nodeTouched.zPosition = 10;
                    [nodeTouched setTexture:[walls2D objectAtIndex:3]];
                } // end else if
                
            } // end if ! visited
        }// end inner for
    }// end outer for
    
    
    
} // END colorIn
//X Tiles: 0-39. 40 total
//Y Tiles: 0-23. 24 total
-(void)DFS:(int)y :(int)x {
    gridNode *temp = [[gridNode alloc] init];
    //[temp setNodeIsVisited:gridLayout[y][x]];
    
    //FOR TESTING: when you visit something mark it with an X
    // then print out grid
    
    for (int i = y -1; i <= y+1; i++) {
        for (int j = x - 1; j <= x+1; j++) {
            if (i < 0 || i > 23 || j < 0 || j > 39) {
                //NSLog(@"J =: %i", j);
            }
            else if ([temp getNodeIsVisited:gridLayout[i][j]] || [temp getNodeIsWall:gridLayout[i][j]]) {
                //visited or is wall
            }
            else {
                [temp setNodeIsVisited:gridLayout[y][x]];
                [temp setNodeForTestingDFSX:gridLayout[y][x] :'X'];
                
                //[self printGridLayout];
                [self DFS:i :j];
            }
        }
    }//end outer for
    
} // END DFS

-(void)timerFireMethod:(NSTimer*)theTimer{
    
    switch (GameMode) {
        case CASTLE_MODE:
            GameMode = CANNON_MODE; //go to select castle
            NSLog(@"changed to cannon mode");
            [theTimer invalidate];
            theTimer = nil;
            CannonTimer = [NSTimer scheduledTimerWithTimeInterval:CANNON_TIME
                                                           target:self
                                                         selector:@selector(timerFireMethod:)
                                                         userInfo:nil
                                                          repeats:NO];
            break;
            
        case CANNON_MODE:
            GameMode = BATTLE_MODE; //go to battle mode
            option = @"3D";
            [self createSweep:@"Battle Mode"];
            NSLog(@"changed to battle mode");
            //            for (SKSpriteNode *node in Terrain3D)
            //            {
            //                node.hidden = NO;
            //                node.zPosition = 0;
            //            }
            //            for (SKSpriteNode *node in Walls3D)
            //            {
            //                node.hidden = NO;
            //                node.zPosition = 3;
            //            }
            //            [self BattleModeCastleTiles];
            //            [self BattleModeCannons];
            //            [self BattleModeCastles];
            //            [self BattleModeWalls];
            [theTimer invalidate];
            theTimer = nil;
            
            RebuildTimer = [NSTimer scheduledTimerWithTimeInterval:BATTLE_TIME
                                                            target:self
                                                          selector:@selector(timerFireMethod:)
                                                          userInfo:nil
                                                           repeats:NO];
            
            
            
            break;
            
        case BATTLE_MODE:
            //once in battle mode,
            option = @"2D";
            [self createSweep:@"Build Castles"];
            [self removeDestroyedWalls];
            [cannonCountImage removeFromParent];
            [self createTimerLabel];
            secondLeft = 25;
            startTimer = [NSTimer scheduledTimerWithTimeInterval:0.93
                                                          target:self
                                                        selector:@selector(timerCount)
                                                        userInfo:nil
                                                         repeats:YES];
            GameMode = REBUILD_MODE;
            NSLog(@"changed to rebuild mode");
            //            for (SKSpriteNode *node in Walls3D)
            //            {
            //                node.hidden = YES;
            //                node.zPosition = -1;
            //            }
            //            [self revertBattleModeCastleTiles];
            //            [self revertBattleModeCastles];
            //            [self revertBattleModeWalls];
            //            [self revertBattleModeCannons];
            //            [self removeDestroyedWalls];
            [theTimer invalidate];
            theTimer = nil;
            
            RebuildTimer = [NSTimer scheduledTimerWithTimeInterval:REBUILD_TIME
                                                            target:self
                                                          selector:@selector(timerFireMethod:)
                                                          userInfo:nil
                                                           repeats:NO];
            
            
            break;
            
        case REBUILD_MODE:
            // if the player's castles don't have the max number of cannons, we enter cannon mode (else skip cannon mode)
            if(CannonCount != topCannons) {
                GameMode = CANNON_MODE; //go back to cannon mode
                //                [self createSweep:@"Place Cannons"];
                NSLog(@"changed to cannon mode1");
                [theTimer invalidate];
                theTimer = nil;
                [timerRemaining removeAllChildren];
                [self createTimerLabel];
                secondLeft = CANNON_TIME;
                CannonTimer = [NSTimer scheduledTimerWithTimeInterval:CANNON_TIME
                                                               target:self
                                                             selector:@selector(timerFireMethod:)
                                                             userInfo:nil
                                                              repeats:NO];
            }
            else {
                option = @"3D";
                [self createSweep:@"Battle Mode"];
                GameMode = BATTLE_MODE; //go to battle mode
                NSLog(@"changed to battle mode");
                
                //                NSLog(@"changed to battle mode");
                //                for (SKSpriteNode *node in Terrain3D)
                //                {
                //                    node.hidden = NO;
                //                    node.zPosition = -1;
                //                }
                //                for (SKSpriteNode *node in Walls3D)
                //                {
                //                    node.hidden = NO;
                //                    node.zPosition = -1;
                //                }
                //                [self BattleModeCastleTiles];
                //                [self BattleModeCannons];
                //                [self BattleModeCastles];
                //                [self BattleModeWalls];
                //                [theTimer invalidate];
                theTimer = nil;
                BattleTimer = [NSTimer scheduledTimerWithTimeInterval:BATTLE_TIME
                                                               target:self
                                                             selector:@selector(timerFireMethod:)
                                                             userInfo:nil
                                                              repeats:NO];
            }
            
            break;
            
            
        default:
            break;
    }
    //remove a second from the display
}

-(void)BattleModeWalls{
    for(SKSpriteNode *singleWall in componentWallArray){
        [self makeWall3D:singleWall];
    }
} // never called
-(void)makeWall3D:(SKSpriteNode*)singleWall{
    NSMutableArray* wallArray1 = [self extractRectangleTiles:@"3DWallsAllPartOne" NumberOfTiles:63];
    NSMutableArray* wallArray2 = [self extractRectangleTiles:@"3DWallsAllPartTwo" NumberOfTiles:63];
    NSMutableArray* wallArray3 = [self extractRectangleTiles:@"3DWallsAllPartThree" NumberOfTiles:63];
    int imageInd = [self get3DWallImageIndex:singleWall];
    int wallArrayNum = imageInd / 63;
    imageInd %= 63;
    
    CGPoint position = [self convertPoint:singleWall.position fromNode:self];
    SKSpriteNode *castleWall3D = [SKSpriteNode spriteNodeWithTexture:[wallArray1 objectAtIndex:17]];
    
    switch (wallArrayNum) {
        case 0:
            [castleWall3D setTexture:[wallArray3 objectAtIndex:imageInd]];
            break;
        case 1:
            [castleWall3D setTexture:[wallArray2 objectAtIndex:imageInd]];
            break;
        case 2:
            [castleWall3D setTexture:[wallArray1 objectAtIndex:imageInd]];
            break;
    }
    
    castleWall3D.scale = MAP_SCALE;
    castleWall3D.position = CGPointMake(position.x, position.y+6);
    castleWall3D.zPosition = 3 + -0.0000001*castleWall3D.position.y;
    castleWall3D.hidden = NO;
    [self MakePhysicsBody:castleWall3D ForType:WALL3D_BODY];
    [self addChild:castleWall3D];
    [Walls3D addObject:castleWall3D];
}
-(int)get3DWallImageIndex:(SKSpriteNode*)wall{
    int imageInd = 0;
    char teamChar = 'B';
    if( [wall.name isEqualToString:@"RedWall"] )
        teamChar = 'R';
    else if( [wall.name isEqualToString:@"BlueWall"] )
        teamChar = 'B';
    
    int colPos = [self getXRowNum:wall.position] + 1;
    int rowPos = [self getYInvertedColNum:wall.position] + 1;
    if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 0; // isolated
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 1; // up
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 2; // right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,0,0,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 3; // up, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,1,0,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 4; // up-right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 5; // down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 6; // up, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,1,2,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 7; // right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,1,2,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 8; // right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,0,0,1,1,2,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 9; // up, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,1,0,1,1,2,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 10; // up-right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,0,0,1,1,2,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 11; // up, right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,1,0,1,1,2,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 12; // up-right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 13; // left
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,2,1,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 14; // up, left
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,2,1,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 15; // up-left
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 16; // left, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,0,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 17; // up, left, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,1,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 18; // up-right, left
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,0,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 19; // up-left, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,1,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 20; // left-up-right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,0,0,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 21; // left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,0,1,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 22; // left-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,2,1,1,0,0,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 23; // up, left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,2,1,1,0,1,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 24; // up, left-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,2,1,1,0,0,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 25; // up-left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,2,1,1,0,1,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 26; // up-left-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,0,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 27; // left, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,0,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 28; // left, right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,1,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 29; // left-down, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,1,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 30; // left-down-right
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,0,1,1,1,0,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 31; // up, left, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,1,1,1,1,0,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 32; // up-right, left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,0,1,1,1,0,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 33; // up, left, right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,1,1,1,1,0,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 34; // up-right-down, left
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,0,1,1,1,1,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 35; // up, left-down, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,1,1,1,1,1,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 36; // up-right, left-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,0,1,1,1,1,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 37; // up, left-down-right
    else if( [self CheckWallMapTileSurroundings:(int[9]){0,1,1,1,1,1,1,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 38; // up-right-down-left
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,0,1,1,1,0,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 39; // up-left, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,1,1,1,1,0,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 40; // left-up-right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,0,1,1,1,0,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 41; // up-left, right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,1,1,1,1,0,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 42; // left-up-right-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,0,1,1,1,1,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 43; // up-left-down, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,1,1,1,1,1,1,0} team:teamChar i:rowPos j:colPos] )
        imageInd = 44; // right-up-left-down
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,0,1,1,1,1,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 45; // up-left-down-right
    else if( [self CheckWallMapTileSurroundings:(int[9]){1,1,1,1,1,1,1,1,1} team:teamChar i:rowPos j:colPos] )
        imageInd = 46; // surrounded
    
    if( [wall.name isEqualToString:@"RedWall"] )
        imageInd += 47;
    else if( [wall.name isEqualToString:@"BlueWall"] )
        imageInd += 47*2;
    
    imageInd += 16*3;
    return imageInd;
}
-(void)revertBattleModeWalls{
    
    
    
} // empty function

-(void)BattleModeCastles{
    NSMutableArray *tileArray = [self extractRectangleTiles:@"3DCastles" NumberOfTiles:109];
    for(SKSpriteNode __strong *singleCastle in unusedCastles){
        CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
        [singleCastle setTexture:[tileArray objectAtIndex:108]]; // castle with no flag
        singleCastle.xScale = MAP_SCALE;
        singleCastle.yScale = MAP_SCALE;
        singleCastle.position = CGPointMake(position.x, position.y);
        
    }
    [self updateCastleWind:8 windSpeed:0];
    
}
-(void)updateCastleWind:(int)windDir windSpeed:(float)windSpd{
    NSMutableArray *tileArray = [self extractRectangleTiles:@"3DCastles" NumberOfTiles:109];
    
    // wind is number from 0~10, is adjusted to time delay for looping:
    // looping range is .1 to 1 sec between images
    windSpd /= 10.0;
    if( windSpd > .9 )
        windSpd = .9;
    if( windSpd < 0 )
        windSpd = 0;
    windSpd = 1 - windSpd; // windSpd inversely proportional to timePerFrame
    
    for(SKSpriteNode __strong *singleCastle in usedCastles){
        CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
        int imageInd = 0; // yellow castle
        if ([singleCastle.name isEqualToString:@"RedCastle"]) {
            imageInd = 36; // red castle
        }
        else if ([singleCastle.name isEqualToString:@"BlueCastle"]){
            imageInd = 72; // blue castle
        }
        imageInd += 4 * windDir; // offset to find image w/ proper wind direction
        
        [singleCastle setTexture:[tileArray objectAtIndex:imageInd]];
        
        singleCastle.xScale = MAP_SCALE;
        singleCastle.yScale = MAP_SCALE;
        singleCastle.position = CGPointMake(position.x, position.y);
        
        NSArray *animateArray = [tileArray subarrayWithRange:NSMakeRange(imageInd, 4)]; // get 4 images to animate
        NSArray *reversedArray = [[animateArray reverseObjectEnumerator] allObjects]; // reverse array
        SKAction *animateAction = [SKAction animateWithTextures:reversedArray timePerFrame:windSpd]; // make animation
        [singleCastle runAction:[SKAction repeatActionForever:animateAction]]; // run animation forever
    }
}
-(void)revertBattleModeCastles{
    NSMutableArray *tileArray = [self extractTiles:@"2DCastleCannon"];
    for(SKSpriteNode __strong *singleCastle in unusedCastles){
        CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
        [singleCastle setTexture:[tileArray objectAtIndex:31]];
        singleCastle.xScale = MAP_SCALE;
        singleCastle.yScale = MAP_SCALE;
        singleCastle.position = CGPointMake(position.x, position.y);
    }
    for(SKSpriteNode __strong *singleCastle in usedCastles){
        CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
        [singleCastle setTexture:[tileArray objectAtIndex:30]];
        singleCastle.xScale = MAP_SCALE;
        singleCastle.yScale = MAP_SCALE;
        singleCastle.position = CGPointMake(position.x, position.y);
    }
}

-(void)BattleModeCastleTiles{
    NSMutableArray *tileArray = [self extractTiles:@"3DFloor"];
    for (SKSpriteNode *node in castleFloorTiles)
    {
        [node setTexture:[tileArray objectAtIndex:2]];
    }
}
-(void)revertBattleModeCastleTiles{
    NSMutableArray *tileArray = [self extractTiles:@"2DTerrain"];
    int check = 1;
    int numInRow = 0;
    for (SKSpriteNode *node in castleFloorTiles)
    {
        if(0 == check%2) {
            [node setTexture:[tileArray objectAtIndex:3]];
            check+=2;
        }
        else
            [node setTexture:[tileArray objectAtIndex:4]];
        check++;
        numInRow++;
        if (numInRow%6 == 0)
            check++;
    }
}

-(void)BattleModeCannons{
    
    NSMutableArray *tileArray = [self extractTiles:@"3DCannon"];
    for(SKSpriteNode __strong *singleCannon in cannons){
        CGPoint position = [self convertPoint:singleCannon.position fromNode:self];
        [singleCannon setTexture:[tileArray objectAtIndex:0]];
        singleCannon.xScale = MAP_SCALE;
        singleCannon.yScale = MAP_SCALE;
        singleCannon.position = CGPointMake(position.x, position.y);
    }
}
-(void)revertBattleModeCannons{
    NSMutableArray *tileArray = [self extractTiles:@"2DCastleCannon"];
    for(SKSpriteNode __strong *singleCannon in cannons)
    {
        CGPoint position = [self convertPoint:singleCannon.position fromNode:self];
        [singleCannon setTexture:[tileArray objectAtIndex:27]];
        singleCannon.xScale = MAP_SCALE;
        singleCannon.yScale = MAP_SCALE;
        singleCannon.position = CGPointMake(position.x, position.y);
    }
}

-(bool)CheckWaterMapTileSurroundings:(int*)checks i:(int)row j:(int)col{
    // called by setupMap() and update3Dmap()
    // checks[] array is of size 9, and corresponds to the following positions:
    /* 0 1 2
     3 4 5
     6 7 8 */
    // position 4 is the water being checked
    // i and j are the row and column of position 4
    // 1 == must be water
    // 0 == must not be water
    // 2 == does not matter
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if( checks[i*3+j] == 1 )
            { // check mapArray == ' '
                if( mapArray[i+row-1][j+col-1] != ' ' )
                    return false; // check failed
            }
            else if( checks[i*3+j] == 0 )
            { // check mapArray != ' '
                if( mapArray[i+row-1][j+col-1] == ' ' )
                    return false; // check failed
            }
            // else if( checks == 2 ) do nothing
        } // for cols
    } // for rows
    return true; // all checks passed
}

NSMutableArray *Terrain2D;
-(void)setupMap:(NSString *)fileName withExtension:(NSString *)extension{
    firstClick = true;
    //Load map
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:extension];
    NSError *error;
    NSString *mapFile = [NSString stringWithContentsOfFile:filePath
                                                  encoding:NSASCIIStringEncoding
                                                     error:&error];
    //NSLog(@"%@", mapFile);
    NSArray *mapLines = [mapFile componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    NSMutableArray *map = [NSMutableArray arrayWithArray:mapLines];
    
    
    
    // Store map dimensions
    NSArray *mapDimensions = [[mapLines objectAtIndex:1] componentsSeparatedByString:@" "];
    NSNumber *MAP_WIDTH = [mapDimensions objectAtIndex:0];
    NSNumber *MAP_HEIGHT = [mapDimensions objectAtIndex:1];
    //NSLog(@"%d %d", [MAP_HEIGHT integerValue] , [MAP_WIDTH integerValue]);
    
    
    //create map array
    for (int i = 0; i < [MAP_HEIGHT integerValue] + 2; i++) {
        for (int j = 0; j < [MAP_WIDTH integerValue] + 2; j++) {
            mapArray[i][j] = [[map objectAtIndex:i+2] characterAtIndex:j];
            //NSLog(@"%d %d %c", i, j, mapArray[i][j]);
        }
    }
    
    
    
    // STORE BRWATER and CASTLE COORDINATES
    // store grid data and locations
    for (int i = 1; i < [MAP_HEIGHT integerValue] + 1; i++) {
        for (int j = 1; j < [MAP_WIDTH integerValue] + 1; j++) {
            gridNode *node = [[gridNode alloc] init]; // add gridNode to gridLayout array to track it
            [node setNodeBRWater:node :mapArray[i][j]]; // setBRWater as 'B' or 'R' or ' ' (water)
            if ([node getNodeBRWater:node] == 'B' || [node getNodeBRWater:node] == 'R' ) { // if Blue or Red then it can be grass
                [node setNodeIsGrass:node];
            }
            else if ([node getNodeBRWater:node] == ' ') {
                
            }
            gridLayout[i - 1][j - 1] = node; // gridLayout holds 'B' 'R' or ' ' (water)
        }
    }
    
    
    
    //NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
    // +2 for first two lines in file +MAP_HEIGHT for # of lines in map +2 for border of map
    int startOfCastleInformation = (int)(2 + [MAP_HEIGHT integerValue] + 2);
    NSArray *castleInformation = [[mapLines objectAtIndex:startOfCastleInformation] componentsSeparatedByString:@"\n"];
    //NSArray holds #castles: 10 and their coordinates 4 5 \n...13,5\n...
    
    
    int number_of_castles = (int)[[castleInformation objectAtIndex:0] integerValue];
    
    
    for (int i = 0; i < number_of_castles; i++) {
        // store castle coordinates
        NSArray *castleCoordinates = [[mapLines objectAtIndex:startOfCastleInformation + i + 1] componentsSeparatedByString:@" "];
        NSNumber *u = [castleCoordinates objectAtIndex:0];
        NSNumber *v = [castleCoordinates objectAtIndex:1];
        
        gridNode *node = [[gridNode alloc] init]; // add gridNode to gridLayout array to track it
        int xRow = (int)([u integerValue]+1);
        int yCol = (int)[v integerValue];
        
        [node setNodeIsCastle:gridLayout[yCol][xRow]]; // set node as castle
        
    }
    
    
    
    NSMutableArray *terrainTileArray = [self extractTiles:@"2DTerrain"];
    
#pragma mark Map Population
    int y = 640+20;// - 12 * MAP_SCALE / 2;
    for (int i = 1; i < [MAP_HEIGHT integerValue] + 1; i++) {
        int x = 12 * MAP_SCALE / 2;
        for (int j = 1; j < [MAP_WIDTH integerValue] + 1; j++) {
            
            
            /* LAND TILE PLACEMENTS */
            // place dark grass if all surrounding tiles aren't water
            //NSLog(@"%d %d %c", i , j, mapArray[i][j]);
            if (((i + j) % 2 == 0) &&
                (mapArray[i][j] != ' '))
            {
                SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[terrainTileArray objectAtIndex:29]];
                tile.position = CGPointMake(x,y);
                tile.scale = MAP_SCALE;
                if (mapArray[i][j] == 'R') {
                    [tile setName:@"R"];
                }
                else if (mapArray[i][j] == 'B') {
                    [tile setName:@"B"];
                }
                [self addChild:tile];
                [Terrain2D addObject:tile];
            }
            // place light grass if all surrounding tiles aren't water
            else if (((i + j) % 2 == 1) &&
                     (mapArray[i][j] != ' '))
            {
                SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[terrainTileArray objectAtIndex:28]];
                tile.position = CGPointMake(x,y);
                tile.scale = MAP_SCALE;
                if (mapArray[i][j] == 'R') {
                    [tile setName:@"R"];
                }
                else if (mapArray[i][j] == 'B') {
                    [tile setName:@"B"];
                }
                [self addChild:tile];
                [Terrain2D addObject:tile];
            }
            
            /* WATER TILE PLACEMENT */
            else
            {
                int imageInd = 5;
                
                // Top left shoreline
                if ( [self CheckWaterMapTileSurroundings:(int[]){0,0,2,0,1,1,2,1,1} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 12;
                    else
                        imageInd = 13;
                }
                // Top shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){2,0,2,1,1,1,1,1,1} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 26;
                    else
                        imageInd = 27;
                }
                // Top right shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){2,0,0,1,1,0,1,1,1} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 24;
                    else
                        imageInd = 25;
                }
                // Left shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,0,1,1,2,2,2} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 14;
                    else
                        imageInd = 15;
                }
                // Right shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){2,2,2,1,1,0,1,1,0} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 22;
                    else
                        imageInd = 23;
                }
                // Bottom left shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,0,1,1,0,0,0} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 16;
                    else
                        imageInd = 17;
                }
                // Bottom shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,2,0,2} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 18;
                    else
                        imageInd = 19;
                }
                // Bottom right shoreline
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,2,1,2,0,2,0,0} i:i j:j] )
                {
                    if( (i+j) % 2 )
                        imageInd = 20;
                    else
                        imageInd = 21;
                }
                // Open seas yo
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,1,1,1} i:i j:j] )
                {
                    imageInd = 5;
                }
                // thin middle channel (forward slash shape)
                else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,1,1,1,1,1,0} i:i j:j] )
                {
                    imageInd = 6;
                }
                // thin middle channel (backward slash shape)
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,0,1,1,1,0,1,1} i:i j:j] )
                {
                    imageInd = 7;
                }
                // Top left corner tile
                else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,1,1,1,1,1,1} i:i j:j] )
                {
                    imageInd = 8;
                }
                // Top right corner tile
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,0,1,1,1,1,1,1} i:i j:j] )
                {
                    imageInd = 11;
                }
                // Bottom left corner tile
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,0,1,1} i:i j:j] )
                {
                    imageInd = 9;
                }
                // Bottom right corner tile
                else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,1,1,0} i:i j:j] )
                {
                    imageInd = 10;
                }
                
                SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[terrainTileArray objectAtIndex:imageInd]];
                tile.position = CGPointMake(x,y);
                tile.scale = MAP_SCALE;
                [self addChild:tile];
            }
            x += 12 * MAP_SCALE;
        }
        y -= 12 * MAP_SCALE;
    }
    
    
    /* Castles */
    FIRST_SELECT_CASTLE_STAGE = true;
    NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
    /* Place castles at coordinates */
    // +2 for first two lines in file +MAP_HEIGHT for # of lines in map +2 for border of map
    int startOfCastleInfo = 2 + [MAP_HEIGHT integerValue] + 2;
    NSArray *castleInfo = [[mapLines objectAtIndex:startOfCastleInfo] componentsSeparatedByString:@"\n"];
    NUM_CASTLES = [[castleInfo objectAtIndex:0] integerValue];
    //NSLog(@"num castles info = %d", numCastles);
    
    
    // NSMutableArray that keeps track of castles that have not been used
    unusedCastles =[NSMutableArray arrayWithCapacity:NUM_CASTLES];
    // NSMutableArray that keeps track of castles that have been used
    usedCastles = [NSMutableArray arrayWithCapacity:NUM_CASTLES];
    // NSMutableArray that keeps track of selected castle
    selectedCastle = [NSMutableArray arrayWithCapacity:1];
    
    
    for (int i = 0; i < NUM_CASTLES; i++) {
        // store castle coordinates
        NSArray *castleCoordinates = [[mapLines objectAtIndex:startOfCastleInfo + i + 1] componentsSeparatedByString:@" "];
        NSNumber *u = [castleCoordinates objectAtIndex:0];
        NSNumber *v = [castleCoordinates objectAtIndex:1];
        SKSpriteNode *castleImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:31]];
        castleImage.scale = MAP_SCALE;
        castleImage.position = CGPointMake(([u integerValue]+1)*12*MAP_SCALE,
                                           672-([v integerValue]+1)*12*MAP_SCALE);
        //NSLog(@"u = %ld, v = %ld, mapArray[i][j] = %c", (long)[u integerValue], (long)[v integerValue], mapArray[[v integerValue]+1][[u integerValue]+1]);
        castleImage.zPosition = 1;
        if (mapArray[[v integerValue]+1][[u  integerValue]+1] == 'R') {
            [castleImage setName:@"RedCastle"];
        }
        else if (mapArray[[v integerValue]+1][[u  integerValue]+1] == 'B') {
            [castleImage setName:@"BlueCastle"];
        }
        
        [self addChild:castleImage];
        [unusedCastles addObject:castleImage];
    }
    
    //setup cannons for later usage
    cannons = [NSMutableArray arrayWithCapacity:20];
    // basic AI
    oppCannons = [NSMutableArray arrayWithCapacity:20];
    // array must be initialized somewhere. otherwise it's nil
    wallsOnGrid = [NSMutableArray arrayWithCapacity:100]; //to prevent overwriting blocks
    outlineWallsOnGrid = [NSMutableArray arrayWithCapacity:100];
    tempWallShapeNodes = [NSMutableArray arrayWithCapacity:15];
    
    
    
    
}
-(void)update3Dmap:(NSString *)fileName withExtension:(NSString *)extension windDirection:(int)windDir windSpeed:(float)windSpd{
    
    /* wind image order is
     8 == no wind
     7 == up
     6 == up right
     5 == right
     4 == down right
     3 == down
     2 == down left
     1 == left
     0 == up left
     */
    //RC:WTF
    for (SKSpriteNode* t in Terrain3D) {
        [Terrain3D removeObject:t];
        [t removeFromParent];
    }
    
    //Load map
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:extension];
    NSError *error;
    NSString *mapFile = [NSString stringWithContentsOfFile:filePath
                                                  encoding:NSASCIIStringEncoding
                                                     error:&error];
    
    NSArray *mapLines = [mapFile componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    // NSMutableArray *map = [NSMutableArray arrayWithArray:mapLines];
    
    
    // Store map dimensions
    NSArray *mapDimensions = [[mapLines objectAtIndex:1] componentsSeparatedByString:@" "];
    NSNumber *MAP_WIDTH = [mapDimensions objectAtIndex:0];
    NSNumber *MAP_HEIGHT = [mapDimensions objectAtIndex:1];
    
    
    // Had to split 3DTerrain into different PNGs because it was too big for Objective-C
    NSMutableArray *terrainTileArray1 = [self extractTiles:@"3DTerrainPartOne"];
    
    NSMutableArray *terrainTileArray2 = [self extractTiles:@"3DTerrainPartTwo"];
    
    NSMutableArray *terrainTileArray3 = [self extractTiles:@"3DTerrainPartThree"];
    
    NSMutableArray *terrainTileArray4 = [self extractTiles:@"3DTerrainPartFour"];
    
    windSpd /= 10.0;
    if( windSpd > .9 )
        windSpd = .9;
    if( windSpd < 0 )
        windSpd = 0;
    windSpd = 1 - windSpd; // windSpd inversely proportional to timePerFrame
    
#pragma mark Map Population
    int y = 640+20;// - 12 * MAP_SCALE / 2;
    for (int i = 1; i < [MAP_HEIGHT integerValue] + 1; i++) {
        int x = 12 * MAP_SCALE / 2;
        for (int j = 1; j < [MAP_WIDTH integerValue] + 1; j++) {
            
            int terrainTileArrayNum = -1;
            int imageInd = -1;
            
            /* LAND TILE PLACEMENTS */
            // place grass if all surrounding tiles aren't water -- not being applied?
            if ( mapArray[i][j] != ' ' )
            {
                terrainTileArrayNum = 4;
                imageInd = 3;
            }
            
            /* WATER TILE PLACEMENT */
            // Top left shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){0,0,2,0,1,1,2,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 2;
                imageInd = 3;
            }
            // Top shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){2,0,2,1,1,1,1,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 4;
                imageInd = 2;
            }
            // Top right shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){2,0,0,1,1,0,1,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 4;
                imageInd = 1;
            }
            // Left shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,0,1,1,2,2,2} i:i j:j] )
            {
                terrainTileArrayNum = 3;
                imageInd = 0;
            }
            // Right shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){2,2,2,1,1,0,1,1,0} i:i j:j] )
            {
                terrainTileArrayNum = 4;
                imageInd = 0;
            }
            // Bottom left shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,0,1,1,0,0,0} i:i j:j] )
            {
                terrainTileArrayNum = 3;
                imageInd = 1;
            }
            // Bottom shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,2,0,2} i:i j:j] )
            {
                terrainTileArrayNum = 3;
                imageInd = 2;
            }
            // Bottom right shoreline
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,2,1,2,0,2,0,0} i:i j:j] )
            {
                terrainTileArrayNum = 3;
                imageInd = 3;
            }
            // Open seas yo
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,1,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 1;
                imageInd = 0;
            }
            else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,1,1,1,1,1,0} i:i j:j] )
            {
                terrainTileArrayNum = 1;
                imageInd = 1;
            }
            // thin middle channel (backward slash shape)
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,0,1,1,1,0,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 1;
                imageInd = 2;
            }
            // Top left corner tile
            else if ( [self CheckWaterMapTileSurroundings:(int[]){0,1,1,1,1,1,1,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 1;
                imageInd = 3;
            }
            // Top right corner tile
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,0,1,1,1,1,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 2;
                imageInd = 2;
            }
            // Bottom left corner tile
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,0,1,1} i:i j:j] )
            {
                terrainTileArrayNum = 2;
                imageInd = 0;
            }
            // Bottom right corner tile
            else if ( [self CheckWaterMapTileSurroundings:(int[]){1,1,1,1,1,1,1,1,0} i:i j:j] )
            {
                terrainTileArrayNum = 2;
                imageInd = 1;
            }
            
            imageInd *= 36;
            imageInd += 4 * windDir;
            NSMutableArray* tileArray;
            switch (terrainTileArrayNum)
            { // terrain images split up into 4 .png files
                case 1:
                    tileArray = terrainTileArray1;
                    imageInd++; // extra image at beginning
                    break;
                case 2:
                    tileArray = terrainTileArray2;
                    break;
                case 3:
                    tileArray = terrainTileArray3;
                    break;
                case 4:
                    tileArray = terrainTileArray4;
                    break;
            }
            
            SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[tileArray objectAtIndex:imageInd]];
            tile.position = CGPointMake(x,y);
            tile.scale = MAP_SCALE;
            [self addChild:tile];
            [Terrain3D addObject:tile];
            NSArray *animateArray = [tileArray subarrayWithRange:NSMakeRange(imageInd, 4)]; // get 4 images to loop
            NSArray *reversedArray = [[animateArray reverseObjectEnumerator] allObjects]; // reverse the order
            SKAction *animateAction = [SKAction animateWithTextures:reversedArray timePerFrame:windSpd]; // loop animation
            [tile runAction:[SKAction repeatActionForever:animateAction]]; // run animation forever
            
            x += 12 * MAP_SCALE;
        }
        y -= 12 * MAP_SCALE;
    }
    
}

// DS,AM (2/22/2015): originally one function (CursorAndCannon), but split into two
-(void)PlaceCannon:(CGPoint)touchLocation{
    SKSpriteNode *spriteTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    
    //Setup the cursor for that initial click
    if(firstClick && [spriteTouched.name isEqualToString:@"InnerCastleTile"]){
        NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
        cannonCountImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:0]];
        cannonCountImage.position = touchLocation;
        cannonCountImage.scale = MAP_SCALE;
        cannonCountImage.zPosition = 1;
        [cannonCountImage setName:@"Cursor"];
        [self addChild:cannonCountImage];
        
        // basic AI
        //		oppCannonCountImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:0]];
        //		oppCannonCountImage.position = oppCannonPosition;
        //		oppCannonCountImage.scale = MAP_SCALE;
        //		oppCannonCountImage.zPosition = 1;
        //		[oppCannonCountImage setName:@"Cursor"];
        //		[self addChild:oppCannonCountImage];
        
        firstClick = false;
    }
    
    
    /* Cannons for the Blue team*/
    if([spriteTouched.name isEqualToString:@"InnerCastleTile"] && CannonCount < 3
       && GameMode == CANNON_MODE){
        
        [self PlaySound:@"tick"];
        
        CGPoint newPosition;
        float step = 24.0; // Grid step size.
        newPosition.x = step * floor((touchLocation.x / step) + 0.5);
        newPosition.y = step * floor((touchLocation.y / step) + 0.5);
        
        NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
        
        if(teamChoice == BLUE_TEAM){
            [cannonCountImage setTexture:[castleTileArray objectAtIndex:24 + CannonCount]];
            //basic AI
            //[oppCannonCountImage setTexture:[castleTileArray objectAtIndex:15 + CannonCount]];
        }
        else{
            [cannonCountImage setTexture:[castleTileArray objectAtIndex:15 + CannonCount]];
            //basic AI
            //[oppCannonCountImage setTexture:[castleTileArray objectAtIndex:24 + CannonCount]];
        }
        cannonCountImage.scale = MAP_SCALE;
        cannonCountImage.zPosition = 1;
        cannonCountImage.position = newPosition;
        [cannonCountImage setName:@"Cursor"];
        
        //basic AI
        //		oppCannonCountImage.scale = MAP_SCALE;
        //		oppCannonCountImage.zPosition = 1;
        //		oppCannonPosition.x = 540 + ((2*24) * CannonCount);
        //		oppCannonCountImage.position = oppCannonPosition;
        //		[oppCannonCountImage setName:@"Cursor"];
        
        
    }
    
    //AM: not a clean way to do it, but cannot reset timer everytime the cannons switch place
    BOOL threeCannons = false;
    if (CannonCount == 3)
        threeCannons = true;
    
    /*RC: Must be here!*/
    if (CannonCount == 3 && GameMode == CANNON_MODE){
        GameMode = BATTLE_MODE; //go to battle mode
        option = @"3D";
        [self createSweep:@"Battle Mode"];
        NSLog(@"changed to first battle mode");
        //[self BattleModeCannons];
        //[self BattleModeCastleTiles];
        //[self BattleModeWalls];
        //[self BattleModeCastles];
        Terrain3D = [[NSMutableArray alloc] init];
        [self update3Dmap:@"NorthSouth" withExtension:@"map" windDirection:8 windSpeed:0];
        //RC:WTF
        for (SKSpriteNode *node in Terrain3D)
        {
            node.hidden = YES;
            node.zPosition = -1;
        }
        [CannonTimer invalidate];
        CannonTimer = nil;
        BattleTimer = [NSTimer scheduledTimerWithTimeInterval:BATTLE_TIME
                                                       target:self
                                                     selector:@selector(timerFireMethod:)
                                                     userInfo:nil
                                                      repeats:NO];
    }
    
    
    if([spriteTouched.name isEqualToString:@"Cursor"] && GameMode == CANNON_MODE){
        if(teamChoice == BLUE_TEAM){
            [spriteTouched setName:@"BlueCannon"];
        }
        else{
            [spriteTouched setName:@"RedCannon"];
        }
        
        NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
        SKSpriteNode *cannonImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:27]];
        // basic AI
        //SKSpriteNode *oppCannonImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:27]];
        
        cannonImage.scale = MAP_SCALE;
        // basic AI
        //oppCannonImage.scale = MAP_SCALE;
        
        CGPoint newPosition;
        float step = 24.0; // Grid step size.
        newPosition.x = step * floor((touchLocation.x / step) + 0.5);
        newPosition.y = step * floor((touchLocation.y / step) + 0.5);
        
        cannonImage.position = newPosition;
        // basic AI
        //oppCannonImage.position = oppCannonPosition;
        
        bool objectPresent = false;
        for(SKSpriteNode *cannon in cannons){
            if([cannonImage intersectsNode:cannon]){
                objectPresent = true;
            }
        }
        // basic AI
        //		for(SKSpriteNode *cannon in oppCannons){
        //			if([oppCannonImage intersectsNode:cannon]){
        //				objectPresent = true;
        //			}
        //		}
        for(SKSpriteNode *wall in componentWallArray){
            if([cannonImage intersectsNode:wall]){
                objectPresent = true;
            }
        }
        for(SKSpriteNode *castle in usedCastles){
            if([cannonImage intersectsNode:castle]){
                objectPresent = true;
            }
        }
        
        if(!objectPresent){
            //Play double tap sound effect
            [self PlaySound:@"place"];
            
            CannonCount++;
            [cannons addObject:cannonImage];
            cannonCountImage.zPosition = -1;
            cannonImage.zPosition = 2;
            [self addChild:cannonImage];
            
            // basic AI
            //			[oppCannons addObject:oppCannonImage];
            //			oppCannonCountImage.zPosition = -1;
            //			oppCannonImage.zPosition = 2;
            //			[self addChild:oppCannonImage];
        }
    }
    // the following segment is duplicated code?? -- RM 2/24/15
    //    if (CannonCount == 3 && GameMode == CANNON_MODE){
    //        GameMode = BATTLE_MODE; //go to battle mode
    //        NSLog(@"changed to first battle mode");
    //        [self BattleModeCannons];
    //        [self BattleModeCastleTiles];
    //        [self BattleModeWalls];
    //        [self BattleModeCastles];
    //        Terrain3D = [[NSMutableArray alloc] init];
    //        [self update3Dmap:@"NorthSouth" withExtension:@"map" windDirection:8 windSpeed:0];
    //        maxCannons = true;
    //        [CannonTimer invalidate];
    //        CannonTimer = nil;
    //        BattleTimer = [NSTimer scheduledTimerWithTimeInterval:BATTLE_TIME
    //                                                       target:self
    //                                                     selector:@selector(timerFireMethod:)
    //                                                     userInfo:nil
    //                                                      repeats:NO];
    //    }
    
}

//Handles the movement of the cannons
// DS,AM (2/22/2015): originally one function (CursorAndCannon), but split into two
-(void)SwivelCannon:(CGPoint)touchLocation{
    if(GameMode == BATTLE_MODE){
        [self PlaySound:@"tick"];
        
        
        for(SKSpriteNode __strong *singleCannon in cannons){
            CGFloat canX = singleCannon.position.x;
            CGFloat canY = singleCannon.position.y;
            //Look Right
            NSMutableArray *tileArray = [self extractTiles:@"3DCannon"];
            if(canX < touchLocation.x && canY < touchLocation.y) {
                //Look Left
                if (canY >= (touchLocation.y - 20) && canY <= (touchLocation.y + 20)){
                    [singleCannon setTexture:[tileArray objectAtIndex:5]];
                    
                }
                else{
                    [singleCannon setTexture:[tileArray objectAtIndex:6]];
                }
                singleCannon.xScale = MAP_SCALE;
                singleCannon.yScale = MAP_SCALE;
                
            }
            else if(canX < touchLocation.x && canY > touchLocation.y){
                
                if (canX >= (touchLocation.x - 20) && canX <= (touchLocation.x + 20)){
                    [singleCannon setTexture:[tileArray objectAtIndex:3]];
                }
                else{
                    [singleCannon setTexture:[tileArray objectAtIndex:4]];
                }
                singleCannon.xScale = MAP_SCALE;
                singleCannon.yScale = MAP_SCALE;
                
            }//this one
            else if(canX > touchLocation.x && canY < touchLocation.y ){
                if (canX >= (touchLocation.x - 30) && canX <= (touchLocation.x + 30)){
                    [singleCannon setTexture:[tileArray objectAtIndex:7]];
                }
                else{
                    [singleCannon setTexture:[tileArray objectAtIndex:0]];
                }
                singleCannon.xScale = MAP_SCALE;
                singleCannon.yScale = MAP_SCALE;
                
            }
            else if(canX > touchLocation.x && canY > touchLocation.y){
                if (canY >= (touchLocation.y - 20) && canY <= (touchLocation.y + 20)){
                    [singleCannon setTexture:[tileArray objectAtIndex:1]];
                }
                else{
                    [singleCannon setTexture:[tileArray objectAtIndex:2]];
                }
                singleCannon.xScale = MAP_SCALE;
                singleCannon.yScale = MAP_SCALE;
            }
        }
        
        // basic AI
        // Currently opp castles face direction of click rather than random point it is shooting at
        //		for(SKSpriteNode __strong *singleCannon in oppCannons){
        //			CGFloat canX = singleCannon.position.x;
        //			CGFloat canY = singleCannon.position.y;
        //			//Look Right
        //			NSMutableArray *tileArray = [self extractTiles:@"3DCannon"];
        //			if(canX < touchLocation.x && canY < touchLocation.y) {
        //				//Look Left
        //				if (canY >= (touchLocation.y - 20) && canY <= (touchLocation.y + 20)){
        //					[singleCannon setTexture:[tileArray objectAtIndex:5]];
        //
        //				}
        //				else{
        //					[singleCannon setTexture:[tileArray objectAtIndex:6]];
        //				}
        //				singleCannon.xScale = MAP_SCALE;
        //				singleCannon.yScale = MAP_SCALE;
        //
        //			}
        //			else if(canX < touchLocation.x && canY > touchLocation.y){
        //
        //				if (canX >= (touchLocation.x - 20) && canX <= (touchLocation.x + 20)){
        //					[singleCannon setTexture:[tileArray objectAtIndex:3]];
        //				}
        //				else{
        //					[singleCannon setTexture:[tileArray objectAtIndex:4]];
        //				}
        //				singleCannon.xScale = MAP_SCALE;
        //				singleCannon.yScale = MAP_SCALE;
        //
        //			}//this one
        //			else if(canX > touchLocation.x && canY < touchLocation.y ){
        //				if (canX >= (touchLocation.x - 30) && canX <= (touchLocation.x + 30)){
        //					[singleCannon setTexture:[tileArray objectAtIndex:7]];
        //				}
        //				else{
        //					[singleCannon setTexture:[tileArray objectAtIndex:0]];
        //				}
        //				singleCannon.xScale = MAP_SCALE;
        //				singleCannon.yScale = MAP_SCALE;
        //
        //			}
        //			else if(canX > touchLocation.x && canY > touchLocation.y){
        //				if (canY >= (touchLocation.y - 20) && canY <= (touchLocation.y + 20)){
        //					[singleCannon setTexture:[tileArray objectAtIndex:1]];
        //				}
        //				else{
        //					[singleCannon setTexture:[tileArray objectAtIndex:2]];
        //				}
        //				singleCannon.xScale = MAP_SCALE;
        //				singleCannon.yScale = MAP_SCALE;
        //			}
        //		}
    }
}

// RM (2/27/15): Add2DWalls
-(void)Add2DWall:(NSString*)team atLoc:(CGPoint)pos{
    // team is "Red" or "Blue" currently
    // if changed, change inside get2DWallImageIndex()
    NSMutableArray* wallImages = [self extractTiles:@"2DWalls"];
    int imageInd = 4; // default initial value
    SKSpriteNode* wallPiece = [SKSpriteNode spriteNodeWithTexture:[wallImages objectAtIndex:imageInd]];
    wallPiece.scale = MAP_SCALE;
    wallPiece.position = pos;
    wallPiece.name = [NSString stringWithFormat:@"%@Wall",team]; // "[Color]Wall"
    
    char teamChar = 'w'; // default initial value of char stored in mapArray to represent a team's wall
    if( [team isEqualToString:@"Red"] )
        teamChar = 'W';
    else if( [team isEqualToString:@"Blue"] )
        teamChar = 'w';
    int xPos = [self getXRowNum:pos];
    int yPos = [self getYInvertedColNum:pos];
    mapArray[yPos+1][xPos+1] = teamChar;
    
    [componentWallArray addObject:wallPiece];
    [self addChild: wallPiece];
    [self reset2DWallImages:team];
} // ADD WALLS USING THIS!!
-(int)get2DWallImageIndex:(NSString*)team atLoc:(CGPoint)pos{
    char teamChar = 'B'; // default initial value of character to represent team color
    if( [team isEqualToString:@"Red"] )
        teamChar = 'R';
    else if( [team isEqualToString:@"Blue"] )
        teamChar = 'B';
    
    int imageInd = 4; // default initial value
    int colPos = [self getXRowNum:pos] + 1;
    int rowPos = [self getYInvertedColNum:pos] + 1;
    if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 4; // isolated
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 5; // up
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 6; // right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 7; // up, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 8; // down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 9; // up, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,0,1,1,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 10; // right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,0,1,1,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 11; // up, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 12; // left
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,1,1,0,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 13; // up, left
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 14; // left, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,1,1,1,2,0,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 15; // up, left, right
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 16; // left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,1,1,0,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 17; // up, left, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,0,2,1,1,1,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 18; // left, right, down
    else if( [self CheckWallMapTileSurroundings:(int[9]){2,1,2,1,1,1,2,1,2} team:teamChar i:rowPos j:colPos] )
        imageInd = 19; // up, left, right, down
    
    // default color is yellow, offset for red and blue:
    if( teamChar == 'R' )
        imageInd += 16 * 1;
    else if( teamChar == 'B' )
        imageInd += 16 * 2;
    return imageInd;
}
-(bool)CheckWallMapTileSurroundings:(int*)checks team:(char)team i:(int)row j:(int)col{
    // called by get2DWallImageIndex(), get3DWallImageIndex()
    // checks[] array is of size 9, and corresponds to the following positions:
    /* 0 1 2
     3 4 5
     6 7 8 */
    // position 4 is the wall being checked
    // i and j are the row and column of position 4
    // 1 == must be wall
    // 0 == must not be wall
    // 2 == does not matter
    
    // teamChar is the character stored in mapArray to represent each team's walls
    char teamChar = 'w';
    if( team == 'R' )
        teamChar = 'W';
    else if( team == 'B' )
        teamChar = 'w';
    
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if( checks[i*3+j] == 1 )
            { // check mapArray == ' '
                if( mapArray[i+row-1][j+col-1] != teamChar )
                    return false; // check failed
            }
            else if( checks[i*3+j] == 0 )
            { // check mapArray != ' '
                if( mapArray[i+row-1][j+col-1] == teamChar )
                    return false; // check failed
            }
            // else if( checks == 2 ) do nothing
        } // for cols
    } // for rows
    return true; // all checks passed
}
-(void)reset2DWallImages:(NSString*)team{
    NSMutableArray* castleImages = [self extractTiles:@"2DWalls"];
    NSString* spriteName = [NSString stringWithFormat:@"%@Wall",team]; // only check walls of same team
    for (SKSpriteNode* wallTile in componentWallArray) {
        if ([wallTile.name isEqualToString:spriteName]) {
            [wallTile setTexture:[castleImages objectAtIndex:[self get2DWallImageIndex:team atLoc:wallTile.position]]];
        }
    }
}

-(void)CreateInitialCastle:(CGPoint)touchLocation{
    SKSpriteNode *spriteTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    
    // JL
    // renamed shai declaration of Data type
    int colClicked = spriteTouched.position.x/(12*MAP_SCALE);
    int rowClicked = (672-spriteTouched.position.y)/(12*MAP_SCALE);
    //	int rowPixelClicked = spriteTouched.position.y;
    //	int colPixelClicked = spriteTouched.position.x;
    NSLog(@"%d %d", rowClicked, colClicked);
    //NSLog(@"PX %d %d", rowPixelClicked, colPixelClicked);
    //oppCannonPosition.x	= 540;
    oppCannonPosition.y = 276;
    // -JL
    
    /* CASTLE SELECT STAGE */
    if (FIRST_SELECT_CASTLE_STAGE)
    {
        /* Castles */
        NSMutableArray *castleWallTileArray = [self extractTiles:@"2DWalls"];
        float offset = 12*MAP_SCALE/2;
        NSMutableArray *castleSelectTileArray = [self extractTiles:@"2DCastleSelect"];
        NSMutableArray *castleTileArray = [self extractTiles:@"2DCastleCannon"];
        
        
        castleFloorTiles = [[NSMutableArray alloc] init];
        
        // only remove tiles if clicking on castle, if clicking on grass do nothing
        if ([spriteTouched.name isEqualToString:@"RedCastle"] || [spriteTouched.name isEqualToString:@"BlueCastle"])
        {
            // remove all select tiles from previously selected castle
            [self removeChildrenInArray:selectCastleTiles];
            selectCastleTiles = [[NSMutableArray alloc] init];
        }
        
        // play sound after castle is clicked on
        [self PlaySound:@"gust2"];
        
        NSString* teamColor;
        bool castleClicked = NO;
        int colorImageOffsetMultiplier = 0;
        if( [spriteTouched.name isEqualToString:@"RedCastle"] )
        {
            teamChoice = RED_TEAM;
            NSLog(@"Red team chosen");
            teamColor = @"Red";
            castleClicked = YES;
            colorImageOffsetMultiplier = 1;
        }
        else if( [spriteTouched.name isEqualToString:@"BlueCastle"] )
        {
            teamChoice = BLUE_TEAM;
            NSLog(@"Blue team chosen");
            teamColor = @"Blue";
            castleClicked = YES;
            colorImageOffsetMultiplier = 2;
        }
        
        if( castleClicked )
        {
            if([unusedCastles containsObject:spriteTouched])
            {
                // Remove selected castle from unused array
                [unusedCastles removeObject:spriteTouched];
                // Put old selected castles back into unused array
                if( [selectedCastle count] != 0 )
                {
                    [unusedCastles addObjectsFromArray:selectedCastle];
                    // remove the colored castle upon selecting a different castle
                    [self removeChildrenInArray:selectedCastle];
                }
                
                // change image of selected castle..?
                SKSpriteNode *castleImage = [SKSpriteNode spriteNodeWithTexture:[castleTileArray objectAtIndex:28 + 1*colorImageOffsetMultiplier]];
                castleImage.scale = MAP_SCALE;
                castleImage.position = CGPointMake(spriteTouched.position.x, spriteTouched.position.y);
                castleImage.zPosition = 1;
                castleImage.name = [NSString stringWithFormat:@"%@Castle",teamColor];
                [self addChild:castleImage];
                [selectedCastle setObject:castleImage atIndexedSubscript:0];
                
                
                // Top Left Corner Select Piece
                SKSpriteNode *castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:0+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x-12*MAP_SCALE - offset, spriteTouched.position.y+12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Top Left Side Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:1+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x-12*MAP_SCALE - offset, spriteTouched.position.y + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Left Side Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:1+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x-12*MAP_SCALE - offset, spriteTouched.position.y-12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Left Corner Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:2+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x-12*MAP_SCALE - offset, spriteTouched.position.y-12*MAP_SCALE*2 + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Left Bottom Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:3+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x - offset, spriteTouched.position.y-12*MAP_SCALE*2 + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Right Bottom Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:3+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE - offset, spriteTouched.position.y-12*MAP_SCALE*2 + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Right Corner Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:4+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*2 - offset, spriteTouched.position.y-12*MAP_SCALE*2 + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Bottom Right Side Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:5+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*2 - offset, spriteTouched.position.y-12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Top Right Side Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:5+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*2 - offset, spriteTouched.position.y + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Top Right Corner Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:6+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*2 - offset, spriteTouched.position.y+12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Top Right Top Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:7+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE - offset, spriteTouched.position.y+12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                // Top Left Top Select Piece
                castleSelectTile = [SKSpriteNode spriteNodeWithTexture:[castleSelectTileArray objectAtIndex:7+8*colorImageOffsetMultiplier]];
                castleSelectTile.position = CGPointMake(spriteTouched.position.x - offset, spriteTouched.position.y+12*MAP_SCALE + offset);
                [selectCastleTiles addObject:castleSelectTile];
                
                for (SKSpriteNode* selectTile in selectCastleTiles) {
                    selectTile.scale = MAP_SCALE;
                    [self addChild:selectTile];
                }
            }
            // castle is double clicked, so we build wall around it
            else
            {
                [usedCastles addObject:spriteTouched];
                componentWallArray = [[NSMutableArray alloc] init];
                
                // JL
                // print out maparray castle wall in console
                for(int rowItr = 0; rowItr < 8; rowItr++){
                    for(int colItr = 0; colItr < 8; colItr++){
                        if(3 == rowItr && 3 == colItr){
                            printf("! ");
                            //                                                  printf("%c! ", mapArray[u-3+col][v-3+row]);
                        }
                        else {
                            if (' ' == mapArray[rowClicked-3+rowItr][colClicked-3+colItr]) {
                                printf("W ");
                                //                                                              SKSpriteNode *castleWallLeftTile = [SKSpriteNode spriteNodeWithTexture:[castleWallTileArray objectAtIndex:29]];
                                //                                                              castleWallLeftTile.scale = MAP_SCALE;
                                //                                                              castleWallLeftTile.position = CGPointMake(rowClicked, colClicked);//spriteTouched.position.x-12*MAP_SCALE*3 - offset, spriteTouched.position.y+12*MAP_SCALE*(2-i) + offset);
                                //                                                              [self addChild:castleWallLeftTile];
                                //                                                              [castleTileArray addObject:castleWallLeftTile];
                            }
                            else {
                                printf("%c ", mapArray[rowClicked-3+rowItr][colClicked-3+colItr]);
                            }
                            
                            /* Wall Placement */
                            // water
                            if (mapArray[rowClicked-3+rowItr][colClicked-3+colItr] == ' ') {
                                continue;
                            }
                            // top walls
                            else if (rowItr == 0) {
                                // top left corner 26
                                if (colItr == 0) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                        spriteTouched.position.x-12*MAP_SCALE*(3) - offset,
                                        spriteTouched.position.y+12*MAP_SCALE*3 + offset)];
                                }
                                // top right corner 32
                                else if (colItr == 7) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(4) - offset,
                                         spriteTouched.position.y+12*MAP_SCALE*3 + offset)];
                                }
                                // top
                                else {
                                    // top right corner tile
                                    if (mapArray[rowClicked-3+rowItr][colClicked-3+colItr+1] == ' ') {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y-12*MAP_SCALE*3 + offset)];
                                    }
                                    // top left corner tile
                                    else if (mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] == ' ') {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y+12*MAP_SCALE*3 + offset)];
                                    }
                                    else {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y+12*MAP_SCALE*3 + offset)];
                                    }
                                }
                            }
                            // bottom walls
                            else if (rowItr == 7) {
                                // bottom left corner 23
                                if (colItr == 0) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x-12*MAP_SCALE*(3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*4 + offset)];
                                }
                                // bottom right corner 29
                                else if (colItr == 7) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(4) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*4 + offset)];
                                }
                                // bottom
                                else {
                                    // bottom right corner tile
                                    if (mapArray[rowClicked-3+rowItr][colClicked-3+colItr+1] == ' ') {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y-12*MAP_SCALE*4 + offset)];
                                    }
                                    // bottom left corner tile
                                    else if (mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] == ' ') {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y-12*MAP_SCALE*4 + offset)];
                                    }
                                    
                                    // straight bottom tile
                                    else {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y-12*MAP_SCALE*4 + offset)];
                                    }
                                }
                            }
                            // left walls
                            else if (colItr == 0) {
                                // bottom left corner tile
                                if (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] == ' ') {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x-12*MAP_SCALE*3 - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*(rowItr-3) + offset)];
                                }
                                // straight left tile
                                else {
                                    // top left
                                    if (mapArray[rowClicked-3+rowItr-1][colClicked-3+colItr] == ' ') {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                             spriteTouched.position.y+12*MAP_SCALE*2 + offset)];
                                    }
                                    else {
                                        [self Add2DWall:teamColor atLoc:CGPointMake(
                                             spriteTouched.position.x-12*MAP_SCALE*3 - offset,
                                             spriteTouched.position.y-12*MAP_SCALE*(rowItr-3) + offset)];
                                    }
                                }
                            }
                            // right walls
                            else if (colItr == 7) {
                                // bottom right corner tile
                                if (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] == ' ') {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*4 - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*(rowItr-3) + offset)];
                                }
                                // straight right tile
                                else {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*4 - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*(rowItr-3) + offset)];
                                }
                            }
                            // building interior walls when castle walls would be built on water
                            else if (rowItr == 6) {
                                // build straight walls
                                if ((mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr][colClicked-3+colItr+1] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*3 + offset)];
                                }
                                // top right corner
                                else if ((mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] != ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] != ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr-1] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*3 + offset)];
                                }
                                // top left corner
                                else if ((mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] != ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] != ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr+1] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*3 + offset)];
                                }
                                // bottom right corner
                                else if ((mapArray[rowClicked-3+rowItr][colClicked-3+colItr+1] == ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] == ' ') &&
                                         (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr+1] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*3 + offset)];
                                }
                            }
                            else if (colItr == 6) {
                                // top left corner
                                if ( (mapArray[rowClicked-3+rowItr][colClicked-3+colItr+1] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr+1][colClicked-3+colItr+1] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y-12*MAP_SCALE*2 + offset)];
                                }
                            }
                            else if (rowItr == 1) {
                                // bottom right corner
                                if ((mapArray[rowClicked-3+rowItr][colClicked-3+colItr-1] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr-1][colClicked-3+colItr] != ' ') &&
                                    (mapArray[rowClicked-3+rowItr-1][colClicked-3+colItr-1] == ' ')) {
                                    [self Add2DWall:teamColor atLoc:CGPointMake(
                                         spriteTouched.position.x+12*MAP_SCALE*(colItr-3) - offset,
                                         spriteTouched.position.y+12*MAP_SCALE*2 + offset)];
                                }
                            }
                        }
                        
                    }
                    
                    printf("\n");
                }
                
                // Place Castle Floor Tiles
                for (int i = 0; i<6;i++)
                {
                    for (int j = 0; j<6; j++)
                    {
                        if (mapArray[rowClicked-2+i][colClicked-2+j] == 'w' ||
                            mapArray[rowClicked-2+1][colClicked-2+j] == 'W' ||
                            mapArray[rowClicked-2+i][colClicked-2+j] == ' ') {
                            continue;
                        }
                        else {
                            // place colored tile
                            if (((i + j) % 2 == 0))
                            {
                                SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[castleWallTileArray objectAtIndex:0+colorImageOffsetMultiplier]];
                                tile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*(j-2) - offset,spriteTouched.position.y+12*MAP_SCALE*(2-i) + offset);
                                tile.scale = MAP_SCALE;
                                [tile setName:@"InnerCastleTile"];
                                [self addChild:tile];
                                [castleFloorTiles addObject:tile];
                            }
                            // place black tile
                            else if (((i + j) % 2 == 1))
                            {
                                SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[castleWallTileArray objectAtIndex:3]];
                                tile.position = CGPointMake(spriteTouched.position.x+12*MAP_SCALE*(j-2) - offset,spriteTouched.position.y+12*MAP_SCALE*(2-i) + offset);
                                tile.scale = MAP_SCALE;
                                [tile setName:@"InnerCastleTile"];
                                [self addChild:tile];
                                [castleFloorTiles addObject:tile];
                            }
                        }
                    }
                }
                
                FIRST_SELECT_CASTLE_STAGE = false;
                
                // once the castle walls are placed, we set the timer for placing cannons
                GameMode = CANNON_MODE; //go to select castle
                NSLog(@"changed to cannon mode");
                [CastleTimer invalidate];
                CastleTimer = nil;
                CannonTimer = [NSTimer scheduledTimerWithTimeInterval:CANNON_TIME
                                                               target:self
                                                             selector:@selector(timerFireMethod:)
                                                             userInfo:nil
                                                              repeats:NO];

            }
        }
    }
}

-(void)CannonFiringAnimation:(CGPoint)touchLocation{
    //handles the firing of cannonballs
    if(GameMode == BATTLE_MODE)
    {
        if(CannonCount > 0){
            switch (arc4random_uniform(2)) {
                case 0:
                    [self PlaySound:@"cannon0"];
                    break;
                case 1:
                    [self PlaySound:@"cannon0"];
                    //                    [self PlaySound:@"cannon1"];
                    break;
            }
        }
        
        //Creates cannonballs and fires them to clicked location. Destroys them upon arrival at location
        
        for(SKSpriteNode __strong * singleCannon in cannons)
        {
            SKSpriteNode * cannonballImage = [SKSpriteNode spriteNodeWithTexture:[cannonballTileArray objectAtIndex:0]];
            
            [self MakePhysicsBody:cannonballImage ForType:CANNONBALL_BODY];
            
            float velocity = 500.0/1.0;
            float realMoveDuration = self.size.width / velocity;
            
            SKAction *animateCannonballSmaller = [SKAction animateWithTextures:cannonballTileArray timePerFrame:realMoveDuration/24];
            SKAction *animateCannonballBigger = [SKAction animateWithTextures:reversedcannonballTileArray timePerFrame:realMoveDuration/24];
            
            SKAction *animateCannonball = [SKAction sequence:@[animateCannonballBigger, animateCannonballSmaller]];
            [cannonballImage runAction:animateCannonball];
            
            cannonballImage.position = singleCannon.position;
            cannonballImage.zPosition = 3;
            cannonballImage.scale = MAP_SCALE;
            
            //Code which creates a Beizer path which is followed by the cannonball
            int xPullDirection = 64;
            int yPullDirection = 256;
            CGPoint control1 = CGPointMake(cannonballImage.position.x + xPullDirection, cannonballImage.position.y);
            CGPoint control2 = CGPointMake(touchLocation.x, touchLocation.y + yPullDirection);
            
            CGPoint realLocation;
            realLocation.x = touchLocation.x + (touchLocation.x * globalWindSpeed.dx);
            realLocation.y = touchLocation.y + (touchLocation.y * globalWindSpeed.dy);
            
            UIBezierPath *bezierPath = [UIBezierPath bezierPath];
            [bezierPath moveToPoint:cannonballImage.position];
            [bezierPath addCurveToPoint:realLocation controlPoint1:control1 controlPoint2:control2];
            
            [self addChild:cannonballImage];
            
            [cannonballImage runAction:[SKAction followPath:bezierPath.CGPath asOffset:NO orientToPath:NO duration:realMoveDuration] completion:^{
                if (cannonballImage.parent){
                    [SKAction removeFromParent];
                    [self SetExplosion:realLocation ForExplosionType:[self CheckCannonHit:realLocation]];  // FIXME: should actually specify which explosion (water or ground)
                }
                // NOTE: should actually specify which explosion
            }];
            
            
            
            
            //            SKAction * actionMoveAndAnimate = [SKAction group:@[actionMove, animateCannonball]];
            //            SKAction * actionMoveDone = [SKAction removeFromParent];
            //
            //           [cannonballImage runAction:[SKAction sequence:@[actionMoveAndAnimate, actionMoveDone]] completion:^{
            //                //Have an if condition here where if it hits a wall, then play the sound.
            //                [self SetExplosion:touchLocation ForExplosionType:WALL_EXPLOSION];
            //                // NOTE: should actually specify which explosion
            //            }];
        }
        
        
        //opponent Cannons
        
        //		for(SKSpriteNode __strong * singleCannon in oppCannons)
        //		{
        //			SKSpriteNode * cannonballImage = [SKSpriteNode spriteNodeWithTexture:[cannonballTileArray objectAtIndex:0]];
        //
        //			[self MakePhysicsBody:cannonballImage ForType:CANNONBALL_BODY];
        //
        //            float velocity = 500.0/1.0;
        //            float realMoveDuration = self.size.width / velocity;
        //
        //            SKAction *animateCannonballSmaller = [SKAction animateWithTextures:cannonballTileArray timePerFrame:realMoveDuration/24];
        //            SKAction *animateCannonballBigger = [SKAction animateWithTextures:reversedcannonballTileArray timePerFrame:realMoveDuration/24];
        //			SKAction *animateCannonball = [SKAction sequence:@[animateCannonballBigger, animateCannonballSmaller]];
        //			[cannonballImage runAction:animateCannonball];
        //
        //			cannonballImage.position = singleCannon.position;
        //			cannonballImage.zPosition = 3;
        //			cannonballImage.scale = MAP_SCALE;
        //
        //			NSArray *points = [NSArray arrayWithObjects:
        //							   [NSValue valueWithCGPoint:CGPointMake(100, 600)],
        //							   [NSValue valueWithCGPoint:CGPointMake(200, 300)],
        //							   [NSValue valueWithCGPoint:CGPointMake(400, 100)], nil];
        //
        //			NSUInteger randomIndex = arc4random() % [points count];
        //			NSValue *val = [points objectAtIndex:randomIndex];
        //			CGPoint oppCannonShot = [val CGPointValue];
        //
        //			//add to the scene
        //			[self addChild:cannonballImage];
        //
        //			SKAction * actionMove = [SKAction moveTo: oppCannonShot duration:realMoveDuration];
        //			SKAction * actionMoveAndAnimate = [SKAction group:@[actionMove, animateCannonball]];
        //			SKAction * actionMoveDone = [SKAction removeFromParent];
        //
        //            [cannonballImage runAction:actionMoveAndAnimate completion:^{
        //                //Have an if condition here where if it hits a wall, then play the sound.
        //
        //                //if cannonball has not hit a wall already, then remove it here
        //                if (cannonballImage.parent){
        //                    [cannonballImage runAction:actionMoveDone];
        //                    [self SetExplosion:touchLocation ForExplosionType:[self CheckCannonHit:touchLocation]];  // FIXME: should actually specify which explosion (water or ground)
        //                }
        //            }];
        //
        //
        //			cannonballImage.position = singleCannon.position;
        //			cannonballImage.zPosition = 3;
        //			cannonballImage.scale = MAP_SCALE;
        
        
        //
        //			//add to the scene
        //			[self addChild:cannonballImage];
        //
        //			float velocity = 500.0/1.0;
        //			float realMoveDuration = self.size.width / velocity;
        //			SKAction * actionMove = [SKAction moveTo:oppCannonShot duration:realMoveDuration];
        //			SKAction * actionMoveDone = [SKAction removeFromParent];
        //			[cannonballImage runAction:[SKAction sequence:@[actionMove, actionMoveDone]] completion:^{
        //				//Have an if condition here where if it hits a wall, then play the sound.
        //				NSString *path = [[NSBundle mainBundle] pathForResource:@"explosion0" ofType:@"wav"];
        //				NSURL *soundURL = [NSURL fileURLWithPath:path];
        //				_player[_currentChannel] =  [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL error:nil];
        //				[_player[_currentChannel] play];
        //				_currentChannel++;
        //				if (_currentChannel == MAX_CHANNELS) {
        //					_currentChannel = 0;
        //				}
        //				[self SetExplosion:touchLocation ForExplosionType:WALL_EXPLOSION];  // NOTE: should actually specify which explosion
        //			}];
        //		}
        
    }
}

-(int)CheckCannonHit:(CGPoint)touchLocation{
    // takes in location of a canonball hit
    // can be called from CannonFiringAnimation() ?
    // -- means no need for GameMode check
    // at cannon landing location
    
    int explosionType = GROUND_EXPLOSION; // default
    //    SKSpriteNode *spriteTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    int colClicked = [self getXRowNum:touchLocation]+1;
    int rowClicked = [self getYInvertedColNum:touchLocation]+1;
    if( mapArray[rowClicked][colClicked] == 'W' ){
        // red wall hit
        explosionType = WALL_EXPLOSION;
    }
    if( mapArray[rowClicked][colClicked] == 'w' ){
        // blue wall hit
        explosionType = WALL_EXPLOSION;
    }
    if( mapArray[rowClicked][colClicked] == ' ' ){
        // water hit
        explosionType = WATER_EXPLOSION;
    }
    
    return explosionType;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    /* Called when a touch begins */
    UITouch *touch = [touches anyObject];
    CGPoint touchLocation = [touch locationInNode:self.scene];
    
    
    
    
    SKSpriteNode *spriteTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    NSLog(@"%f %f", touchLocation.x, touchLocation.y);
    //    // Play sound after castle selected
    //    if ([spriteTouched.name isEqualToString:@"castle"]) {
    //
    //        [unusedCastles removeObject:spriteTouched];
    //
    //        [self PlaySound:@"aim2"];
    //
    //        if ([unusedCastles count] == 0) {
    //            double delayInSeconds = 0.5; // number of seconds to wait
    //            dispatch_time_t timer = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    //            dispatch_after(timer, dispatch_get_main_queue(), ^(void){
    //                exit(1);
    //            });
    //        }
    //    }
    
    
    
    if(GameMode == CASTLE_MODE){
        [self CreateInitialCastle:touchLocation];
    }
    if(GameMode == BATTLE_MODE){
        [self SwivelCannon:touchLocation];
        [self CannonFiringAnimation:touchLocation];
    }
    if(GameMode == CANNON_MODE && !maxCannons){
        [self PlaceCannon:touchLocation];
    }
    
    //    [self createBanner];
    //    [self createSweep];
    
    NSString *teamChoiceString;
    
    if(teamChoice == 0){
        teamChoiceString = @"R";
    }
    if(teamChoice == 1){
        teamChoiceString = @"B";
    }
    
    if((teamChoiceString == spriteTouched.name || [spriteTouched.name isEqualToString:@"setWall"] || [spriteTouched.name isEqualToString:@"rotateButton"]) && GameMode == REBUILD_MODE)
    {
        [self placeWall:touchLocation];
    }
    
}

-(void)createTimerLabel{
    // Time remaining label
    timerRemaining = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    timerRemaining.fontSize = 50;
    timerRemaining.fontColor = [SKColor whiteColor];
    timerRemaining.position = CGPointMake( 485 , 380);
    [self addChild:timerRemaining];
}


-(void)timerCount{
    if (secondLeft <= -1)
    {
        [timerRemaining removeAllChildren];
        [startTimer invalidate];
    }
    else if(secondLeft < 10 && secondLeft >= 0)
    {
        timerRemaining.text = [NSString stringWithFormat:@"0%i", secondLeft];
        secondLeft = secondLeft - 1;
    }
    else
    {
        timerRemaining.text = [NSString stringWithFormat:@"%i", secondLeft];
        secondLeft = secondLeft - 1;
    }
}

-(void)update:(CFTimeInterval)currentTime{
    /* Called before each frame is rendered */
}

-(void)removeDestroyedWalls{
    for(SKSpriteNode* node in burningWalls){
        [node removeAllChildren];
        [node removeFromParent];
    }
    
    NSMutableArray *wallsToDelete = [[NSMutableArray alloc] init];
    NSMutableArray *wallConflicts = [[NSMutableArray alloc] init];
    
    for(SKSpriteNode* obj in destroyedWalls){
        for(SKSpriteNode* wall in componentWallArray){
            if([wall intersectsNode:obj]){
                [wall removeFromParent];
                [wallsToDelete addObject:wall];
            }
        }
        for(SKSpriteNode* wall in Walls3D){
            if([wall intersectsNode:obj]){
                [wallConflicts addObject:wall];
                
            }
        }
    }
    [componentWallArray removeObjectsInArray:wallsToDelete];
    [Walls3D removeObjectsInArray:wallConflicts];
    
    for (SKSpriteNode* wall in wallsToDelete) {
        int xpos = [self getXRowNum:wall.position] + 1;
        int ypos = [self getYInvertedColNum:wall.position] + 1;
        if ( [wall.name isEqualToString:@"RedWall"] ) {
            mapArray[ypos][xpos] = 'R';
        }
        else if( [wall.name isEqualToString:@"BlueWall"]) {
            mapArray[ypos][xpos] = 'B';
        }
    }
    [self reset2DWallImages:@"Red"];
    [self reset2DWallImages:@"Blue"];
}

-(void)setDestroyedWallsAddBurn:(SKNode*)node{
    /*Changing the texture of the wall and making it destroyed*/
    SKNode* referenceNode = node;
    
    int randBurnArray = arc4random_uniform(8);
    NSArray *burnArray = [[self extractTiles:@"3DBurn"] subarrayWithRange:NSMakeRange(randBurnArray*4, 4)];
    NSMutableArray *destroyedWallArray = [self extractRectangleTiles:@"3DWallsAllPartThree" NumberOfTiles:63];
    
    
    SKSpriteNode* destroyedWallReplacement;
    if(teamChoice == BLUE_TEAM){
        destroyedWallReplacement = [SKSpriteNode spriteNodeWithTexture:[destroyedWallArray objectAtIndex:32]];
    }
    else if(teamChoice == RED_TEAM){
        destroyedWallReplacement = [SKSpriteNode spriteNodeWithTexture:[destroyedWallArray objectAtIndex:16]];
        
    }
    destroyedWallReplacement.position = referenceNode.position;
    destroyedWallReplacement.zPosition = referenceNode.zPosition;
    destroyedWallReplacement.scale = MAP_SCALE;
    [self addChild:destroyedWallReplacement];
    [burningWalls addObject:destroyedWallReplacement];
    
    
    SKAction *burningAction = [SKAction animateWithTextures:burnArray timePerFrame:.1];
    SKSpriteNode *burnNode = [SKSpriteNode spriteNodeWithTexture:[burnArray objectAtIndex:0]];
    
    
    burnNode.position = CGPointMake(destroyedWallReplacement.position.x, destroyedWallReplacement.position.y);
    burnNode.zPosition = 3;
    burnNode.scale = MAP_SCALE;
    
    [self addChild:burnNode];
    [burningWalls addObject:burnNode];
    [burnNode runAction:[SKAction repeatActionForever:burningAction] withKey:@"fire"];
    
    
}

-(void)SetExplosion:(CGPoint)explosionPoint ForExplosionType:(int)explosionType{
    // DS,AM (2/7/15): function to set explosion based on location
    NSArray *ExplosionArray;
    _currentCount++;
    
    // random number (1 or 2)
    int r = arc4random_uniform(2) + 1;
    //choose which explosion type to display
    switch (explosionType) {
        case WALL_EXPLOSION:
            if(_currentCount == CannonCount){
                switch (arc4random_uniform(4)) {
                    case 0:
                        [self PlaySound:@"explosion0"];
                        break;
                    case 1:
                        [self PlaySound:@"explosion1"];
                        //                        [self PlaySound:@"explosion1"];
                        break;
                    case 2:
                        [self PlaySound:@"explosion2"];
                        //                        [self PlaySound:@"explosion2"];
                        break;
                    case 3:
                        [self PlaySound:@"explosion3"];
                        //                        [self PlaySound:@"explosion3"];
                        break;
                }
                _currentCount = 0;
            }
            if (r == 1) {
                ExplosionArray = WallExplosion1;
            }
            else{
                ExplosionArray = WallExplosion2;
            }
            break;
            
        case WATER_EXPLOSION:
            if(_currentCount == CannonCount){
                switch (arc4random_uniform(4)) {
                    case 0:
                        [self PlaySound:@"waterexplosion0"];
                        //                        [self PlaySound:@"waterexplosion0"];
                        break;
                    case 1:
                        [self PlaySound:@"waterexplosion1"];
                        //                        [self PlaySound:@"waterexplosion1"];
                        break;
                    case 2:
                        [self PlaySound:@"waterexplosion2"];
                        //                        [self PlaySound:@"waterexplosion2"];
                        break;
                    case 3:
                        [self PlaySound:@"waterexplosion3"];
                        //                        [self PlaySound:@"waterexplosion3"];
                        break;
                }
                _currentCount = 0;
            }
            if (r == 1) {
                ExplosionArray = WaterExplosion1;
            }
            else{
                ExplosionArray = WaterExplosion2;
            }
            break;
            
        case GROUND_EXPLOSION:
            if(_currentCount == CannonCount){
                switch (arc4random_uniform(2)) {
                    case 0:
                        [self PlaySound:@"groundexplosion0"];
                        //                        [self PlaySound:@"groundexplosion0"];
                        break;
                    case 1:
                        [self PlaySound:@"groundexplosion1"];
                        //                        [self PlaySound:@"groundexplosion1"];
                        break;
                }
                _currentCount = 0;
            }
            if (r == 1) {
                ExplosionArray = GroundExplosion1;
            }
            else{
                ExplosionArray = GroundExplosion2;
            }
            break;
    }
    
    SKAction *ExplodeAction = [SKAction animateWithTextures:ExplosionArray timePerFrame:.03];
    SKSpriteNode *ExplosionNode = [SKSpriteNode spriteNodeWithTexture:[ExplosionArray objectAtIndex:0]];
    
    
    ExplosionNode.position = CGPointMake(explosionPoint.x, explosionPoint.y);
    ExplosionNode.zPosition = 3;
    ExplosionNode.scale = MAP_SCALE;
    
    SKAction * actionMoveDone = [SKAction removeFromParent];
    [self addChild:ExplosionNode];
    [ExplosionNode runAction:[SKAction sequence:@[ExplodeAction, actionMoveDone]]];
    
}

-(void)PlaySound:(NSString *)fileName{
    // do NOT include ".wav" in the file name!!!
    NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:@"wav"];
    NSURL *soundURL = [NSURL fileURLWithPath:path];
    _player[currentAudioChannel] =  [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL error:nil];
    [_player[currentAudioChannel] play];
    currentAudioChannel++;
    //    _currentCount = 0; // wrong location of variable reset
    if (currentAudioChannel == MAX_AUDIO_CHANNELS) {
        currentAudioChannel = 0;
    }
}

NSMutableArray *tilePlacementIndicatorArray;
SKSpriteNode *refTile;
-(void)placeWall:(CGPoint)touchLocation{
    SKSpriteNode *spriteTouched = (SKSpriteNode*)[self nodeAtPoint:touchLocation];
    
    NSMutableArray* builtTileArray = [self extractTiles:@"2DWalls.png"];
    SKSpriteNode * buildImage;
    //buildImage.scale = MAP_SCALE;
    
    //Create Rotate Button
    buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:1]];
    buildImage.scale = MAP_SCALE*3;
    CGPoint rotateButton = CGPointMake ( 1000 , 600 ); //1136, 640
    buildImage.position = rotateButton;
    buildImage.name = @"rotateButton";
    [self addChild:buildImage];
    
    
    NSString* teamName = @"Blue";
    if(teamChoice == BLUE_TEAM){
        teamName = @"Blue";
    }
    else if(teamChoice == RED_TEAM){
        teamName = @"Red";
    }
    
    
    if(currentTile == single){
        bool objectPresent = false;
        
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:84]];
        buildImage.position = newPosition;
        buildImage.scale = MAP_SCALE;
        
        int xRow = [self getXRowNum:newPosition];
        int yCol = [self getYInvertedColNum:newPosition];
        
        for(SKSpriteNode *obj in componentWallArray)
        {
            if([buildImage intersectsNode:obj])
            {
                objectPresent = true;
            }
        }
        
        if(!objectPresent && !secondTap){
            [buildImage setName:@"setWall"];
            
            [self addChild:buildImage];
            refTile = buildImage;
            secondTap = true;
        }
        
        if([spriteTouched.name isEqualToString:@"setWall"] && secondTap){
            [self Add2DWall:teamName atLoc:spriteTouched.position];
            
            gridNode *temp = [[gridNode alloc] init];
            [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
            [self checkEnclosedPerimeter];
            
            [spriteTouched removeFromParent];
            
            currentTile++;
            secondTap = false;
        }
        
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            
            refTile.position = [self calculateNewPosition:spriteTouched secondValue:12];
        }
        
        
        
    }
    
    
    
    else if(currentTile == twoLTile){
        
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        bool objectPresent = false;
        
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:85]];
            buildImage.position = newPosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            
            
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            newPosition.y = newPosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            
            
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = modifyPosition;
                    count++;
                }
                else{//keeps the rotated position after moving the wall
                    if(dir==0){
                        modifyPosition.y = modifyPosition.y + 24;
                    }
                    else if(dir==1){
                        modifyPosition.x = modifyPosition.x + 24;
                    }
                    else if(dir==2){
                        modifyPosition.y = modifyPosition.y - 24;
                    }
                    else{
                        modifyPosition.x = modifyPosition.x - 24;
                    }
                    obj.position = modifyPosition;
                    count = 0;
                }
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                secondTap = false;
                tempBuildCount++;
            }
            //change to a differnt tile
            currentTile++;
            dir = North; // initalize direction of the next object in the North direction
        }
        
        //check if cursor is on the rotateButton, if it is rotate object
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){ // in NORTH config, is bottom tile
                    if(dir == North){
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                    }
                    else if(dir == East){
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                    }
                    else if(dir == South){
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                    }
                    else if(dir == West) {
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                    }
                    count++;
                }
                else{ // in NORTH config, is top tile
                    if(dir == North){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        dir = East;
                    }
                    else if(dir == East){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        dir = South;
                    }
                    else if(dir == South){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        dir = West;
                    }
                    else if(dir == West) {
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        dir = North;
                        
                    }
                    count = 0;
                }
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
            
        }
        
    }
    
    else if(currentTile == tTile){
        /******CREATE THE T SHAPED TILE*****/
        //t tile initially upside down
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:95]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:92]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x - 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:86]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){//keeps rotated position
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    if(dir==East){
                        modifyPosition.y = basePosition.y-24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-24;
                        obj.position = modifyPosition;
                    }
                    if(dir==West){
                        modifyPosition.y = basePosition.y+24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 3){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-24;
                        obj.position = modifyPosition;
                    }
                    if(dir==East){
                        modifyPosition.y = basePosition.y+24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    if(dir==West){
                        modifyPosition.y = basePosition.y-24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count=0;
                }
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:91]];//NOTE: incorrect tile. can't find the correct one
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 3){//left side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:98]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:97]];//NOTE: incorrect tile, but can't find the correct one
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:95]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            NSLog(@"count resetted");
            count=0;
            
        }
    }
    else if(currentTile == threeLTile){
        /******CREATE THE 3L SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        if(firstThreeLTile){
            dir=0;
            firstThreeLTile=false;
        }
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:85]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:89]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 48;
            newPosition.x = basePosition.x;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+48;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-48;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x-24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:92]];//NOTE: incorrect tile, but can't find the correct one
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
    }
    else if(currentTile == lessTTile){
        /******CREATE THE LESS T SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        bool objectPresent = false;
        
        if(firstLessTTile){
            dir=0;
            firstLessTTile=false;
            NSLog(@"trying to reset");
        }
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:87]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:92]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x-24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
        
    }
    else if(currentTile == threeLTileWithTwo){
        /******CREATE THE THREE L TILE WITH TWO*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        if(firstThreeLTileWithTwo){
            dir=0;
            firstThreeLTileWithTwo=false;
        }
        
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:93]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:89]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 48;
            newPosition.x = basePosition.x;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:90]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 48;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:92]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x - 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:86]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 48;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 48;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 3){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 48;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x + 48;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 48;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x - 48;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 4){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 72;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 4){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    
                }
                else if(dir==East){//rotates shape from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 4){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
                else if(dir==South){//rotates shape from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 72;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 4){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==West){//rotates shape from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                    else if(count == 4){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
    }
    else if(currentTile == zTile){
        /******CREATE THE Z SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        if(firstZTile){
            dir=0;
            firstZTile=false;
        }
        
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:84 + + 9]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:84 + 6]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 24;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:92]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x - 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:86]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 3){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
    }
    else if(currentTile == fourLTile){
        /******CREATE THE 4 L SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        bool objectPresent = false;
        
        if(firstFourLTile){
            dir=0;
            firstFourLTile=false;
        }
        
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:85]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:89]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 48;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:89]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 72;
            newPosition.x = basePosition.x;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+48;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-48;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 3){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 72;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x + 72;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 72;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 72;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 72;
                        currPosition.x = currPosition.x + 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x-24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 72;
                        currPosition.x = currPosition.x - 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:92]];//NOTE: incorrect tile, but can't find the correct one
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 72;
                        currPosition.x = currPosition.x - 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 72;
                        currPosition.x = currPosition.x + 72;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
        
    }
    else if(currentTile == fourActualLTile){
        /******CREATE THE 4 ACTUAL SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        if(firstFourActualLTile){
            dir=0;
            firstFourActualLTile=false;
        }
        
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:87]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:89]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 48;
            newPosition.x = basePosition.x;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:88]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:92]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
            
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"] && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-24;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 2){
                    if(dir==North){
                        modifyPosition.y = basePosition.y + 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+48;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y - 48;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x-48;
                        obj.position = modifyPosition;
                    }
                    count++;
                }
                else if(count == 3){
                    if(dir==North){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x+ 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==East){
                        modifyPosition.y = basePosition.y - 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    else if(dir==South){
                        modifyPosition.y = basePosition.y;
                        modifyPosition.x = basePosition.x - 24;
                        obj.position = modifyPosition;
                    }
                    else if(dir==West){
                        modifyPosition.y = basePosition.y + 24;
                        modifyPosition.x = basePosition.x;
                        obj.position = modifyPosition;
                    }
                    count = 0;
                }
                
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            currentTile++;
        }
        //does 90 degree rotation clockwise
        if(secondTap && [spriteTouched.name isEqualToString:@"rotateButton"] && ![spriteTouched.name isEqualToString:@"setWall"]) {
            
            NSLog(@"%d, %d, %d",secondTap,![spriteTouched.name isEqualToString:@"setWall"],!objectPresent);
            
            CGPoint currPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(dir==North){//rotates t tile from north to east
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:90]];
                        count++;
                    }
                    else if(count == 1){//upper middle tile of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                    else if(count == 3){//right side of upside down t tile
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                }
                else if(dir==East){//rotates t tile from east to south
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:96]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x-24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:85]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                }
                else if(dir==South){//rotates t tile from south to west
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:93]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x - 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:94]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x - 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:86]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                }
                else if(dir==West){//rotates t tile from west to north
                    if(count == 0){ // base tile after rotation
                        [obj setTexture:[builtTileArray objectAtIndex:87]];
                        count++;
                    }
                    else if(count == 1){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:89]];
                        count++;
                        
                    }
                    else if(count == 2){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y + 48;
                        currPosition.x = currPosition.x + 48;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:88]];
                        count++;
                    }
                    else if(count == 3){
                        currPosition = obj.position;
                        currPosition.y = currPosition.y - 24;
                        currPosition.x = currPosition.x + 24;
                        obj.position = currPosition;
                        [obj setTexture:[builtTileArray objectAtIndex:92]];
                        count++;
                    }
                }
            }
            dir++;
            if(dir>3){
                dir=0;
            }
            count=0;
        }
        
    }
    else if(currentTile == squareTile){
        /******CREATE THE T SHAPED TILE*****/
        CGPoint newPosition = [self calculateNewPosition:spriteTouched secondValue:12];
        CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
        
        bool objectPresent = false;
        if(!secondTap && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            tempCurrentWallComponents = [[NSMutableArray alloc] init];
            
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:87]];//add 10
            buildImage.position = basePosition;
            buildImage.scale = MAP_SCALE;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition = basePosition;
            newPosition.y = basePosition.y + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:90]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y + 24;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:96]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            newPosition.y = basePosition.y;
            newPosition.x = basePosition.x + 24;
            buildImage = [SKSpriteNode spriteNodeWithTexture:[builtTileArray objectAtIndex:93]];//add 4 base is 84
            buildImage.scale = MAP_SCALE;
            buildImage.position = newPosition;
            buildImage.name = @"setWall";
            [tempCurrentWallComponents addObject: buildImage];
            [self addChild:buildImage];
            
            //94 is the straight
            
            
            secondTap = true;//just added
        }
        
        // checks for if there is an object present OR water underneath pending wall
        for(SKSpriteNode* obj in componentWallArray){
            for(SKSpriteNode* curComponent in tempCurrentWallComponents){
                int y = [self getXRowNum:curComponent.position] + 1, x = [self getYInvertedColNum:curComponent.position] + 1;
                if ([curComponent intersectsNode:obj] || mapArray[x][y] == ' ') {
                    objectPresent = true;
                }
            }
        }
        
        //handle movement of wall
        if(secondTap && ![spriteTouched.name isEqualToString:@"setWall"]  && ![spriteTouched.name isEqualToString:@"rotateButton"]){
            CGPoint modifyPosition = [self calculateNewPosition:spriteTouched secondValue:12];
            CGPoint basePosition = [self calculateNewPosition:spriteTouched secondValue:12];
            NSMutableArray* temp = [[NSMutableArray alloc]init ];
            
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                if(count == 0){
                    obj.position = basePosition;
                    count++;
                }
                else if(count == 1){
                    modifyPosition.y = basePosition.y + 24;
                    modifyPosition.x = basePosition.x;
                    obj.position = modifyPosition;
                    count++;
                }
                else if(count == 2){
                    modifyPosition.y = basePosition.y + 24;
                    modifyPosition.x = basePosition.x + 24;
                    obj.position = modifyPosition;
                    count++;
                }
                else if(count == 3){
                    modifyPosition.y = basePosition.y;
                    modifyPosition.x = basePosition.x + 24;
                    obj.position = modifyPosition;
                    count = 0;
                }
                [temp addObject:obj];
            }
            
            tempCurrentWallComponents = [[NSMutableArray alloc]init];
            for(SKSpriteNode* obj in temp){
                [tempCurrentWallComponents addObject:obj];
            }
        }
        
        //check if the cursor is placed there, if it is place the wall
        if(secondTap && [spriteTouched.name isEqualToString:@"setWall"] && !objectPresent){
            int tempBuildCount = 0;
            for(SKSpriteNode* obj in tempCurrentWallComponents){
                // Get Positions
                int xRow, yCol;
                xRow = [self getXRowNum:obj.position];
                yCol = [self getYInvertedColNum:obj.position];
                
                [self Add2DWall:teamName atLoc:obj.position];
                
                // Mark Map
                // Check Enclosed
                gridNode *temp = [[gridNode alloc] init];
                [temp setNodeIsWall:gridLayout[yCol][xRow]]; // mark as wall on Grid
                [self checkEnclosedPerimeter];
                
                for (SKSpriteNode* wallOutline in tempCurrentWallComponents) {
                    [wallOutline removeFromParent];
                }
                
                tempBuildCount++;
            }
            secondTap = false;
            //change to a differnt tile
            //currentTile++;
            currentTile = 0;
        }
        
    }
    
}

-(void)MakePhysicsBody:(SKSpriteNode *)nodeObj ForType:(int)nodeType{
    // AM (2/16/15): function to make a node into a physics body
    // type of object is passed in as second parameter
    switch (nodeType) {
        case WALL2D_BODY:
            nodeObj.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:nodeObj.size];
            nodeObj.physicsBody.categoryBitMask = WALL2D_MASK;
            nodeObj.physicsBody.contactTestBitMask = CANNONBALL_MASK;
            break;
        case WALL3D_BODY:
            nodeObj.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:nodeObj.size];
            nodeObj.physicsBody.categoryBitMask = WALL3D_MASK;
            nodeObj.physicsBody.contactTestBitMask = CANNONBALL_MASK;
            break;
            
        case CANNONBALL_BODY:
            nodeObj.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:nodeObj.size.width/2.5]; //should be 2, but changed to 2.5 for precision
            nodeObj.physicsBody.categoryBitMask = CANNONBALL_MASK;
            nodeObj.physicsBody.contactTestBitMask = WALL3D_MASK;
            break;
            
        default:
            break;
    }
    
    nodeObj.physicsBody.dynamic = YES;
    nodeObj.physicsBody.collisionBitMask = 0;
    nodeObj.physicsBody.usesPreciseCollisionDetection = YES;
}

-(void)didBeginContact:(SKPhysicsContact *)contact{
    // reference: http://www.raywenderlich.com/42699/spritekit-tutorial-for-beginners
    //NSLog(@"physics collision");
    
    BOOL lowEnough = false;
    
    SKPhysicsBody *firstBody;   // Wall
    SKPhysicsBody *secondBody;  // Cannonball
    
    if (contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask) {
        firstBody = contact.bodyA;
        secondBody = contact.bodyB;
    }
    else {
        firstBody = contact.bodyB;
        secondBody = contact.bodyA;
    }
    
    //check to see if cannonball is low enough
    SKTexture *currentCannonball = ((SKSpriteNode *)secondBody.node).texture;
    NSUInteger cannonballHeight = [reversedcannonballTileArray indexOfObject:currentCannonball];
    
    if (cannonballHeight < WALL_HEIGHT) {
        lowEnough = true;
    }
    
    if ((firstBody.categoryBitMask & WALL3D_MASK) != 0 &&
        (secondBody.categoryBitMask & CANNONBALL_MASK) != 0 && lowEnough) {
        [self SetExplosion:contact.contactPoint ForExplosionType:WALL_EXPLOSION];
        [destroyedWalls addObject:firstBody.node]; //
        [self setDestroyedWallsAddBurn:firstBody.node];
        [firstBody.node removeFromParent];  // remove wall when hit
        [secondBody.node removeFromParent]; // remove cannonball when hit
        //[Walls3D removeObject:firstBody.node];
    }
}

-(CGPoint)calculateNewPosition:(SKSpriteNode*)spriteTouched secondValue:(int)step{
    CGPoint newPosition;
    newPosition.x = step * floor((spriteTouched.position.x / step) + 0.5);
    newPosition.y = step * floor((spriteTouched.position.y / step) + 0.5);
    
    return newPosition;
}

+(SKSpriteNode *)initializeSKNode:(NSMutableArray *)array :(int)index :(CGPoint)position {
    SKSpriteNode *node = [SKSpriteNode spriteNodeWithTexture:[array objectAtIndex:index]];
    node.position = position;
    node.scale = MAP_SCALE;
    return node;
}

-(void)checkEnclosedPerimeter {
    [self DFS:0 :0];
    //[self printGridLayout];
    [self colorInFloorPattern];
    [self resetGridLayoutVisited];
}

SKSpriteNode* banner;
-(void)createSweep:(NSString*)message{
    banner = [[SKSpriteNode alloc] init];
    banner = [SKSpriteNode spriteNodeWithColor:
              [UIColor colorWithRed:11/255.0 green:87/255.0 blue:1/255.0 alpha:1]
                                          size:CGSizeMake(self.frame.size.width - 50, 150)];
    banner.position = CGPointMake(474.386810, 667.00);
    banner.zPosition = 5;
    
    NSMutableArray* bannerImages = [self createBannerImage:banner.position message:message];
    
    SKAction *moveUp = [SKAction moveByX:0 y:-self.frame.size.height duration:5];
    for (SKSpriteNode* image in bannerImages) {
        [image runAction:moveUp completion:^{
            [image removeFromParent];
        }];
    }
}


/*
 
 USAGE:Call this function if you want to change the current screen from 2d to 3d and back.
 If you want to change it to 3d change the "option" variable from @"2D" to @"3D" first
 and then call [self createSweep:@"message"].
 if you want to change from 3d to 2d, then set the option variable to 2D and call [self createSweep:@"message"].
 
 
 */
NSString* option = @"2D";
bool creation = false;
//funciton override for the run animation of the sweep
-(void)didEvaluateActions{
    if(banner.hasActions &&[option isEqualToString:@"3D"] ){
        
        
        
        //        NSMutableArray *wallArray1 = [self extractRectangleTiles:@"3DWallsAllPartOne" NumberOfTiles:63];
        
        for(SKSpriteNode* tileindicator in tempCurrentWallComponents){
            [tileindicator removeFromParent];
        }
        
        [refTile removeFromParent];
        
        for(SKSpriteNode *singleWall in componentWallArray){
            if([banner intersectsNode:singleWall]){
                [self makeWall3D:singleWall];
            }
            
        }
        
        for(SKSpriteNode* terrain in Terrain3D){
            if([banner intersectsNode:terrain]){
                terrain.hidden = NO;
                terrain.zPosition = 0;
            }
        }
        
        for(SKSpriteNode* wall in Walls3D){
            if([banner intersectsNode:wall]){
                wall.hidden = NO;
                wall.zPosition = 3;
            }
        }
        
        for(SKSpriteNode* wall in componentWallArray){
            if([banner intersectsNode:wall]){
                wall.hidden = YES;
                wall.zPosition = 3;
            }
            
        }
        
        for(SKSpriteNode* terrain in Terrain2D){
            if([banner intersectsNode:terrain]){
                terrain.hidden = YES;
                terrain.zPosition = 0;
            }
        }
        
        NSMutableArray *tileArray = [self extractTiles:@"3DCannon"];
        for(SKSpriteNode __strong *singleCannon in cannons){
            if([banner intersectsNode:singleCannon]){
                CGPoint position = [self convertPoint:singleCannon.position fromNode:self];
                [singleCannon setTexture:[tileArray objectAtIndex:0]];
                singleCannon.xScale = MAP_SCALE;
                singleCannon.yScale = MAP_SCALE;
                singleCannon.position = CGPointMake(position.x, position.y);
            }
        }
        
        tileArray = [self extractTiles:@"3DFloor"];
        for (SKSpriteNode *node in castleFloorTiles)
        {
            [node setTexture:[tileArray objectAtIndex:2]];
            for(SKSpriteNode* terrain in Terrain3D){
                if([node intersectsNode:terrain]){
                    terrain.hidden = YES;
                    terrain.zPosition = 0;
                }
            }
        }
        
        tileArray = [self extractRectangleTiles:@"3DCastles" NumberOfTiles:109];
        for(SKSpriteNode __strong *singleCastle in unusedCastles){
            if([banner intersectsNode:singleCastle]){
                CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
                [singleCastle setTexture:[tileArray objectAtIndex:108]];
                singleCastle.xScale = MAP_SCALE;
                singleCastle.yScale = MAP_SCALE;
                singleCastle.position = CGPointMake(position.x, position.y);
            }
        }
        
        for(SKSpriteNode __strong *singelCastle in usedCastles){
            if([banner intersectsNode:singelCastle]){
                [self updateCastleWind:8 windSpeed:0];
            }
        }
    }
    
    
    //revert back to 2d
    if(banner.hasActions &&[option isEqualToString:@"2D"] ){
        
        NSMutableArray *tileArray = [self extractTiles:@"2DCastleCannon"];
        for(SKSpriteNode __strong *singleCastle in unusedCastles){
            if([banner intersectsNode:singleCastle]){
                CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
                [singleCastle setTexture:[tileArray objectAtIndex:31]];
                singleCastle.xScale = MAP_SCALE;
                singleCastle.yScale = MAP_SCALE;
                singleCastle.position = CGPointMake(position.x, position.y);
            }
        }
        
        for(SKSpriteNode __strong *singleCastle in usedCastles){
            if([banner intersectsNode:singleCastle]){
                CGPoint position = [self convertPoint:singleCastle.position fromNode:self];
                [singleCastle setTexture:[tileArray objectAtIndex:20]];
                singleCastle.xScale = MAP_SCALE;
                singleCastle.yScale = MAP_SCALE;
                singleCastle.position = CGPointMake(position.x, position.y);
            }
        }
        //Reverse castle tiles
        tileArray = [self extractTiles:@"2DTerrain"];
        int check = 1;
        int numInRow = 0;
        for (SKSpriteNode *node in castleFloorTiles)
        {
            if([banner intersectsNode:node]){
				NSLog(@"%f %f", floor(node.position.x/(12*MAP_SCALE)), 27 - floor(node.position.y/(12*MAP_SCALE)));
				//if (((i + j) % 2 == 0))
				int x = floor(node.position.x/(12*MAP_SCALE));
				int y = 27 - floor(node.position.y/(12*MAP_SCALE));
				NSLog(@"%d %d", x, y);
                if(0 == (x + y) % 2) {
                    [node setTexture:[tileArray objectAtIndex:3]];
                    check+=2;
                }
                else
                    [node setTexture:[tileArray objectAtIndex:4]];
                check++;
                numInRow++;
                if (numInRow%6 == 0)
                    check++;
            }
        }
        
        //revert battlemodeCannons
        tileArray = [self extractTiles:@"2DCastleCannon"];
        for(SKSpriteNode __strong *singleCannon in cannons)
        {
            CGPoint position = [self convertPoint:singleCannon.position fromNode:self];
            [singleCannon setTexture:[tileArray objectAtIndex:27]];
            singleCannon.xScale = MAP_SCALE;
            singleCannon.yScale = MAP_SCALE;
            singleCannon.position = CGPointMake(position.x, position.y);
        }
        
        
        for(SKSpriteNode* terrain in Terrain3D){
            if([banner intersectsNode:terrain]){
                terrain.hidden = YES;
                terrain.zPosition = -1;
            }
        }
        
        for(SKSpriteNode* terrain in Terrain2D){
            if([banner intersectsNode:terrain]){
                terrain.hidden = NO;
                terrain.zPosition = 0;
            }
        }
        
        for(SKSpriteNode* wall in Walls3D){
            if([banner intersectsNode:wall]){
                wall.hidden = YES;
                wall.zPosition = -1;
            }
        }
        
        for(SKSpriteNode* wall in componentWallArray){
            if([banner intersectsNode:wall]){
                wall.hidden = NO;
                wall.zPosition = 2;
            }
        }
    }
}

-(NSMutableArray*)createBannerImage:(CGPoint)startPos message:(NSString*)message{
    //    NSMutableArray* brickImages = [self extractRectangleTiles:@"Bricks" NumberOfTiles:10];
    //    NSMutableArray* asciiBlackImages = [self extractRectangleTiles:@"FontKingthingsBlack" NumberOfTiles:95];
    NSMutableArray* asciiWhiteImages = [self extractRectangleTiles:@"FontKingthingsWhite" NumberOfTiles:95];
    
    NSMutableArray* bannerImages = [[NSMutableArray alloc] init];
    [bannerImages addObject:banner];
    
    // hardCode Brick locations
    //    SKSpriteNode* brick = [SKSpriteNode spriteNodeWithTexture:[brickImages objectAtIndex:9]];
    //    brick.position = startPos;
    //    brick.zPosition = 6;
    //    brick.scale = MAP_SCALE;
    //    [bannerImages addObject:brick];
    
    // put in message
    // offset is 126 - char to get proper char image
    int xincrement = 30; // space between characters
    int xpos = 500 - xincrement * message.length / 2.0; // starting position, centers the message
    for ( int charCount = 0; charCount < message.length; charCount++) {
        int imageInd = 126 - [message characterAtIndex:charCount];
        SKSpriteNode* character = [SKSpriteNode spriteNodeWithTexture:[asciiWhiteImages objectAtIndex:imageInd]];
        character.scale = MAP_SCALE;
        character.zPosition = 7;
        character.position = CGPointMake(xpos, startPos.y);
        [bannerImages addObject:character];
        xpos += xincrement;
    }
    
    for (SKSpriteNode* image in bannerImages) {
        [self addChild:image];
    }
    return bannerImages;
}

-(void)initVar{
    componentWallArray = [[NSMutableArray alloc]init];
    wallLocations = [[NSMutableArray alloc]init];
    destroyedWalls = [[NSMutableArray alloc] init];
    burningWalls = [[NSMutableArray alloc] init];
    tilePlacementIndicatorArray =[[NSMutableArray alloc] init];
    Terrain2D = [[NSMutableArray alloc] init];
}
@end
