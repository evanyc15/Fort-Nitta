//
//  castleWall.h
//  FortNitta
//
//  Created by Ricky Cheung on 2/7/15.
//  Copyright (c) 2015 ECS 160 iOS Development. All rights reserved.
//


#ifndef FortNitta_castleWall_h
#define FortNitta_castleWall_h

#define MAP_SCALE 2.0

#import <SpriteKit/SpriteKit.h>

@interface castleWallChoices:NSObject
{
    @public
    NSMutableArray* currentBuildWall;
    NSMutableArray* componentWallLocations;
    NSMutableArray *castleBuildWallArray;
    float locationX;
    float locationY;
}
-(id)init;
-(NSMutableArray*) setThings:(CGPoint)touchLocation;
-(NSMutableArray*)AlterLocation:(NSMutableArray*)oldArray secondValue:(CGPoint)touchLocation;
@end
#endif
