# ECS160iOS
ECS 160 Project iOS Version

## Requirements

Documentation:
- Doxygen

## Install Doxygen
Instructions:
- git clone https://github.com/doxygen/doxygen.git
- cd doxygen
- ./configure
- make 
- install

## Documentation
To build docs, run `doxygen`

## File Organization

    |- Source - XCode Project files
      |- .m files
      |- .h files
      |- .xcodeproj file
      |- .sks file
      |- Base.lproj
        |- .xib file
        |- .storyboard file
      |- Images.xcassets
        |- .plist file
        |- .m file
        |- Appicon.appiconset
          |- .json file
        |-Spaceship.imageset
          |-.json file
          |-.png file
      |-FortNittaTests
        |- .m file
        |- .plist file       
    |- docs - Docs generated from Doxygen
    |- data - Data describing assets
    |- pngs - Graphical assets
    |- sounds - Sound effects
    |- README.md - This file

## Working on Issues

- Start a new branch for the issue

            git checkout -b issue-name

- Work on fixing issue
- Commit changes

            git commit -m "<what you did> fixes #<issue number>"

- Push new branch up

            git push --set-upstream origin issue-name

- Create a new pull request from master to your branch
    - Name it "<what you did>. Fixes #<issue number>"
    - Include description
    - Tag anyone that should review it

## Source Conventions

- Indentation
    - 4 spaces per level
    - Spaces only!
    - Allman style
- Whitespace
    - No whitespace between identifier and paren
    - Whitespace on both sides of identifier and operators
    - No whitespace between identifier and bracket (for Obj-C messages)
    - Bracket everything, even single line if statement.
    - Syntax for declaring custom methods: -(return_type)method_name

- Comments
    - Multiline comments - Double star aligned

                /*
                ** ... text ...
                ** ... more text ...
                */

    - Single line comments - Before the line of code

                // If value is set
                if(val()){

    - Tags - One of the following
            - `// FIXME: Problem to be fixed`
            - `// NOTE: Keep this in mind`
            - `// TODO: Finish this code here`
- Naming convention
    - Pascal Case
        - Local Variables
    - Screaming Snake
        - Defines  
    - Camel Case
        - Functions
        - Parameters

- Metadata Conventions
    - Classes begin with C
    - Data member variables begin with D
    - Enum names begin with E
    - Struct names begin with S
    - Global Variables begin with G
    - Enumerated values begin with lowercase intials of enum type
    - Type names begin with T

- Project Coding Principles
    - Use the import as a define guard in order to make sure a file is only every included once.
    - The use of the automatically synthesized accessor methods in order to access an encapsulated class members (get/set member function equivalent).
        You access or set an object’s properties via accessor methods:
            NSString *firstName = [somePerson firstName];
            [somePerson setFirstName:@"Johnny"];
            By default, these accessor methods are synthesized automatically for you by the compiler, so you don’t need to do anything other than declare the property using @property in the class interface.
            The synthesized methods follow specific naming conventions:
            The method used to access the value (the getter method) has the same name as the property.
            The getter method for a property called firstName will also be called firstName.
            The method used to set the value (the setter method) starts with the word “set” and then uses the capitalized property name.
            The setter method for a property called firstName will be called setFirstName:.
            If you don’t want to allow a property to be changed via a setter method, you can add an attribute to a property declaration to specify that it should be readonly:
            @property (readonly) NSString *fullName;

### Example from Conway, Joe; Hillegass, Aaron (2012-03-16). iOS Programming: The Big Nerd Ranch Guide, Third Edition (3rd Edition) (Big Nerd Ranch Guides) (p. 509). Pearson Education. Kindle Edition. 

        #define MY_INT_CONSTANT ((int) 12345)

        /*
        ** This is what the function is supposed to do...
        */
        -(void)fetchEntries 
        { 
            // Initiate the request... 
            [[BNRFeedStore sharedStore] fetchRSSFeedWithCompletion: 
            ^(RSSChannel *obj, NSError *err) 
            { 
                // When the request completes, this block will be called. 
                if (! err) 
                {
                    // If everything went ok, grab the channel object, and reload the table. 
                    channel = obj; 
                    [[self tableView] reloadData];
                } 
                else 
                { 
                    // If things went bad, show an alert view 
                    UIAlertView *av = [[UIAlertView alloc] 
                    initWithTitle:@" Error" 
                    message:[err localizedDescription] 
                    delegate:nil 
                    cancelButtonTitle:@" OK" 
                    otherButtonTitles:nil]; 
                    [av show]; 
                } 
            }]; 
        }


Subgroups:

Ali Minty, Dhruvi Sompura
Kasra Mirblouk, Shai Bruhis, Justin Lee
Ricky Cheung, Yvone Chau, Stefan Peterson
Artie Sobol, Russell Miller,Nico Lo, Nelson Li
Raul Cano, Taylor Yang
David Chen, Bipul Wagle, Michael Mathew



