#include <QFileDialog>
#include <QString>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QDebug>
#include "csoundHandler.h"


#define NUM_SOUNDS 25
#define NUM_WAVS 4
#define SOUNDS_FOLDER "../sounds/"

CSoundHandler::CSoundHandler(QWidget* parent)
{
    DParent = parent;
    DPropertiesWidget = new QWidget();
    DSigManager = new QSignalMapper(this);

    DProperties.setupUi(DPropertiesWidget);

    QObject* area = DProperties.midiArea;

    DLabels = new QLabel* [NUM_SOUNDS];
    DSoundPaths = new QString [NUM_SOUNDS];

    connect(DSigManager, SIGNAL(mapped(int)), this, SLOT(SelectFile(int)));
    QString labelName = "label", buttonName = "button", number;
    for( int i = 0; i < NUM_SOUNDS ; ++i )
    {
        if( area != DProperties.wavArea && i >= NUM_WAVS)
            area = DProperties.wavArea;

        number.setNum(i);
        buttonName.append(number);
        labelName.append(number);

        QPushButton* temp = area->findChild<QPushButton*>(buttonName);
        DSigManager->setMapping(temp, i);
        connect(temp, SIGNAL(clicked()), DSigManager, SLOT(map()));

        DLabels[i] = area->findChild<QLabel*>(labelName);

        labelName.remove(number);
        buttonName.remove(number);
    }

    DLastVisitedDirectory = ".";

    DSoundFolder = QDir::current();
    DSoundFolder.mkdir(SOUNDS_FOLDER);
    DSoundFolder.cd(SOUNDS_FOLDER);
}

CSoundHandler::~CSoundHandler()
{
    delete DPropertiesWidget;
    delete DSigManager;

    delete [] DLabels;
    delete [] DSoundPaths;

}

/**
 * @return the property widget for the tool
 */
QWidget* CSoundHandler::GetPropertiesWidget()
{
    return DPropertiesWidget;
}

/**
 * Requests a path to a sound file from the user
 * @param id list index of the sound the user wishes to select
 * @return the path to the sound file the user selected
 */
QString CSoundHandler::SelectFile(int id)
{
    QString filename;

    if( id < 4 )
        filename = QFileDialog::getOpenFileName(DParent, "Open MIDI", DLastVisitedDirectory, "MIDI (*.mid)");
    else
        filename = QFileDialog::getOpenFileName(DParent, "Open WAV", DLastVisitedDirectory, "WAV (*.wav)");

    if( filename.isEmpty() )
        return filename;

    DLastVisitedDirectory = filename;
    int index = DLastVisitedDirectory.lastIndexOf('/');
    DLastVisitedDirectory.remove(index, 255);

    filename = CopySound(filename);

    (DLabels[id])->setText(filename.section('/', -1, -1));
    DSoundPaths[id] = filename;

    return filename;

}

/**
 * Copies the sound file from the given path to the soundset destination
 * @param filename file to copy
 * @return path to newly copied file
 */
QString CSoundHandler::CopySound(QString filename)
{
    //checks if the file was choosen from the SOUNDS_FOLDER
    if( filename.contains(DSoundFolder.absolutePath()) )
        return filename.section('/',-2,-1);

    QString destinationPath = DSoundFolder.absoluteFilePath(filename.section('/',-1,-1));

    QString currSuffix, prevSuffix = ".";
    for( int i = 0; QFile::exists(destinationPath); ++i)
     {
        currSuffix = '_' + QString::number(i) + '.';
        destinationPath.replace(prevSuffix, currSuffix);
        prevSuffix = currSuffix;
     }

    qDebug() << filename << "\n";
    qDebug() << destinationPath << "\n";

    if( !QFile::copy(filename,destinationPath) )
        exit(5);

    return destinationPath.section('/',-2,-1);
}

/**
 * Creates a soundset structure with the given title
 * @param title title for the soundset
 * @return path to the soundset
 */
QString CSoundHandler::CreateSoundSet(const QString title) const
{
    QString destinationPath = DSoundFolder.absoluteFilePath(title + ".dat");
    QFile file(destinationPath);
    file.open(QFile::WriteOnly | QFile::Truncate | QFile::Text);
    QTextStream destination(&file);

    if( destination.status() )
        exit(3);

    destination << title << "\n\n";
    int i;
    for( i = 0; i < NUM_WAVS; ++i )
        destination << DSoundPaths[i] << '\n';

    destination << '\n';

    for( ; i < NUM_SOUNDS; ++i )
        destination << DSoundPaths[i] << '\n';

    file.close();

    return destinationPath.section('/',-2,-1);

}

/**
 * Loads a soundset from a path that is chosen by the user
 * @return
 */
bool CSoundHandler::LoadSoundSet()
{
    #define BUFFER_SIZE 255
    QDir workDirectory = QDir::current();
    workDirectory.cd("..");
    QString filename = QFileDialog::getOpenFileName(DParent, "Select Sound Set", DSoundFolder.absolutePath(), "SoundSet (*.dat)");

    if( filename.isEmpty() )
        return false;

    QFile set(filename);
    set.open(QFile::ReadOnly | QFile::Text);

    int i, charsRead;
    char buffer[BUFFER_SIZE];

    set.readLine(BUFFER_SIZE);
    set.readLine(BUFFER_SIZE);
    for( i = 0; i < NUM_WAVS; ++i )
    {
        charsRead = set.readLine(buffer, BUFFER_SIZE);
        //if line is not blank
        if( charsRead > 1)
        {
            //trim off '\n'
            buffer[charsRead-1] = '\0';

            //check if file exists
            if( workDirectory.exists(buffer) )
                DSoundPaths[i] = buffer;
            else
                DSoundPaths[i] = "";
        }
        //else, default should be used
        else
            DSoundPaths[i] = "";


        if( DSoundPaths[i].isEmpty() )
            (DLabels[i])->setText("Default");
        else
            (DLabels[i])->setText(DSoundPaths[i].section('/',-1,-1));

    }
    set.readLine(BUFFER_SIZE);
    for( ; i < NUM_SOUNDS; ++i )
    {
        charsRead = set.readLine(buffer, BUFFER_SIZE);
        //if line is not blank
        if( charsRead > 1)
        {
            //trim off '\n'
            buffer[charsRead-1] = '\0';

            //check if file exists
            if( workDirectory.exists(buffer) )
                DSoundPaths[i] = buffer;
            else
                DSoundPaths[i] = "";
        }
        //else, default should be used
        else
            DSoundPaths[i] = "";


        if( DSoundPaths[i].isEmpty() )
            (DLabels[i])->setText("Default");
        else
            (DLabels[i])->setText(DSoundPaths[i].section('/',-1,-1));

    }

    return true;

}
