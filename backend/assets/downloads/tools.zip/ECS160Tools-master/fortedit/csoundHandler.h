#ifndef CSOUNDHANDLER_H
#define CSOUNDHANDLER_H

#include <QWidget>
#include <QString>
#include <QLabel>
#include <QSignalMapper>
#include <QDir>
#include "ui_music_options.h"

/**
 * Manager class to handle all things related to sounds
 */
class CSoundHandler: public QObject
{
    Q_OBJECT
    public:
        CSoundHandler(QWidget *parent = 0);
        ~CSoundHandler();

        QWidget* GetPropertiesWidget();

    public slots:
        bool LoadSoundSet();
        QString CreateSoundSet(const QString title) const;

   private slots:
        QString SelectFile(int id);
        QString CopySound(QString filename);


    private:
        QWidget* DParent;
        QWidget* DPropertiesWidget;
        QSignalMapper* DSigManager;

        QLabel** DLabels;
        QString* DSoundPaths;
        QDir     DSoundFolder;

        Ui::MusicProperties DProperties;
        QString DLastVisitedDirectory;

};

#endif // CSOUNDHANDLER_H
