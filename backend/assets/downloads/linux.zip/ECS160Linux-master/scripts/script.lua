testString = "LuaBridge works!"
number = 42
