mkdir -p build
cd build
rm Logjoined.txt LogFile.txt Log.txt ThreadLog.txt Logprocess.txt Logupdate.txt ThreadLog.txt 
cmake -DCMAKE_BUILD_TYPE=Debug .. && make -j4 && ./FortNitta

