echo "Committing, pulling and pushing on ECS160Linux"
expect commit.exp && expect push.exp && expect pull.exp 
echo "Pulling and pushing on ECS160Linux1/ECS160Linux"
cd ../ECS160Linux1/ECS160Linux && expect pull.exp && expect commit.exp && expect push.exp
echo "Making directory build."
mkdir -p build 
cd build
rm Logjoined.txt LogFile.txt Log.txt ThreadLog.txt Logprocess.txt Logupdate.txt ThreadLog.txt 
echo "Making and running the game."
cmake -DCMAKE_BUILD_TYPE=Debug .. && make -j4 && ./FortNitta

