# Game Logic

## Menus

- Main Menu
    - Single Player - Goes to Map Select
    - Multiplayer - Goes to Login
    - Options - Shows sound and network options
    - Exit - closes the game
- Map Select
    - Shows list of maps. Hovering over a map shows a small preview of the map, the size of the map, and the player count. The preview of the map is drawn in `CTerrainMap::DrawPreviewMap`
    - Selecting a map loads its tileset and soundset and then goes to Game Options. See `CTerrainMap::Update`
- Game Options
    - Allows the ability to choose wind, color, and AI difficulty
        - Wind: None, Mild, Moderate, Erratic
        - Color: Blue, Red
        - AI Difficulty: Easy, Normal, Hard, Insane
    - Selecting continue initializes the players and moves on to the banner transition mode and then to the select castle mode. See `CGameOptionsMenuMode::Update`

- Sound Options
    - Adjust FX and Music volumes which changes the volume the sound clips and songs are played at
- Network Options
    - Allows for adjusting of the server address

## Banner Transition

The banner transition mode provides a way to move between two different modes via a message that is shown on the screen. The banner transition caches a frame of the leaving mode and then draws the next mode, the banner being shown, and the cached frame to provide a seamless transition. The next mode is also updated, allowing it to respond to input. The banner start above and offscreen, and then moves by five until it is offscreen again. See `CBannerTransitionMode`

## Terrain Map

The terrain map contains a grid of squares that are for a player or are water. It also contains castles and their positions on the map. The castles are also 2x2 tiles wide. The tiles and screen coordinates are converted frequently. See `CTerrainMap::ConvertToSscreenCoordinates`. The tiles belong to a single player color and are usually divided by water. This means there are basically separate islands for each player which has a certain number of castles.

## Castle Select

The first part of the game requires players to select a home castle. Playrs can move their cursor around the screen to decide on a castle. The castle that is hovered by the player is shown with a ring surrounding it. See `Castle::DrawSelectionRing`. The hovered castle is determined by calculating the castle with the shorteest distance from the players color. See `CPlayer::UpdateHoveredCastle` for that algorithm. The castles must be on territory that the player owns.

The game does not start until all players have selected a home castle. There is no time limit for this.

Once a player selects a home castle. A wall surrounds the castle with up to 2 spaces between the wall and the castle. If there are obstructions in the terrain, the surrounded walls are generated to maximize the area contained. See `CConstructionMap::SurroundCastle` for the algorithm.

Once all the players have selected a caslte, the game moves on to the cannon placement mode after a banner transition.

## Cannon Placement

The cannon placement mode allows players to place more cannons in the area they have surrounded. In each canon placement round, the players are given `n` cannons to place in their areas where `n` is the number of surrounded castles at the beginning of the round. During the first round, the players are also awarded two extra cannons for a total of three. The players can move their cursor to determine a location that is not obstructued by any other cannon, castle, wall, or terrain. The cannons are 2x2 and must be placed in areas that are completely covered by floor of the player's color. See `CPlayer::TryToPlaceCannon` for the algorithm used.

There is a 15 second time limit for placing cannons. If all players have placed all their cannons or the timer runs out, whichever happens first, the game moves on to battle mode after a banner transition.

## Battle Mode

Battle mode has players fire cannonsballs at their opponent's walls. Battle mode begins with a sequence of sound effects, `Ready`, `Aim`, `Fire` starting when the mode is entered, one second later, and one second later, respectively. The Players cannot fire cannonballs until the fire sound effect has started.

Once the fire sound effect has started, players have 15 seconds to cause as much destruction as possible. However, each cannon can only have one cannonball fired at a time and cannons are fired in the the sequence that they were placed. Once a cannon has fired, the cannonball must return to the ground or cause some destruction before its cannon can be fired again. See `CCannon::CannonballDestroyed`. The cannons are aimed via the ouse and the cannonballs interact with the current wind.

The cannon ball trajectory and speed are calculated in `CCannonball:CCannonball` and use precomputed values. They are drawn at different sizes depending on their height. Cannonballs have three ways of being destroyed. They can land in the water, on the ground, or hit a wall if they are less than 2 tile units low. See `CCannonball:Update` for the specific algorithm used to determine if the cannonball has been destroyed.

After the timer has run out, a cease fire sound effect is played and after one second the game moves onto the rebuild mode

## Rebuild Mode

Rebuild mode allows players to rebuild the walls and re-surround castles in their territory. The mode begins by recalculating which tiles on the terrain map belong to a certain player. The players have a PRNG each and it is used to calculate the next wall piece. They are seeded once and act independently to avoid problems. The players are given a shape calculated from the PRNG and they can place it as long as it is completely unobstructed by any castle, cannon, wall, or terrain. Players can also rotate their shape by 90 degrees clockwise by using the right mouse button. See `CPlayer::TryToPlaceWall` and `CPlayer::RotateWall`.

Each frame, an algorithm is run to determine if any new castles have been surrounded with each new wall placement. See `CRebuildMode::CheckSurroundedCastles` for more information on the algorithm.

The rebuild mode ends after 15 seconds and either transitions back to cannon placement mode or to game over mode to show who won or was defeated. If there are no winners, the rebuild mode is started again.

