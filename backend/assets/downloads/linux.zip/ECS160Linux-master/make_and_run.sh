mkdir -p build
cd build
rm LogFile.txt Log.txt ThreadLog.txt Logprocess.txt Logupdate ThreadLog.txt 

cmake -DCMAKE_BUILD_TYPE=Debug .. && make -j4 && ./FortNitta
