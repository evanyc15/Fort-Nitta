mkdir -p build
rm build/LogFile.txt build/Log.txt build/ThreadLog.txt Logfile.txt Log.txt ThreadLog.txt
cd build
cmake -DCMAKE_BUILD_TYPE=Debug -DBUILD_ON_FEDORA=ON .. && make -j4 && ./FortNitta

