#include "NetworkMessage.h"

CNetworkMessage::CNetworkMessage(){

}

