#ifndef SPRITE_STATE_H
#define SPRITE_STATE_H
#include "types/Double3.h"
/**
 * Structure representing a sprite's position
 */

typedef SDouble3 SSpriteState;
typedef SDouble3 *SSpriteStateRef;

#endif
