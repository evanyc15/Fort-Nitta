#ifndef MATHUTIL_H
#define MATHUTIL_H

#include "../game/Cannonball.h"
#include "../SpriteState.h"
#include "../types/Direction.h"

/**
 * MathUtil class
 */
class CMathUtil{
    
    public:
        /**
         * Calculates integer square root of integer passed in,
         * code from http://www.codecodex.com/wiki/Calculate_an_integer_square_root
         *
         * @param x Number to take square root of
         *
         * @return Integer portion of the square root of the parameter
         */
        static unsigned int IntegerSquareRoot(unsigned int x);

        /**
         * Compares positions of two sprites
         *
         * @param first const reference to a SpriteState
         * @param second const reference to a SpriteState
         *
         * @return True if first's position is greater than second's position, 
         * false if first's position is greater than second's position;
         * checked in order of z position, x position
         */
        static bool SpriteCompare(const SSpriteState &first, const SSpriteState &second);

        /**
         * Calculates direction of vector between two points
         *
         * @param x1 x coordinate of first point
         * @param y1 y coordinate of first point
         * @param x2 x coordinate of second point
         * @param y2 y coordinate of second point
         *
         * @return enum value representing direction
         */
        static int CalculateDirection(int x1, int y1, int x2, int y2);
        /**
         * @brief Calculates the direction between two SInt2
         *
         * @param a First point
         * @param b Second point
         *
         * @return Direction
         */
        static int CalculateDirection(SInt2 a, SInt2 b){
            return CalculateDirection(a.DX, a.DY, b.DX, b.DY);
        }

        /**
         * @brief Calculates if rectangles defined overlap
         *
         * @param position1 The top left of first rectangle
         * @param size1 Size of first rectangle
         * @param position2 The top left of second rectangle
         * @param size2 Size of second rectangle
         *
         * @return true if overlap, false otherwise
         */
        static bool DoRectanglesOverlap(SInt2 position1, SInt2 size1, SInt2 position2, SInt2 size2);
};

#endif
