#include "MathUtil.h"
#include "../game/Cannonball.h"
#include "../types/Direction.h"

// Code from http://www.codecodex.com/wiki/Calculate_an_integer_square_root
unsigned int CMathUtil::IntegerSquareRoot(unsigned int x){
    register unsigned int Op, Result, One;
    Op = x;
    Result = 0;
    One = 1 << (sizeof(unsigned int) * 8 - 2);
    while(One > Op){
        One >>= 2;
    }
    while(0 != One){
        if(Op >= Result + One){
            Op -= Result + One;
            Result += One << 1; // <-- faster than 2 * one
        }
        Result >>= 1;
        One >>= 2;
    }
    return Result;
}


bool CMathUtil::SpriteCompare(const SSpriteState &first, const SSpriteState &second){
    if(first.DY < second.DY){
        return true;
    }
    if(first.DY > second.DY){
        return false;
    }
    if(first.DX < second.DX){
        return true;
    }
    return false;
}

int CMathUtil::CalculateDirection(int x1, int y1, int x2, int y2){
    int XDistance = x2 - x1;
    int YDistance = y2 - y1;
    bool NegativeX = XDistance < 0;
    bool NegativeY = YDistance > 0; // Top of screen is 0
    double SinSquared;
    XDistance *= XDistance;
    YDistance *= YDistance;
    if(0 == (XDistance + YDistance)){
        return SDirection::dNorth;
    }
    SinSquared = (double)YDistance / (XDistance + YDistance);
    if(0.1464466094 > SinSquared){
        // East or West
        if(NegativeX){
            return SDirection::dWest; // West
        }
        else{
            return SDirection::dEast; // East
        }
    }
    else if(0.85355339059 > SinSquared){
        // NE, SE, SW, NW
        if(NegativeY){
            if(NegativeX){
                return SDirection::dSouthWest; // SW
            }
            else{
                return SDirection::dSouthEast; // SE
            }
        }
        else{
            if(NegativeX){
                return SDirection::dNorthWest; // NW
            }
            else{
                return SDirection::dNorthEast; // NE
            }
        }
    }
    else{
        // North or South
        if(NegativeY){
            return SDirection::dSouth; // South
        }
        else{
            return SDirection::dNorth; // North
        }
    }
}

bool CMathUtil::DoRectanglesOverlap(SInt2 position1, SInt2 size1, SInt2 position2, SInt2 size2){
    SInt2 P1 = position1,
          P2 = position1 + size1,
          P3 = position2,
          P4 = position2 + size2;
    return !(P2.DY <= P3.DY || P1.DY >= P4.DY || P2.DX <= P3.DX || P1.DX >= P4.DX);
}
