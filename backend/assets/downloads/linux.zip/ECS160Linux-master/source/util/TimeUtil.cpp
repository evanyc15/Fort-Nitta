#include "TimeUtil.h"

#include <sys/time.h>
#include <stdlib.h>

struct timeval CTimeUtil::MakeTimeoutSecondsInFuture(int seconds){
    struct timeval NewTimeout;
    gettimeofday(&NewTimeout, NULL);
    NewTimeout.tv_sec += seconds;
    return NewTimeout;
}

int CTimeUtil::SecondsUntilDeadline(struct timeval deadline){
    struct timeval CurrentTime;
    gettimeofday(&CurrentTime, NULL);
    return ((deadline.tv_sec * 1000 + deadline.tv_usec / 1000) - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000)) / 1000;
}

int CTimeUtil::MilliSecondsUntilDeadline(struct timeval deadline){
    struct timeval CurrentTime;
    gettimeofday(&CurrentTime, NULL);
    return ((deadline.tv_sec * 1000 + deadline.tv_usec / 1000) - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000));
}
