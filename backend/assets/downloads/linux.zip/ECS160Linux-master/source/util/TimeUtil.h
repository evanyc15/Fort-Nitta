#ifndef TIMEUTIL_H
#define TIMEUTIL_H

#include <sys/time.h>

/**
 * Holds routines for dealing with time
 */
class CTimeUtil{

    public:
        /**
         * @brief Calculates the timeout for seconds in the future
         *
         * @param seconds Number of second to count down
         *
         * @return Timeout seconds into the future
         */
        static struct timeval MakeTimeoutSecondsInFuture(int seconds);

        /**
         * Calculates the number of seconds until stage timeout
         * 
         * @param deadline time of when stage will time out
         *
         * @return number of seconds until timeout
         */
        static int SecondsUntilDeadline(struct timeval deadline);

        /**
         * Calculates the number of milliseconds until stage timeout
         * 
         * @param deadline time of when stage will time out
         *
         * @return number of milliseconds until timeout
         */
        static int MilliSecondsUntilDeadline(struct timeval deadline);
};

#endif
