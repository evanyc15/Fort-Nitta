#include "GameContainer.h"

#include <stdio.h>
#include <sys/time.h>
#include <algorithm>

#include "game/Game.h"

#define CANVAS_WIDTH 480
#define CANVAS_HEIGHT 288
#define COPY_FULL 0, 0, 0, 0, -1, -1

CGameContainer::CGameContainer(){
    DMainWindow = NULL;
    DDoubleBufferPixmap = NULL;
    DDrawingAreaPixmap = NULL;
    DDoubleBufferPixbuf = NULL;
    DScaledPixbuf = NULL;
    DGame = NULL;
}

CGameContainer::~CGameContainer(){
    if(DGame != NULL){
        delete DGame;
    }
    if(DDoubleBufferPixmap != NULL){
        g_object_unref(DDoubleBufferPixmap);
    }
    if(DDoubleBufferPixbuf != NULL){
        g_object_unref(DDoubleBufferPixbuf);
    }
    if(DScaledPixbuf != NULL){
        g_object_unref(DScaledPixbuf);
    }
    if(DDrawingAreaPixmap != NULL){
        g_object_unref(DDrawingAreaPixmap);
    }
}

int CGameContainer::Run(int argc, char* argv[]){
    /*
     * This is called in all GTK applications.
     *
     * Arguments are parsed from the
     * command line and are returned to the application. All GTK+ specific
     * arguments are removed from the argc/argv list.
     */
    gtk_init(&argc, &argv);

    CreateWindow();
    CreateDrawingArea();

    gtk_widget_show(DDrawingArea);
    gtk_widget_show(DMainWindow);

    DDrawingContext = DDrawingArea->style->fg_gc[gtk_widget_get_state(DDrawingArea)];

    DGame = new CGame(DDrawingArea);



    DBlankCursor = gdk_cursor_new(GDK_BLANK_CURSOR);
    gdk_window_set_cursor(DDrawingArea->window, NULL);
    gdk_window_set_cursor(DDrawingArea->window, DBlankCursor);

    InitTimeout();

    gtk_main();
    return 0;
}

void CGameContainer::CreateWindow(){
    DMainWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(DMainWindow), "Fort Nitta");

    g_signal_connect(DMainWindow, "delete-event", G_CALLBACK(MainWindowDeleteEventCallback), this);
    g_signal_connect(DMainWindow, "destroy", G_CALLBACK(MainWindowDestroyCallback), this);
    g_signal_connect(DMainWindow, "key-press-event", G_CALLBACK(MainWindowKeyPressEventCallback), this);

    gtk_container_set_border_width(GTK_CONTAINER(DMainWindow), 10);
}

void CGameContainer::CreateDrawingArea(){
    DDrawingArea = gtk_drawing_area_new();

    gtk_drawing_area_size(GTK_DRAWING_AREA(DDrawingArea), CANVAS_WIDTH, CANVAS_HEIGHT);

    gtk_container_add(GTK_CONTAINER(DMainWindow), DDrawingArea);

    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "expose_event", G_CALLBACK(DrawingAreaExposeCallback), this);
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "button_press_event", G_CALLBACK(DrawingAreaButtonPressEventCallback), this);
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "motion_notify_event", G_CALLBACK(DrawingAreaMotionNotifyEventCallback), this);
    gtk_signal_connect(GTK_OBJECT(DDrawingArea), "configure_event", G_CALLBACK(DrawingAreaConfigureCallback), this);
    gtk_widget_set_events(DDrawingArea, GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK | GDK_POINTER_MOTION_MASK);
}

void CGameContainer::Quit(){
    gtk_main_quit();
}

void CGameContainer::InitTimeout(){
    gettimeofday(&DNextExpectedTimeout, NULL);
    DNextExpectedTimeout.tv_usec += TIMEOUT_INTERVAL * 1000;
    if(1000000 <= DNextExpectedTimeout.tv_usec){
        DNextExpectedTimeout.tv_usec %= 1000000;
        DNextExpectedTimeout.tv_sec++;
    }
    g_timeout_add(TIMEOUT_INTERVAL, TimeoutCallback, this);
}

gboolean CGameContainer::Timeout(){
    DGame->Update();

    // Render game into double buffer used to redraw until game is rerendered
    GdkPixmap* Frame = DGame->Draw(DDrawingContext);

    // Create the double buffer with the same size as the frame if needed
    if(DDoubleBufferPixmap == NULL){
        gint FrameWidth, FrameHeight;
        gdk_pixmap_get_size(Frame, &FrameWidth, &FrameHeight);
        DDoubleBufferPixmap = gdk_pixmap_new(DDrawingArea->window,
                                       FrameWidth,
                                       FrameHeight,
                                       -1);
    }
    gdk_draw_pixmap(DDoubleBufferPixmap, DDrawingContext, Frame, COPY_FULL);

    UpdateDrawingAreaPixmap();

    gdk_draw_pixmap(DDrawingArea->window, DDrawingContext, DDrawingAreaPixmap, COPY_FULL);

    // Schedule new timeout with expected frame rate
    g_timeout_add(GetTimeDelta(), TimeoutCallback, this);

    // Do not timeout again
    return FALSE;
}

void CGameContainer::UpdateDrawingAreaPixmap(){
    gdk_draw_rectangle(DDrawingAreaPixmap,
                       DDrawingArea->style->black_gc,
                       TRUE,
                       0, 0,
                       DDrawingArea->allocation.width,
                       DDrawingArea->allocation.height);

    if(DDoubleBufferPixmap != NULL) {
        UpdateScaledFrame();
        DDoubleBufferPixbuf = gdk_pixbuf_get_from_drawable(DDoubleBufferPixbuf,
                DDoubleBufferPixmap, NULL, COPY_FULL);

        gdk_pixbuf_scale(DDoubleBufferPixbuf, DScaledPixbuf, 0, 0,
                DScaledFrame.DWidth, DScaledFrame.DHeight, 0, 0,
                DScaledFrame.DScale, DScaledFrame.DScale, GDK_INTERP_NEAREST);
        gdk_draw_pixbuf(DDrawingAreaPixmap, DDrawingContext, DScaledPixbuf, 0, 0,
                DScaledFrame.DX, DScaledFrame.DY, DScaledFrame.DWidth, DScaledFrame.DHeight,
                GDK_RGB_DITHER_NONE, 0, 0);
    }
}

void CGameContainer::UpdateScaledFrame(){
    int DoubleBufferWidth, DoubleBufferHeight;
    gdk_pixmap_get_size(DDoubleBufferPixmap, &DoubleBufferWidth, &DoubleBufferHeight);
    double DoubleBufferAspect = DoubleBufferWidth / (double) DoubleBufferHeight;

    gint AllocationWidth = DDrawingArea->allocation.width,
            AllocationHeight = DDrawingArea->allocation.height;
    double AllocationAspect = AllocationWidth / (double) AllocationHeight;

    if(DoubleBufferAspect > AllocationAspect) {
        DScaledFrame.DScale = AllocationWidth / (double) DoubleBufferWidth;
        DScaledFrame.DWidth = AllocationWidth;
        DScaledFrame.DHeight = AllocationWidth / DoubleBufferAspect;
        DScaledFrame.DX = 0;
        DScaledFrame.DY = (AllocationHeight - DScaledFrame.DHeight) / 2;
    } else {
        DScaledFrame.DScale = AllocationHeight / (double) DoubleBufferHeight;
        DScaledFrame.DHeight = AllocationHeight;
        DScaledFrame.DWidth = AllocationHeight * DoubleBufferAspect;
        DScaledFrame.DX = (AllocationWidth - DScaledFrame.DWidth) / 2;
        DScaledFrame.DY = 0;
    }
}

gboolean CGameContainer::DrawingAreaConfigureEvent(GtkWidget *widget, GdkEventConfigure *event){
    if(DDrawingAreaPixmap != NULL) {
        g_object_unref(DDrawingAreaPixmap);
    }
    if(DScaledPixbuf != NULL) {
        g_object_unref(DScaledPixbuf);
        // Needed to NULL so gdk_pixbuf_get_from_drawable doesn't reuse
        DScaledPixbuf = NULL;
    }
    DDrawingAreaPixmap = gdk_pixmap_new(widget->window,
                                        widget->allocation.width,
                                        widget->allocation.height,
                                        -1);
    DScaledPixbuf = gdk_pixbuf_get_from_drawable(DScaledPixbuf,
                                                 DDrawingAreaPixmap,
                                                 NULL,
                                                 COPY_FULL);
    UpdateDrawingAreaPixmap();
    return TRUE;
}

gboolean CGameContainer::DrawingAreaExpose(GtkWidget *widget, GdkEventExpose *event){
    gdk_draw_pixmap(widget->window,
            widget->style->fg_gc[gtk_widget_get_state (widget)],
            DDrawingAreaPixmap,
            event->area.x, event->area.y,
            event->area.x, event->area.y,
            event->area.width, event->area.height);
    return FALSE;
}

gboolean CGameContainer::MainWindowDeleteEvent(GtkWidget *widget, GdkEvent *event){
    return FALSE;
}

void CGameContainer::MainWindowDestroy(GtkWidget *widget){
    Quit();
}

gboolean CGameContainer::MainWindowKeyPressEvent(GtkWidget *widget, GdkEventKey *event){
    DGame->KeyPressed(event->keyval);
    return TRUE;
}

int64_t CGameContainer::GetTimeDelta(){
    struct timeval CurrentTime;
    int64_t TimeDelta;

    /*
     * Do math to get amount of time should wait until next frame to keep
     * framerate steady
     */
    gettimeofday(&CurrentTime, NULL);
    do{
        DNextExpectedTimeout.tv_usec += TIMEOUT_INTERVAL * 1000;
        if(DNextExpectedTimeout.tv_usec >= 1000000){
            DNextExpectedTimeout.tv_usec %= 1000000;
            DNextExpectedTimeout.tv_sec++;
        }
        TimeDelta = (DNextExpectedTimeout.tv_sec * 1000 + DNextExpectedTimeout.tv_usec / 1000)
                - (CurrentTime.tv_sec * 1000 + CurrentTime.tv_usec / 1000);
    }while(TimeDelta <= 0);
    return TimeDelta;
}

gboolean CGameContainer::DrawingAreaButtonPressEvent(GtkWidget *widget, GdkEventButton *event){
    CInputState::EInputButton ButtonCode = CInputState::ibUnknownButton;
    // Right click is with right button or ctrl-click on single button Macs
    if(event->button == 3 || (event->button == 1 && event->state & GDK_CONTROL_MASK)){
        ButtonCode = CInputState::ibRightButton;
    // Left click is with left button or single button
    }else if(event->button == 1){
        ButtonCode = CInputState::ibLeftButton;
    }
    // If button recognized
    if(ButtonCode != CInputState::ibUnknownButton){
        DGame->ButtonPressed(ButtonCode);
    }
    return TRUE;
}

gboolean CGameContainer::DrawingAreaMotionNotifyEvent(GtkWidget *widget, GdkEventMotion *event){
    SInt2 NewPosition;
    NewPosition.DX = std::min<int>(DScaledFrame.DWidth / DScaledFrame.DScale,
                     std::max<int>(0, (event->x - DScaledFrame.DX) / DScaledFrame.DScale));
    NewPosition.DY = std::min<int>(DScaledFrame.DHeight / DScaledFrame.DScale,
                     std::max<int>(0, (event->y - DScaledFrame.DY) / DScaledFrame.DScale));
    DGame->MouseMoved(NewPosition);
    return TRUE;
}

gboolean CGameContainer::MainWindowDeleteEventCallback(GtkWidget *widget, GdkEvent *event, gpointer data){
    return ((CGameContainer*)data)->MainWindowDeleteEvent(widget, event);
}

void CGameContainer::MainWindowDestroyCallback(GtkWidget *widget, gpointer data){
    ((CGameContainer*)data)->MainWindowDestroy(widget);
}

gboolean CGameContainer::MainWindowKeyPressEventCallback(GtkWidget *widget, GdkEventKey *event, gpointer data){
    return ((CGameContainer*)data)->MainWindowKeyPressEvent(widget, event);
}

gboolean CGameContainer::DrawingAreaExposeCallback(GtkWidget *widget, GdkEventExpose *event, gpointer data){
    return ((CGameContainer *)data)->DrawingAreaExpose(widget, event);
}

gboolean CGameContainer::DrawingAreaButtonPressEventCallback(GtkWidget *widget, GdkEventButton *event, gpointer data){
    return ((CGameContainer *)data)->DrawingAreaButtonPressEvent(widget, event);
}

gboolean CGameContainer::DrawingAreaMotionNotifyEventCallback(GtkWidget *widget, GdkEventMotion *event, gpointer data){
    return ((CGameContainer *)data)->DrawingAreaMotionNotifyEvent(widget, event);
}

gboolean CGameContainer::DrawingAreaConfigureCallback(GtkWidget *widget, GdkEventConfigure *event, gpointer data){
    return ((CGameContainer *)data)->DrawingAreaConfigureEvent(widget, event);
}

gboolean CGameContainer::TimeoutCallback(gpointer data){
    return ((CGameContainer*)data)->Timeout();
}
