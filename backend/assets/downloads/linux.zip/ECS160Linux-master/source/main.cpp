/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.

    All source material (source code, images, sounds, etc.) have been provided to
    University of California, Davis students of course ECS 160 for educational
    purposes. It may not be distributed beyond those enrolled in the course without
    prior permission from the copyright holder.

    Some sound files, sound fonts, and midi files have been included that were
    freely available via internet sources. They have been included in this
    distribution for educational purposes only and this copyright notice does not
    attempt to claim any ownership of this material.
*/

#include <stdio.h>
#include "GameContainer.h"

/**
 * Bootstrap the game and show copyright info
 */
int main(int argc, char *argv[]){

    CGameContainer GameContainer;

    printf("Copyright (c) 2015, Christopher Nitta\n");
    printf("All rights reserved.\n\n");
    printf("All source material (source code, images, sounds, etc.) have been provided to\n");
    printf("University of California, Davis students of course ECS 160 for educational\n");
    printf("purposes. It may not be distributed beyond those enrolled in the course without\n");
    printf("prior permission from the copyright holder.\n\n");
    printf("Some sound files, sound fonts, and midi files have been included that were\n");
    printf("freely available via internet sources. They have been included in this\n");
    printf("distribution for educational purposes only and this copyright notice does not\n");
    printf("attempt to claim any ownership of this material.\n");

    return GameContainer.Run(argc, argv);
}
