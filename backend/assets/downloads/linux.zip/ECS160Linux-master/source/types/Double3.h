#ifndef DOUBLE3_H
#define DOUBLE3_H

#include "Int2.h"
/**
 * Structure representing 3 doubles
 */

struct SDouble3{
    double DX;
    double DY;
    double DZ;

    /**
     * @brief Makes a new 3D double
     *
     * @param x x
     * @param y y
     * @param z z
     */
    SDouble3(double x=0, double y=0, double z=0)
        : DX(x), DY(y), DZ(z){
    }

    /**
     * @brief Makes a new 3D double on z=0 from 2D int
     *
     * @param a
     */
    SDouble3(SInt2& a){
        DX = a.DX;
        DY = a.DY;
        DZ = 0;
    }

    /**
     * @brief In place scalar addition of another 3D double
     * @param a
     * @return A new 3D double
     */
    SDouble3 operator+=(const SDouble3& a){
        DX += a.DX;
        DY += a.DY;
        DZ += a.DZ;
        return *this;
    }

    /**
     * @brief Returns the rounded 2D position on z=0 plane
     *
     * @return 
     */
    SInt2 SInt2Position(){
        return SInt2(DX, DY);
    }
};

#endif
