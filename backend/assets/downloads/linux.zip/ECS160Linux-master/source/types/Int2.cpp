#include "Int2.h"

#include "Double2.h"
#include "Double3.h"

SInt2::SInt2(const SDouble2& a){
    DX = a.DX;
    DY = a.DY;
}

SInt2::SInt2(const SDouble3& a){
    DX = a.DX;
    DY = a.DY;
}

bool SInt2::IsContainedWithin(const SInt2& top_left, const SInt2& size) const{
    SInt2 BottomRight = top_left + size;
    return (top_left.DX <= DX && DX <= BottomRight.DX
            && top_left.DY <= DY && DY <= BottomRight.DY);
}
