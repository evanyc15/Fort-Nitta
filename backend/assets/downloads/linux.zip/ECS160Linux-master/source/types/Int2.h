#ifndef INT2_H
#define INT2_H

struct SDouble2;
struct SDouble3;

/**
 * @brief 2D Int
 */
struct SInt2{
    int DX, DY;

    /**
     * @brief Make a new 2D int
     * @param x
     * @param y
     */
    SInt2(int x=0, int y=0)
        : DX(x), DY(y){
    }

    /**
     * @brief Cast a 2D double into a 2D int
     * @param a
     */
    SInt2(const SDouble2& a);

    /**
     * @brief Casts a 3D double into a 2D int
     *
     * @param a
     */
    SInt2(const SDouble3& a);

    /**
     * @brief Copy to another 2D int
     * @param a
     * @retur
     */
    SInt2& operator=(const SInt2& a){
        DX = a.DX;
        DY = a.DY;
        return *this;
    }

    /**
     * @brief Scalar addition of another 2D int
     * @param a
     * @return A new 2D int
     */
    SInt2 operator+(const SInt2& a) const{
        return SInt2(DX + a.DX, DY + a.DY);
    }

    /**
     * @brief In place scalar addition of another 2D int
     * @param a
     * @return A new 2D int
     */
    SInt2 operator+=(const SInt2& a){
        DX += a.DX;
        DY += a.DY;
        return *this;
    }

    /**
     * @brief Scalar subtraction of another 2D int
     * @param a
     * @return A new 2D int
     */
    SInt2 operator-(const SInt2& a) const{
        return SInt2(DX - a.DX, DY - a.DY);
    }

    /**
     * @brief Scalar multiplication of another 2D int
     * @param a
     * @return A new 2D int
     */
    SInt2 operator*(const int& a) const{
        return SInt2(DX * a, DY * a);
    }

    /**
     * @brief Scalar multiplication of another 2D int
     *
     * @param a
     *
     * @return A new 2D int
     */
    SInt2 operator*(const SInt2& a) const{
        return SInt2(DX * a.DX, DY * a.DY);
    }

    /**
     * @brief Scalar division of 2D int
     * @param a
     * @return A new 2D int
     */
    SInt2 operator/(const int& a) const{
        return SInt2(DX / a, DY / a);
    }

    /**
     * @brief Scalar division with another 2D int
     *
     * @param a
     *
     * @return A new 2D int
     */
    SInt2 operator/(const SInt2& a) const{
        return SInt2(DX / a.DX, DY / a.DY);
    }

    /**
     * @brief Equality testing of 2D int
     * @param a
     * @return True if equal X and Y
     */
    bool operator==(const SInt2& a) const{
        return DX == a.DX && DY == a.DY;
    }

    /**
     * @brief Checks if this is within the rectangle defined by top_left and size
     * @param top_left The top left point of the rectangle
     * @param size The size of the rectangle
     * @return True if this is within the rectangle
     */
    bool IsContainedWithin(const SInt2& top_left, const SInt2& size) const;
    
    /**
     * @brief Returns the square magnitude of 2D int
     *
     * @return Square magnitude
     */
    int Magnitude() const{
        return DX*DX + DY*DY;
    }
};

#endif
