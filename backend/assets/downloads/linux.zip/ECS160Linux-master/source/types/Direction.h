#ifndef DIRECTION_H
#define DIRECTION_H

/**
 * @brief Holds enumeration for directions
 */
class SDirection{
    public:
        /**
         * @brief Enum for directions
         */
        typedef enum{
            dNorth = 0,
            dNorthEast,
            dEast,
            dSouthEast,
            dSouth,
            dSouthWest,
            dWest,
            dNorthWest,
            dMax
        } EValue, *EValueRef;
};

#endif
