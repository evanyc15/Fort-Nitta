#ifndef DOUBLE2_H
#define DOUBLE2_H

struct SInt2;

/**
 * @brief 2D double
 */
struct SDouble2{
    double DX;
    double DY;

    /**
     * @brief Make a new 2D double
     * @param x
     * @param y
     */
    SDouble2(double x=0, double y=0)
        : DX(x), DY(y){
    }

    /**
     * @brief Multiply with a SInt2
     * @param a The other operand
     * @return A new 2D double
     */
    SDouble2 operator*(const SInt2& a) const;
};

#endif
