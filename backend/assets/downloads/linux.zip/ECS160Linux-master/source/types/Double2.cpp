#include "Double2.h"

#include "Int2.h"

SDouble2 SDouble2::operator *(const SInt2& a) const{
    return SDouble2(DX * a.DX, DY * a.DY);
}
