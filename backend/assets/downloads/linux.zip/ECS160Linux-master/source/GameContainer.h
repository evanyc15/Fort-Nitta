#ifndef GAMECONTAINER_H
#define GAMECONTAINER_H

#include <gtk/gtk.h>

#include "game/Game.h"
#include "types/Int2.h"

/**
 * @brief Struct for storing how the frame was scaled
 */
typedef struct{
    gint DX;
    gint DY;
    gint DWidth;
    gint DHeight;
    double DScale;
} SScaledFrame, *SScaledFrameRef;

/**
 * @brief The container that sets up the window, graphics, and the timer needed
 *        for the GAMECONTAINER_H
 */
class CGameContainer {
    public:
        /**
         * @brief Builds the game
         */
        CGameContainer();
        ~CGameContainer();

        /**
         * @brief Bootstraps the game
         * @param argc Parameter count
         * @param argv Standard parameters
         * @return 0 for success
         */
        int Run(int argc, char* argv[]);

    protected:

        /**
         * @brief The game running inside this container
         */
        CGame* DGame;

        /**
         * @brief The window the game is run inside
         */
        GtkWidget* DMainWindow;
        /**
         * @brief The canvas the game is rendered inside
         */
        GtkWidget* DDrawingArea;
        /**
         * @brief The context used to draw the game
         */
        GdkGC* DDrawingContext;
        /**
         * @brief A cursor to hide the mouse
         */
        GdkCursor* DBlankCursor;

        /**
         * @brief The buffer used to store the last frame rendered if the
         *        window has to be rerendered.
         */
        GdkPixmap* DDoubleBufferPixmap;
        /**
         * @brief The pixbuf of the buffer used to scale it for the final canvas
         *        size
         */
        GdkPixbuf* DDoubleBufferPixbuf;
        /**
         * @brief The scaled version of the DDoubleBufferPixbuf for the final canvas
         *        size
         */
        GdkPixbuf* DScaledPixbuf;
        /**
         * @brief The final pixmap the pixbuf is drawn to that is the same size
         *        as the canvas
         */
        GdkPixmap* DDrawingAreaPixmap;
        /**
         * @brief Information about how the double buffer was scaled. Used for
         *        scaling mouse inputs later
         */
        SScaledFrame DScaledFrame;
        /**
         * @brief Draws the buffer frame centered on the canvas to the canvas pixmap
         */
        void UpdateDrawingAreaPixmap();
        /**
         * @brief Re-calculates how the buffer frame should be centered on the canvas
         */
        void UpdateScaledFrame();

        /**
         * @brief Creates the game window and sets up the window events
         */
        void CreateWindow();
        /**
         * @brief Creates the canvas and sets up the canvas events for mouse
         */
        void CreateDrawingArea();

        /**
         * @brief Stops the application
         */
        void Quit();

        /**
         * @brief Handler for key events
         * @param widget DMainWindow
         * @param event The key event
         * @return TRUE to signal consumed
         */
        gboolean MainWindowKeyPressEvent(GtkWidget *widget, GdkEventKey *event);
        /**
         * @brief Handler to close the window
         * @param widget DMainWindow
         * @param event The close event
         * @return FALSE to stop the game
         */
        gboolean MainWindowDeleteEvent(GtkWidget *widget, GdkEvent *event);
        /**
         * @brief Handler to quit because window closed
         * @param widget DMainWindow
         */
        void MainWindowDestroy(GtkWidget *widget);
        /**
         * @brief Handler to redraw area of drawing canvas that needs to be
         *        repainted
         * @param widget DDrawingArea
         * @param event The repaint event
         * @return FALSE to signal drawn
         */
        gboolean DrawingAreaExpose(GtkWidget *widget, GdkEventExpose *event);
        /**
         * @brief Handler for mouse button presses and forwards to DGame
         * @param widget DDrawingArea
         * @param event The mouse event
         * @return TRUE to signal consumed
         * @see CGame::ButtonPressed()
         */
        gboolean DrawingAreaButtonPressEvent(GtkWidget *widget, GdkEventButton *event);
        /**
         * @brief Handler for mouse movement and forwards to DGame
         * @param widget DDrawingArea
         * @param event The mouse event
         * @return TRUE to signal consumed
         * @see CGame::MouseMoved()
         */
        gboolean DrawingAreaMotionNotifyEvent(GtkWidget *widget, GdkEventMotion *event);

        /**
         * @brief Handler for when the canvas is resized. Used to create a new
         *        pixmap for the canvas
         * @param widget DDrawingArea
         * @param event The resizing event
         * @return TRUE to signal configured
         */
        gboolean DrawingAreaConfigureEvent(GtkWidget *widget, GdkEventConfigure *event);

        /**
         * @brief Holds value for when the next timeout should occur for steady
         *        framerate
         */
        struct timeval DNextExpectedTimeout;

        /**
         * @brief Schedules first timeout
         */
        void InitTimeout();
        /**
         * @brief Calculates amount of time to wait for next frame for steady
         *        framerate
         * @return Milliseconds to wait
         */
        int64_t GetTimeDelta();
        /**
         * @brief Advances game by one frame and renders game into double buffer
         * @return FALSE to not reschedule
         * @see CGame::Update()
         * @see CGame::Draw()
         */
        gboolean Timeout();

    private:

        static gboolean MainWindowDeleteEventCallback(GtkWidget *widget,
                GdkEvent *event, gpointer data);
        static void MainWindowDestroyCallback(GtkWidget *widget, gpointer data);
        static gboolean DrawingAreaExposeCallback(GtkWidget *widget,
                GdkEventExpose *event, gpointer data);
        static gboolean DrawingAreaButtonPressEventCallback(GtkWidget *widget,
                GdkEventButton *event, gpointer data);
        static gboolean DrawingAreaMotionNotifyEventCallback(GtkWidget *widget,
                GdkEventMotion *event, gpointer data);
        static gboolean DrawingAreaConfigureCallback(GtkWidget *widget,
                GdkEventConfigure *event, gpointer data);

        static gboolean MainWindowKeyPressEventCallback(GtkWidget *widget,
                GdkEventKey *event, gpointer data);
        static gboolean TimeoutCallback(gpointer data);
};

#endif
