#include "Cannonball.h"
#include "animations/BurnAnimation.h"
#include "animations/ExplosionAnimation.h"
#include "ConstructionTile.h"


#include "Game.h"
#include "../util/MathUtil.h"
#include "Wind.h"


std::vector<double> CCannonball::CInitialVelocities;

CCannonball::CCannonball(SInt2 position, SInt2 target, CCannon* cannon, CWind wind) {
    DToneID = -1; //So we know the tone hasn't been played yet
    LoadInitialVelocities();
    DPosition = position;
    DWind = wind;
    SInt2 Delta = target - position;
    int Distance = CMathUtil::IntegerSquareRoot(Delta.Magnitude());
    DVelocity.DZ = CInitialVelocities[Distance];
    DVelocity.DX = Delta.DX * DVelocity.DZ / Distance;
    DVelocity.DY = Delta.DY * DVelocity.DZ / Distance;
    DCannon = cannon;
    DIsAlive = true;
}

void CCannonball::LoadInitialVelocities(){
    if(CInitialVelocities.size() == 0){
        CInitialVelocities.resize(
                CMathUtil::IntegerSquareRoot(
                    GAME_WIDTH*GAME_WIDTH + GAME_HEIGHT*GAME_HEIGHT) + 1);
        for(int Index = 0; Index < CInitialVelocities.size(); Index++){
            CInitialVelocities[Index] = sqrt(STANDARD_GRAVITY * Index / 2);
        }
    }
}

bool CCannonball::TrajectoryCompare(const CCannonball &first, const CCannonball &second){
    if(first.DPosition.DZ < second.DPosition.DZ){
        return true;
    }
    if(first.DPosition.DZ > second.DPosition.DZ){
        return false;
    }
    if(first.DPosition.DY < second.DPosition.DY){
        return true;
    }
    if(first.DPosition.DY > second.DPosition.DY){
        return false;
    }
    if(first.DPosition.DX < second.DPosition.DX){
        return true;
    }
    return false;
}

int CCannonball::CalculateCannonballSize(){

    if(100.1499064 < DPosition.DZ){
        return 11;
    }
    if(97.5217589 < DPosition.DZ){
        return 10;
    }
    if(95.41127261 < DPosition.DZ){
        return 9;
    }
    if(92.81657303 < DPosition.DZ){
        return 8;
    }
    if(89.55578929 < DPosition.DZ){
        return 7;
    }
    if(85.34315122 < DPosition.DZ){
        return 6;
    }
    if(79.70240953 < DPosition.DZ){
        return 5;
    }
    if(71.77635988 < DPosition.DZ){
        return 4;
    }
    if(59.85065264 < DPosition.DZ){
        return 3;
    }
    return 2;
}


SDouble3 CCannonball::Position() {
    return DPosition;
}


void CCannonball::Position(SDouble3 PositionIn) {
    DPosition = PositionIn;
}

SDouble3 CCannonball::Velocity() {
    return DVelocity;
}


void CCannonball::Velocity(SDouble3 VelocityIn) {
    DVelocity = VelocityIn;
}

void CCannonball::Draw(CGame* game) {
    CGraphicTileset& Tileset = game->Resources()->DTilesets->D3DCannonballTileset;
    
    Tileset.DrawTile(game,
            DPosition.SInt2Position()
            - SInt2(Tileset.TileWidth(), Tileset.TileHeight())/2
            - SInt2(0, DPosition.DZ),
            CalculateCannonballSize());
}

bool CCannonball::IsAlive(){
    return DIsAlive;
}

void CCannonball::Update(CGame* game) {
    SDouble3 WindVector = game->GameState()->DWind.GetVector();
    DVelocity += WindVector;
    DPosition.DX += DVelocity.DX * TIMESTEP_PERIOD;
    DPosition.DY += DVelocity.DY * TIMESTEP_PERIOD;
    DPosition.DZ += DVelocity.DZ * TIMESTEP_PERIOD;
    DVelocity.DZ -= STANDARD_GRAVITY * TIMESTEP_PERIOD;
    bool WasAlive = DIsAlive;

    if(DVelocity.DZ < 0) {
        PlayFallingTone(game);

        CTerrainMap* TerrainMap = game->GameState()->TerrainMap();
        SInt2 IndexPosition = TerrainMap->ConvertToTileIndex(DPosition);
        if(CMathUtil::DoRectanglesOverlap(IndexPosition, SInt2(),
                    SInt2(), SInt2(TerrainMap->Width(), TerrainMap->Height()))){
            if((DPosition.DZ < 2 * TerrainMap->ConvertToScreenPosition(SInt2(0, 1)).DY)
                    && game->GameState()->ConstructionMap()->GetTileAt(IndexPosition).IsWall()){ //Trigger wall explosion
                if (10 <= ++game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DHitsTaken){
                    if (game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].IsFloor()){
                        if (game->GameState()->DRandomNumberGenerator.Random() % 5 == 0){
                            switch(game->GameState()->TerrainMap()->TileType(IndexPosition.DY,IndexPosition.DX)){
                                 case CPlayer::pcBlue:    game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttBlueFloorDamaged;
                                                          break;
                                 case CPlayer::pcRed:     game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttRedFloorDamaged;
                                                          break;
                                 case CPlayer::pcYellow:  game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttYellowFloorDamaged;
                                                          break;
                                 default:                 game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttNone;
                                                          break;
                            }
                        }
                    }
                }
                game->GameState()->ConstructionMap()->GetTileAt(IndexPosition).DestroyWall();
                game->GameState()->DAnimations.push_back(new CExplosionAnimation(game,
                            DPosition.SInt2Position() - SInt2(6,3),
                            IndexPosition,
                            game->GameState()->DRandomNumberGenerator.Random()%2 ? SBurnAndExplosion::etWallExplosion0 : SBurnAndExplosion::etWallExplosion1));
                DIsAlive = false;
            }else if(DPosition.DZ <= 0.0){
                game->Resources()->DSounds->DSoundMixer.StopTone(DToneID);//Stop tone once it hits the ground
                char compare = game->GameState()->TerrainMap()->StringMap()[IndexPosition.DY+1][IndexPosition.DX+1];
                if (compare == ' '){ //Trigger water explosion
                    game->GameState()->DAnimations.push_back(new CExplosionAnimation(game,
                                DPosition.SInt2Position() - SInt2(18,12),
                                IndexPosition,
                                game->GameState()->DRandomNumberGenerator.Random()%2 ? SBurnAndExplosion::etWaterExplosion0 : SBurnAndExplosion::etWaterExplosion1));
                } else {
                    if (5 <= ++game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DHitsTaken){
                        CPlayer* CannonballOwner = DCannon->GetPlayerOwner(game);
                        if (game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].IsFloor()){
                            if (CannonballOwner->DRandomNumberGenerator.Random() % 5 == 0){
                                switch(game->GameState()->TerrainMap()->TileType(IndexPosition.DY,IndexPosition.DX)){
                                     case CPlayer::pcBlue:    game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttBlueFloorDamaged;
                                                              break;
                                     case CPlayer::pcRed:     game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttRedFloorDamaged;
                                                              break;
                                     case CPlayer::pcYellow:  game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttYellowFloorDamaged;
                                                              break;
                                     default:                 game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttNone;
                                                              break;
                                }
                            }
                        } else if (game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType == CConstructionTile::cttNone){
                            if(0 == (CannonballOwner->DRandomNumberGenerator.Random() % 5)){
                                game->GameState()->ConstructionMap()->DTiles[IndexPosition.DY][IndexPosition.DX].DType = CConstructionTile::cttGroundDamaged;
                            }
                        }
                    }
                    game->GameState()->DAnimations.push_back(new CExplosionAnimation(game,
                                DPosition.SInt2Position() - SInt2(18,6),
                                IndexPosition,
                                game->GameState()->DRandomNumberGenerator.Random()%2 ? SBurnAndExplosion::etGroundExplosion0 : SBurnAndExplosion::etGroundExplosion1));
                }
                DIsAlive = false;
            }
        }else{
            DIsAlive = false;
        }
    }

    if(WasAlive && !DIsAlive) {
        DCannon->GetPlayerOwner(game)->DReadyCannons.push_back(DCannon);
    }
}

void CCannonball::PlayFallingTone(CGame* game) {
    if(DToneID != -1) //only want to play tone once
        return;
    float DSoundEffectVolume = 1;

    int CannonBallSize = CalculateCannonballSize();

    float freq        = 2500.0 + (CannonBallSize / 12.0) * 500.0;
    float freqdecay   = -500.0;
    float volume      = DSoundEffectVolume * CannonBallSize / 36.0;
    float volumedecay = -0.1 * DSoundEffectVolume;
    float rightbias   = (((double)DPosition.DX / GAME_WIDTH) - 0.5) * 2.0;
    float rightshift  = DVelocity.DX / (2.0 * GAME_WIDTH);

    DToneID = game->Resources()->DSounds->DSoundMixer.PlayTone(freq, freqdecay, volume, volumedecay, rightbias, rightshift);
}
