#include "Timer.h"

#include "Game.h"
#include "../util/TimeUtil.h"
#include <algorithm>

void CTimer::Draw(CGame* game){
    if(DIsVisible){
        int SecondsLeft = std::max(0, CTimeUtil::SecondsUntilDeadline(DTimeout));
        CGraphicTileset& Digits = game->Resources()->DTilesets->DDigitTileset;

        Digits.DrawTile(game, 0, 0, (SecondsLeft/10) % 10);
        Digits.DrawTile(game, Digits.TileWidth(), 0, SecondsLeft % 10);
    }
}

void CTimer::Update(CGame* game){
    if(DIsAudible){
        PlayTickTockSound(game);
    }
}

void CTimer::PlayTickTockSound(CGame* game){
    int MSUntilDeadline = CTimeUtil::MilliSecondsUntilDeadline(DTimeout) - 3000;
    int LastTickTockMS = -CTimeUtil::MilliSecondsUntilDeadline(DLastTickTockTime);
    bool PlaySound = false;
    bool PlayTick = true;

    if(MSUntilDeadline >= 5000){
        if((MSUntilDeadline/1000) != ((MSUntilDeadline + LastTickTockMS)/1000)){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/1000) & 0x01;
        }
    }else if(MSUntilDeadline >= 0){
        if((5000 < MSUntilDeadline + LastTickTockMS)
                ||((MSUntilDeadline/500) != ((MSUntilDeadline + LastTickTockMS)/500))){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/500) & 0x01;
        }
    }else{
        if((0 < MSUntilDeadline + LastTickTockMS) 
                ||((MSUntilDeadline/250) != ((MSUntilDeadline + LastTickTockMS)/250))){
            PlaySound = true;
            PlayTick = (MSUntilDeadline/500) & 0x01;
        }
    }
    if(PlaySound){
        game->Resources()->DSounds->PlaySoundClip(PlayTick ? CSounds::sctTick : CSounds::sctTock, 1, 0.0);
        gettimeofday(&DLastTickTockTime, NULL);
    }    
    
}

