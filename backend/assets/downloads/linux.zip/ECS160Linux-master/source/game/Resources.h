#ifndef RESOURCES_H
#define RESOURCES_H

#include <gtk/gtk.h>
#include "sounds/Sounds.h"
#include "tilesets/Tilesets.h"
#include "TerrainMap.h"
#include <vector>
#include <dirent.h>

class CGame;

/**
 * @brief Resources used by the game
 */
class CResources{

    public:
        CResources();
        ~CResources();

        /**
         * @brief Resource for playing clips and songs
         */
        CSounds *DSounds;

        /**
         * @brief The tilesets in the game
         */
        CTilesets *DTilesets;

        /**
         * @brief The available terrain maps
         */
        std::vector<CTerrainMap*> DTerrainMaps;

        /**
         * @brief Load calls the functions for each sub resource to initialize
         *
         */
        void Load(CGame*);
        /**
         * @brief Loads the available terrain maps
         *
         * @param game Game playing
         *
         * @return 0
         */
        bool LoadTerrainMaps(CGame* game);
};

#endif
