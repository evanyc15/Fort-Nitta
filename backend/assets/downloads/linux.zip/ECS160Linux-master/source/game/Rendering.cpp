#include "Rendering.h"
#include "TerrainMap.h"

CRendering::CRendering(GtkWidget *drawing_area, int width, int height){
    DWorkingBufferPixmap = gdk_pixmap_new(drawing_area->window, width, height, -1);
    DPreviousWorkingBufferPixmap = gdk_pixmap_new(drawing_area->window, width, height, -1);
    for(int Index = 0; Index < TERRAIN_ANIMATION_TIMESTEPS; Index++){
        D3DTerrainPixmaps.push_back(gdk_pixmap_new(drawing_area->window, width, height, -1));
    }
    D2DTerrainPixmap = NULL;
    DBannerPixmap = NULL;
    DMessagePixmap = NULL;
    DDrawingContext = NULL;
}

CRendering::~CRendering(){
    if(DWorkingBufferPixmap != NULL){
        g_object_unref(DWorkingBufferPixmap);
    }
    if(DPreviousWorkingBufferPixmap != NULL){
        g_object_unref(DPreviousWorkingBufferPixmap);
    }
}
