#ifndef GAMESTATE_H
#define GAMESTATE_H

#include "TerrainMap.h"
#include "ConstructionMap.h"
#include "players/Player.h"
#include <vector>
#include "Timer.h"
#include "Wind.h"
#include "animations/Animation.h"
#include "../util/RandomNumberGenerator.h"
#include "../network/Network.h"
#include <string>
#include "Room.h"

class CPlayer;
class CCannonball;

class CGameState{
    public:
        // Enum for AI difficulty
        typedef enum{
            aiEasy = 0, // easy ai
            aiNormal, // normal ai
            aiHard, // hard ai
            aiInsane, // highest difficulty ai
        } EAIDifficulty, *EAIDifficultyRef;

        CGameState();
        //~CGameState();
        void Reset();

        CTerrainMap* TerrainMap() const{ return DTerrainMap; }
        void TerrainMap(CTerrainMap* terrain_map){
            DTerrainMap = terrain_map; 
            DTerrainMap->DHasCached3D = false;
            DConstructionMap->ResetForMap(DTerrainMap);
        }
        CConstructionMap* ConstructionMap() const{ return DConstructionMap; }
        CNetwork* Network() const{ return DNetwork; }
        std::string DUsername;
        CRoom DRoom;
        int DTimeStep;

        CRandomNumberGenerator DRandomNumberGenerator;
        std::vector<CPlayer*> DPlayers;
        std::vector<CAnimation*> DAnimations;
        std::vector<CCannonball*> DCannonballs;
        CWind DWind;

        /**
         * @brief True if the network is updating
         */
        bool DIsNetworkUpdate;

        CTimer DTimer;
        //Wind functions
        //void SetWindType(EWindType); //Sets the WindType
        //EWindType GetWindType(); //Gets the WindType
        //void SetWindSpeed(int);
        //int GetWindSpeed();
        //void SetWindDirection(int);
        //int GetWindDirection():

        //AI Settings
        void SetAIDifficulty(EAIDifficulty difficulty) { DAIDifficulty = difficulty; } //Set AI Difficulty
        //EAIDifficulty getAIDifficulty(): //Gets the AI Difficulty
        
        CPlayer::EPlayerColor GetMainPlayerColor();
        CPlayer* GetPlayerWithColor(CPlayer::EPlayerColor color);
        std::vector<CPlayer*> GetPlayersWithOwnedCastles(CGame* game);
    private:
        // pointer to Terrain data: field, water, castle locations, etc
        CTerrainMap* DTerrainMap;
        
        CConstructionMap* DConstructionMap;

        CNetwork* DNetwork;

        /**
         * pointer to animation object
         * we may want to make this a vector later on
         */
        //CAnimations* DAnimations; 

        //Stores the AI Difficulty Setting
        EAIDifficulty DAIDifficulty;
};

#endif
