#include "UIElement.h"
#include "../Game.h"

void CUIElement::Update(CGame * const game, const SInt2 translation){
    DIsHovered = game->InputState()->DMousePosition.IsContainedWithin(
                translation + Translation(), Size());
    DIsSelected = (this == game->InputState()->SelectedElement());
    DIsPressed = DIsSelected && game->InputState()->ActionPressed();
    for(std::list<CUIElement*>::iterator it = DChildren.begin();
            it != DChildren.end(); it++){
        (*it)->Update(game, translation + Translation());
    }
}

void CUIElement::Draw(CGame * const game, const SInt2 translation){
    for(std::list<CUIElement*>::iterator it = DChildren.begin();
            it != DChildren.end(); it++){
        (*it)->Draw(game, translation + Translation());
    }
}

void CUIElement::UpdateTranslation(){
    DTranslation = DPosition - SInt2(DAnchor * DSize);
}

void CUIElement::AddChildElement(CUIElement *child){
    DChildren.push_back(child);
}

void CUIElement::RemoveChildElement(CUIElement *child){
    DChildren.remove(child);
}

void CUIElement::ClearChildren(){
    DChildren.clear();
}

void CUIElement::ConnectVertically(CUIElement* other){
    this->UpElement(other);
    other->DownElement(this);
}

CUIElement* CUIElement::DetermineSelected(SInt2 mousePosition, const SInt2 translation){
    CUIElement* selected;
    for(std::list<CUIElement*>::iterator it = DChildren.begin();
            it != DChildren.end(); it++){
        if ((selected = (*it)->DetermineSelected(mousePosition, translation + Translation()))){
            return selected;
        }
    }
    return NULL;
}
