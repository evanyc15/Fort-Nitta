#include "Button.h"

#include "../Game.h"
#include "../tilesets/FontTileset.h"

void CButton::Update(CGame * const game, const SInt2 translation){
    CLabel::Update(game, translation);
    if(IsSelected() && !DWasSelected){
        game->Resources()->DSounds->PlaySoundClip(CSounds::sctTick);
    }
    if(IsPressed()){
        game->Resources()->DSounds->PlaySoundClip(CSounds::sctPlace);
    }
    DWasSelected = IsSelected();
}

void CButton::Draw(CGame * const game, const SInt2 translation){
    SInt2 CombinedTranslation = translation + Translation();
    CFontTileset* BackgroundFont,
               * ForegroundFont;

    if(IsPressed()){
        BackgroundFont = &game->Resources()->DTilesets->DWhiteFont;
        ForegroundFont = &game->Resources()->DTilesets->DBlackFont;
    }else if(IsSelected()){
        BackgroundFont = &game->Resources()->DTilesets->DBlackFont;
        ForegroundFont = &game->Resources()->DTilesets->DWhiteFont;
    }else{
        BackgroundFont = &game->Resources()->DTilesets->DWhiteFont;
        ForegroundFont = &game->Resources()->DTilesets->DBlackFont;
    }

    BackgroundFont->DrawText(game,
          SInt2(Margin().DX + CombinedTranslation.DX - 1,
              Margin().DY + CombinedTranslation.DY - 1),
          Text());
    ForegroundFont->DrawText(game,
          SInt2(Margin().DX + CombinedTranslation.DX,
              Margin().DY + CombinedTranslation.DY),
          Text());

    CUIElement::Draw(game, translation);
}

CUIElement* CButton::DetermineSelected(SInt2 mousePosition, const SInt2 translation){
    if(mousePosition.IsContainedWithin(translation + Translation(), Size())){
        return this;
    }else{
        return NULL;
    }
}
