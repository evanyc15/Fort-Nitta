#include "Label.h"

#include "../Game.h"

CLabel::CLabel(CGame* game, std::string text, SInt2 margin, CFontTileset* font){
    DFont = font != NULL ? font : &(game->Resources()->DTilesets->DBlackFont);
    Text(text);
    Margin(margin);
}

void CLabel::Draw(CGame * const game, const SInt2 translation){
    DFont->DrawText(game,
        SInt2(Margin().DX + translation.DX + Translation().DX,
            Margin().DY + translation.DY + Translation().DY),
        Text());

    CUIElement::Draw(game, translation);
}

void CLabel::UpdateSize(){
    int Width, Height;
    DFont->MeasureText(Text(), Width, Height);
    Size(SInt2(Width, Height) + Margin()*2);
}
