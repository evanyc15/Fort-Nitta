#include "StackElement.h"

void CStackElement::AddChildElement(CUIElement *child){
    CUIElement::AddChildElement(child);
    LayoutChildren();
}

void CStackElement::RemoveChildElement(CUIElement *child){
    CUIElement::RemoveChildElement(child);
    LayoutChildren();
}

void CStackElement::ClearChildren(){
    CUIElement::ClearChildren();
    LayoutChildren();
}

void CStackElement::LayoutChildren(){
    SInt2 NewSize(Size().DX, 0);
    for(std::list<CUIElement*>::iterator it = Children()->begin();
            it != Children()->end(); it++){
        CUIElement* child = *it;
        child->Position(SInt2(Anchor().DX * NewSize.DX, NewSize.DY));
        child->Anchor(SDouble2(Anchor().DX, 0));
        NewSize += SInt2(0, child->Size().DY);
    }
    Size(NewSize);
}
