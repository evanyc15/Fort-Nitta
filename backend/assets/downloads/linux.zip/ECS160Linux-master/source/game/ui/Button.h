#ifndef BUTTON_H
#define BUTTON_H

#include "Label.h"

/**
 * @brief A Button with sound effects built in
 */
class CButton : public CLabel{
    public:
        /**
         * @brief Create a new button
         * @param text The text of the button
         * @param margin The margin around the text to also respond to
         */
        CButton(CGame *game, std::string text, SInt2 margin=DEFAULT_LABEL_MARGIN)
            : CLabel(game, text, margin), DWasSelected(false){
        }
        /**
         * @brief Updates the button and play any needed sound effects
         * @param game The game to update in
         * @param translation The computed translation
         */
        virtual void Update(CGame * const game, const SInt2 translation);
        /**
         * @brief Draws the button into the game using a basic font for now
         * @param game The game to draw in
         * @param translation The computed translation
         */
        virtual void Draw(CGame * const game, const SInt2 translation);
        /**
         * @brief Sets the previous state of the selected flag
         * @param wasSelected The previous state of the selected flag
         */
        void WasSelected(bool wasSelected){
            DWasSelected = wasSelected;
        }

        virtual CUIElement* DetermineSelected(SInt2 mousePosition, const SInt2 translation);
    private:
        /**
         * @brief Used to determine if sound effect for changing options should be played
         */
        bool DWasSelected;
};

#endif
