#include "Spinner.h"

#include <algorithm>

CSpinner::CSpinner(CGame* game, std::string text, std::vector<std::string>* const options, SInt2 margin)
    : CUIElement() {
    DOptions = *options;
    DOptionName = new CButton(game, text, margin);
    DMinus = new CButton(game, "-", margin);

    // want to leave enough room for the longest option name
    std::string LongestOption = *max_element(DOptions.begin(), DOptions.end(), StrLenComp);
    DSelectedOption = new CButton(game, LongestOption, margin);
    DLongestHorizontalSize = DSelectedOption->Size().DX;
    // logically would expect to see the first option initially
    DSelectedOption->Text(DOptions.at(0));
    DOptionsIt = DOptions.begin();

    DPlus = new CButton(game, "+", margin);
    
    Size(SInt2(Size().DX, DOptionName->Size().DY));
    LayoutElements();

    AddChildElement(DMinus);
    AddChildElement(DPlus);
    AddChildElement(DOptionName);
    AddChildElement(DSelectedOption);

}

CSpinner::~CSpinner(){
    delete DOptionName;
    delete DMinus;
    delete DPlus;
    delete DSelectedOption;
}

void CSpinner::Update(CGame* const game, const SInt2 translation){
    CUIElement::Update(game, translation);
    if(DOptionName->IsPressed()
            || DPlus->IsPressed()
            || DSelectedOption->IsPressed()){
        ChangeSelectedOption(pmPlus);
    }else if(DMinus->IsPressed()){
        ChangeSelectedOption(pmMinus);
    }
}

void CSpinner::ChangeSelectedOption(EPlusOrMinus choice){
    if(pmPlus == choice){
        if(DOptions.end() == ++DOptionsIt){
            DOptionsIt = DOptions.begin();
        }
    }else{
        if(DOptions.begin() == DOptionsIt){
            DOptionsIt = DOptions.end() - 1;
        }else{
            --DOptionsIt;
        }
    }
    DSelectedOption->Text(*DOptionsIt); 
    LayoutElements();
}

void CSpinner::LayoutElements(){
    SInt2 NewSize(0, Size().DY);
    DOptionName->Position(SInt2(NewSize.DX, 0));
    NewSize += SInt2(DOptionName->Size().DX, 0);
    DMinus->Position(SInt2(NewSize.DX, 0));
    NewSize += SInt2(DMinus->Size().DX, 0);

    // find offset to center selected option text
    int offset = (DLongestHorizontalSize - DSelectedOption->Size().DX) / 2;
    DSelectedOption->Position(SInt2(NewSize.DX + offset, 0));
    NewSize += SInt2(DLongestHorizontalSize, 0);
    DPlus->Position(SInt2(NewSize.DX, 0));
    NewSize += SInt2(DPlus->Size().DX, 0);
    Size(NewSize);
}

bool StrLenComp(std::string str1, std::string str2){ 
    return str1.length() < str2.length(); 
}
