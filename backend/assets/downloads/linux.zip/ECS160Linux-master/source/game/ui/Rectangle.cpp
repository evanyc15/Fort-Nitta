#include "Rectangle.h"

#include <gtk/gtk.h>
#include "../Game.h"

void CRectangle::Update(CGame * const game, const SInt2 translation){
    CUIElement::Update(game, translation);
    if(IsPressed()){
        Position(Position() + SInt2(10, 0));
    }
}

void CRectangle::Draw(CGame * const game, const SInt2 translation){
    GdkPixmap* Pixmap = game->Rendering()->DWorkingBufferPixmap;
    GdkGC* DrawingContext;
    if(IsPressed()){
        DrawingContext = game->DrawingArea()->style->white_gc;
    }else if(IsSelected()){
        DrawingContext = game->DrawingArea()->style->dark_gc[0];
    }else{
        DrawingContext = game->DrawingArea()->style->black_gc;
    }
    gdk_draw_rectangle(Pixmap,
            DrawingContext,
            TRUE,
            translation.DX,
            translation.DY,
            Size().DX,
            Size().DY);

    CUIElement::Draw(game, translation);
}
