#ifndef STACK_ELEMENT_H
#define STACK_ELEMENT_H

#include "UIElement.h"

/**
 * @brief A UI container that stacks its children verticaly
 */
class CStackElement : public CUIElement{
    public:
        /**
         * @brief Create a new empty stack element
         */
        CStackElement() : CUIElement() { }
        /**
         * @brief Adds a new child element and recomputes the layout
         * @param child The new child
         */
        virtual void AddChildElement(CUIElement* child);
        /**
         * @brief Removes the child element and recomputes the layout
         * @param child The child to remove
         */
        virtual void RemoveChildElement(CUIElement* child);
        /**
         * @brief Removes all the children and recomputes the layout
         */
        virtual void ClearChildren();
        /**
         * @brief Computes the layout and places the children vertically, and
         *        updates the size of the container
         */
        void LayoutChildren();
};

#endif
