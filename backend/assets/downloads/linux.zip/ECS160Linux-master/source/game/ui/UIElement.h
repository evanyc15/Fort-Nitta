#ifndef UI_ELEMENT_H
#define UI_ELEMENT_H

#include <stdlib.h>

#include "../../types/Double2.h"
#include "../../types/Int2.h"
#include <list>

class CGame;

/**
 * @brief A UI element that can be placed via its position, anchor, and size,
 *        and can render child elements in a heirarchy
 */
class CUIElement{
    public:
        /**
         * @brief CUIElement constructor to initialize element pointers
         */
        CUIElement() : DDownElement(NULL), DUpElement(NULL),
            DLeftElement(NULL), DRightElement(NULL),
            DIsPressed(false), DIsHovered(false),
            DIsSelected(false) { }
        /**
         * @brief Updates the element given its computed translation. Derived classes should
         *        override this. Also updates its children and hovered/clicked status
         * @param game The game to update in
         * @param translation The computed translation to base updating on
         */
        virtual void Update(CGame* const game, const SInt2 translation=SInt2());
        /**
         * @brief Draws the element given its computed translation. Derived classes should
         *        override this. Also draws its children.
         * @param game
         * @param translation
         */
        virtual void Draw(CGame* const game, const SInt2 translation=SInt2());
        /**
         * @brief Recomputes the translation given the size, position, and anchor
         */
        void UpdateTranslation();

        /**
         * @brief Sets the anchor (0, 0) -> Top Left, (1, 1) -> Bottom Right
         * @param anchor The new anchor
         */
        void Anchor(const SDouble2& anchor) {
            DAnchor = anchor; UpdateTranslation();
        }
        /**
         * @brief Sets the position
         * @param position The new position
         */
        void Position(const SInt2& position) {
            DPosition = position; UpdateTranslation();
        }
        /**
         * @brief Sets the size
         * @param size The new size
         */
        void Size(const SInt2& size) {
            DSize = size; UpdateTranslation();
        }
        /**
         * @brief The Anchor
         * @return
         */
        const SDouble2 Anchor() const { return DAnchor; }
        /**
         * @brief The Position
         * @return
         */
        const SInt2 Position() const { return DPosition; }
        /**
         * @brief The Size
         * @return
         */
        const SInt2 Size() const { return DSize; }
        /**
         * @brief The computed translation
         * @return
         */
        const SInt2 Translation() const { return DTranslation; }
        /**
         * @brief If the mouse is over this element
         * @return TRUE if the mouse is over this element
         */
        const bool IsHovered() const { return DIsHovered; }
        /**
         * @brief If the mouse or enter key pressed this element
         * @return TRUE if the mouse or enter key pressed this element
         */
        const bool IsPressed() const { return DIsPressed; }

        /**
         * @brief Adds a child element to this element
         * @param child The child to add
         */
        virtual void AddChildElement(CUIElement* child);
        /**
         * @brief Removes a child from this element
         * @param child The child to remove
         */
        virtual void RemoveChildElement(CUIElement* child);
        /**
         * @brief Removes all children from this element
         */
        virtual void ClearChildren();

        /**
         * @brief Gets the children of this element
         * @return
         */
        std::list<CUIElement*>* Children() { return &DChildren; }

        /**
         * @brief Sets down pointer to the element below
         * @param element The element below
         */
        void DownElement(CUIElement* element) { 
            DDownElement = element;
        }
        /**
         * @brief Gets down pointer
         * @return
         */
        CUIElement* DownElement() const { return DDownElement; }
        /**
         * @brief Sets up pointer to the element above
         * @param element The element above
         */
        void UpElement(CUIElement* element) {
            DUpElement = element;
        }
        /**
         * @brief Gets up pointer
         * @return
         */
        CUIElement* UpElement() const { return DUpElement; }
        /**
         * @brief Sets left pointer to the element left
         * @param element The element left
         */
        void LeftElement(CUIElement* element) {
            DLeftElement = element;
        }
        /**
         * @brief Gets left pointer
         * @return
         */
        CUIElement* LeftElement() const { return DLeftElement; }
        /**
         * @brief Sets right pointer to the element right
         * @param element The element right
         */
        void RightElement(CUIElement* element) {
            DRightElement = element;
        }
        /**
         * @brief Gets right pointer
         * @return
         */
        CUIElement* RightElement() const { return DRightElement; }
        /**
         * @brief If the element has been selected
         * @return TRUE if the element has been selected
         */
        const bool IsSelected() const { return DIsSelected; }
        /**
         * @brief Sets this's up pointer to other, other's down pointer to this
         */
        void ConnectVertically(CUIElement* other);

        /**
         * @brief Determines which UI element is selected given the computed translation
         * @param mousePosition Position of the mouse
         * @param parent Parent of UI element
         * @return The selected UI element
         */
        virtual CUIElement* DetermineSelected(SInt2 mousePosition, const SInt2 translation=SInt2());

    private:
        /**
         * @brief The children of this element
         */
        std::list<CUIElement*> DChildren;
        /**
         * @brief Stores if the element is currently hovered
         */
        bool DIsHovered;
        /**
         * @brief Stores if the element is currently clicked
         */
        bool DIsPressed;
        /**
         * @brief Stores the anchor to position the element by
         */
        SDouble2 DAnchor;
        /**
         * @brief Stores the computed translation
         */
        SInt2 DTranslation;
        /**
         * @brief Stores the position
         */
        SInt2 DPosition;
        /**
         * @brief Stores the size of the element
         */
        SInt2 DSize;
        /**
         * @brief The element below
         */
        CUIElement* DDownElement;
        /**
         * @brief The element above
         */
        CUIElement* DUpElement;
        /**
         * @brief The element to the left
         */
        CUIElement* DLeftElement;
        /**
         * @brief The element to the right
         */
        CUIElement* DRightElement;        
        /**
         * @brief Stores if the element is currently highlighted
         */
        bool DIsSelected;

};

#endif
