#ifndef LABEL_H
#define LABEL_H

#include <string>

#include "UIElement.h"
#include "../tilesets/FontTileset.h"

#define DEFAULT_LABEL_MARGIN SInt2(15, 15)

/**
 * @brief A UI element that renders text
 */
class CLabel : public CUIElement{
    public:
        /**
         * @brief Create a new label
         * @param text The text to show
         * @param margin The margin around the text for spacing
         * @param font The font to use
         */
        CLabel(CGame *game, std::string text, SInt2 margin=DEFAULT_LABEL_MARGIN, CFontTileset* font=NULL);
        
        
        /**
         * @brief Sets the text and updates the size
         * @param text The new text
         */
        void Text(std::string text){
            DText = text; UpdateSize();
        }
        /**
         * @brief Sets the margin and updates the size
         * @param margin The new margin
         */
        void Margin(SInt2 margin){
            DMargin = margin; UpdateSize();
        }
        /**
         * @brief The text
         * @return The text
         */
        const std::string Text() const { return DText; }
        /**
         * @brief The margin
         * @return The margin
         */
        const SInt2 Margin() const { return DMargin; }

        /**
         * @brief Draws the text into the game
         * @param game The game to draw in
         * @param translation The computed translation
         */
        virtual void Draw(CGame * const game, const SInt2 translation);
    protected:
        /**
         * @brief Used to recompute the size of the text and update the size of the label
         */
        virtual void UpdateSize();
        /**
         * @brief The margin around the text
         */
        SInt2 DMargin;
        /**
         * @brief The text to show
         */
        std::string DText;

        /**
         * @brief Font used to draw
         */
        CFontTileset* DFont;
};

#endif
