#ifndef SPINNER_H
#define SPINNER_H

#include <stdlib.h>
#include <string>
#include <vector>

#include "Button.h"
#include "../Game.h"
#include "../../types/Int2.h"
#include "Label.h"

/**
 * @brief Spinner UI Element class
 */
class CSpinner : public CUIElement{
    public:
        /**
         * @brief Spinner constructor
         *
         * @param game The game
         * @param text The option type name to be displayed
         * @param options Pointer to a vector of options, must be filled with at least one string when instantiating a spinner
         * @param margin The margin around the text for spacing
         */
        CSpinner(CGame* game, std::string text, std::vector<std::string>* const options, SInt2 margin=DEFAULT_LABEL_MARGIN);
        /**
         * @brief Spinner destructor
         */
        ~CSpinner();
        /**
         * Enum for plus or minus click
         */
        typedef enum{
            pmMinus = 0,
            pmPlus = 1
        } EPlusOrMinus, *EPlusOrMinusRef;
        /**
         * @brief Updates the spinner and changes the selected option if necessary
         *
         * @param game The game to update in
         * @param translation The computed translation
         */
        virtual void Update(CGame* const game, const SInt2 translation);
        /**
         * @brief Changes the selected option to next or previous option
         *
         * @param choice Indicates if the spinner should cycle left (minus) or right (plus)
         */
        void ChangeSelectedOption(EPlusOrMinus choice);
        /**
         * @brief Lays out the elements of the spinner horizontally
         */
        void LayoutElements();
        /**
         * @brief Gets the selected option
         *
         * @return The selected option
         */
        std::string SelectedOption() const { return *DOptionsIt; }
        /**
         * @brief Gets the longest horizontal sized option
         *
         * @return DLongestHorizontalSize
         */
        int LongestHorizontalSize() const { return DLongestHorizontalSize; }
        /**
         * @brief Sets the longest horizontal sized option
         *
         * @param size The new size
         */
        void LongestHorizontalSize(int size) { DLongestHorizontalSize = size; }

    private:
        /**
         * @brief The name for the spinner
         */
        CLabel* DOptionName;
        /**
         * @brief The minus button
         */
        CButton* DMinus;
        /**
         * @brief The plus button
         */
        CButton* DPlus;
        /**
         * @brief The selected option
         */
        CButton* DSelectedOption;
        /**
         * @brief The vector of options
         */
        std::vector<std::string> DOptions;
        /**
         * @brief Iterator pointing to the selected option in the vector
         */
        std::vector<std::string>::iterator DOptionsIt;
        /**
         * @brief The horizontal size of the selected option with the longest string
         */
        int DLongestHorizontalSize;
};

/**
 * @brief A string length comparision function
 */
bool StrLenComp(std::string str1, std::string str2);

#endif
