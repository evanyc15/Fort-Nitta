#include "TextField.h"

#include <string>

void CTextField::Update(CGame * const game, const SInt2 translation){
    CLabel::Update(game, translation);
    if(IsSelected() && game->InputState()->BackSpacePressed() && !Text().empty()){
        DTextEntered = DTextEntered.substr(0, DTextEntered.length() - 1);

        // Reset to full text to trim
        if(PasswordMode()){
            Text("");
            for(int i = 0; i < DTextEntered.length(); i++){
                Text(Text() + '*');
            }
        }else{
            Text(DTextEntered);
        }
    }else if(IsSelected()){
        if(PasswordMode() && !game->InputState()->DTextEntered.empty()){
            for(int i = 0; i < game->InputState()->DTextEntered.length(); i++){
                Text(Text() + '*');
            }
        }else{
            Text(Text() + game->InputState()->DTextEntered);
        }
        DTextEntered += game->InputState()->DTextEntered;
    }

    // Trim off left until fits
    int width, height;
    while(true){
        DFont->MeasureText(Text(), width, height);
        if(width > Size().DX - Margin().DX){
            Text(Text().substr(1, Text().length()));
        }else{
            break;
        }
    }
}

void CTextField::Draw(CGame * const game, const SInt2 translation){
    CBrickTileset& Bricks = game->Resources()->DTilesets->DBrickTileset;
    SInt2 StartingPosition(translation + Translation());
    gint BrickType = 0;
    
    // Make the horizontal size a multiple of the tile width
    int HorizontalSize = Size().DX;
    for( ; HorizontalSize % Bricks.TileWidth() != 0; HorizontalSize++);

    // Draws top and bottom borders
    for(gint WidthOffset = 0; WidthOffset < HorizontalSize; WidthOffset += Bricks.TileWidth()){
        Bricks.DrawTile(game, StartingPosition + SInt2(WidthOffset, 0), CBrickTileset::bbtTopCenter);
        Bricks.DrawTile(game, StartingPosition + SInt2(WidthOffset, Size().DY - Bricks.TileHeight()), CBrickTileset::bbtBottomCenter);
    }
    // Draws left and right borders
    for(gint HeightOffset = 0; HeightOffset < Size().DY - 4; HeightOffset += Bricks.TileHeight()){
        Bricks.DrawTile(game, StartingPosition + SInt2(0, HeightOffset), BrickType ? CBrickTileset::bbtLeft1 : CBrickTileset::bbtLeft0);
        Bricks.DrawTile(game, StartingPosition + SInt2(HorizontalSize - Bricks.TileWidth(), HeightOffset), BrickType ? CBrickTileset::bbtRight1 : CBrickTileset::bbtRight0);
        BrickType++;
        BrickType &= 0x1;
    }
    // Draws the 4 corner tiles 
    Bricks.DrawTile(game, StartingPosition, CBrickTileset::bbtTopLeft);
    Bricks.DrawTile(game, StartingPosition + SInt2(HorizontalSize - Bricks.TileWidth(), 0), CBrickTileset::bbtTopRight);
    Bricks.DrawTile(game, StartingPosition + SInt2(0, Size().DY - Bricks.TileHeight()), CBrickTileset::bbtBottomLeft);
    Bricks.DrawTile(game, StartingPosition + SInt2(HorizontalSize - Bricks.TileWidth(), Size().DY - Bricks.TileHeight()), CBrickTileset::bbtBottomRight);
    CLabel::Draw(game, translation);
}

CUIElement* CTextField::DetermineSelected(SInt2 mousePosition, const SInt2 translation){
    if(mousePosition.IsContainedWithin(translation + Translation(), Size())){
        return this;
    }else{
        return NULL;
    }
}

void CTextField::UpdateSize(){

}
