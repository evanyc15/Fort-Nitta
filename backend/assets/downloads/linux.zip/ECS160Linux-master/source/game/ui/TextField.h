#ifndef TEXTFIELD_H
#define TEXTFIELD_H

#include "Label.h"
#include "../Game.h"
#include "../../types/Int2.h"

/**
 * @brief Text field UI Element class
 */
class CTextField : public CLabel{
    public:
        /**
         * @brief CTextField constructor
         *
         * @param game The game
         * @param text The buffer to allow the user to type into
         * @param margin The margin around the element
         */
        CTextField(CGame *game, std::string text, bool mode=false, SInt2 margin=DEFAULT_LABEL_MARGIN)
                : CLabel(game, text, margin), DPasswordMode(mode), DTextEntered(text){   
        }
        /**
         * @brief Updates the text field if necessary
         *
         * @param game The game to update in
         * @param translation The computed translation
         */
        virtual void Update(CGame * const game, const SInt2 translation);
        /**
         * @brief Draws the text box and displays the user input
         *
         * @param game The game to draw in
         * @param translation The computed translation
         */
        virtual void Draw(CGame * const game, const SInt2 translation);
        /**
         * @brief Gets the actual text entered
         *
         * @return The entered text
         */
        std::string TextEntered() const { return DTextEntered; }
        /**
         * @brief Gets the password mode
         *
         * @return Whether the password mode is on or off
         */
        bool PasswordMode() const { return DPasswordMode; }
        /**
         * @brief Determines if this element is currently being selected
         *
         * @param mousePosition The position of the mouse
         * @param translation The computed translation
         *
         * @return This element if it is selected, NULL if not
         */
        CUIElement* DetermineSelected(SInt2 mousePosition, const SInt2 translation);
    protected:
        virtual void UpdateSize();
    private:
        /**
         * @brief Used to determine if the element is in password mode
         */
        bool DPasswordMode;
        /**
         * @brief Stores actual text entered, mainly for passwords since '*' is displayed on the screen
         */
        std::string DTextEntered;
};

#endif
