#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "UIElement.h"

class CRectangle : public CUIElement{
    public:
        virtual void Draw(CGame* const game, const SInt2 translation);
        virtual void Update(CGame * const game, const SInt2 translation);
};

#endif
