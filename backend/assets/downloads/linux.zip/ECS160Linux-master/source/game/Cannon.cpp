#include "Cannon.h"

#include "Game.h"
#include "animations/PlumeAnimation.h"

SInt2 CCannon::CSize(2, 2);

CCannon::CCannon(SInt2 position) {
    this->DPosition = position;

    //May want this initialized elsewhere or as a static member
    DInitialVelocities.resize(CMathUtil::IntegerSquareRoot(GAME_WIDTH * GAME_WIDTH
                + GAME_HEIGHT * GAME_HEIGHT) + 1);
    for(int Index = 0; Index < DInitialVelocities.size(); Index++){
        DInitialVelocities[Index] = sqrt(STANDARD_GRAVITY * Index / 2);
    }
}

SDirection::EValue CCannon::CalcDirection(SInt2 targetCoords) {
    int x1, y1;
    int x2, y2;

    x1 = DPosition.DX;
    y1 = DPosition.DY;
    x2 = targetCoords.DX;
    y2 = targetCoords.DY;

    return (SDirection::EValue)CMathUtil::CalculateDirection(x1, y1, x2, y2);
}

SDouble3 CCannon::CalcFiringSolution(SInt2 targetCoords) {
    int CenterX, CenterY;
    int DeltaX, DeltaY;
    int TargetX, TargetY;
    int Distance;

    SDouble3 firingSolution;

                        
    CenterX = (DPosition.DX + 1);// * DTileWidth; //not sure the purpose of these parts
    CenterY = (DPosition.DX + 1);// * DTileHeight;

    TargetX = targetCoords.DX;
    TargetY = targetCoords.DY;//slightly different from original, may need to cross check

    DeltaX = TargetX - CenterX;
    DeltaY = TargetY - CenterY;
    Distance = CMathUtil::IntegerSquareRoot(DeltaX * DeltaX + DeltaY * DeltaY);

    firingSolution.DZ = DInitialVelocities[Distance];
    firingSolution.DX = DeltaX * firingSolution.DZ / Distance;
    firingSolution.DY = DeltaY * firingSolution.DZ / Distance;

    return firingSolution;
}

void CCannon::Draw2D(CGame* game) {
    game->Resources()->DTilesets->D2DCastleCannonTileset.Draw2DCannonTile(game, 
            game->GameState()->TerrainMap()->ConvertToScreenPosition(DPosition));
}

CPlayer* CCannon::GetPlayerOwner(CGame* game){
    CConstructionTile& ConstructionTile = game->GameState()->ConstructionMap()->GetTileAt(DPosition); 
    if(ConstructionTile.IsFloor()){
        return game->GameState()->GetPlayerWithColor(ConstructionTile.GetColor());
    }else{
        return NULL;
    }
}

void CCannon::Draw3D(CGame* game){
    SDirection::EValue direction = SDirection::dSouth;
    CPlayer* Owner = GetPlayerOwner(game);
    if(Owner != NULL){
        SInt2 CenterPosition = game->GameState()->TerrainMap()
            ->ConvertToScreenPosition(DPosition + SInt2(1, 1));
        direction = (SDirection::EValue)CMathUtil::CalculateDirection(CenterPosition, 
                    Owner->DCursorPosition);
    }

    game->Resources()->DTilesets->D3DCannonTileset.DrawTile(game,
            game->GameState()->TerrainMap()->ConvertToScreenPosition(DPosition),
            direction);
}


void CCannon::FireAt(CGame* game, SInt2 target) {
    SInt2 CenterPosition = game->GameState()->TerrainMap()
        ->ConvertToScreenPosition(DPosition + SInt2(1, 1));

    game->GameState()->DAnimations.push_back(new CPlumeAnimation(game,
                game->GameState()->TerrainMap()->ConvertToScreenPosition(DPosition),
                DPosition,
                (SDirection::EValue)CMathUtil::CalculateDirection(CenterPosition, target)));
    game->GameState()->DCannonballs.push_back(new CCannonball(CenterPosition, target, this,
                game->GameState()->DWind));

}

void CCannon::Update(CGame* game) {
    //DDirection = CalcDirection(targetCoords);
}
