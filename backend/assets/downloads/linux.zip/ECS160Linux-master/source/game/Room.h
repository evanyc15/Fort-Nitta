#ifndef ROOM_H
#define ROOM_H

#include <string>
#include <vector>

class CRoom{
    public:
        CRoom()
            : DIsOwnedByLocalUser(false)
        { }
        CRoom(std::string name, int player_count, bool is_broadcast=false)
            : DName(name), DPlayerCount(player_count), DIsOwnedByLocalUser(false),
              DIsBroadcast(is_broadcast)
        { }
        
        std::string Name() { return DName; }
        int PlayerCount() { return DPlayerCount; }

        std::vector<std::string> DPlayerUsernames;
        std::vector<std::string> DSpectatorUsernames;
        bool DIsOwnedByLocalUser;
        bool DIsBroadcast;
        bool DIsMultiplayer;
        std::string DName;
        int DPlayerCount;
    protected:
};


#endif
