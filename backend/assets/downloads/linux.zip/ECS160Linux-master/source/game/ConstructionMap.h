#ifndef CONSTRUCTIONMAP_H
#define CONSTRUCTIONMAP_H

#include <vector>
#include "TerrainMap.h"
#include "ConstructionTile.h"
#include "Castle.h"
#include "Cannon.h"

class CGame;

/**
 * @brief Map containing information about walls and cannons in game
 */
class CConstructionMap{
    public:
        /**
         * @brief Clears map and cannons, and resizes the construction map for a terrain map
         *
         * @param map Terrain map to match size
         */
        void ResetForMap(CTerrainMap* map);
        /**
         * @brief Draws the walls, floors, and cannons in 2D
         *
         * @param game Game to draw in
         */
        void Draw2D(CGame* game);
        /**
         * @brief Draws the cannons in 2D
         *
         * @param game Game to draw in
         */
        void Draw2DCannons(CGame* game);
        /**
         * @brief Draws the walls and floors in 3D
         *
         * @param game The game to draw in
         */
        void Draw3D(CGame* game, int XIndex, int YIndex, int XPos, int YPos);
        /**
         * @brief Draws the floors in 3D
         *
         * @param game The game to draw in
         */
        void Draw3DFloor(CGame* game, int XIndex, int YIndex, int XPos, int YPos);
        /**
         * @brief Draws the walls in 3D
         *
         * @param game The game to draw in
         */
        void Draw3DWalls(CGame* game, int XIndex, int YIndex, int XPos, int YPos);
        /**
         * @brief Draws the cannons in 3D
         *
         * @param game The game to draw in
         */
        void Draw3DCannons(CGame* game, int XPos, int YPos);
        /**
         * @brief Builds walls around a castle, adjusting for obstructions
         *
         * @param game The game playing
         * @param castle The castle to surround
         */
        void SurroundCastle(CGame* game, Castle* castle);
        /**
         * @brief Determines if the given rectangle is open in the map for a color
         *
         * @param player_color The color to be open for
         * @param position The top left of the rectangle
         * @param size The size of the rectangle
         *
         * @return True if space is open, otherwise false
         */
        bool IsSpaceOpenForColor(CPlayer::EPlayerColor player_color, SInt2 position, SInt2 size);
        /**
         * @brief Determines if given rectangle does not collide with cannons
         *
         * @param position The top left of the rectangle
         * @param size The size of the rectangle
         *
         * @return True if no collisions, otherwise false
         */
        bool IsSpaceFreeOfCannons(SInt2 position, SInt2 size);
        /**
         * @brief Gets the construction tile at the position
         *
         * @param position Index of the tile
         *
         * @return Reference to tile
         */
        CConstructionTile& GetTileAt(SInt2 position);

        /**
         * @brief Getter for tiles of map
         *
         * @return Reference to 2D array
         */
        std::vector<std::vector<CConstructionTile> > &Tiles() { return DTiles; }
        /**
         * @brief Getter for cannons of map
         *
         * @return Reference to cannon list
         */
        std::vector<CCannon*> &Cannons(){ return DCannons; }
        /**
         * @brief Stores the 2D array of construction
         */
        std::vector<std::vector<CConstructionTile> > DTiles;

    protected:
        /**
         * @brief Stores the list of cannons
         */
        std::vector<CCannon*> DCannons;
};

#endif

