#include "ConstructionMap.h"
#include "Game.h"
#include "tilesets/WallFloorTileset.h"
#include "../util/MathUtil.h"

void CConstructionMap::ResetForMap(CTerrainMap* map){
    DCannons.clear();
    DTiles.resize(map->Height());
    for(std::vector<std::vector<CConstructionTile> >::iterator row = DTiles.begin();
            row != DTiles.end();
            row++){
        (*row).resize(map->Width());
        for(std::vector<CConstructionTile>::iterator column = (*row).begin();
                column != (*row).end();
                column++){
            (*column).Reset();
        }
    }
}

void CConstructionMap::Draw2D(CGame* game){
    CTerrainMap* Map = game->GameState()->TerrainMap();
    CWallFloorTileset& Tileset = game->Resources()->DTilesets->DWallFloorTileset;
    SInt2 TileSize = Map->ConvertToScreenPosition(SInt2(1, 1));
    for(int YIndex = 0, YPos = 0; YIndex < DTiles.size(); YIndex++, YPos += TileSize.DY){
        for(int XIndex = 0, XPos = 0; XIndex < DTiles[YIndex].size(); XIndex++, XPos+= TileSize.DX){
            bool IsEven = ((YIndex + XIndex) & 0x1) ? false : true;
            int WallType = 0xF;
            if(DTiles[YIndex][XIndex].IsWall()){
                if(YIndex && (DTiles[YIndex-1][XIndex].IsWall()||DTiles[YIndex-1][XIndex].IsWallDamaged())){
                    WallType &= 0xE;
                }
                if((XIndex + 1 < DTiles[YIndex].size()) && (DTiles[YIndex][XIndex+1].IsWall()||DTiles[YIndex][XIndex+1].IsWallDamaged())){
                    WallType &= 0xD;
                }
                if((YIndex + 1 < DTiles.size()) && (DTiles[YIndex+1][XIndex].IsWall()||DTiles[YIndex+1][XIndex].IsWallDamaged())){
                    WallType &= 0xB;
                }
                if(XIndex && (DTiles[YIndex][XIndex-1].IsWall()||DTiles[YIndex][XIndex-1].IsWallDamaged())){
                    WallType &= 0x7;
                }
            }

            switch(DTiles[YIndex][XIndex].DType){
                case CConstructionTile::cttBlueWall:           Tileset.Draw2DWallTile(game, XPos, YPos, CPlayer::pcBlue, WallType);
                                                               break;
                case CConstructionTile::cttRedWall:            Tileset.Draw2DWallTile(game, XPos, YPos, CPlayer::pcRed, WallType);
                                                               break;
                case CConstructionTile::cttYellowWall:         Tileset.Draw2DWallTile(game, XPos, YPos, CPlayer::pcYellow, WallType);
                                                               break;
                case CConstructionTile::cttBlueFloor:          
                case CConstructionTile::cttBlueFloorDamaged:   Tileset.Draw2DFloorTile(game, XPos, YPos, IsEven ? CPlayer::pcNone : CPlayer::pcBlue);
                                                               break;
                case CConstructionTile::cttRedFloor:
                case CConstructionTile::cttRedFloorDamaged:    Tileset.Draw2DFloorTile(game, XPos, YPos, IsEven ? CPlayer::pcNone : CPlayer::pcRed);
                                                               break;
                case CConstructionTile::cttYellowFloor:    
                case CConstructionTile::cttYellowFloorDamaged: Tileset.Draw2DFloorTile(game, XPos, YPos, IsEven ? CPlayer::pcNone : CPlayer::pcYellow);
                                                               break;
                default:                break;
            }
            if(DTiles[YIndex][XIndex].IsGroundDamaged()){
                game->Resources()->DTilesets->D2DTerrainTileset.DrawDamagedGroundTile(game, SInt2(XPos, YPos));
            }
        }
    }

    Draw2DCannons(game);
}

void CConstructionMap::Draw2DCannons(CGame* game){
    for(std::vector<CCannon*>::iterator it = DCannons.begin();
            it != DCannons.end();
            it++){
        (*it)->Draw2D(game);
    }
}

bool TileTypeIsFloor(CConstructionTile tile){
    CConstructionTile::EConstructionTileType type = tile.DType;
    return (CConstructionTile::cttBlueFloor == type)||(CConstructionTile::cttRedFloor == type)||(CConstructionTile::cttYellowFloor == type);
};

bool TileTypeIsFloorDamaged(CConstructionTile tile){
    CConstructionTile::EConstructionTileType type = tile.DType;
    return (CConstructionTile::cttBlueFloorDamaged == type)||(CConstructionTile::cttRedFloorDamaged == type) || (CConstructionTile::cttYellowFloorDamaged == type);
};

bool TileTypeIsWall(CConstructionTile tile){
    CConstructionTile::EConstructionTileType type = tile.DType;
    return (CConstructionTile::cttBlueWall == type)||(CConstructionTile::cttRedWall == type)||(CConstructionTile::cttYellowWall == type);
};

bool TileTypeIsWallDamaged(CConstructionTile tile){
    CConstructionTile::EConstructionTileType type = tile.DType;
    return (CConstructionTile::cttBlueWallDamaged == type)||(CConstructionTile::cttRedWallDamaged == type)||(CConstructionTile::cttYellowWallDamaged == type);
};

bool TileTypeIsFloorGroundDamaged(CConstructionTile tile){
    CConstructionTile::EConstructionTileType type = tile.DType;
    return (CConstructionTile::cttGroundDamaged == type)||(CConstructionTile::cttBlueFloorDamaged == type)||(CConstructionTile::cttRedFloorDamaged == type) || (CConstructionTile::cttYellowFloorDamaged == type);
};

void CConstructionMap::Draw3DFloor(CGame* game, int XIndex, int YIndex, int XPos, int YPos){
    C3DFloorTileset& FloorTileset = game->Resources()->DTilesets->D3DFloorTileset;
    
    /**
     * For each tile, check whether tile should be a wall or floor, and if they are damaged,
     * then draw that tile.
     */
    switch(DTiles[YIndex][XIndex].DType){
    case CConstructionTile::cttBlueWall:
    case CConstructionTile::cttBlueWallDamaged:
    case CConstructionTile::cttRedWall:
    case CConstructionTile::cttRedWallDamaged:
    case CConstructionTile::cttYellowWall:
    case CConstructionTile::cttYellowWallDamaged:
        if(YIndex + 1 < DTiles.size()){
            if(!DTiles[YIndex+1][XIndex].IsFloor()){
                break;
            }
        }
        else{
            break;
        }
    case CConstructionTile::cttBlueFloor:
    case CConstructionTile::cttBlueFloorDamaged:
    case CConstructionTile::cttRedFloor:
    case CConstructionTile::cttRedFloorDamaged:
    case CConstructionTile::cttYellowFloor:
    case CConstructionTile::cttYellowFloorDamaged:
        FloorTileset.Draw3DFloorTile(game, SInt2(XPos, YPos+FloorTileset.TileHeight()), game->GameState()->TerrainMap()->TileType(XIndex, YIndex));
        break;
    default:
        break;
    }
}

void CConstructionMap::Draw3DWalls(CGame* game, int XIndex, int YIndex, int XPos, int YPos){
    C3DWallTileset& WallTileset = game->Resources()->DTilesets->D3DWallTileset;
    C3DTerrainTileset& TerrainTileset = game->Resources()->DTilesets->D3DTerrainTileset;
    //For each tile, determine WallType, and WallOffset, and call appropriate draw function, if
    //the tile is not part of a fortress/castle, then draw the appropriate tile, i.e. grass/water/
    //smoke, etc.

    int WallType = 0xF;
    int WallOffset = 0x0;
    if(TileTypeIsWall(DTiles[YIndex][XIndex])){
        if(YIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex]))){
            WallType &= 0xE;
        }
        if((XIndex + 1 < DTiles[YIndex].size()) && (TileTypeIsWall(DTiles[YIndex][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex][XIndex+1]))){
            WallType &= 0xD;
        }
        if((YIndex + 1 < DTiles.size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex]))){
            WallType &= 0xB;
        }
        if(XIndex && (TileTypeIsWall(DTiles[YIndex][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex][XIndex-1]))){
            WallType &= 0x7;
        }
        switch(WallType){
        case 0: WallOffset = 0xF;
            if(YIndex){
                if((XIndex + 1 < DTiles[YIndex].size()) && (TileTypeIsWall(DTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex+1]))){
                    WallOffset &= 0xE;
                }
                if(XIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex-1]))){
                    WallOffset &= 0x7;
                }
            }
            if(YIndex + 1 < DTiles.size()){
                if((XIndex + 1 < DTiles[YIndex].size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex+1]))){
                    WallOffset &= 0xD;
                }
                if(XIndex && (TileTypeIsWall(DTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex-1]))){
                    WallOffset &= 0xB;
                }
            }
            break;
        case 1: WallOffset = 0x3;
            if(YIndex + 1 < DTiles.size()){
                if((XIndex + 1 < DTiles[YIndex].size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex+1]))){
                    WallOffset &= 0x2;
                }
                if(XIndex && (TileTypeIsWall(DTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex-1]))){
                    WallOffset &= 0x1;
                }
            }
            break;
        case 2: WallOffset = 0x3;
            if(XIndex){
                if((YIndex + 1 < DTiles.size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex-1]))){
                    WallOffset &= 0x2;
                }
                if(YIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex-1]))){
                    WallOffset &= 0x1;
                }
            }
            break;
        case 3: WallOffset = 1;
            if(XIndex && (YIndex + 1 < DTiles.size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex-1]))){
                WallOffset = 0;
            }
            break;
        case 4: WallOffset = 0x3;
            if(YIndex){
                if((XIndex + 1 < DTiles[YIndex].size()) && (TileTypeIsWall(DTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex+1]))){
                    WallOffset &= 0x2;
                }
                if(XIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex-1]))){
                    WallOffset &= 0x1;
                }
            }
            break;
        case 6: WallOffset = 1;
            if(XIndex && YIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex-1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex-1]))){
                WallOffset = 0;
            }
            break;
        case 8: WallOffset = 0x3;
            if(XIndex + 1 < DTiles[YIndex].size()){
                if(YIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex+1]))){
                    WallOffset &= 0x2;
                }
                if((YIndex + 1 < DTiles.size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex+1]))){
                    WallOffset &= 0x1;
                }
            }
            break;
        case 9: WallOffset = 1;
            if((XIndex + 1 < DTiles[YIndex].size()) && (YIndex + 1 < DTiles.size()) && (TileTypeIsWall(DTiles[YIndex+1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex+1][XIndex+1]))){
                WallOffset = 0;
            }
            break;
        case 12:WallOffset = 1;
            if((XIndex + 1 < DTiles[YIndex].size()) && YIndex && (TileTypeIsWall(DTiles[YIndex-1][XIndex+1])||TileTypeIsWallDamaged(DTiles[YIndex-1][XIndex+1]))){
                WallOffset = 0;
            }
            break;
        default:WallOffset = 0;
            break;
        }

        switch(DTiles[YIndex][XIndex].DType){
        case CConstructionTile::cttBlueWall:       WallTileset.Draw3DWallTile(game, SInt2(XPos, YPos), CPlayer::pcBlue, WallType, WallOffset);
            break;
        case CConstructionTile::cttRedWall:        WallTileset.Draw3DWallTile(game, SInt2(XPos, YPos), CPlayer::pcRed, WallType, WallOffset);
            break;
        case CConstructionTile::cttYellowWall:     WallTileset.Draw3DWallTile(game, SInt2(XPos, YPos), CPlayer::pcYellow, WallType, WallOffset);
            break;
        default:                break;
        }
    }
    else if(TileTypeIsWallDamaged(DTiles[YIndex][XIndex])){
        if(YIndex && TileTypeIsWall(DTiles[YIndex-1][XIndex])){
        WallType &= 0xE;
        }
        if((XIndex + 1 < DTiles[YIndex].size()) && TileTypeIsWall(DTiles[YIndex][XIndex+1])){
        WallType &= 0xD;
        }
        if((YIndex + 1 < DTiles.size()) && TileTypeIsWall(DTiles[YIndex+1][XIndex])){
        WallType &= 0xB;
        }
        if(XIndex && TileTypeIsWall(DTiles[YIndex][XIndex-1])){
        WallType &= 0x7;
        }
        switch(DTiles[YIndex][XIndex].DType){
            case CConstructionTile::cttBlueWallDamaged:    WallTileset.Draw3DDamagedWallTile(game, SInt2(XPos, YPos), CPlayer::pcBlue, WallType);
                                                           break;
            case CConstructionTile::cttRedWallDamaged:     WallTileset.Draw3DDamagedWallTile(game, SInt2(XPos, YPos), CPlayer::pcRed, WallType);
                                                           break;
            case CConstructionTile::cttYellowWallDamaged:  WallTileset.Draw3DDamagedWallTile(game, SInt2(XPos, YPos), CPlayer::pcYellow, WallType);
                                                           break;
            default:                                       break;
        }
    }
    else if(TileTypeIsFloorGroundDamaged(DTiles[YIndex][XIndex])){
        TerrainTileset.DrawDamagedGroundTile(game, SInt2(XPos, YPos + TerrainTileset.TileHeight()));
    }

}
void CConstructionMap::Draw3D(CGame* game, int XIndex, int YIndex, int XPos, int YPos){
    
//    Draw3DFloor(game);
//    Draw3DWalls(game);
}

void CConstructionMap::Draw3DCannons(CGame* game,  int XPos, int YPos){
    for(std::vector<CCannon*>::iterator it = DCannons.begin();
            it != DCannons.end();
            it++){
        if ((*it)->DPosition == SInt2(XPos-1,YPos-1)){
            (*it)->Draw3D(game);

        }
    }
}

CConstructionTile& CConstructionMap::GetTileAt(SInt2 position){
    return DTiles[position.DY][position.DX];
}

bool CConstructionMap::IsSpaceOpenForColor(CPlayer::EPlayerColor player_color, SInt2 position, SInt2 size){
    CConstructionTile::EConstructionTileType ConTileType;

    if(CPlayer::pcBlue == player_color){
        ConTileType = CConstructionTile::cttBlueFloor;
    }
    else if(CPlayer::pcRed == player_color){
        ConTileType = CConstructionTile::cttRedFloor;
    }
    else{
        ConTileType = CConstructionTile::cttYellowFloor;
    }
    if(position.DX + 1 >= DTiles[0].size()){
        return false;
    }
    if(position.DY + 1 >= DTiles.size()){
        return false;
    }
    for(int YOff = 0; YOff < 2; YOff++){
        for(int XOff = 0; XOff < 2; XOff++){
            if(ConTileType != DTiles[position.DY + YOff][position.DX + XOff].DType){
                return false;
            }
        }
    }

    return IsSpaceFreeOfCannons(position, size);
}

bool CConstructionMap::IsSpaceFreeOfCannons(SInt2 position, SInt2 size){
    for(std::vector<CCannon*>::iterator it = DCannons.begin();
            it != DCannons.end();
            it++){
        if(CMathUtil::DoRectanglesOverlap((*it)->DPosition, (*it)->CSize, position, size)){
            return false;
        }
    }
    return true;
}

void CConstructionMap::SurroundCastle(CGame* game, Castle* castle){
    CConstructionTile::EConstructionTileType ConTileType, WallType;
    double LRRatio;

    int XPos = castle->IndexPosition().DX;
    int YPos = castle->IndexPosition().DY;

    if(CPlayer::pcBlue == castle->DColor){
        ConTileType = CConstructionTile::cttBlueFloor;
        WallType = CConstructionTile::CConstructionTile::cttBlueWall;
    }
    else if(CPlayer::pcRed == castle->DColor){
        ConTileType = CConstructionTile::cttRedFloor;
        WallType = CConstructionTile::cttRedWall;
    }
    else{
        ConTileType = CConstructionTile::cttYellowFloor;
        WallType = CConstructionTile::cttYellowWall;
    }

    for(int YOffset = -3; YOffset <= 4; YOffset++){
        int YI = YPos + YOffset;
        for(int XOffset = -3; XOffset <= 4; XOffset++){
            int XI = XPos + XOffset;
            char TileType = game->GameState()->TerrainMap()->TileType(XI, YI);

            if(TileType == castle->DColor && !DTiles[YI][XI].IsGroundDamaged()){
                DTiles[YI][XI].DType = ConTileType;       
            }
        }
    }
    for(int YOffset = -3; YOffset <= 4; YOffset++){
        int YI = YPos + YOffset;
        for(int XOffset = -3; XOffset <= 4; XOffset++){
            int XI = XPos + XOffset;

            if(ConTileType == DTiles[YI][XI].DType){
                bool MakeWall = false;
                if(YI){
                    if(XI && (CConstructionTile::cttNone == DTiles[YI-1][XI-1].DType)){
                        MakeWall = true;   
                    }
                    if(CConstructionTile::cttNone == DTiles[YI-1][XI].DType){
                        MakeWall = true;
                    }
                    if((XI + 1 < DTiles[YI].size()) && (CConstructionTile::cttNone == DTiles[YI-1][XI+1].DType)){
                        MakeWall = true;
                    }
                }
                else{
                    MakeWall = true;   
                }
                if(XI){
                    if(CConstructionTile::cttNone == DTiles[YI][XI-1].DType){
                        MakeWall = true;
                    }
                }
                else{
                    MakeWall = true;   
                }
                if(XI + 1 < DTiles[YI].size()){
                    if(CConstructionTile::cttNone == DTiles[YI][XI+1].DType){
                        MakeWall = true;
                    }
                }
                else{
                    MakeWall = true;    
                }
                if(YI + 1 < DTiles.size()){
                    if(XI && (CConstructionTile::cttNone == DTiles[YI+1][XI-1].DType)){
                        MakeWall = true;
                    }
                    if(CConstructionTile::cttNone == DTiles[YI+1][XI].DType){
                        MakeWall = true;
                    }
                    if((XI + 1 < DTiles[YI].size()) && (CConstructionTile::cttNone == DTiles[YI+1][XI+1].DType)){
                        MakeWall = true;
                    }
                }
                else{
                    MakeWall = true;    
                }
                if(MakeWall){
                    DTiles[YI][XI].DType = WallType;
                }
            }
        }
    }
}
