#ifndef CANNONBALL_H
#define CANNONBALL_H

#include "../types/Double3.h"
#include "tilesets/GraphicTileset.h"
#include "sounds/SoundLibraryMixer.h"
#include "players/Player.h"
#include "Wind.h"
#include <vector>


class CCannon;
/**
 * Class representing Cannonball
 */
class CCannonball {
    public:
        /**
         * @brief Makes cannonball headed to a target fired from a cannon
         *
         * @param position The position starting from
         * @param target The target headed to
         * @param cannon The originating cannon, for reloading
         * @param wind The wind for this cannonball
         */
        CCannonball(SInt2 position, SInt2 target, CCannon* cannon, CWind wind); 

        /**
         * Calculates cannonball size depending on z position
         *
         * @param z z position of cannonball
         *
         * @return cannonball size
         */ 
        int CalculateCannonballSize();

        /**
         * @brief Returns if cannonball should continue its existence 
         *
         * @return DIsAlive
         */
        bool IsAlive();

        /**
         * @brief The load precomputed velocities needed to head to target
         */
        static void LoadInitialVelocities();

        /**
         * Compares positions of two cannonballs
         *
         * @param first const reference to a CannonBall
         * @param second const reference to a CannonBall
         *
         * @return True if first's position is greater than second's position,
         * false if first's position is greater than second's position; 
         * checked in order of z position, y position, x position
         */
        static bool TrajectoryCompare(const CCannonball &first, const CCannonball &second);
        /**
         * @brief Stores the precomputed velocities need to head to target
         */
        static std::vector<double> CInitialVelocities;
        
        /*
         * Getter for position of the Cannonball
         */
        SDouble3 Position();

        /*
         * Setter for position of the Cannonball
         */
        void Position(SDouble3 PositionIn);

        /*
         * Getter for velocity of the Cannonball
         */
        SDouble3 Velocity();


        /*
         * Setter for Velocity of the Cannonball
         */
        void Velocity(SDouble3 VelocityIn);

        /*
         * Getter for the Cannonball's cannon
         */
        CCannon* Cannon(){ return DCannon; }

        /*
         * Draw the Cannonball
         * Will probably have to pass in a pointer to game or at least the drawing context
         */
        void Draw(CGame* game);

        /**
         * @brief Moves cannonball in air and calculates if collided and destroys walls.
         *        Updates if it is alive, and reloads the cannon if not.
         *
         * @param game The game updating in
         */
        void Update(CGame* game);

        /**
         * Play tone for falling cannonball
         * @param game The game we're updating
         */
        void PlayFallingTone(CGame* game);

    protected: 
        //these will either be initialized in constructor or passed in with something else
        bool DIsAlive;

        /**
         * @brief Position of the ball
         */
        SDouble3 DPosition;
        /**
         * @brief Velocity of the ball
         */
        SDouble3 DVelocity;
        /**
         * @brief The originating cannon used for reloading
         */
        CCannon* DCannon;
        /**
         * @brief ID for the currently playing tone
         */
        int DToneID;

        /**
         * @brief Stores the wind properties on this cannonball
         */
        CWind DWind;
};
#endif
