#ifndef CANNON_H
#define CANNON_H

#include "../types/Double3.h"
#include "../util/MathUtil.h"
#include "../types/Direction.h"
#include "../types/Int2.h"
#include <math.h>
#include "Cannonball.h"
#include "players/Player.h"

/**
 * @brief A cannon used to fire cannonballs in a construction map
 */
class CCannon {
    public:
        /**
         * @brief Creates a new cannon at a position and initializes the initial velocities
         *
         * @param position The position of the cannon
         */
        CCannon(SInt2 position);

        /**
         * @brief Draws the 2D tile for the cannon
         *
         * @param game The game to draw in
         */
        void Draw2D(CGame* game);
        /**
         * @brief Draws the 3D tile for its owner if it has one
         *
         * @param game The game to draw in
         */
        void Draw3D(CGame* game);
        /**
         * @brief Fires a cannonball at the target and adds the plume animation
         *
         * @param game The game to fire in
         * @param target The position of the target
         */
        void FireAt(CGame* game, SInt2 target);
        /**
         * @brief Does nothing
         *
         * @param game The game to update in
         */
        void Update(CGame* game);

        /**
         * @brief Gets the owner of the cannon based on the floor tile it is located on
         *
         * @param game The game to search for tile
         *
         * @return Pointer to owner or NULL
         */
        CPlayer* GetPlayerOwner(CGame* game);

        /**
         * @brief The size of the cannon: (2, 2)
         */
        static SInt2 CSize;
        /**
         * @brief The position of the cannon
         */
        SInt2  DPosition;
    protected:
        /**
         * @brief Not used
         */
        SDirection::EValue DDirection;

    private:
        /**
         * @brief Precomputed values of velocities needed to hit targets
         */
        std::vector< double > DInitialVelocities;
        /**
         * @brief Calculated direction to face for a target
         *
         * @param targetCoords The target to fire at
         *
         * @return Direction should be seen facing
         */
        SDirection::EValue CalcDirection(SInt2 targetCoords);
        /**
         * @brief Calculates the velocities to fire cannonball at
         *
         * @param targetCoords The target to fire at
         *
         * @return The X/Y/Z of velocities for cannonball
         */
        SDouble3 CalcFiringSolution(SInt2 targetCoords);

};
#endif
