#include "GameState.h"

#include "players/Player.h"

#include <pthread.h>


/**
 * The GameState object is created in by the Game class before a match has actually started
 * So this constructor just prepares some default values
 * CGameState::Init() will set up the Game State object for an actual match
 */
CGameState::CGameState(){
    //We don’t know what map the player is playing on yet
    DTerrainMap = NULL;
    DConstructionMap = new CConstructionMap();

    pthread_attr_t ThreadAttributes;
    size_t StackSize;
    pthread_attr_init(&ThreadAttributes);
    pthread_attr_getstacksize(&ThreadAttributes, &StackSize);
    DNetwork = new CNetwork(StackSize, true);
    DIsNetworkUpdate = false;
    DTimeStep = 0;

    this->Reset();
};

void CGameState::Reset(){
    DPlayers.clear();
    if(DTerrainMap != NULL){
        DTerrainMap->Reset();
        DConstructionMap->ResetForMap(DTerrainMap);
    }

    DAIDifficulty = aiEasy;
}

CPlayer::EPlayerColor CGameState::GetMainPlayerColor(){
    CPlayer::EPlayerColor MainColor = CPlayer::pcNone;
    for(std::vector<CPlayer*>::iterator it = DPlayers.begin();
            it != DPlayers.end();
            it++){
        if((*it)->DIsLocalPlayer && !(*it)->DIsAI){
            MainColor = (*it)->DColor;
        }
    }
    return MainColor;
}

CPlayer* CGameState::GetPlayerWithColor(CPlayer::EPlayerColor color){
    for(std::vector<CPlayer*>::iterator it = DPlayers.begin();
            it != DPlayers.end();
            it++){
        if((*it)->DColor == color){
            return *it;
        }
    }
    return NULL;
}

std::vector<CPlayer*> CGameState::GetPlayersWithOwnedCastles(CGame* game){
    std::vector<CPlayer*> PlayersWithOwnedCastles;
    for(std::vector<CPlayer*>::iterator it = DPlayers.begin();
            it != DPlayers.end();
            it++){
        if((*it)->OwnedCastleCount(game) > 0){
            PlayersWithOwnedCastles.push_back(*it);
        }
    }
    return PlayersWithOwnedCastles;
}
