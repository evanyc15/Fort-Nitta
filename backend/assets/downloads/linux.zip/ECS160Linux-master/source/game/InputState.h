#ifndef INPUT_STATE_H
#define INPUT_STATE_H

#include "../types/Int2.h"
#include "ui/UIElement.h"
#include <string>

/**
 * @brief Simple management of input
 */
class CInputState{
    public:
        CInputState();

        /**
         * @brief Enum for mouse buttons, left and right
         */
        typedef enum{
            ibNone = -1,
            ibUnknownButton = 0,
            ibLeftButton = 1,
            ibRightButton = 3
        } EInputButton, *EInputButtonRef;

        /**
         * @brief Resets if the button was pressed, called per frame
         */
        void Reset();
        /**
         * @brief Changes the selected UI element
         * @param element The new selected UI element
         */
        void SelectedElement(CUIElement* element);
        /**
         * @brief Gets the selected UI element
         */
        CUIElement* SelectedElement() const { return DSelectedUIElement; }
        /**
         * @brief Handles keyboard input
         * @param keyval The key that was pressed
         */
        void KeyPressed(unsigned int keyval);
        /**
         * @brief Updates the selected UI element if necessary
         * @param root The root UI element to begin search
         */
        void UpdateSelectedElement(CUIElement* root);
        /**
         * @brief Updates the state if a button is pressed
         * @param pressed Whether the mouse was clicked or enter key pressed
         */
        void ButtonPressed(CInputState::EInputButton button);
        /**
         * @brief Gets the state of if a button was pressed
         */
        bool ActionPressed() const { return DActionPressed; }
        /**
         * @brief Gets the state of if the backspace key was pressed
         */
        bool BackSpacePressed() const { return DBackSpacePressed; }
        /**
         * @brief Holds the position the mouse is currently at
         */
        SInt2 DMousePosition;
        /**
         * @brief Holds the button pressed for the frame
         */
        EInputButton DButtonPressed;
        /**
         * @brief The currently selected element
         */
        CUIElement* DSelectedUIElement;
        /**
         * @brief Whether the mouse button is down or the enter key is pressed
         */
        bool DActionPressed;
        /**
         * @brief The text entered by the user
         */
        std::string DTextEntered;
        /**
         * @brief Whether the backspace key was pressed
         */
        bool DBackSpacePressed;
};

#endif
