#ifndef TERRAINMAP_H
#define TERRAINMAP_H
/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.

    All source material (source code, images, sounds, etc.) have been provided to
    University of California, Davis students of course ECS 160 for educational
    purposes. It may not be distributed beyond those enrolled in the course without
    prior permission from the copyright holder.

    Some sound files, sound fonts, and midi files have been included that were
    freely available via internet sources. They have been included in this
    distribution for educational purposes only and this copyright notice does not
    attempt to claim any ownership of this material.
*/
#include "tilesets/GraphicTileset.h"
#include "players/Player.h"
#include "Castle.h"
#include <vector>

#define TERRAIN_ANIMATION_TIMESTEPS 4
        

/**
 * CTerrainMap class, used to build game map.
 */
class CTerrainMap{
    protected:
        CGraphicTileset *D2DTileset; /*!< 2D tile set. */
        CGraphicTileset *D3DTileset; /*!< 3D tile set. */
        
        std::vector< std::vector< int > > D2DMap; /*!< 2D map */
        std::vector< std::vector< int > > D3DMap; /*!< 3D map */
        std::vector< std::vector< CPlayer::EPlayerColor > > DTileTypeMap; /*!< Tile type map */
        std::vector< std::string > DStringMap; /*!< String map */
        std::vector< Castle > DCastles; /*!< Castles */
        int DPlayerCount; /*!< Player count */

        /**
         * @brief Which animation step the terrain map is at
         */
        int DAnimationStep;
        std::string DMapName; /*!< Map name */
        std::string DMapFileName; /*!< The source filename */ 

        //The new added categories in the new map: saving paths so they can be linked in where needed
        //Give audio manager and AI manager the paths so they can load the files correctly
        std::string D2DTilesetPath; /*!< Path to map specific 2D tileset */
        std::string D3DTilesetPath; /*!< Path to map specific 3D tileset */
        std::string DAIPath; /*!< Path for AI scripts */
        std::string DSongPath; /*!< Path to a song database */
        
        /**
         * @brief Sorts castles top to bottom, left to right
         */
        void SortCastlesForDrawing();

    public:
        /**
         * Empty constructor, initialize map to NULL.
         */
        CTerrainMap();

        /**
         * Terrain Map constructor.
         *
         * @param map Used to initialized terrain map
         */
        CTerrainMap(const CTerrainMap &map);

        /**
         * Terrain Map destructor.
         */
        ~CTerrainMap();

        /**
         * Operator overload =.
         */
        CTerrainMap &operator=(const CTerrainMap &map);

        /**
         * @brief Resets the castles in this terrain map
         */
        void Reset();

        /**
         * @brief Stores if cache is up to date
         */
        bool DHasCached3D;

        /**
         * Getter function for DMapName.
         */
        std::string MapName() const;

        /**
         * @brief Get the map in string format
         *
         * @return 
         */
        std::string MapFileData() const;

        /**
         * Getter function for DPlayerCount.
         */
        int PlayerCount() const;

        /**
         * @brief Getter function for DCastles
         * @return DCastles
         */
        std::vector< Castle >& Castles();

        /**
         * @brief Getter function for D3DMap
         * @return D3DMap
         */
        std::vector< std::string > StringMap();

        /**
         * Gets width of map.
         */
        int Width() const;

        /**
         * Gets height of map.
         */
        int Height() const;

        /**
         * Gets tile type if x and y indices are within constraints of DTileTypeMap.
         * @param xindex xindex
         * @param yindex yindex
         */
        CPlayer::EPlayerColor TileType(int xindex, int yindex) const;

        /**
         * Loads map
         *
         * @param tileset2d 2D tile set
         * @param tileset3d 3D tile set
         * @param filename Map to load
         */
        bool LoadMap(CGraphicTileset *tileset2d, CGraphicTileset *tileset3d, const std::string &filename);
        /**
         * @brief Loads map from string
         *
         * @param tileset2d 2D tileset
         * @param tileset3d 3D tileset
         * @param data String data to load from
         *
         * @return try if loaded
         */
        bool LoadMapString(CGraphicTileset *tileset2d, CGraphicTileset *tileset3d, const std::string &data);

        /**
         * Draws preview of map.
         *
         * @param drawable The destination to draw the map
         * @param gc The graphics context to draw the map in
         * @param xoff Offset x
         * @param yoff Offset y
         */
        void DrawPreviewMap(GdkDrawable *drawable, GdkGC *gc, gint xoff, gint yoff);

        /**
         * Draws 2D version of the map
         *
         * @param drawable The destination to draw the map
         * @param gc The graphics context to draw the map in
         */
        void Draw2DMap(CGame* game);

        /**
         * @brief Draws 3D version of the map
         *
         * @param game Game drawing
         */
        void Draw3D(CGame* game);

        /**
         * @brief Caches the frames of the 3D version of the map
         *
         * @param game Game drawing
         */
        void Cache3DMap(CGame* game);

        /**
         * @brief Draws the 2D versions of the castles
         *
         * @param game Game drawing
         */
        void Draw2DCastles(CGame* game);

        /**
         * Draws 3D version of the map
         *
         * @param drawable The destination to draw the map
         * @param gc The graphics context to draw the map in
         * @param winddir Wind direction
         * @param totalsteps Total steps
         * @param timestep Time increment
         */
        void Draw3DMap(CGame* game, int winddir, int totalsteps, int timestep);

        /**
         * @brief Draws the 3D versions of the castles
         *
         * @param game Game drawing
         */
        void Draw3DCastles(CGame* game, int XPos, int YPos);

        /**
         * @brief Converts a on screen position to a tile position
         *
         * @param position On screen position (pixels)
         *
         * @return tile position (indices)
         */
        SInt2 ConvertToTileIndex(SInt2 position);

        /**
         * @brief Converts a tile position to a screen position
         *
         * @param index Tile position (indices)
         *
         * @return On screen position (pixels)
         */
        SInt2 ConvertToScreenPosition(SInt2 index);

        /**
         * @brief Determines if there are no obstructions in the defined rectangle
         *
         * @param position Top left of rectangle
         * @param size Size of rectangle
         *
         * @return True if there are no castles overlapping, otherwise false
         */
        bool IsSpaceOpen(SInt2 position, SInt2 size);

        /**
         * @brief Updates the castles and the animation step of terrain map 
         *
         * @param game Game to update
         */
        void Update(CGame* game);
        /**
         * @brief Loads the proper tilestes for drawing the game 
         *
         * @param game Game to update
         */
        void LoadMapTileset(CGame* game);
        
        /**
         * @brief Returns the map's song set path 
         */
         std::string SongPath() {return DSongPath;}
};

#endif

