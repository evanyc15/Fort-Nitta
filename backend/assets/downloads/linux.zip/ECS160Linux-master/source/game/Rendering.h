#ifndef RENDERING_H
#define RENDERING_H

#include <gtk/gtk.h>
#include <vector>

/**
 * @brief Stores the pixmaps and graphics state of the game
 */
class CRendering {
    public:
        /**
         * @brief Initializes pixmaps and buffers
         */
        CRendering(GtkWidget* drawing_area, int width, int height);
        ~CRendering();

        /**
         * @brief Used for the game's everyday drawing needs
         */
        GdkPixmap *DWorkingBufferPixmap;
        /**
         * @brief Used for banner transition as the last frame of previous mode
         */
        GdkPixmap *DPreviousWorkingBufferPixmap;
        /**
         * @brief Used to cache the terrain map's 2D version
         */
        GdkPixmap *D2DTerrainPixmap;
        /**
         * @brief Used to cache the animation of the terrain map's 3D versions
         */
        std::vector< GdkPixmap * > D3DTerrainPixmaps;
        /**
         * @brief Used to cache the banner in the transition mode
         */
        GdkPixmap *DBannerPixmap;
        /**
         * @brief Used to cache the message in the game over mode
         */
        GdkPixmap *DMessagePixmap;
        /**
         * @brief The drawing context of the game
         */
        GdkGC *DDrawingContext;

};

#endif
