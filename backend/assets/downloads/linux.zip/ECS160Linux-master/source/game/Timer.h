#ifndef TIMER_H
#define TIMER_H

#include <sys/time.h>

class CGame;

/**
 * @brief Timer that plays tick tock and draws on screen
 */
class CTimer{
    public:
        /**
         * @brief Initializes timer to be invisible
         */
        CTimer() :
            DIsVisible(false),
            DIsAudible(false){
        }
        /**
         * @brief Timeout that timer is counting down to
         */
        struct timeval DTimeout;
        /**
         * @brief Stores last time sound effect was played
         */
        struct timeval DLastTickTockTime;
        /**
         * @brief Stores if timer should draw on screen
         */
        bool DIsVisible;
        /**
         * @brief Stores if timer should play sound effects
         */
        bool DIsAudible;

        /**
         * @brief Draws on screen if visible
         *
         * @param game Game drawing
         */
        void Draw(CGame* game);
        /**
         * @brief Updates timer, playing sound effects if audible
         *
         * @param game Game updating
         */
        void Update(CGame* game);
        /**
         * @brief Plays the sound effects if needed
         *
         * @param game Game updating
         */
        void PlayTickTockSound(CGame* game);

};

#endif
