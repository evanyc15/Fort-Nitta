#include "Resources.h"
#include "Game.h"

CResources::CResources(){
    DSounds = new CSounds();
    DTilesets = new CTilesets();
}

CResources::~CResources(){
    delete DSounds;
    delete DTilesets;
}

void CResources::Load(CGame* game){
    DSounds->Load(game);
    DTilesets->Load(game);
    LoadTerrainMaps(game);
}

bool CResources::LoadTerrainMaps(CGame* game){
    struct dirent *DirectoryEntry;
    std::string MapPath = "maps";
    // Opens game maps directory.
    DIR* MapDirectory = opendir(MapPath.c_str());

    // Checks if game maps directory opened correctly.
    if(NULL == MapDirectory){
        printf("Failed to open directory.\n");
        return -1;
    }

    // While loop to load all map files
    while((DirectoryEntry = readdir( MapDirectory ))){
        std::string Filename = MapPath + "/";
        Filename += DirectoryEntry->d_name;
        if(Filename.rfind(".map") == (Filename.length() - 4)){
            CTerrainMap* TempMap = new CTerrainMap();
            
            /**
             * Checks if the map loaded correctly. 
             * If not, go to next map file.
             */
            if(!TempMap->LoadMap(&(game->Resources()->DTilesets->D2DTerrainTileset),
                        &(game->Resources()->DTilesets->D3DTerrainTileset), Filename)){
                printf("Failed to load map \"%s\".\n",Filename.c_str());
                continue;
            }
            DTerrainMaps.push_back(TempMap);
        }
    }

    // Close the game maps directory.
    closedir(MapDirectory);
    return 0;
}

