#include "ConstructionTile.h"

void CConstructionTile::Reset(){
    DHitsTaken = 0;
    DType = CConstructionTile::cttNone;
}

bool CConstructionTile::IsFloor(){
    return (cttBlueFloor == DType)||(cttRedFloor == DType)||(cttYellowFloor == DType);
};
        
bool CConstructionTile::IsFloorDamaged(){
    return (cttBlueFloorDamaged == DType)||(cttRedFloorDamaged == DType) || (cttYellowFloorDamaged == DType);
};
        
bool CConstructionTile::IsWall(){
    return (cttBlueWall == DType)||(cttRedWall == DType)||(cttYellowWall == DType);
};
        
bool CConstructionTile::IsWallDamaged(){
    return (cttBlueWallDamaged == DType)||(cttRedWallDamaged == DType)||(cttYellowWallDamaged == DType);
};
        
bool CConstructionTile::IsGroundDamaged(){
    return (cttGroundDamaged == DType)||(cttBlueFloorDamaged == DType)||(cttRedFloorDamaged == DType) || (cttYellowFloorDamaged == DType);
};

void CConstructionTile::DestroyWall(){
    switch(GetColor()){
        case CPlayer::pcBlue:
            DType = cttBlueWallDamaged;
            break;
        case CPlayer::pcRed:
            DType = cttRedWallDamaged;
            break;
        case CPlayer::pcYellow:
            DType = cttYellowWallDamaged;
            break;
        default:
            DType = cttNone;
            break;
    }
};

CPlayer::EPlayerColor CConstructionTile::GetColor(){
    switch(DType){
        case CConstructionTile::cttBlueFloor:
        case CConstructionTile::cttBlueWall:
            return CPlayer::pcBlue;

        case CConstructionTile::cttRedFloor:
        case CConstructionTile::cttRedWall:
            return CPlayer::pcRed;

        case CConstructionTile::cttYellowFloor:
        case CConstructionTile::cttYellowWall:
            return CPlayer::pcYellow;

        default:
            break;
    }
    return CPlayer::pcNone;
}
