#include "../Game.h"
#include "AIBridge.h"
#include <iostream>

CGame* CAIBridge::DGameCopy = NULL;

int CAIBridge::getWallType(int x, int y){
    SInt2 position;
    position.DX = x;
    position.DY = y;
    CConstructionMap* Map = DGameCopy->GameState()->ConstructionMap();
    int WallType = Map->GetTileAt(position).DType;
    return (int)WallType;
}

bool CAIBridge::isValidCannonLoc(int colorInt, int DAvailableCannons, int x, int y){
    SInt2 position;
    position.DX = x;
    position.DY = y;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    bool result = DAvailableCannons > 0
        && DGameCopy->GameState()->ConstructionMap()->IsSpaceOpenForColor(colorindex, position, CCannon::CSize)
        && DGameCopy->GameState()->TerrainMap()->IsSpaceOpen(position, CCannon::CSize);
    return result;
}

void CAIBridge::setDAITarget(int colorInt, int x, int y){
    SInt2 position;
    position.DX = x;
    position.DY = y;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            Player->DCursorPosition = position;
        }
    }
}

int CAIBridge::getDAITargetX(int colorInt){
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DCursorPosition.DX;
        }
    }
}

int CAIBridge::getDAITargetY(int colorInt){
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DCursorPosition.DY;
        }
    }
}

int CAIBridge::getWallShapeHeight(int colorInt){
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DWallShape.Height();
        }
    }
}

int CAIBridge::getWallShapeWidth(int colorInt){
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DWallShape.Width();
        }
    }
}

bool CAIBridge::getWallShapeIsBlock(int colorInt, int x, int y){
    SInt2 position;
    position.DX = x;
    position.DY = y;
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DWallShape.IsBlock(position.DX, position.DY);
        }
    }
}

bool CAIBridge::getValidWallPlacement(int colorInt, int x, int y){
    SInt2 position;
    position.DX = x;
    position.DY = y;
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            return Player->DWallShape.CanBePlaced(DGameCopy, Player, position);
        }
    }
}

void CAIBridge::rotateWallShape(int colorInt){
    std::vector<CPlayer*>& Players = DGameCopy->GameState()->DPlayers;
    CPlayer::EPlayerColor colorindex = (CPlayer::EPlayerColor) colorInt;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->DColor == colorindex){
            Player->DWallShape.Rotate();
        }
    }
}
