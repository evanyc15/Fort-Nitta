#ifndef PLAYER_H
#define PLAYER_H

#include "../../types/Int2.h"
#include <cstdlib>
#include <deque>
#include "../WallShape.h"
#include <string>
#include "../../util/RandomNumberGenerator.h"

class CGame;
class Castle;
class CCannon;

/**
 * @brief Player with state about cursors, cannons, and castle owned, and actions that can be taken
 */
class CPlayer{
    public:
        /**
         * @brief Initializes player with nothing owned
         */
        CPlayer() : DAvailableCannons(0),
            DIsLocalPlayer(false),
            DPlacedHomeCastle(false),
            DHoveredCastle(NULL),
            DExtraCannons(0),
            DIsAI(false),
            DUsername(""){
        }
        //Enum for player colors
        typedef enum{
            pcNone = 0, // No players
            pcBlue, // Player color: Blue
            pcRed, // Player color: Red
            pcYellow, // Player color: Yellow
            pcMax // Max player count
        } EPlayerColor, *EPlayerColorRef;

        /**
         * @brief Updates cursor tile position
         *
         * @param game
         */
        virtual void Update(CGame* game);
        /**
         * @brief Updates cursor tile position
         *
         * @param game
         */
        void UpdateCursorTilePosition(CGame* game);
        /**
         * @brief Returns if the primary action should be taken this frame
         *
         * @param game Game playing
         *
         * @return False, subclasses would override
         */
        virtual bool ShouldTakePrimaryAction(CGame* game);
        /**
         * @brief Returns if the secondary action should be taken this frame
         *
         * @param game Game playing
         *
         * @return False, subclasses would override
         */
        virtual bool ShouldTakeSecondaryAction(CGame* game);
        /**
         * @brief Updates which castle is hovered by this player by calculating the best distance
         *
         * @param game The game updating
         */
        virtual void UpdateHoveredCastle(CGame* game);
        /**
         * @brief Gets the number of castles this player has currently surrounded
         *
         * @param game The game updating
         *
         * @return Count of castles surrounded
         */
        int OwnedCastleCount(CGame* game);
        /**
         * @brief Rotates the wall shape currently placing
         *
         * @param game The game playing
         */
        virtual void RotateWall(CGame* game);

        /**
         * @brief The number of cannons available for placing, based on number of castles owned
         */
        int DAvailableCannons;
        /**
         * @brief The number of extra cannons available given at the first round
         */
        int DExtraCannons;
        /**
         * @brief The position of the cursor on screen
         */
        SInt2 DCursorPosition;
        /**
         * @brief The position of the cursor in tile indices
         */
        SInt2 DCursorTilePosition;
        /**
         * @brief The castle being hovered by this player
         */
        Castle *DHoveredCastle;
        /**
         * @brief The list of cannons ready to fire
         */
        std::deque<CCannon*> DReadyCannons;
        /**
         * @brief The color of this player
         */
        EPlayerColor DColor;
        /**
         * @brief Stores if player has placed a home castle
         */
        bool DPlacedHomeCastle;
        /**
         * @brief If player is local to this client
         */
        bool DIsLocalPlayer;

        CRandomNumberGenerator DRandomNumberGenerator;

        /**
         * @brief Username of the player
         */
        std::string DUsername;
        /**
         * @brief The wall shape being placed
         */
        CWallShape DWallShape;
        
        /**
         * @brief Is true if the player is an AI
         */
        bool DIsAI;

        /**
         * @brief Selects the home castle, and gets extra cannons
         *
         * @param game Game updating
         * @param castle Castle selected
         */
        virtual void PlaceHomeCastle(CGame* game, Castle* castle);
        /**
         * @brief Tries to place cannon at the position
         *
         * @param game The game updating
         * @param position The tile position to place at
         *
         * @return true if cannon was placed, otherwise false
         */
        virtual bool TryToPlaceCannon(CGame* game, SInt2 position);
        /**
         * @brief Fires the next cannon in ready cannons
         *
         * @param game The game updating
         */
        virtual void FireNextCannon(CGame* game);
        /**
         * @brief Tries to place a wall shape at the position
         *
         * @param game The game updating
         * @param tile_position The position to placea t
         *
         * @return true if wall was placed, otherwise false
         */
        virtual bool TryToPlaceWall(CGame* game, SInt2 tile_position);

        static EPlayerColor GetColorForID(int i);

};
#endif
