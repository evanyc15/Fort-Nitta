#ifndef NETWORKED_HUMAN_PLAYER_H
#define NETWORKED_HUMAN_PLAYER_H

#include "HumanPlayer.h"

class CNetworkedHumanPlayer : public CHumanPlayer{
    public:
        virtual void Update(CGame* game);
        virtual void PlaceHomeCastle(CGame* game, Castle* castle);
        virtual void RotateWall(CGame* game);
        virtual bool TryToPlaceCannon(CGame* game, SInt2 position);
        virtual void FireNextCannon(CGame* game);
        virtual bool TryToPlaceWall(CGame* game, SInt2 tile_position);
    protected:
        void SendActionPacket(CGame* game, int type);
};


#endif
