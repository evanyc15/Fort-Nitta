#include "HumanPlayer.h"

#include "../Game.h"

void CHumanPlayer::Update(CGame* game){

    DCursorPosition = game->InputState()->DMousePosition;

    CPlayer::Update(game);
}

bool CHumanPlayer::ShouldTakePrimaryAction(CGame* game){
    return game->InputState()->DButtonPressed == CInputState::ibLeftButton;
}

bool CHumanPlayer::ShouldTakeSecondaryAction(CGame* game){
    return game->InputState()->DButtonPressed == CInputState::ibRightButton;
}
