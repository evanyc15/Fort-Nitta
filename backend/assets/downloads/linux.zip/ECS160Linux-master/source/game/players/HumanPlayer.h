#ifndef HUMANPLAYER_H
#define HUMANPLAYER_H

#include "Player.h"

/**
 * @brief A human player taking input from input state
 */
class CHumanPlayer : public CPlayer{
    public:
        /**
         * @brief Makes a new human player setting as local player
         */
        CHumanPlayer(){
            DIsLocalPlayer = true;
        }
        /**
         * @brief Updates cursor position based on mouse position
         *
         * @param game Game to update
         */
        virtual void Update(CGame* game);
        /**
         * @brief Returns if left button is pressed
         *
         * @param game Game to update
         *
         * @return true if left button pressed, false otherwise
         */
        virtual bool ShouldTakePrimaryAction(CGame* game);
        /**
         * @brief Returns if right button is pressed
         *
         * @param game Game to update
         *
         * @return true if right button is pressed, false otherwise
         */
        virtual bool ShouldTakeSecondaryAction(CGame* game);
};

#endif

