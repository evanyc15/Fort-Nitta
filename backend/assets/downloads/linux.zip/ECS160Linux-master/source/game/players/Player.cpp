#include "Player.h"

#include "../TerrainMap.h"
#include "../Game.h"
#include "../Cannon.h"

void CPlayer::Update(CGame* game){
    UpdateCursorTilePosition(game);
}

void CPlayer::UpdateCursorTilePosition(CGame* game){
    CTerrainMap *Map = game->GameState()->TerrainMap();
    if(Map != NULL){
        DCursorTilePosition = Map->ConvertToTileIndex(DCursorPosition);
    }
}

void CPlayer::UpdateHoveredCastle(CGame* game){
    int XTile, YTile;
    CTerrainMap* Map = game->GameState()->TerrainMap();
    SInt2 TileIndex = Map->ConvertToTileIndex(DCursorPosition);
    XTile = TileIndex.DX;
    YTile = TileIndex.DY;
    int BestDistance = 999999;
    Castle* BestCastle = NULL;

    for(std::vector<Castle>::iterator it = Map->Castles().begin();
            it != Map->Castles().end();
            it++){
        if(it->DColor != DColor) continue;

        int Distance;
        int XPos = (*it).IndexPosition().DX;
        int YPos = (*it).IndexPosition().DY;

        Distance = (XPos - XTile) * (XPos - XTile) + (YPos - YTile) * (YPos - YTile);
        if(Distance < BestDistance){
            BestDistance = Distance;
            BestCastle = &*it;
        } 
    }
    DHoveredCastle = BestCastle;
}

bool CPlayer::ShouldTakePrimaryAction(CGame* game){
    return false;
}

bool CPlayer::ShouldTakeSecondaryAction(CGame* game){
    return false;
}

void CPlayer::RotateWall(CGame*){
    DWallShape.Rotate();
}

void CPlayer::PlaceHomeCastle(CGame* game, Castle* castle){
    game->GameState()->ConstructionMap()->SurroundCastle(game, castle);
    castle->DSurrounded = true;
    DPlacedHomeCastle = true;
    DExtraCannons += 2;
}

int CPlayer::OwnedCastleCount(CGame* game){
    int Count = 0;
    std::vector<Castle>& Castles = game->GameState()->TerrainMap()->Castles();
    for(std::vector<Castle>::iterator it = Castles.begin();
            it != Castles.end();
            it++){
        if(it->DColor == DColor && it->DSurrounded){
            Count++;
        }
    }
    return Count;
}

bool CPlayer::TryToPlaceCannon(CGame* game, SInt2 position){
    bool result = DAvailableCannons > 0
        && game->GameState()->ConstructionMap()->IsSpaceOpenForColor(DColor, position, CCannon::CSize)
        && game->GameState()->TerrainMap()->IsSpaceOpen(position, CCannon::CSize);
    if(result){
        game->GameState()->ConstructionMap()->Cannons().push_back(new CCannon(position));
        DAvailableCannons--; 
    }
    return result;
}

bool CPlayer::TryToPlaceWall(CGame* game, SInt2 tile_position){
    return DWallShape.Place(game, this, tile_position);
}

void CPlayer::FireNextCannon(CGame* game){
    if(DReadyCannons.size() > 0){
        DReadyCannons.front()->FireAt(game, DCursorPosition);
        DReadyCannons.pop_front();
    }
}

CPlayer::EPlayerColor CPlayer::GetColorForID(int i){
    return (CPlayer::EPlayerColor)i;
}
