#include "NetworkedHumanPlayer.h"

#include "../Game.h"
#include "../modes/MapMode.h"
#include "../modes/BannerTransitionMode.h"

void CNetworkedHumanPlayer::SendActionPacket(CGame* game, int type){
    SInt2 NetworkPosition = game->GameState()
        ->Network()->ConvertToNetworkPosition(DCursorPosition);
    game->GameState()->Network()->InGameAction(type,
            game->GameState()->DTimeStep,
            DColor,
            NetworkPosition.DX,
            NetworkPosition.DY);
}
void CNetworkedHumanPlayer::Update(CGame* game){
    CHumanPlayer::Update(game);
    if(dynamic_cast<CMapMode*>(game->GameMode())
            || dynamic_cast<CBannerTransitionMode*>(game->GameMode())){
        SendActionPacket(game, POINTER_LOCATION);
    }
}

void CNetworkedHumanPlayer::PlaceHomeCastle(CGame* game, Castle* castle){
    if(game->GameState()->DIsNetworkUpdate){
        CHumanPlayer::PlaceHomeCastle(game, castle);
    }else{
        SendActionPacket(game, SELECTED_CASTLE);
    }
}

void CNetworkedHumanPlayer::RotateWall(CGame* game){
    if(game->GameState()->DIsNetworkUpdate){
        CHumanPlayer::RotateWall(game);
    }else{
        SendActionPacket(game, ROTATED_WALL);
    }
}

bool CNetworkedHumanPlayer::TryToPlaceCannon(CGame* game, SInt2 position){
    if(game->GameState()->DIsNetworkUpdate){
        return CHumanPlayer::TryToPlaceCannon(game, position);
    }else{
        SendActionPacket(game, PLACED_CANNON);
        return false;
    }
}

void CNetworkedHumanPlayer::FireNextCannon(CGame* game){
    if(game->GameState()->DIsNetworkUpdate){
        CHumanPlayer::FireNextCannon(game);
    }else{
        SendActionPacket(game, FIRED_CANNON);
    }
}

bool CNetworkedHumanPlayer::TryToPlaceWall(CGame* game, SInt2 position){
    if(game->GameState()->DIsNetworkUpdate){
        return CHumanPlayer::TryToPlaceWall(game, position);
    }else{
        SendActionPacket(game, PLACED_WALL);
        return false;
    }
}
