#include "AIPlayer.h"

#include "../Game.h"
#include "../ConstructionTile.h"
#include <iostream>
lua_State* L = luaL_newstate();
LuaRef getxy(L);
LuaRef getCastleLocation(L);
LuaRef getCannonLocs(L);
LuaRef findBestPlacement(L);
int difficultylevel = 1;
int numberCastleLocations;
int DTileWidth_rebuild;
int DTileHeight_rebuild;
int DMapHeight_rebuild;
int DMapWidth_rebuild;


CAIBridge* CAIPlayer::DAIBridge = NULL;

void CAIPlayer::Update(CGame* game){
    this->DAIBridge->Update(game);
    SInt2 position;
    position.DX = 130;
    position.DY = 130;

    CPlayer::Update(game);
}

bool CAIPlayer::ShouldTakePrimaryAction(CGame* game){
    return game->InputState()->DButtonPressed == CInputState::ibLeftButton;
}

bool CAIPlayer::ShouldTakeSecondaryAction(CGame* game){
    return game->InputState()->DButtonPressed == CInputState::ibRightButton;
}

void CAIPlayer::UpdateHoveredCastle(CGame* game){
    this->DAIBridge->Update(game);
    this->Update(game);
    int XTile, YTile;
    CTerrainMap* Map = game->GameState()->TerrainMap();
    SInt2 TileIndex = Map->ConvertToTileIndex(DCursorPosition);
    XTile = TileIndex.DX;
    YTile = TileIndex.DY;

    int BestDistance = 999999;
    Castle* BestCastle = NULL;

    for(std::vector<Castle>::iterator it = Map->Castles().begin();
            it != Map->Castles().end();
            it++){
        if(it->DColor != DColor) continue;

        int Distance;
        int XPos = (*it).IndexPosition().DX;
        int YPos = (*it).IndexPosition().DY;

        Distance = (XPos - XTile) * (XPos - XTile) + (YPos - YTile) * (YPos - YTile);
        if(Distance < BestDistance){
            BestDistance = Distance;
            BestCastle = &*it;
        } 
    }
    DHoveredCastle = BestCastle;

    //Simulate a castle select click
    if(!DPlacedHomeCastle) PlaceHomeCastle(game, DHoveredCastle);
}

bool CAIPlayer::TryToPlaceCannon(CGame* game, SInt2 position){
	bool result;    
        if(DAvailableCannons)
    {    
        // Find potential cannon positions and try to place them
        
        int XTile, YTile;
        bool XDir, YDir;
        XDir = DAvailableCannons & 0x1;
        YDir = DAvailableCannons & 0x2;
        XTile = DCursorPosition.DX / 12;
        YTile = DCursorPosition.DY / 12;
        result = getCannonLocs((int)DColor, XTile, YTile, XDir, YDir, 40, 24, DAvailableCannons);

        //Temporary fix to overlaping AI cannons
        result = DAvailableCannons > 0
            && game->GameState()->ConstructionMap()->IsSpaceOpenForColor(DColor, position, CCannon::CSize)
            && game->GameState()->TerrainMap()->IsSpaceOpen(position, CCannon::CSize);
        if(result && DAvailableCannons > 0){
            game->GameState()->ConstructionMap()->Cannons().push_back(new CCannon(DCursorTilePosition));
            DAvailableCannons--; 
        } else {}
    }
    this->DAIBridge->Update(game);
    return result;
}


void CAIPlayer::FireNextCannon(CGame* game){
    framelimit = 40;
    if(framecount >= framelimit)
    {  
        if(DReadyCannons.size() > 0){
            LuaRef coords = getxy((int)DColor);
		    int x = coords["xpos"].cast<int>();
		    int y = coords["ypos"].cast<int>();
    //convet form squares to pixels
		    x *=12;
		    y *=12;
            DCursorPosition.DX = x+6;
            DCursorPosition.DY = y+6;
            DReadyCannons.front()->FireAt(game, DCursorPosition);
            DReadyCannons.pop_front();
            framecount = 0;
        }
    }
    else
        framecount++;
}

bool CAIPlayer::TryToPlaceWall(CGame* game, SInt2 tile_position){
    framelimit = 10;
    if(framecount >= framelimit)
    {
        //DWallShape.Randomize(game->GameState()->DRandomNumberGenerator.Random());
        //printf("Executing TryToPlaceWall()\n");           
        framecount = 0;    
        bool DoMove = true;
        std::vector<Castle>& Castles = game->GameState()->TerrainMap()->Castles();
        std::vector<Castle>::iterator it = Castles.begin();
	    SInt2 bestpos;
        int mostwalls = 0;
        CConstructionMap* Map = game->GameState()->ConstructionMap();
        while(it < Castles.end())
	    {
	        if(it->DColor != DColor || it->DSurrounded)    
                	it++;
		    else
        	{
		
                SInt2 p = it->IndexPosition();  
                //set the initial wall to check (upper left corner)              
                p.DX-=3; p.DY-=3;            
                int xdir,ydir;
                xdir =0;
                int wallcount = 0;
                //this for loop will check each tiletype in a "radius" of 2 from the given castle
	            for(int i=1; i <=4; i++)
                {
                    if(i==1)     {xdir=1; ydir=0;}
                    else if(i==2){xdir=0; ydir=1;}
                    else if(i==3){xdir=-1; ydir=0;}
                    else if(i==4){xdir=0; ydir=-1;}
                    for(int j =1; j<=8; j++)
                    {
                        p.DX+=xdir;
                        p.DY+=ydir;
                        //printf("(%d,%d) ",p.DX,p.DY);
                        if(Map->GetTileAt(p).IsWall())
                        {
                            wallcount++;
                        }
                    }
                    //printf("\n");
                }
                if(wallcount >= mostwalls)
                {
                    bestpos = it->IndexPosition();
                    mostwalls = wallcount;
                }
                it++;
            }
	}
        DCursorPosition.DX = -1;
        DCursorPosition.DY = -1;
        if(0 > DCursorPosition.DX){
            int XTile, YTile;
            int BestX, BestY, BestRotation, BestCoverage, BestInterference;

            /*
            if(0 > DAITargetCastle[ColorIndex]){
                DAITargetX[ColorIndex] = DCastleLocations[ColorIndex][0].DXIndex;
                DAITargetY[ColorIndex] = DCastleLocations[ColorIndex][0].DYIndex;
                DAITargetX[ColorIndex] *= DTileWidth;
                DAITargetX[ColorIndex] += DTileWidth / 2;
                DAITargetY[ColorIndex] *= DTileHeight;
                DAITargetY[ColorIndex] += DTileHeight / 2;
            }
            */
            //else{
                
                XTile = bestpos.DX;
                YTile = bestpos.DY;
                
                DTileWidth_rebuild = 12;
                DTileHeight_rebuild = 12;
                DMapHeight_rebuild = 24;
                DMapWidth_rebuild = 40;  
                LuaRef Best = findBestPlacement((int)DColor, XTile, YTile);
                BestX = Best["X"].cast<int>();
                BestY = Best["Y"].cast<int>();
                BestRotation = Best["Rotation"].cast<int>();
                BestCoverage = Best["BCoverage"].cast<int>();
                BestInterference = Best["BInterference"].cast<int>();
            //}
            if(0 > BestX){
                DoMove = false;
            }
            else if(BestRotation){
                RotateWall(game);
                return false;
            }
            else{
		        DCursorPosition.DX = BestX * 40 + 6;
		        DCursorPosition.DY = BestY * 24 + 6;                
		        DCursorTilePosition.DX = BestX;
                DCursorTilePosition.DY = BestY;
		
                return (DWallShape.Place(game, this, DCursorTilePosition));
            }
        }
    }
    else
        framecount++;

    return false;
}


void CAIPlayer::init_lua(){


	luaL_openlibs(L);
  
	//load the scripts
	luaL_dofile(L, "scripts/castle_select.lua");
	luaL_dofile(L, "scripts/battle_ai.lua");
	luaL_dofile(L, "scripts/cannon_placement_ai.lua");
	luaL_dofile(L, "scripts/rebuild_ai.lua");
        getGlobalNamespace(L)
        .beginNamespace("test")
        .addFunction ("getWallType",DAIBridge->getWallType)
        .addFunction("isValidCannonLoc", DAIBridge->isValidCannonLoc)
        .addFunction("setDAITarget", DAIBridge->setDAITarget)
        .addFunction("getDAITargetX", DAIBridge->getDAITargetX)
        .addFunction("getWallShapeHeight", DAIBridge->getWallShapeHeight)
        .addFunction("getWallShapeWidth", DAIBridge->getWallShapeWidth)
        .addFunction("getWallShapeIsBlock", DAIBridge->getWallShapeIsBlock)
        .addFunction("getValidWallPlacement", DAIBridge->getValidWallPlacement)
        .addFunction("rotateWallShape", DAIBridge->rotateWallShape)
        .addVariable("difficultyLevel",&difficultylevel)
        .addVariable("numberCastleLocations",&numberCastleLocations)
        .addVariable("DTileWidth_rebuild",&DTileWidth_rebuild)
        .addVariable("DTileHeight_rebuild",&DTileHeight_rebuild)
        .addVariable("DMapHeight_rebuild",&DMapHeight_rebuild)
        .addVariable("DMapWidth_rebuild",&DMapWidth_rebuild)
    .endNamespace();

    getxy = getGlobal(L, "getxy");
    getCannonLocs = getGlobal(L, "getCannonLocs");
    findBestPlacement = getGlobal(L, "findBestPlacement");
    getCastleLocation = getGlobal(L, "getCastleLocation");


}
