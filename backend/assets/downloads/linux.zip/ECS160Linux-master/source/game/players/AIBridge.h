#ifndef AIBRIDGE_H
#define AIBRIDGE_H

#include "../TerrainMap.h"
#include "../ConstructionMap.h"
#include "../ConstructionTile.h"
#include "Player.h"
#include <vector>
#include "../../util/RandomNumberGenerator.h"
#include "../../network/Network.h"
#include <string>
#include "../Game.h"

//using namespace luabridge;

//extern lua_State* L;

class CAIBridge{
    public:
        void Update(CGame *game){
            DGameCopy = game; 
            //std::cout << "Bridge Updated" << std::endl;
        }

        //Returns DConstructionTiles[y][x], the type of tile existing at a given coordinate.
        static int getWallType(int x, int y);

        //Returns true if a location is a valid placement for the player with the colorindex value
        static bool isValidCannonLoc(int colorInt, int DAvailableCannons,  int x, int y);

        //Set the target location of the cursor for the player with the colorindex value
        static void setDAITarget(int colorInt, int x, int y); 

        //Returns the X-position of the cursor’s destinatcion for the player with the colorindex value
        static int getDAITargetX(int colorInt);

        //Returns the Y-position of the cursor’s destinatcion for the player with the colorindex value
        static int getDAITargetY(int colorInt);

        //Returns the height of the wall piece that player with the colorindex value is currently holding
        static int getWallShapeHeight(int colorInt);

        //Returns the width of the wall piece that player with the colorindex value is currently holding
        static int getWallShapeWidth(int colorInt);

        //Returns true if the wall piece has a block at that location
        static bool getWallShapeIsBlock(int colorInt, int x, int y);

        //Returns true if the wall piece is placed in a valid tile location
        static bool getValidWallPlacement(int ColorInt, int x, int y);

        //Rotate the orientation of the wall piece 90° clockwise
        static void rotateWallShape(int colorInt);

    private:
        static CGame *DGameCopy;
};

#endif
