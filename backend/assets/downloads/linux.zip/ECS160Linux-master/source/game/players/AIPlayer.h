#ifndef AIPLAYER_H
#define AIPLAYER_H

#include "Player.h"
#include <iostream>
#include "AIBridge.h"

#ifdef FEDORA_BUILD
#include <lua.hpp>
#else
#include <lua5.2/lua.hpp>
#endif

#include "../../LuaBridge/LuaBridge.h"

using namespace luabridge;


//extern lua_State* L;

/**
 * @brief An AI player taking input from input state
 */

class CAIPlayer : public CPlayer{
    public:
        /**
         * @brief Makes a new AI player setting as local player
         */
	
	
        CAIPlayer(CGame* game){
            DAIBridge = new CAIBridge;
            DAIBridge->Update(game);
            //std::cout << "AIPlayer Created" << std::endl;
            DIsLocalPlayer = true;
            DIsAI = true;
            //L = luaL_newstate();
	        init_lua();
	        framelimit = 30;
	        framecount = framelimit;
	        DWallShape.Randomize(game->GameState()->DRandomNumberGenerator.Random());
	
        }
        /**
         * @brief Updates cursor position based on mouse position
         *
         * @param game Game to update
         */
        virtual void Update(CGame* game);
        /**
         * @brief Returns if left button is pressed
         *
         * @param game Game to update
         *
         * @return true if left button pressed, false otherwise
         */
        virtual bool ShouldTakePrimaryAction(CGame* game);
        /**
         * @brief Returns if right button is pressed
         *
         * @param game Game to update
         *
         * @return true if right button is pressed, false otherwise
         */
        virtual bool ShouldTakeSecondaryAction(CGame* game);

        virtual void UpdateHoveredCastle(CGame* game);

        virtual bool TryToPlaceCannon(CGame* game, SInt2 position);

	    virtual void FireNextCannon(CGame* game);

	    virtual bool TryToPlaceWall(CGame* game, SInt2 tile_position);
        
        static CAIBridge* DAIBridge;

	    void init_lua();

	//Frame counting variables used to ensure the AI doesn't execute functions too quickly
	    int framecount;
	    int framelimit;
	   
};

#endif

