#include "Wind.h"

CWind::CWind(){
    DWindType = CWind::wtMild;
    DWindSpeed = 1;
    DWindDirection = 0;
}

void CWind::WindUpdate(int Change, int DirChange, int SpeedChange){

    if(wtNone == DWindType){
        DWindDirection = 0;
        DWindSpeed = 1;
    }
    else{
        unsigned int ChangeProbability;
        unsigned int DirectionProbability;
        unsigned int SpeedProbability;
        int MinWindSpeed, MaxWindSpeed;

        if(wtMild == DWindType){
            ChangeProbability = RANDOM_NUMBER_MAX * 0.01;
            DirectionProbability = RANDOM_NUMBER_MAX * 0.01;
            SpeedProbability = RANDOM_NUMBER_MAX * 0.1;
            MinWindSpeed = 1;
            MaxWindSpeed = WINDSPEED_COUNT / 2;
        }
        else if(wtModerate == DWindType){
            ChangeProbability = RANDOM_NUMBER_MAX * 0.025;
            DirectionProbability = RANDOM_NUMBER_MAX * 0.025;
            SpeedProbability = RANDOM_NUMBER_MAX * 0.2;
            MinWindSpeed = 2;
            MaxWindSpeed = WINDSPEED_COUNT - 1;
        }
        else{
            ChangeProbability = RANDOM_NUMBER_MAX * 0.1;
            DirectionProbability = RANDOM_NUMBER_MAX * 0.1;
            SpeedProbability = RANDOM_NUMBER_MAX * 0.3;
            MinWindSpeed = WINDSPEED_COUNT / 2;
            MaxWindSpeed = WINDSPEED_COUNT - 1;
        }

        if((Change % RANDOM_NUMBER_MAX) < ChangeProbability){
            DirChange = DirChange % RANDOM_NUMBER_MAX;
            SpeedChange = SpeedChange % RANDOM_NUMBER_MAX;

            if(DirChange < DirectionProbability){
                DWindDirection += WINDDIRECTION_COUNT-1;
                DWindDirection %= WINDDIRECTION_COUNT;
                if(!DWindDirection){
                    DWindDirection = WINDDIRECTION_COUNT-1;
                }
                DWindDirectionChange = true;
            }
            else if(DirChange < DirectionProbability * 2){
                DWindDirection++;
                DWindDirection %= WINDDIRECTION_COUNT;
                if(!DWindDirection){
                    DWindDirection = 1;
                }
                DWindDirectionChange = true;
            }
            if(SpeedChange < DirectionProbability){
                DWindSpeed += WINDSPEED_COUNT-1;
                DWindSpeed %= WINDSPEED_COUNT;
            }
            else if(SpeedChange < DirectionProbability * 2){
                DWindSpeed++;
                DWindSpeed %= WINDSPEED_COUNT;
            }

        }
        if(!DWindDirection){
            DWindDirection = 1;
            DWindDirectionChange = true;
        }
        if(DWindSpeed < MinWindSpeed){
            DWindSpeed = MinWindSpeed;
        }
        if(DWindSpeed > MaxWindSpeed){
            DWindSpeed = MaxWindSpeed;
        }
    }
}

SDouble3 CWind::GetVector(){
    double WindX = 0, WindY = 0; 
    switch(DWindDirection){
        case 1: WindY = -DWindSpeed;
                break;
        case 2: WindX = DWindSpeed;
                WindY = -DWindSpeed;
                break;
        case 3: WindX = DWindSpeed;
                break;
        case 4: WindX = DWindSpeed;
                WindY = DWindSpeed;
                break;
        case 5: WindY = DWindSpeed;
                break;
        case 6: WindX = -DWindSpeed;
                WindY = DWindSpeed;
                break;
        case 7: WindX = -DWindSpeed;
                break;
        case 8: WindX = -DWindSpeed;
                WindY = -DWindSpeed;
                break;
        default: break;
    }
    WindX /= 10;
    WindY /= 10;
    WindX *= TIMESTEP_PERIOD;
    WindY *= TIMESTEP_PERIOD;
    return SDouble3(WindX, WindY);
}

