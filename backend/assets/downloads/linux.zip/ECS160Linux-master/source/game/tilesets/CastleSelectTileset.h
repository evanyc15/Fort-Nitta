#ifndef CASTLESELECTTILESET_H
#define CASTLESELECTTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset containing ring for castle hovering
 */
class CCastleSelectTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game The game to load in
         * @param filename The filename to load from 
         *
         * @return true
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the tile for a color
         *
         * @param game Game to draw in
         * @param position Position to draw at
         * @param player_color Color to draw
         * @param index Index of ring tile
         */
        void Draw2DCastleSelectTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int index);
    private:
        /**
         * @brief Stores the starting indices for each color
         */
        int D2DSelectColorIndices[CPlayer::pcMax];
};

#endif

