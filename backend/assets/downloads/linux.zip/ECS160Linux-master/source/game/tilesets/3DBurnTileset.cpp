#include "3DBurnTileset.h"


bool C3DBurnTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DBurnIndices[SBurnAndExplosion::btRubbleBurn0] = this->FindTile("rubbleburn-0");
    D3DBurnIndices[SBurnAndExplosion::btRubbleBurn1] = this->FindTile("rubbleburn-alt-0");
    D3DBurnIndices[SBurnAndExplosion::btHoleBurn0] = this->FindTile("holeburn-0");
    D3DBurnIndices[SBurnAndExplosion::btHoleBurn1] = this->FindTile("holeburn-alt-0");

    return true;
}

int C3DBurnTileset::GetBaseFrame(SBurnAndExplosion::EBurnType burnType){
    return D3DBurnIndices[burnType];
}
