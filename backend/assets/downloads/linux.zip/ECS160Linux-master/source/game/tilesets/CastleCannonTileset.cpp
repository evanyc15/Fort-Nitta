#include "CastleCannonTileset.h"

bool CCastleCannonTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D2DCastleIndices[CPlayer::pcNone] = this->FindTile("castle-none");
    D2DCastleIndices[CPlayer::pcBlue] = this->FindTile("castle-blue");
    D2DCastleIndices[CPlayer::pcRed] = this->FindTile("castle-red");
    D2DCastleIndices[CPlayer::pcYellow] = this->FindTile("castle-yellow");

    D2DCannonIndices[CPlayer::pcNone] = this->FindTile("cannon");
    D2DCannonIndices[CPlayer::pcBlue] = this->FindTile("cannon-blue-1");
    D2DCannonIndices[CPlayer::pcRed] = this->FindTile("cannon-red-1");
    D2DCannonIndices[CPlayer::pcYellow] = this->FindTile("cannon-yellow-1");

}

void CCastleCannonTileset::Draw2DCastleTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color){
    CGraphicTileset::DrawTile(game, SInt2(x, y), D2DCastleIndices[player_color]);
}

void CCastleCannonTileset::Draw2DCannonTile(CGame* game, SInt2 position){
    CGraphicTileset::DrawTile(game, position, D2DCannonIndices[CPlayer::pcNone]);
}

void CCastleCannonTileset::Draw2DCannonToPlaceTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color,
        int count){
    CGraphicTileset::DrawTile(game, position, D2DCannonIndices[player_color] + count - 1);
}
