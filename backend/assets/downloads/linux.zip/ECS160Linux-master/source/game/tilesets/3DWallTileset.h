#ifndef WALLTILESET_H
#define WALLTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief The tileset used to draw the 3D walls
 */
class C3DWallTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game Game to load in
         * @param filename The filename to load from 
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the specified wall tile in the game
         *
         * @param game The game to draw in
         * @param position Position to draw at
         * @param player_color The color of the wall
         * @param type The type of the wall
         * @param offset Offset of the wall
         *
         * @see CTerrainMap
         */
        void Draw3DWallTile(CGame* game, SInt2 position,
                CPlayer::EPlayerColor player_color, int type, int offset);
        /**
         * @brief Draws the damaged wall tile in the game
         *
         * @param game The game to draw in
         * @param position Position to draw in
         * @param player_color The color of the wall
         * @param index The index of the wall
         * 
         * @see CTerrainMap
         */
        void Draw3DDamagedWallTile(CGame* game, SInt2 position,
                CPlayer::EPlayerColor player_color, int index);
    private:
        /**
         * @brief Stores the indices to the walls for each type and color
         */
        int D3DWallIndices[CPlayer::pcMax][16];
        /**
         * @brief Stores the indices to the damaged walls for each color
         */
        int D3DDamagedWallIndices[CPlayer::pcMax];
};

#endif

