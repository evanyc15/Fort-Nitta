#include "3DExplosionTileset.h"


bool C3DExplosionTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DExplosionIndices[SBurnAndExplosion::etWallExplosion0] = this->FindTile("explosion-0");
    D3DExplosionIndices[SBurnAndExplosion::etWallExplosion1] = this->FindTile("explosion-alt-0");
    D3DExplosionIndices[SBurnAndExplosion::etWaterExplosion0] = this->FindTile("water-explosion-0");
    D3DExplosionIndices[SBurnAndExplosion::etWaterExplosion1] = this->FindTile("water-explosion-alt-0");
    D3DExplosionIndices[SBurnAndExplosion::etGroundExplosion0] = this->FindTile("ground-explosion-0");
    D3DExplosionIndices[SBurnAndExplosion::etGroundExplosion1] = this->FindTile("ground-explosion-alt-0");
    return true;
}

int C3DExplosionTileset::GetBaseFrame(SBurnAndExplosion::EExplosionType explosionType){
    return D3DExplosionIndices[explosionType];
}
