#ifndef CASTLETILESET_H
#define CASTLETILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset for drawing 3D castles
 */
class C3DCastleTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game The game to lod in
         * @param filename The file to load from 
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the 3D castle for a player color at a position
         *
         * @param game The game to draw in
         * @param position The position to draw at
         * @param player_color The color of the castle
         */
        void Draw3DCastleTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int index=0);
    private:
        /**
         * @brief Stores the indices to the tiles with each color castle
         */
        int D3DCastleIndices[CPlayer::pcMax];
};

#endif

