#include "3DWallTileset.h"
#include <cstdio>
#include "../players/Player.h"

bool C3DWallTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    for(int Index = 0; Index < 16; Index++){
        char Name[16];
        sprintf(Name,"blue-%d-0",Index);
        D3DWallIndices[CPlayer::pcNone][Index] = this->FindTile(Name);
        D3DWallIndices[CPlayer::pcBlue][Index] = this->FindTile(Name);
        sprintf(Name,"red-%d-0",Index);
        D3DWallIndices[CPlayer::pcRed][Index] = this->FindTile(Name);
        sprintf(Name,"yellow-%d-0",Index);
        D3DWallIndices[CPlayer::pcYellow][Index] = this->FindTile(Name);

    }
    //sprintf(Name,"blue-damaged-0",Index);
    D3DDamagedWallIndices[CPlayer::pcBlue] = this->FindTile("blue-damaged-0");
    //sprintf(Name,"red-damaged-0",Index);
    D3DDamagedWallIndices[CPlayer::pcRed] = this->FindTile("red-damaged-0");
    //sprintf(Name,"yellow-damaged-0",Index);
    D3DDamagedWallIndices[CPlayer::pcYellow] = this->FindTile("yellow-damaged-0");
}

void C3DWallTileset::Draw3DWallTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int type, int offset){
    CGraphicTileset::DrawTile(game, position, D3DWallIndices[player_color][type] + offset);
}

void C3DWallTileset::Draw3DDamagedWallTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int index){
    CGraphicTileset::DrawTile(game, position, D3DDamagedWallIndices[player_color] + index);
}
