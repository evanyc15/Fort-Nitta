#include "Tilesets.h"
#include <stdio.h>
#include "../Game.h"

CTilesets::CTilesets(){

}

CTilesets::~CTilesets(){

}

void CTilesets::Load(CGame* game){
    GdkGC* GC = game->Rendering()->DDrawingContext;
    GdkDrawable* GD = game->DrawingArea()->window;

    if(!DWhiteFont.LoadFont(game,
        "data/FontKingthingsWhite.dat")){
    
        printf("Failed\n");
    }
    DBlackFont.LoadFont(game,
        "data/FontKingthingsBlack.dat");
    DBrickTileset.LoadTileset(game, "data/Bricks.dat");
    DMortarTileset.LoadTileset(game, "data/Mortar.dat");
    DWallFloorTileset.LoadTileset(game, "data/2DWallFloor.dat");
    D2DTerrainTileset.LoadTileset(game, "data/2DTerrain.dat");
    D3DTerrainTileset.LoadTileset(game, "data/3DTerrain.dat");
    D2DCastleCannonTileset.LoadTileset(game, "data/2DCastleCannon.dat");
    D2DCastleSelectTileset.LoadTileset(game, "data/2DCastleSelect.dat");
    DDigitTileset.LoadTileset(game, "data/Digits.dat");
    D3DCastleTileset.LoadTileset(game, "data/3DCastle.dat");
    D3DCannonTileset.LoadTileset(game, "data/3DCannon.dat");
    D3DWallTileset.LoadTileset(game, "data/3DWall.dat");
    D3DFloorTileset.LoadTileset(game, "data/3DFloor.dat");
    DTargetTileset.LoadTileset(game, "data/Target.dat");
    D3DCannonPlumeTileset.LoadTileset(game, "data/3DCannonPlume.dat");
    D3DCannonballTileset.LoadTileset(game, "data/3DCannonball.dat");
    D3DBurnTileset.LoadTileset(game, "data/3DBurn.dat");
    D3DExplosionTileset.LoadTileset(game, "data/3DExplosion.dat");
}

