#ifndef BRICKTILESET_H
#define BRICKTILESET_H

#include "GraphicTileset.h"
#include "../../types/Int2.h"

class CGame;

/**
 * @brief Brick tileset used to draw menus and borders
 */
class CBrickTileset : public CGraphicTileset{
    public:
        /**
         * @brief The different brick types
         */
        typedef enum{
            bbtTopCenter = 0,
            bbtTopRight,
            bbtRight0,
            bbtRight1,
            bbtBottomRight,
            bbtBottomCenter,
            bbtBottomLeft,
            bbtLeft0,
            bbtLeft1,
            bbtTopLeft,
            bbtSingle,
            bbtMax
        } EBorderBrickType, *EBorderBrickTypeRef;

        /**
         * @brief Loads the tileset
         *
         * @param game The game loading in
         * @param filename The filename to load from 
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the brick tile at the position
         *
         * @param game The game to draw in
         * @param position The position to draw at
         * @param brick_type The brick type to draw
         */
        void DrawTile(CGame* game, SInt2 position, EBorderBrickType brick_type);

    private:
        /**
         * @brief Stores the indices of the brick types
         */
        int DBrickIndices[bbtMax];
};

#endif
