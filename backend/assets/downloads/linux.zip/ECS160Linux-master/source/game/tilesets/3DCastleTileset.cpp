#include "3DCastleTileset.h"

bool C3DCastleTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DCastleIndices[CPlayer::pcNone] = this->FindTile("castle-none");
    D3DCastleIndices[CPlayer::pcBlue] = this->FindTile("castle-blue-0");
    D3DCastleIndices[CPlayer::pcRed] = this->FindTile("castle-red-0");
    D3DCastleIndices[CPlayer::pcYellow] = this->FindTile("castle-yellow-0");

}

void C3DCastleTileset::Draw3DCastleTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int index){
    CGraphicTileset::DrawTile(game, position, D3DCastleIndices[player_color] + index);
}
