#include "2DTerrainTileset.h"
#include <cstdio>
#include "../players/Player.h"

bool C2DTerrainTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D2DDamagedGroundIndex = this->FindTile("hole");
}

void C2DTerrainTileset::DrawDamagedGroundTile(CGame* game, SInt2 position){
    CGraphicTileset::DrawTile(game, position, D2DDamagedGroundIndex);
}
