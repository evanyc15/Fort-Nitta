#include "TargetTileset.h"

bool CTargetTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    DTargetIndices[CPlayer::pcBlue] = this->FindTile("blue-target");
    DTargetIndices[CPlayer::pcRed] = this->FindTile("red-target");
    DTargetIndices[CPlayer::pcYellow] = this->FindTile("yellow-target");

    return true;
}

void CTargetTileset::DrawTargetTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color){
    CGraphicTileset::DrawTile(game, position, DTargetIndices[player_color]);
}
