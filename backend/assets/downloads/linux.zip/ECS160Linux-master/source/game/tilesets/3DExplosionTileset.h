#ifndef EXPLOSION_TILESET_H
#define EXPLOSION_TILESET_H


#include "GraphicTileset.h"
#include "../animations/BurnAndExplode.h"

class CGame;

/**
 * @brief Tileset used for drawing plumes when cannons fire cannonballs
 */
class C3DExplosionTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads tileset
         *
         * @param game The game to load in
         * @param filename The name of the dat file
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Gets the index of the base frame of the animation for a burn type
         *
         * @param burnType The type of burn animation to play
         *
         * @return The index of the base frame
         */
        int GetBaseFrame(SBurnAndExplosion::EExplosionType explosionType);
    private:
        /**
         * @brief Stores the indices to the base frames burn type
         */
        int D3DExplosionIndices[SBurnAndExplosion::etMax];
};

#endif
