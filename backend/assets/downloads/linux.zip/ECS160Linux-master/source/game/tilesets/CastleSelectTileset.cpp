#include "CastleSelectTileset.h"

bool CCastleSelectTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D2DSelectColorIndices[CPlayer::pcNone] = 0;
    D2DSelectColorIndices[CPlayer::pcBlue] = this->FindTile("blue-0");
    D2DSelectColorIndices[CPlayer::pcRed] = this->FindTile("red-0");
    D2DSelectColorIndices[CPlayer::pcYellow] = this->FindTile("yellow-0");
}

void CCastleSelectTileset::Draw2DCastleSelectTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int index){
    CGraphicTileset::DrawTile(game, position, D2DSelectColorIndices[player_color] + index);
}
