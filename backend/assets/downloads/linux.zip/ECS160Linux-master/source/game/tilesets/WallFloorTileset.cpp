#include "WallFloorTileset.h"

bool CWallFloorTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D2DFloorIndices[CPlayer::pcNone] = this->FindTile("floor-even");
    D2DFloorIndices[CPlayer::pcBlue] = this->FindTile("floor-blue");
    D2DFloorIndices[CPlayer::pcRed] = this->FindTile("floor-red");
    D2DFloorIndices[CPlayer::pcYellow] = this->FindTile("floor-yellow");
    D2DWallIndices[CPlayer::pcNone] = this->FindTile("bad-0");
    D2DWallIndices[CPlayer::pcBlue] = this->FindTile("blue-0");
    D2DWallIndices[CPlayer::pcRed] = this->FindTile("red-0");
    D2DWallIndices[CPlayer::pcYellow] = this->FindTile("yellow-0");
    D2DWallIndices[CPlayer::pcMax] = this->FindTile("good-0");
    D2DWallIndices[CPlayer::pcMax+1] = this->FindTile("good-alt-0");
    return true;
}

void CWallFloorTileset::Draw2DFloorTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color){
    CGraphicTileset::DrawTile(game, SInt2(x, y), D2DFloorIndices[player_color]);
}

void CWallFloorTileset::Draw2DWallTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color, int index){
    CGraphicTileset::DrawTile(game, SInt2(x, y), D2DWallIndices[player_color] + index);
}
