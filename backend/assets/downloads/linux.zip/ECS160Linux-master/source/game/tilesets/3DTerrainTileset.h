#ifndef TERRAINTILESET_H
#define TERRAINTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset for drawing the 3D terrain
 */
class C3DTerrainTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game The game to load in
         * @param filename The filename to load from 
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the damaged ground tile in tileset
         *
         * @param game Game to draw in
         * @param position Position to draw at
         */
        void DrawDamagedGroundTile(CGame* game, SInt2 position);
    private:
        /**
         * @brief Stores the index of the damaged ground tile
         */
        int D3DDamagedGroundIndex;
};

#endif

