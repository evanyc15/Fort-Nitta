#ifndef CANNON_PLUME_TILESET_H
#define CANNON_PLUME_TILESET_H

#include "GraphicTileset.h"
#include "../../types/Direction.h"

class CGame;

/**
 * @brief Tileset used for drawing plumes when cannons fire cannonballs
 */
class C3DCannonPlumeTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads tileset
         *
         * @param game The game to load in
         * @param filename The name of the dat file
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Gets the index of the base frame of the animation for a plume facing
         *        a direction for a cannon
         *
         * @param direction The direction the cannon is facing
         *
         * @return The index of the base frame
         */
        int GetBaseFrame(SDirection::EValue direction);
    private:
        /**
         * @brief Stores the indices to the base frames for each direction
         */
        int D3DCannonPlumeIndices[SDirection::dMax];
};

#endif
