#include "BrickTileset.h"

bool CBrickTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    DBrickIndices[bbtTopCenter] = this->FindTile("brick-tc");
    DBrickIndices[bbtTopRight] = this->FindTile("brick-tr");
    DBrickIndices[bbtRight0] = this->FindTile("brick-r0");
    DBrickIndices[bbtRight1] = this->FindTile("brick-r1");
    DBrickIndices[bbtBottomRight] = this->FindTile("brick-br");
    DBrickIndices[bbtBottomCenter] = this->FindTile("brick-bc");
    DBrickIndices[bbtBottomLeft] = this->FindTile("brick-bl");
    DBrickIndices[bbtLeft0] = this->FindTile("brick-l0");
    DBrickIndices[bbtLeft1] = this->FindTile("brick-l1");
    DBrickIndices[bbtTopLeft] = this->FindTile("brick-tl");
    DBrickIndices[bbtSingle] = this->FindTile("brick-single");

    return true;
}

void CBrickTileset::DrawTile(CGame* game, SInt2 position, EBorderBrickType brick_type){
    CGraphicTileset::DrawTile(game, position, DBrickIndices[brick_type]);
}
