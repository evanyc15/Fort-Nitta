#ifndef WALLFLOORTILESET_H 
#define WALLFLOORTILESET_H

#include "GraphicTileset.h"
#include "../../types/Int2.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Combined tileset for 2D walls and floors
 */
class CWallFloorTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads tileset
         *
         * @param game Game loading
         * @param filename Filename loading from 
         *
         * @return true
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws 2D floor tile for color
         *
         * @param game Game drawing
         * @param x X
         * @param y Y
         * @param player_color Color drawing
         */
        void Draw2DFloorTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color);
        /**
         * @brief Draws 2D wall tile for color
         *
         * @param game Game drawing
         * @param x X
         * @param y Y
         * @param player_color Color drawing
         * @param index Index of wall
         */
        void Draw2DWallTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color, int index);
        /**
         * @brief Holds index of damaged ground tile
         */
        int D2DDamagedGroundIndex;
    private:

        /**
         * @brief Holds indices of floor tiles for players
         */
        int D2DFloorIndices[CPlayer::pcMax];
        /**
         * @brief Holds indices for wall tiles for players, including wall shape placing tiles
         */
        int D2DWallIndices[CPlayer::pcMax+2];
};

#endif
