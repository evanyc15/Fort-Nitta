#ifndef CASTLECANNONTILESET_H
#define CASTLECANNONTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset that contains the 2D castle and cannon tiles
 */
class CCastleCannonTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game Game to load in
         * @param filename The filename to load from 
         *
         * @return true
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the castle tile for a color
         *
         * @param game Game to draw in
         * @param x Legacy X
         * @param y Legacy Y
         * @param player_color Player color to draw in
         */
        void Draw2DCastleTile(CGame* game, int x, int y, CPlayer::EPlayerColor player_color);
        /**
         * @brief Draws the cannon tile at a position
         *
         * @param game Game to draw in
         * @param position Position to draw at
         */
        void Draw2DCannonTile(CGame* game, SInt2 position);
        /**
         * @brief Draws the cannon cursor with number of cannons available for a player
         *
         * @param game Game to draw in
         * @param position Position to draw 
         * @param player_color Color to draw
         * @param count Count to show on tile
         */
        void Draw2DCannonToPlaceTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color, int count);
    private:
        /**
         * @brief Stores indices of castles for colors
         */
        int D2DCastleIndices[CPlayer::pcMax];
        /**
         * @brief Stores indices of cannons for colors
         */
        int D2DCannonIndices[CPlayer::pcMax];
};

#endif

