#ifndef TILESET_H
#define TILESET_H

#include "FontTileset.h"
#include "GraphicTileset.h"
#include "BrickTileset.h"
#include "WallFloorTileset.h"
#include "MortarTileset.h"
#include "CastleCannonTileset.h"
#include "CastleSelectTileset.h"
#include "3DCastleTileset.h"
#include "3DFloorTileset.h"
#include "3DWallTileset.h"
#include "3DTerrainTileset.h"
#include "TargetTileset.h"
#include "3DCannonPlumeTileset.h"
#include "3DBurnTileset.h"
#include "3DExplosionTileset.h"
#include "2DTerrainTileset.h"
class CGame;

/**
 * @brief Groups the tilesets together
 */
class CTilesets{

    public:
        CTilesets();
        ~CTilesets();

        /**
         * @brief Loads the tilesets
         *
         * @param game
         */
        void Load(CGame* game);

       /**
        * @brief 2D terrain tileset
        */
        C2DTerrainTileset D2DTerrainTileset;
        /**
         * @brief 3D terrain tileset
         */
        C3DTerrainTileset D3DTerrainTileset;
        /**
         * @brief 3D floor tileset
         */
        C3DFloorTileset D3DFloorTileset;
        /**
         * @brief 3D wall tileset
         */
        C3DWallTileset D3DWallTileset;
        /**
         * @brief 3D cannon tileset
         */
        CGraphicTileset D3DCannonTileset;
        /**
         * @brief 3D castle tileset
         */
        C3DCastleTileset D3DCastleTileset;
        /**
         * @brief 3D cannonball tileset
         */
        CGraphicTileset D3DCannonballTileset;
        /**
         * @brief 3D explosion tileset
         */
        C3DExplosionTileset D3DExplosionTileset;
        /**
         * @brief 3D burn tileset
         */
        C3DBurnTileset D3DBurnTileset;
        /**
         * @brief 3D cannon plume tileset
         */
        C3DCannonPlumeTileset D3DCannonPlumeTileset;
        /**
         * @brief 3D castle and cannon combined tileset
         */
        CCastleCannonTileset D2DCastleCannonTileset;
        /**
         * @brief 2D ring select tileset
         */
        CCastleSelectTileset D2DCastleSelectTileset;
        /**
         * @brief Digits tileset for timer
         */
        CGraphicTileset DDigitTileset;
        
        /**
         * @brief Combined 2D wall and floor tileset
         */
        CWallFloorTileset DWallFloorTileset;
        /**
         * @brief Brick tileset for menu
         */
        CBrickTileset DBrickTileset;
        /**
         * @brief Mortar tileset for menu
         */
        CMortarTileset DMortarTileset;
        /**
         * @brief Target tileset for battle
         */
        CTargetTileset DTargetTileset;
        /**
         * @brief Black font
         */
        CFontTileset DBlackFont;
        /**
         * @brief White font
         */
        CFontTileset DWhiteFont;
};
#endif
