#include "3DTerrainTileset.h"
#include <cstdio>
#include "../players/Player.h"

bool C3DTerrainTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DDamagedGroundIndex = this->FindTile("hole-0");
}

void C3DTerrainTileset::DrawDamagedGroundTile(CGame* game, SInt2 position){
    CGraphicTileset::DrawTile(game, position, D3DDamagedGroundIndex);
}
