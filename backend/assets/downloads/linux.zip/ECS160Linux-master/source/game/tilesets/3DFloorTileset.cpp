#include "3DFloorTileset.h"

bool C3DFloorTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DFloorIndices[CPlayer::pcBlue] = this->FindTile("floor-blue");
    D3DFloorIndices[CPlayer::pcRed] = this->FindTile("floor-red");
    D3DFloorIndices[CPlayer::pcYellow] = this->FindTile("floor-yellow");

    return true;
}

void C3DFloorTileset::Draw3DFloorTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color){
    CGraphicTileset::DrawTile(game, position, D3DFloorIndices[player_color]);
}
