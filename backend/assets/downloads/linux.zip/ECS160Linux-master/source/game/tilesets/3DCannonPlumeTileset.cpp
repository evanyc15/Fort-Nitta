#include "3DCannonPlumeTileset.h"


bool C3DCannonPlumeTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);

    D3DCannonPlumeIndices[SDirection::dNorth] = this->FindTile("north-0");
    D3DCannonPlumeIndices[SDirection::dNorthEast] = this->FindTile("northeast-0");
    D3DCannonPlumeIndices[SDirection::dEast] = this->FindTile("east-0");
    D3DCannonPlumeIndices[SDirection::dSouthEast] = this->FindTile("southeast-0");
    D3DCannonPlumeIndices[SDirection::dSouth] = this->FindTile("south-0");
    D3DCannonPlumeIndices[SDirection::dSouthWest] = this->FindTile("southwest-0");
    D3DCannonPlumeIndices[SDirection::dWest] = this->FindTile("west-0");
    D3DCannonPlumeIndices[SDirection::dNorthWest] = this->FindTile("northwest-0");

    return true;
}

int C3DCannonPlumeTileset::GetBaseFrame(SDirection::EValue direction){
    return D3DCannonPlumeIndices[direction];
}
