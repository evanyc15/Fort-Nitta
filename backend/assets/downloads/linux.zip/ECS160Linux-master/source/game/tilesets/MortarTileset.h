#ifndef MORTARTILESET_H
#define MORTARTILESET_H

#include "GraphicTileset.h"
#include "../../types/Int2.h"

class CGame;

/**
 * @brief The mortar tileset
 */
class CMortarTileset : public CGraphicTileset{
    public:
        /**
         * @brief Enum of mortar types
         */
        typedef enum{
            bmtTopLeft0 = 0,
            bmtTopLeft1,
            bmtTopLeft2,
            bmtTopCenter,
            bmtTopRight0,
            bmtTopRight1,
            bmtTopRight2,
            bmtRightTop0,
            bmtRightTop1,
            bmtRightTop2,
            bmtRightCenter,
            bmtRightBottom0,
            bmtRightBottom1,
            bmtRightBottom2,
            bmtBottomRight0,
            bmtBottomRight1,
            bmtBottomRight2,
            bmtBottomCenter,
            bmtBottomLeft0,
            bmtBottomLeft1,
            bmtBottomLeft2,
            bmtLeftTop0,
            bmtLeftTop1,
            bmtLeftTop2,
            bmtLeftCenter,
            bmtLeftBottom0,
            bmtLeftBottom1,
            bmtLeftBottom2,
            bmtMax
        } EBorderMotarType, *EBorderMortarTypeRef;

        /**
         * @brief Loads the tileset
         *
         * @param game Game loading
         * @param filename Filename loading from
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the tile specified at the location
         *
         * @param game Game drawing
         * @param position Position drawing at
         * @param mortar_type Mortar drawing
         */
        void DrawTile(CGame* game, SInt2 position, EBorderMotarType mortar_type);
        /**
         * @brief Draws the tile at the location
         *
         * @param game Game drawing
         * @param x X
         * @param y Y
         * @param mortar_type Mortar drawing
         */
        void DrawTile(CGame* game, int x, int y, EBorderMotarType mortar_type);
    private:
        /**
         * @brief Stores indices of tiles
         */
        int DMortarIndices[bmtMax];
};

#endif


