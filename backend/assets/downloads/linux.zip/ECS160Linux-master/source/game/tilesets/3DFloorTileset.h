#ifndef FLOORTILESET_H
#define FLOORTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset for drawing the 3D floor
 */
class C3DFloorTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game The game to load in
         * @param filename The file to load from 
         *
         * @return True
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the floor tile for a player at a position
         *
         * @param game Game to draw in
         * @param position Position to draw at
         * @param player_color The color to draw
         */
        void Draw3DFloorTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color);
    private:
        /**
         * @brief Stores the indices of floors for each color
         */
        int D3DFloorIndices[CPlayer::pcMax];
};

#endif

