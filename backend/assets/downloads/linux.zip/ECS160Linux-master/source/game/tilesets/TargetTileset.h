#ifndef TARGTETILESET_H
#define TARGETTILESET_H

#include "GraphicTileset.h"
#include "../players/Player.h"

class CGame;

/**
 * @brief Tileset with reticule for each player
 */
class CTargetTileset : public CGraphicTileset{
    public:
        /**
         * @brief Loads the tileset
         *
         * @param game Game loading
         * @param filename Filename to load from
         *
         * @return true
         */
        bool LoadTileset(CGame* game, const std::string &filename);
        /**
         * @brief Draws the reticule for a color
         *
         * @param game Game drawing
         * @param position Position to draw
         * @param player_color Color to draw
         */
        void DrawTargetTile(CGame* game, SInt2 position, CPlayer::EPlayerColor player_color);
    private:
        /**
         * @brief Stores indices of reticules for colors
         */
        int DTargetIndices[CPlayer::pcMax];
};

#endif

