#include "MortarTileset.h"

bool CMortarTileset::LoadTileset(CGame* game, const std::string &filename){
    CGraphicTileset::LoadTileset(game, filename);
    
    DMortarIndices[bmtTopCenter] = this->FindTile("mortar-tc");
    DMortarIndices[bmtTopRight0] = this->FindTile("mortar-tr0");
    DMortarIndices[bmtTopRight1] = this->FindTile("mortar-tr1");
    DMortarIndices[bmtTopRight2] = this->FindTile("mortar-tr2");
    DMortarIndices[bmtTopLeft0] = this->FindTile("mortar-tl0");
    DMortarIndices[bmtTopLeft1] = this->FindTile("mortar-tl1");
    DMortarIndices[bmtTopLeft2] = this->FindTile("mortar-tl2");
    DMortarIndices[bmtBottomCenter] = this->FindTile("mortar-bc");
    DMortarIndices[bmtBottomRight0] = this->FindTile("mortar-br0");
    DMortarIndices[bmtBottomRight1] = this->FindTile("mortar-br1");
    DMortarIndices[bmtBottomRight2] = this->FindTile("mortar-br2");
    DMortarIndices[bmtBottomLeft0] = this->FindTile("mortar-bl0");
    DMortarIndices[bmtBottomLeft1] = this->FindTile("mortar-bl1");
    DMortarIndices[bmtBottomLeft2] = this->FindTile("mortar-bl2");
    DMortarIndices[bmtRightCenter] = this->FindTile("mortar-rc");
    DMortarIndices[bmtRightBottom0] = this->FindTile("mortar-rb0");
    DMortarIndices[bmtRightBottom1] = this->FindTile("mortar-rb1");
    DMortarIndices[bmtRightBottom2] = this->FindTile("mortar-rb2");
    DMortarIndices[bmtRightTop0] = this->FindTile("mortar-rt0");
    DMortarIndices[bmtRightTop1] = this->FindTile("mortar-rt1");
    DMortarIndices[bmtRightTop2] = this->FindTile("mortar-rt2");
    DMortarIndices[bmtLeftCenter] = this->FindTile("mortar-lc");
    DMortarIndices[bmtLeftBottom0] = this->FindTile("mortar-lb0");
    DMortarIndices[bmtLeftBottom1] = this->FindTile("mortar-lb1");
    DMortarIndices[bmtLeftBottom2] = this->FindTile("mortar-lb2");
    DMortarIndices[bmtLeftTop0] = this->FindTile("mortar-lt0");
    DMortarIndices[bmtLeftTop1] = this->FindTile("mortar-lt1");
    DMortarIndices[bmtLeftTop2] = this->FindTile("mortar-lt2");
}

void CMortarTileset::DrawTile(CGame* game, SInt2 position, EBorderMotarType mortar_type){
    CGraphicTileset::DrawTile(game, position, DMortarIndices[mortar_type]);
}

void CMortarTileset::DrawTile(CGame* game, int x, int y, EBorderMotarType mortar_type){
    CGraphicTileset::DrawTile(game, x, y, DMortarIndices[mortar_type]);
}
