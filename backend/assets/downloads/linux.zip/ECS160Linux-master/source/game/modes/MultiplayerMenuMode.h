#ifndef MULTIPLAYER_MENU_MODE_H
#define MULTIPLAYER_MENU_MODE_H

#include "MenuMode.h"
#include <string>
#include <vector>
#include "../Room.h"

#define MAX_LIST_SIZE 3
#define MP_MENU_MARGIN SInt2(15, 8)

class CGame;
class CButton;
class CStackElement;
class CLabel;

/**
 * @brief Mode to select a multiplayer room or create one
 */
class CMultiplayerMenuMode : public CMenuMode{
    public:
        /**
         * @brief CMultiplayerMenuMode constructor
         */
        CMultiplayerMenuMode(CGame* game);
        ~CMultiplayerMenuMode();

        /**
         * @brief Lets user select which room to play in
         *
         * @param game The game to update
         */
        virtual void Update(CGame* game);
        /**
         * @brief Gets the available rooms
         *
         * @param game The game to obtain rooms from
         */
        virtual void Enter(CGame* game);

        /**
         * @brief Updates the list of available rooms
         *
         * @param game The game being played
         * @param rooms The list of available rooms
         */
        void UpdateAvailableRooms(CGame* game, std::vector<CRoom*> rooms);

        void SetResponseText(std::string text);

        /**
         * @brief Changes which rooms are displayed on the screen
         */
        void ChangeListView();
   private:
        /**
         * @brief The back button
         */
        CButton* DBackButton;
        /**
         * @brief The create button
         */
        CButton* DCreateRoomButton;
        /**
         * @brief Contains the room buttons
         */
        CStackElement* DRooms;

        CLabel* DResponseLabel;
        int DResponseTimer;

        /**
         * @brief The vector of available room buttons
         */
        std::vector<CButton*> DAvailableRooms;
        /**
         * @brief The list of all available rooms
         */
        std::vector<std::string> DAvailableRoomsList;
        /**
         * @brief Holds the starting index in the list of rooms to display onscreen
         */
        int DStartingIndex;
        /**
         * @brief The scroll up button
         */
        CButton* DUpButton;
        /**
         * @brief The scroll down button
         */
        CButton* DDownButton;
};

#endif
