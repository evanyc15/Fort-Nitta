#ifndef ROOMMENUMODE_H
#define ROOMMENUMODE_H

#include "MenuMode.h"
#include <map>

class CGame;
class CLabel;
class CButton;
class CStackElement;

class CRoomMenuMode : public CMenuMode{
    public:
        CRoomMenuMode(CGame* game);
        ~CRoomMenuMode();

        virtual void Update(CGame* game);

        void PlayerJoined(CGame* game, std::string username);
        void PlayerLeft(std::string username);

        void SpectatorJoined(CGame* game, std::string username);
        void SpectatorLeft(std::string username);

    private:
        CButton* DBackButton;
        CButton* DStartRoomButton;
        CStackElement* DPlayers;
        CStackElement* DSpectators;

        std::map<std::string, CLabel*> DPlayerLabels;
        std::map<std::string, CLabel*> DSpectatorLabels;
};

#endif
