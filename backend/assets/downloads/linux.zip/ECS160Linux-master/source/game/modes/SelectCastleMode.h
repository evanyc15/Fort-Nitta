#ifndef SELECTCASTLEMODE_H
#define SELECTCASTLEMODE_H

#include "MapMode.h"

/**
 * @brief Mode where players select their home castle
 */
class CSelectCastleMode : public CMapMode{
    public:
        CSelectCastleMode();
        ~CSelectCastleMode();
        /**
         * @brief Places the home castles and switches to cannon mode if all placed
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the 2D map
         *
         * @param game Game drawing
         */
        virtual void Draw(CGame* game);
};

#endif
