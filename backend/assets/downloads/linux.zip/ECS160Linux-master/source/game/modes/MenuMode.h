#ifndef MENU_MODE_H
#define MENU_MODE_H

#include <string>
#include "GameMode.h"
#include "../../types/Int2.h"
#include "../tilesets/FontTileset.h"

class CUIElement;

/**
 * @brief Mode mainly dealing with UI and has a title
 */
class CMenuMode : public CGameMode{
    public:
        /**
         * @brief Makes a new menu mode with a title
         *
         * @param title
         */
        CMenuMode(std::string title);
        ~CMenuMode();

        /**
         * @brief Needed to start playing menu music
         *
         * @param game The game to reset
         */
        virtual void Enter(CGame* game);
        
        /**
         * @brief Updates root UI element
         *
         * @param game Game updating
         */

        virtual void Update(CGame* game);
        /**
         * @brief Draws the menu background, title, and root element
         *
         * @param game Game drawing
         */
        virtual void Draw(CGame* game);
    protected:
        /**
         * @brief Draws menu background with bricks
         *
         * @param game Game drawing
         * @param size Size of background
         */
        void DrawMenuBackground(CGame* game, SInt2 size);
        /**
         * @brief Draws the title surrounded by brick border
         *
         * @param game Game drawing
         */
        void DrawTitle(CGame* game);
        /**
         * @brief The root UI element
         */
        CUIElement* DRootElement;
    private:
        /**
         * @brief The title of the mode
         */
        std::string DTitle;
};
#endif
