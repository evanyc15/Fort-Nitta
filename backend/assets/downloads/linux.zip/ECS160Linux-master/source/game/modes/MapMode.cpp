#include "MapMode.h"
#include "../Game.h"

CMapMode::CMapMode(){
}

CMapMode::~CMapMode(){
}

void CMapMode::Update(CGame* game){
    CGameMode::Update(game);
}

void CMapMode::Draw(CGame* game){
    CGameMode::Draw(game);
}

void CMapMode::Draw2D(CGame* game){
    game->GameState()->TerrainMap()->Draw2DMap(game);
    game->GameState()->ConstructionMap()->Draw2D(game);
    game->GameState()->TerrainMap()->Draw2DCastles(game);
}

void CMapMode::Draw3D(CGame* game){
    game->GameState()->TerrainMap()->Draw3D(game);
    for(int YIndex = 0, YPos = -game->Resources()->DTilesets->D3DTerrainTileset.TileHeight();
            YIndex < game->GameState()->ConstructionMap()->DTiles.size();
            YIndex++, YPos += game->Resources()->DTilesets->D3DTerrainTileset.TileHeight()){
        for(int XIndex = 0, XPos = 0;
                XIndex < game->GameState()->ConstructionMap()->DTiles[YIndex].size();
                XIndex++, XPos += game->Resources()->DTilesets->D3DTerrainTileset.TileWidth()){
            game->GameState()->ConstructionMap()->Draw3DFloor(game, XIndex, YIndex, XPos, YPos);
            game->GameState()->ConstructionMap()->Draw3DCannons(game, XIndex, YIndex);
            game->GameState()->TerrainMap()->Draw3DCastles(game, XIndex, YIndex);
            game->GameState()->ConstructionMap()->Draw3DWalls(game, XIndex, YIndex, XPos, YPos);
            CGameMode::DrawCannonballs(game, SInt2(XIndex, YIndex));
            CGameMode::DrawAnimations(game, SInt2(XIndex, YIndex));
        }
    }


}

