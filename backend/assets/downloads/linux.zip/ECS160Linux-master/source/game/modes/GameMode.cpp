#include "GameMode.h"

#include "../Game.h"
#include "../players/Player.h"
#include "../sounds/Sounds.h"

void CGameMode::Enter(CGame* game){
    game->GameState()->DTimer.DIsAudible = false;
    game->GameState()->DTimer.DIsVisible = false;
}

void CGameMode::Update(CGame* game){
    game->GameState()->Network()->Update(game);
    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        (*it)->Update(game);
    }
    std::vector<CCannonball*> ContinuingCannonballs;
    for(std::vector<CCannonball*>::iterator it = game->GameState()->DCannonballs.begin();
            it != game->GameState()->DCannonballs.end();
            it++){
        (*it)->Update(game);
        if((*it)->IsAlive()){
            ContinuingCannonballs.push_back(*it);
        }else{
            delete *it;
        }
    }
    game->GameState()->DCannonballs = ContinuingCannonballs;

    std::vector<CAnimation*> ContinuingAnimations;
    for(int i = 0; i < game->GameState()->DAnimations.size(); i++){
        CAnimation* Animation = game->GameState()->DAnimations.at(i);
        Animation->Update(game);
        if(Animation->ShouldContinuePlaying()){
            ContinuingAnimations.push_back(Animation);
        }else{
            delete Animation;
        }
    }
    game->GameState()->DAnimations = ContinuingAnimations;
    ContinuingAnimations.clear();
    if(game->GameState()->TerrainMap() != NULL){
        game->GameState()->TerrainMap()->Update(game);
    }
    game->GameState()->DTimer.Update(game);
    game->GameState()->DTimeStep++;
}

void CGameMode::Draw(CGame* game){
    game->GameState()->DTimer.Draw(game);
}

void CGameMode::DrawAnimations(CGame* game, SInt2 position){
    for(std::vector<CAnimation*>::iterator it = game->GameState()->DAnimations.begin();
            it != game->GameState()->DAnimations.end();
            it++){

        if ((*it)->Index() == position){
            (*it)->Draw(game);
        }
    }
}

void CGameMode::DrawCannonballs(CGame* game, SInt2 position){
    for(std::vector<CCannonball*>::iterator it = game->GameState()->DCannonballs.begin();
            it != game->GameState()->DCannonballs.end();
            it++){
        if (game->GameState()->TerrainMap()->ConvertToTileIndex((*it)->Position().SInt2Position()) == position){
            (*it)->Draw(game);
        }
    }
}

void CGameMode::Leave(CGame* game){
}

void CGameMode::WillEnter(CGame* game){
}

void CGameMode::DrawTextBackgroundFrame(CGame* game, SInt2 size){
    CWallFloorTileset& Tileset = game->Resources()->DTilesets->DWallFloorTileset;
    CPlayer::EPlayerColor MainColor = game->GameState()->GetMainPlayerColor();
    for(int HeightOffset = 0; HeightOffset < size.DY; HeightOffset += Tileset.TileHeight()){
        for(int WidthOffset = 0; WidthOffset < size.DX; WidthOffset += Tileset.TileWidth()){
            Tileset.Draw2DFloorTile(game, WidthOffset, HeightOffset, MainColor);
        }
    }
}

void CGameMode::DrawBrickFrame(CGame* game, SInt2 position, SInt2 size){
    DrawMortar(game, position, size);
    DrawBrickOutline(game, position, size);
}

void CGameMode::DrawMortar(CGame* game, SInt2 position, SInt2 size){
    CMortarTileset& Mortar = game->Resources()->DTilesets->DMortarTileset;

    // Draws the corner mortar tiles
    Mortar.DrawTile(game, position.DX, position.DY - 5, CMortarTileset::bmtLeftTop2);
    Mortar.DrawTile(game, position.DX + size.DX - Mortar.TileWidth(), position.DY - 5, CMortarTileset::bmtRightTop2);
    Mortar.DrawTile(game, position.DX,  position.DY + size.DY -Mortar.TileHeight() + 5, CMortarTileset::bmtLeftBottom2);
    Mortar.DrawTile(game, position.DX + size.DX - Mortar.TileWidth(), position.DY + size.DY -Mortar.TileHeight() + 5, CMortarTileset::bmtRightBottom2);
    /**
     * Draws mortar tiles according to frame's size.DX
     * Sets index according to index of mortars where center = 0
     */
    for(gint WidthOffset = 0; WidthOffset < size.DX; WidthOffset += Mortar.TileWidth()){
        CMortarTileset::EBorderMotarType TopIndex, BottomIndex; // Top index and bottom index of size.DX 
        int CenterPoint = WidthOffset + Mortar.TileWidth() / 2; // Center point = middle of size.DX 
        int BrickDistance = (size.DX / 2 - CenterPoint) / Mortar.TileWidth(); // Distance of bricks  
        
        if(-3 >= BrickDistance){
            TopIndex = CMortarTileset::bmtTopRight2;
            BottomIndex = CMortarTileset::bmtBottomRight2;
        }
        else if(-2 == BrickDistance){
            TopIndex = CMortarTileset::bmtTopRight1;
            BottomIndex = CMortarTileset::bmtBottomRight1;
        }
        else if(-1 == BrickDistance){
            TopIndex = CMortarTileset::bmtTopRight0;
            BottomIndex = CMortarTileset::bmtBottomRight0;
        }
        else if(0 == BrickDistance){
            TopIndex = CMortarTileset::bmtTopCenter;
            BottomIndex = CMortarTileset::bmtBottomCenter;
        }
        else if(1 == BrickDistance){
            TopIndex = CMortarTileset::bmtTopLeft0;
            BottomIndex = CMortarTileset::bmtBottomLeft0;
        }
        else if(2 == BrickDistance){
            TopIndex = CMortarTileset::bmtTopLeft1;
            BottomIndex = CMortarTileset::bmtBottomLeft1;
        }
        else{
            TopIndex = CMortarTileset::bmtTopLeft2;
            BottomIndex = CMortarTileset::bmtBottomLeft2;
        }
        
        Mortar.DrawTile(game, position.DX + WidthOffset, position.DY, TopIndex); // Draws a row of tiles at the top index 
        Mortar.DrawTile(game, position.DX + WidthOffset, position.DY + size.DY - Mortar.TileHeight(), BottomIndex); // Draws tiles at bottom 
    }

    // Determines the left index and right index of the frame
    for(gint HeightOffset = 3; HeightOffset < size.DY-Mortar.TileHeight(); HeightOffset += 8){
        CMortarTileset::EBorderMotarType LeftIndex, RightIndex;
        int CenterPoint = HeightOffset + Mortar.TileHeight() / 2;
        int BrickDistance = (size.DY / 2 - CenterPoint) / 8;
        
        if(3 <= BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftTop2;
            RightIndex = CMortarTileset::bmtRightTop2;
        }
        else if(2 == BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftTop1;
            RightIndex = CMortarTileset::bmtRightTop1;
        }
        else if(1 == BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftTop0;
            RightIndex = CMortarTileset::bmtRightTop0;
        }
        else if(0 == BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftCenter;
            RightIndex = CMortarTileset::bmtRightCenter;
        }
        else if(-1 == BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftBottom0;
            RightIndex = CMortarTileset::bmtRightBottom0;
        }
        else if(-2 == BrickDistance){
            LeftIndex = CMortarTileset::bmtLeftBottom1;
            RightIndex = CMortarTileset::bmtRightBottom1;
        }
        else{
            LeftIndex = CMortarTileset::bmtLeftBottom2;
            RightIndex = CMortarTileset::bmtRightBottom2;
        }
        
        Mortar.DrawTile(game, position.DX, position.DY + HeightOffset, LeftIndex); // Draws the mortar tiles on left column 
        Mortar.DrawTile(game, position.DX + size.DX - Mortar.TileWidth(), position.DY + HeightOffset, RightIndex); // Draws tile on right col 

    }
}

void CGameMode::DrawBrickOutline(CGame* game, SInt2 position, SInt2 size){
    CBrickTileset& Bricks = game->Resources()->DTilesets->DBrickTileset;

    gint BrickType = 0;
    // Draws brick frame as long as cumulative size.DX offset is less than size.DX
    for(gint WidthOffset = 0; WidthOffset < size.DX; WidthOffset += Bricks.TileWidth()){
        Bricks.DrawTile(game, position + SInt2(WidthOffset, 0), CBrickTileset::bbtTopCenter);
        Bricks.DrawTile(game, position + SInt2(WidthOffset, size.DY - Bricks.TileHeight()), CBrickTileset::bbtBottomCenter);
    }
    // Draws brick frame as long as cumulative size.DY is less than frame size.DY
    for(gint HeightOffset = 0; HeightOffset < size.DY; HeightOffset += Bricks.TileHeight()){
        Bricks.DrawTile(game, position + SInt2(0, HeightOffset), BrickType ? CBrickTileset::bbtLeft1 : CBrickTileset::bbtLeft0);
        Bricks.DrawTile(game, position + SInt2(size.DX - Bricks.TileWidth(), HeightOffset), BrickType ? CBrickTileset::bbtRight1 : CBrickTileset::bbtRight0);
        BrickType++;
        BrickType &= 0x1;
    }
    
    // Draws the 4 corner tiles 
    Bricks.DrawTile(game, SInt2(position.DX, 0), CBrickTileset::bbtTopLeft);
    Bricks.DrawTile(game, position + SInt2(size.DX - Bricks.TileWidth(), 0), CBrickTileset::bbtTopRight);
    Bricks.DrawTile(game, position + SInt2(size.DX - Bricks.TileWidth(), size.DY - Bricks.TileHeight()), CBrickTileset::bbtBottomRight);
    Bricks.DrawTile(game, position + SInt2(0, size.DY - Bricks.TileHeight()), CBrickTileset::bbtBottomLeft);
}

void CGameMode::DrawTargetCursors(CGame* game) {
    CTargetTileset& Target = game->Resources()->DTilesets->DTargetTileset;

    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        Target.DrawTargetTile(game,
                (*it)->DCursorPosition - SInt2(Target.TileWidth(), Target.TileHeight())/2,
                (*it)->DColor);
    }
}
