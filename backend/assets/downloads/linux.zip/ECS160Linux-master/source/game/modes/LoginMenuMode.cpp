#include "LoginMenuMode.h"

#include "../Game.h"
#include "../ui/Button.h"
#include "../ui/Label.h"
#include "MainMenuMode.h"
#include "../ui/StackElement.h"
#include "../ui/TextField.h"

CLoginMenuMode::CLoginMenuMode(CGame* game)
    : CMenuMode("LOG IN"){
    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));

    DLoginButton = new CButton(game, "LOG IN");
    DLoginButton->Position(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DLoginButton->Anchor(SDouble2(1, 1));

    DErrorLabel = new CLabel(game, "");
    DErrorLabel->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT));
    DErrorLabel->Anchor(SDouble2(0.5, 1));

    CStackElement* S = new CStackElement();
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2+10));
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Anchor(SDouble2(0.5, 0.5));

    DUsernameLabel = new CLabel(game, "USERNAME", SInt2(15, 0));
    S->AddChildElement(DUsernameLabel);
    DUsernameField = new CTextField(game, "");
    DUsernameField->Size(SInt2(300, 60));
    S->AddChildElement(DUsernameField);
    DPasswordLabel = new CLabel(game, "PASSWORD", SInt2(15, 0));
    S->AddChildElement(DPasswordLabel);
    DPasswordField = new CTextField(game, "", true);
    DPasswordField->Size(SInt2(300, 60));
    S->AddChildElement(DPasswordField);
    DPassword = "";

    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(DLoginButton);
    DRootElement->AddChildElement(DErrorLabel);
    DRootElement->AddChildElement(S);
}

void CLoginMenuMode::Enter(CGame* game){
    if(!game->GameState()->Network()->Connect()){
        DErrorLabel->Text("ERROR CONNECTING");
        g_print("Error connecting\n");
    }
}

void CLoginMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->SwitchMode(new CMainMenuMode(game));
    }
    if(DLoginButton->IsPressed()){
        game->GameState()->DUsername = DUsernameField->TextEntered();
        game->GameState()->Network()->LogIn(
                DUsernameField->TextEntered(),
                DPasswordField->TextEntered());
    }
}
