#ifndef TEST_GAMEMODE_H
#define TEST_GAMEMODE_H

#include "GameMode.h"

class CUIElement;

class CGame;

class CTestGameMode : public CGameMode{
    public:
        CTestGameMode(CGame* game);
        ~CTestGameMode();
        virtual void Update(CGame* game);
        virtual void Draw(CGame* game);
    private:
        CUIElement* DRootElement;
        
};

#endif
