#ifndef GAME_OPTIONS_MENU_MODE_H
#define GAME_OPTIONS_MENU_MODE_H

#include <map>
#include <string>

#include "../GameState.h"
#include "MenuMode.h"
#include "../players/Player.h"
#include "../Wind.h"

class CGame;
class CButton;
class CSpinner;

/**
 * @brief Mode with menu including wind type, player color, AI difficulty
 */
class CGameOptionsMenuMode : public CMenuMode{
    public:
        /**
         * @brief Makes a new game options menu mode 
         *
         * @param game Game playing
         */
        CGameOptionsMenuMode(CGame* game);
        ~CGameOptionsMenuMode();
        /**
         * @brief Switches to mode clicked, sets game options
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
    private:
        /**
         * @brief Button for going back to map select screen
         */
        CButton* DBackButton;
        /**
         * @brief Button for starting game
         */
        CButton* DContinueButton;
        /**
         * @brief Spinner for setting wind type
         */
        CSpinner* DWindTypeSpinner;
        /**
         * @brief Spinner for setting player color
         */
        CSpinner* DPlayerColorSpinner;
        /**
         * @brief Spinner for setting AI difficulty
         */
        CSpinner* DAIDifficultySpinner;
        /**
         * @brief Map for wind type string name to enum value
         */
        std::map<std::string, CWind::EWindType> DWindTypeMap;
        /**
         * @brief Map for player color string name to enum value
         */
        std::map<std::string, CPlayer::EPlayerColor> DPlayerColorMap;
        /**
         * @brief Map for AI difficulty string name to enum value
         */
        std::map<std::string, CGameState::EAIDifficulty> DAIDifficultyMap;
};

#endif
