#include "NetworkOptionsMenuMode.h"

#include "stdlib.h"
#include "../ui/Spinner.h"
#include "../ui/Button.h"
#include "../ui/Label.h"
#include "../Game.h"
#include "../ui/StackElement.h"
#include "MainMenuMode.h"
#include "OptionsMode.h"
#include "../ui/TextField.h"

CNetworkOptionsMenuMode::CNetworkOptionsMenuMode(CGame* game)
        : CMenuMode("NETWORK OPTIONS"){
    CStackElement* S = new CStackElement();
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2));
    S->Anchor(SDouble2(0.5, 0.5));

    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));

    CLabel* ConnectionStringLabel = new CLabel(game, "SERVER");
    S->AddChildElement(ConnectionStringLabel);

    DConnectionStringField = new CTextField(game,
            game->GameState()->Network()->GetConnectionString());
    DConnectionStringField->Size(SInt2(300, 60));
    S->AddChildElement(DConnectionStringField);

    DRootElement->AddChildElement(S);
    DRootElement->AddChildElement(DBackButton);
}

void CNetworkOptionsMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->GameState()->Network()->SetConnectionString(DConnectionStringField->TextEntered());
        game->SwitchMode(new COptionsMode(game));
    }
    
}
