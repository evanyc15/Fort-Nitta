#ifndef MAPSELECTMENUMODE_H
#define MAPSELECTMENUMODE_H

#include "MenuMode.h"
#include <vector>

class CGame;
class CButton;
class CLabel;
class CStackElement;

/**
 * @brief Mode where user selects a map
 */
class CMapSelectMenuMode : public CMenuMode{
    public:
        /**
         * @brief Sets up UI and maps 
         *
         * @param game Game playing
         */
        CMapSelectMenuMode(CGame* game, bool multiplayer=false, bool broadcast=false);
        ~CMapSelectMenuMode();
        /**
         * @brief Moves to next mode if map is clicked and sets up based on map
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
        
        virtual void Draw(CGame* game);
    private:
        bool DIsMultiplayer;
        bool DIsBroadcast;
        /**
         * @brief Button for going back to main menu
         */
        CButton* DBackButton;
        /**
         * @brief List of button for each map
         */
        std::vector<CButton* > DMaps;
        /**
         * @brief The number of players supported by hovered map
         */
        CLabel* PlayerCountLabel;
        /**
         * @brief The size of hovered map
         */
        CLabel* SizeLabel;
        /**
         * @brief Drawing the selected map preview
         */
         void UpdateMiniMap(CGame* game);
         /**
          * @brief Position of the Map Select Buttons
          */
          SInt2 DText;
          /**
           * @brief Index of the minimap to be drawn
           * -1 Indicates that there is no minimap to be drawn
           */
         int DMapIndex;
         /**
          * @brief Position of the Mini Map
          */
         SInt2 DMini;
         /**
          * @brief This contains the Map Size and number of players
          */
         CStackElement* DMapInfo;
         /**
          * @brief This displays the Size of the highlighted map
          */
         CLabel* DMapSize;
        /**
          * @brief This displays the Number of Players of the highlighted map
          */
         CLabel* DNumPlayers;
};

#endif
