#include "OptionsMode.h"

#include "../ui/Button.h"
#include "../ui/Label.h"
#include "../Game.h"
#include "../ui/StackElement.h"
#include "MainMenuMode.h"
#include "SoundOptionsMenuMode.h"
#include "NetworkOptionsMenuMode.h"

COptionsMode::COptionsMode(CGame* game)
        : CMenuMode("OPTIONS"){
    CStackElement* S = new CStackElement();
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2));
    S->Anchor(SDouble2(0.5, 0.5));

    CButton* M2 = new CButton(game, "SOUND");
    DOptions.push_back(M2);
    S->AddChildElement(M2);
    DRootElement->AddChildElement(S);

    CButton* M3 = new CButton(game, "NETWORK");
    DOptions.push_back(M3);
    S->AddChildElement(M3);
    DRootElement->AddChildElement(S);

    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));
    DRootElement->AddChildElement(DBackButton);

  }

void COptionsMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->SwitchMode(new CMainMenuMode(game));
    }
    //if sound option is pressed
    if(DOptions[0]->IsPressed()){
        game->SwitchMode(new CSoundOptionsMenuMode(game));
    }

    //if network option is pressed
    if(DOptions[1]->IsPressed()){
        game->SwitchMode(new CNetworkOptionsMenuMode(game));
    }

}
