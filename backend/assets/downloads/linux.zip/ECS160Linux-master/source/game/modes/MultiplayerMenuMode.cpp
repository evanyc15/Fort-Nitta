#include "MultiplayerMenuMode.h"

#include "../Game.h"
#include "../ui/Button.h"
#include "MainMenuMode.h"
#include "../ui/StackElement.h"
#include "../ui/Label.h"
#include "CreateRoomMenuMode.h"

std::ofstream Logupdate("Logupdate.txt", std::ofstream::app);

CMultiplayerMenuMode::CMultiplayerMenuMode(CGame* game)
        : CMenuMode("MULTIPLAYER"){
    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));

    DResponseLabel = new CLabel(game, "");
    DResponseLabel->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT));
    DResponseLabel->Anchor(SDouble2(0.5, 1));

    DCreateRoomButton = new CButton(game, "CREATE");
    DCreateRoomButton->Position(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DCreateRoomButton->Anchor(SDouble2(1, 1));

    DRooms = new CStackElement();
    DRooms->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DRooms->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2));
    DRooms->Anchor(SDouble2(0.5, 0.5));

    DRootElement->AddChildElement(DResponseLabel);
    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(DCreateRoomButton);
    DRootElement->AddChildElement(DRooms);

    DUpButton = new CButton(game, "-", MP_MENU_MARGIN);
    DUpButton->Position(SInt2(350, 70));
    DDownButton = new CButton(game, "+", MP_MENU_MARGIN);
    DDownButton->Position(SInt2(350, 170));
}

void CMultiplayerMenuMode::Enter(CGame* game){
    game->GameState()->Network()->GetAvailableRooms();
}

void CMultiplayerMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DResponseTimer-- < 0 && DResponseLabel->Text().length() > 0) {
        DResponseLabel->Text("");
    }
    if(DBackButton->IsPressed()){
        game->SwitchMode(new CMainMenuMode(game));
        game->GameState()->Network()->Disconnect();
    }
    if(DCreateRoomButton->IsPressed()){
        game->SwitchMode(new CCreateRoomMenuMode(game));
    }
    for(std::vector<CButton*>::iterator it = DAvailableRooms.begin();
            it != DAvailableRooms.end();
            it++){
        CButton* Button = *it;
        if(Button->IsPressed()){
            Logupdate << "Calling joinRoom \n";
            Logupdate.flush();
            Logupdate << "Joining room: " << Button->Text() << "\n";
            game->GameState()->Network()->JoinRoom(Button->Text());
        }
    }
    if(DUpButton->IsPressed()){
        if(0 > --DStartingIndex){
            DStartingIndex = DAvailableRoomsList.size() - 1;
        }   
        ChangeListView();
    }
    if(DDownButton->IsPressed()){
        DStartingIndex = ++DStartingIndex % DAvailableRoomsList.size();     
        ChangeListView();
    }
}

void CMultiplayerMenuMode::SetResponseText(std::string text) {
    DResponseLabel->Text(text);
    DResponseTimer = 30;
}

void CMultiplayerMenuMode::UpdateAvailableRooms(CGame* game, std::vector<CRoom*> rooms){
    DAvailableRooms.clear();
    DAvailableRoomsList.clear();
    DRooms->ClearChildren();
    Logupdate << "Number of Rooms received:" << rooms.size() << "rooms.\n";
    Logupdate.flush();
    for(CRoom* room : rooms){
        Logupdate << "Length of name: " << room->Name().size() << "\n";
        Logupdate << room->Name() << "\n";
        Logupdate.flush();
        DAvailableRoomsList.push_back(room->Name());
    }
    if (MAX_LIST_SIZE < rooms.size()){
        DRootElement->AddChildElement(DUpButton);
        DRootElement->AddChildElement(DDownButton);
        for (int i = 0; i < MAX_LIST_SIZE; i++){
            DAvailableRooms.push_back(new CButton(game, "", MP_MENU_MARGIN));
            DRooms->AddChildElement(DAvailableRooms.back());
        }
        DStartingIndex = 0;
        ChangeListView();
    }else{
        for(std::vector<CRoom*>::iterator it = rooms.begin();
                it != rooms.end();
                it++){
            DAvailableRooms.push_back(new CButton(game, (*it)->Name(), MP_MENU_MARGIN));
            DRooms->AddChildElement(DAvailableRooms.back());
        }
    }
}

void CMultiplayerMenuMode::ChangeListView(){
    int Index = DStartingIndex;
    for(int i = 0; i < DAvailableRooms.size(); i++){
        DAvailableRooms[i]->Text(DAvailableRoomsList[Index]);
        Index = ++Index % DAvailableRoomsList.size();
    }
}
