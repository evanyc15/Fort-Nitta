#ifndef REBUILDMODE_H
#define REBUILDMODE_H

#include "MapMode.h"

/**
 * @brief Mode where players build walls to surround castles 
 */
class CRebuildMode : public CMapMode{
    public:
        /**
         * @brief Sets up timer and updates surrounded castles
         *
         * @param game Game entering
         */
        virtual void Enter(CGame* game);
        /**
         * @brief Places and rotates walls, and updates surrounded castles. Moves on to next mode
         *        depending if there is a winner or not
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the 2D game and wall shape cursors for each player
         *
         * @param game Game drawing
         */
        virtual void Draw(CGame* game);

        /**
         * @brief Update surrounded castles
         *
         * @param game Game updating
         */
        virtual void WillEnter(CGame* game);
    protected:
        /**
         * @brief Updates which castles are surrounded and updates the construction map
         *
         * @param game Game updating
         */
        void CheckSurroundedCastles(CGame* game);
        /**
         * @brief Used when checking surrounded castles
         *
         * @param game Game updating
         * @param xpos X position to expand
         * @param ypos Y position to expand
         */
        void ExpandUnclaimed(CGame* game, int xpos, int ypos);
};

#endif
