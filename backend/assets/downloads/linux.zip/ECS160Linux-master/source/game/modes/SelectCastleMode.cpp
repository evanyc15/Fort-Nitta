#include "SelectCastleMode.h"
#include "../Game.h"
#include "../players/Player.h"
#include "CannonPlacementMode.h"
#include "BannerTransitionMode.h"

CSelectCastleMode::CSelectCastleMode(){
}

CSelectCastleMode::~CSelectCastleMode(){
}

void CSelectCastleMode::Update(CGame* game){
    bool AllCastlesPlaced = true;
    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        CPlayer* Player = *it;

        if(!Player->DPlacedHomeCastle
                && Player->ShouldTakePrimaryAction(game)){
            Player->PlaceHomeCastle(game, Player->DHoveredCastle);
        }

        if(Player->DPlacedHomeCastle){
            Player->DHoveredCastle = NULL;
        }else{
            Player->UpdateHoveredCastle(game);
        }

        AllCastlesPlaced &= Player->DPlacedHomeCastle;
    }

    if(AllCastlesPlaced){
        game->SwitchMode(new CBannerTransitionMode(
                    game, "PLACE CANNONS",
                    this, new CCannonPlacementMode()));
    }
    
    CMapMode::Update(game);
}

void CSelectCastleMode::Draw(CGame* game){
    CMapMode::Draw2D(game);
    CMapMode::Draw(game);
    CMapMode::DrawTargetCursors(game);
}
