#ifndef GAMEMODE_H
#define GAMEMODE_H

#include "../../types/Int2.h"
#include "../animations/Animation.h"
#include "vector"

class CGame;

/**
 * @brief A mode that the game can be in that updates and draws the game
 */
class CGameMode{
    public:
        /**
         * @brief Resets the timer
         *
         * @param game The game to reset
         */
        virtual void Enter(CGame* game);
        /**
         * @brief Updates the players, cannonballs, animations, and timer
         *
         * @param game The game to update
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the timer
         *
         * @param game The game to draw
         */
        virtual void Draw(CGame* game);
        /**
         * @brief Does nothing
         *
         * @param game Game to leave
         */
        virtual void Leave(CGame* game);
        /**
         * @brief Does nothing
         *
         * @param game Game to enter
         */
        virtual void WillEnter(CGame* game);

    protected:
        /**
         * @brief Draws the animations
         *
         * @param game The game to draw
         *
         * @param position The current position in draw loop
         */
        void DrawAnimations(CGame* game, SInt2 position);
        /**
         * @brief Draws the cannonballs
         *
         * @param game The game to draw
         *
         * @param position The cannonballs position
         */
        void DrawCannonballs(CGame* game, SInt2 position);
        /**
         * @brief Draws the floor tiles of main player to cover the specified area
         *
         * @param game Game to draw
         * @param size Size to cover
         */
        void DrawTextBackgroundFrame(CGame* game, SInt2 size);
        /**
         * @brief Draws the brick border for text
         *
         * @param game Game to draw
         * @param position Position of top left
         * @param size Size of border
         */
        void DrawBrickFrame(CGame* game, SInt2 position, SInt2 size);
        /**
         * @brief Draws the mortar for text
         *
         * @param game Game to draw
         * @param position Position of top left
         * @param size Size of border
         */
        void DrawMortar(CGame* game, SInt2 position, SInt2 size);
        /**
         * @brief Draws the outline on the brick for border
         *
         * @param game Game to draw
         * @param position Position of top left
         * @param size Size of border
         */
        void DrawBrickOutline(CGame* game, SInt2 position, SInt2 size);

        /**
         * @brief Draws the player cursors using the target tileset
         *
         * @param game The game drawing
         */
        void DrawTargetCursors(CGame* game);
};

#endif
