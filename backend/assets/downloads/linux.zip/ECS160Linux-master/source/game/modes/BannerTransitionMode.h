#ifndef BANNERTRANSITIONMODE_H
#define BANNERTRANSITIONMODE_H

#include "MenuMode.h"
#include <string>

class CUIElement;
class CGame;
class CStackElement;

/**
 * @brief A mode that shows a banner that falls across the screen and then goes to the next mode
 *        and performs a seamless transition
 */
class CBannerTransitionMode : public CMenuMode{
    public:
        /**
         * @brief Creates a new transition with the specified title and game modes transitioning from and to
         *
         * @param game Game transitioning
         * @param title The message to show on the banner
         * @param previous The game mode coming from
         * @param next The game mode going to
         */
        CBannerTransitionMode(CGame* game, std::string title, CGameMode* previous, CGameMode* next);
        /**
         * @brief Cleans up the previous working pixmap
         *
         * @param game The game leaving
         */
        virtual void Leave(CGame* game);
        /**
         * @brief Moves the banner down and switches to next mode if banner has passed screen
         *
         * @param game The game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the banner, the previous mode's frame, and the next mode's frame to provide a seamless transition
         *
         * @param game The game drawing in
         */
        virtual void Draw(CGame* game);
        /**
         * @brief Sets up the rendering pixmaps necessary and caches the banner and previous mode
         *
         * @param game The game entering
         */
        virtual void Enter(CGame* game);
    protected:
        /**
         * @brief Pointer to previous mode transitioning from
         */
        CGameMode* DPreviousGameMode;
        /**
         * @brief Pointer to mode that will be switched to after transition
         */
        CGameMode* DNextGameMode;
        /**
         * @brief The position of the banner on screen
         */
        int DBannerPosition;
        /**
         * @brief The message in banner of the transition
         */
        std::string DTitle;
        /**
         * @brief Draws the banner during the caching of the message
         *
         * @param game The game to draw in
         */
        void DrawBanner(CGame* game);
        /**
         * @brief Caches the banner into its pixmap to improve performance
         *
         * @param game The game to cache in
         */
        void CacheBanner(CGame* game);
        /**
         * @brief Caches a frame from the previous mode to improve performance
         *
         * @param game The game to cache in
         */
        void CachePreviousMode(CGame* game);
        /**
         * @brief The element used to layout the banner
         */
        CStackElement* DStackElement;

};

#endif
