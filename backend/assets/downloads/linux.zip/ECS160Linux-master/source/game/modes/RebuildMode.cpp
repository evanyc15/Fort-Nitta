#include "RebuildMode.h"

#include "../Game.h"
#include "../../util/TimeUtil.h"
#include "CannonPlacementMode.h"
#include "GameOverMode.h"
#include "BannerTransitionMode.h"
#include "../sounds/Sounds.h"

void CRebuildMode::Enter(CGame* game){
    CheckSurroundedCastles(game);
    CMapMode::Enter(game);
    CTimer& Timer = game->GameState()->DTimer;
    Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(15);
    Timer.DIsVisible = true;
    Timer.DIsAudible = true;
    game->Resources()->DSounds->SwitchSong(CSounds::ESongType::stRebuild, 1.0);
}

void CRebuildMode::Update(CGame* game){
    CMapMode::Update(game);

    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        CPlayer* Player = *it;
        if(Player->ShouldTakePrimaryAction(game)){
            if(Player->TryToPlaceWall(game, Player->DCursorTilePosition)){
                Player->DWallShape.Randomize(Player->DRandomNumberGenerator.Random());
            }
        }
	else if(Player->DIsAI)
	{
	if(Player->TryToPlaceWall(game, Player->DCursorTilePosition)){
        Player->DWallShape.Randomize(game->GameState()->DRandomNumberGenerator.Random());
            }
	}
        if(Player->ShouldTakeSecondaryAction(game)){
            Player->RotateWall(game);
        }
	
    }

    CheckSurroundedCastles(game);

    if(CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0){
        int LivingPlayers = game->GameState()
            ->GetPlayersWithOwnedCastles(game).size();
        if(LivingPlayers == 0){
            game->SwitchMode(new CRebuildMode());
        }else if(LivingPlayers == 1) {
            if(!game->GameState()->DRoom.DIsMultiplayer
                    || game->GameState()->DRoom.DIsOwnedByLocalUser){
                game->SwitchMode(new CGameOverMode());
            }
        }else{
            game->SwitchMode(new CBannerTransitionMode(game, "PLACE CANNONS",
                        this, new CCannonPlacementMode()));
        }
    }
}

void CRebuildMode::Draw(CGame* game){
    CMapMode::Draw2D(game);
    CMapMode::Draw(game);

    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        CPlayer* Player = *it;
        Player->DWallShape.Draw(game, Player, Player->DCursorTilePosition);
    }
}

void CRebuildMode::WillEnter(CGame* game){
    CheckSurroundedCastles(game);
}

void CRebuildMode::CheckSurroundedCastles(CGame* game){
    CTerrainMap* TerrainMap = game->GameState()->TerrainMap();
    CConstructionMap* ConstructionMap = game->GameState()->ConstructionMap();
    // Check surrounding
    for(int YPos = 0; YPos < TerrainMap->Height(); YPos++){
        for(int XPos = 0; XPos < TerrainMap->Width(); XPos++){
            if(!(ConstructionMap->Tiles()[YPos][XPos].IsWall())){
                if((ConstructionMap->Tiles()[YPos][XPos].IsFloorDamaged() || ConstructionMap->Tiles()[YPos][XPos].IsGroundDamaged())){
                    switch(TerrainMap->TileType(XPos, YPos)){
                        case CPlayer::pcBlue:    ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttBlueFloorDamaged;
                                        break;
                        case CPlayer::pcRed:     ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttRedFloorDamaged;
                                        break;
                        case CPlayer::pcYellow:  ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttYellowFloorDamaged;
                                        break;
                        default:        ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttNone;
                                        break;
                    }
                }     
                else{
                    switch(TerrainMap->TileType(XPos, YPos)){
                        case CPlayer::pcBlue:    ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttBlueFloor;
                                        break;
                        case CPlayer::pcRed:     ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttRedFloor;
                                        break;
                        case CPlayer::pcYellow:  ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttYellowFloor;
                                        break;
                        default:        ConstructionMap->DTiles[YPos][XPos].DType = CConstructionTile::cttNone;
                                        break;
                    }
                }
            }
        }
    }
    for(int YPos = 0; YPos < TerrainMap->Height(); YPos++){
        for(int XPos = 0; XPos < TerrainMap->Width(); XPos++){
            if(!(ConstructionMap->Tiles()[YPos][XPos].IsWall())){
                if(0 == XPos){
                    ExpandUnclaimed(game, XPos, YPos);
                }
                else if(0 == YPos){
                    ExpandUnclaimed(game, XPos, YPos); 
                }
                else if(XPos + 1 == TerrainMap->Width()){
                    ExpandUnclaimed(game, XPos, YPos);   
                }
                else if(YPos + 1 == TerrainMap->Height()){
                    ExpandUnclaimed(game, XPos, YPos);    
                }
                else if(CConstructionTile::cttNone == ConstructionMap->Tiles()[YPos][XPos].DType){
                    ExpandUnclaimed(game, XPos, YPos);    
                }
            }
        }
    }

    for(std::vector<Castle>::iterator it = TerrainMap->Castles().begin();
            it != TerrainMap->Castles().end();
            it++){
        it->DSurrounded = ConstructionMap->GetTileAt(it->IndexPosition()).IsFloor();
    }
}

void CRebuildMode::ExpandUnclaimed(CGame* game, int xpos, int ypos){
    CTerrainMap* TerrainMap = game->GameState()->TerrainMap();
    CConstructionMap* ConstructionMap = game->GameState()->ConstructionMap();
    bool NValid, EValid, SValid, WValid;
    
    if((ConstructionMap->Tiles()[ypos][xpos].IsGroundDamaged())){
        ConstructionMap->Tiles()[ypos][xpos].DType = CConstructionTile::cttGroundDamaged;
    }
    else{
        ConstructionMap->Tiles()[ypos][xpos].DType = CConstructionTile::cttNone;
    }
    NValid = 0 < ypos;
    WValid = 0 < xpos;
    SValid = ypos + 1 < TerrainMap->Height();
    EValid = xpos + 1 < TerrainMap->Width();
    
    if(NValid){
        if(WValid){
            if((ConstructionMap->Tiles()[ypos-1][xpos-1].IsFloor())||(ConstructionMap->Tiles()[ypos-1][xpos-1].IsFloorDamaged())){
                ExpandUnclaimed(game, xpos-1, ypos-1);
            }
        }
        if((ConstructionMap->Tiles()[ypos-1][xpos].IsFloor())||(ConstructionMap->Tiles()[ypos-1][xpos].IsFloorDamaged())){
            ExpandUnclaimed(game, xpos, ypos-1);
        }
        if(EValid){
            if((ConstructionMap->Tiles()[ypos-1][xpos+1].IsFloor())||(ConstructionMap->Tiles()[ypos-1][xpos+1].IsFloorDamaged())){
                ExpandUnclaimed(game, xpos+1, ypos-1);
            }
        }
    }
    if(WValid){
        if((ConstructionMap->Tiles()[ypos][xpos-1].IsFloor())||(ConstructionMap->Tiles()[ypos][xpos-1].IsFloorDamaged())){
            ExpandUnclaimed(game, xpos-1, ypos);
        }
    }
    if(EValid){
        if((ConstructionMap->Tiles()[ypos][xpos+1].IsFloor())||(ConstructionMap->Tiles()[ypos][xpos+1].IsFloorDamaged())){
            ExpandUnclaimed(game, xpos+1, ypos);
        }
    }
    if(SValid){
        if(WValid){
            if((ConstructionMap->Tiles()[ypos+1][xpos-1].IsFloor())||(ConstructionMap->Tiles()[ypos+1][xpos-1].IsFloorDamaged())){
                ExpandUnclaimed(game, xpos-1, ypos+1);
            }
        }
        if((ConstructionMap->Tiles()[ypos+1][xpos].IsFloor())||(ConstructionMap->Tiles()[ypos+1][xpos].IsFloorDamaged())){
            ExpandUnclaimed(game, xpos, ypos+1);
        }
        if(EValid){
            if((ConstructionMap->Tiles()[ypos+1][xpos+1].IsFloor())||(ConstructionMap->Tiles()[ypos+1][xpos+1].IsFloorDamaged())){
                ExpandUnclaimed(game, xpos+1, ypos+1);
            }
        }
    }
}

