#include "MenuMode.h"

#include "../ui/UIElement.h"
#include "../Game.h"
#include "../sounds/Sounds.h"

CMenuMode::CMenuMode(std::string title){
    DTitle = title;
    DRootElement = new CUIElement();
}

CMenuMode::~CMenuMode(){
    delete DRootElement;
}

void CMenuMode::Enter(CGame* game) {
    CGameMode::Enter(game);
    game->Resources()->DSounds->SwitchSong(CSounds::ESongType::stMenu, 1.0);
}

void CMenuMode::Update(CGame* game){
    CGameMode::Update(game);
    DRootElement->Update(game); 
    game->InputState()->UpdateSelectedElement(DRootElement);
}

void CMenuMode::Draw(CGame* game){
    DrawMenuBackground(game, SInt2(GAME_WIDTH, GAME_HEIGHT));
    DrawTitle(game);
    DRootElement->Draw(game);
    CTargetTileset& Tileset = game->Resources()->DTilesets->DTargetTileset;
    Tileset.DrawTargetTile(game,
            game->InputState()->DMousePosition
                - SInt2(Tileset.TileWidth(), Tileset.TileHeight())/2,
            CPlayer::pcBlue);
}

void CMenuMode::DrawTitle(CGame* game){
    CFontTileset& BlackFont = game->Resources()->DTilesets->DBlackFont;
    CBrickTileset& Bricks = game->Resources()->DTilesets->DBrickTileset;
    CWallFloorTileset& WallFloorTileset = game->Resources()->DTilesets->DWallFloorTileset;

    SInt2 Position, Size, RequiredSize;

    BlackFont.MeasureText(DTitle, Size.DX, Size.DY);

    RequiredSize.DX = Size.DX + (Bricks.TileWidth() * 3) / 2;
    RequiredSize.DX = ((RequiredSize.DX + Bricks.TileWidth() - 1)/Bricks.TileWidth()) * Bricks.TileWidth();
    RequiredSize.DY = Size.DY + 1;
    RequiredSize.DY += Bricks.TileHeight() * 2;
    RequiredSize.DY = ((RequiredSize.DY + Bricks.TileHeight() - 1) / Bricks.TileHeight()) * Bricks.TileHeight();

    for(gint TopPosition = 0, XOffset = (GAME_WIDTH/2) - (RequiredSize.DX/2) - 1; TopPosition + WallFloorTileset.TileHeight() <= RequiredSize.DY; TopPosition += WallFloorTileset.TileHeight()){
        WallFloorTileset.Draw2DFloorTile(game, XOffset, TopPosition, CPlayer::pcNone);
        WallFloorTileset.Draw2DFloorTile(game, XOffset + RequiredSize.DX + 2 - WallFloorTileset.TileWidth(), TopPosition, CPlayer::pcNone);
    }
    for(gint LeftPosition = (GAME_WIDTH/2) - (RequiredSize.DX/2) - 1, YOffset = RequiredSize.DY - WallFloorTileset.TileHeight() + 1; LeftPosition + WallFloorTileset.TileWidth() <= (GAME_WIDTH/2) + (RequiredSize.DX/2) + 1; LeftPosition += WallFloorTileset.TileWidth()){
        WallFloorTileset.Draw2DFloorTile(game, LeftPosition, YOffset, CPlayer::pcNone);
    }
    WallFloorTileset.Draw2DFloorTile(game, (GAME_WIDTH/2) + (RequiredSize.DX/2) + 1 - WallFloorTileset.TileWidth(), RequiredSize.DY - WallFloorTileset.TileHeight() + 1, CPlayer::pcNone);

    DrawBrickFrame(game, SInt2((GAME_WIDTH/2) - (RequiredSize.DX/2), 0), SInt2(RequiredSize.DX, RequiredSize.DY));
    SInt2 TextPosition = SInt2((GAME_WIDTH/2) - (Size.DX/2), (RequiredSize.DY/2) - (Size.DY/2));
    game->Resources()->DTilesets->DBlackFont.DrawText(game, TextPosition + SInt2(1, 1), DTitle);
    game->Resources()->DTilesets->DWhiteFont.DrawText(game, TextPosition, DTitle);
}

void CMenuMode::DrawMenuBackground(CGame* game, SInt2 size){
    CBrickTileset& Bricks = game->Resources()->DTilesets->DBrickTileset;

    for(gint HeightOffset = 0; HeightOffset < size.DY; HeightOffset += 8){
        if(HeightOffset & 0x8){
            for(gint WidthOffset = -(Bricks.TileWidth()/2); WidthOffset < size.DX; WidthOffset += Bricks.TileWidth()){
                Bricks.DrawTile(game, SInt2(WidthOffset, HeightOffset), CBrickTileset::bbtSingle);
            }
        }
        else{
            for(gint WidthOffset = 0; WidthOffset < size.DX; WidthOffset += Bricks.TileWidth()){
                Bricks.DrawTile(game, SInt2(WidthOffset, HeightOffset), CBrickTileset::bbtSingle);
            }            
        }
    }
    DrawBrickFrame(game, SInt2(), size);    
}

