#include "MainMenuMode.h"

#include <string>
#include <vector>

#include "stdlib.h"
#include "../ui/Button.h"
#include "../ui/Spinner.h"
#include "../ui/StackElement.h"
#include "../Game.h"
#include "MapSelectMenuMode.h"
#include "LoginMenuMode.h"
#include "OptionsMode.h"


CMainMenuMode::CMainMenuMode(CGame* game)
        : CMenuMode("FORT NITTA"){
    CStackElement* S =new CStackElement();
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2 + 20));
    S->Anchor(SDouble2(0.5, 0.5));

    SInt2 Margin = SInt2(15, 8);

    DSinglePlayerButton = new CButton(game, "SINGLEPLAYER", Margin);
    DSinglePlayerButton->Anchor(SDouble2(0.5, 0));

    DMultiplayerButton = new CButton(game, "MULTIPLAYER", Margin);
    DMultiplayerButton->Anchor(SDouble2(0.5, 0));

    DOptionsButton = new CButton(game, "OPTIONS", Margin);
    DOptionsButton->Anchor(SDouble2(0.5, 0));

    DExitButton = new CButton(game, "EXIT", Margin);
    DExitButton->Anchor(SDouble2(0.5, 0));

     //test spinner element
    // std::vector<std::string> options;
    // options.push_back("None");
    // options.push_back("Mild");
    // options.push_back("Moderate");
    // options.push_back("Erratic");
    // DTestOptions = new CSpinner(game, "WIND TYPE", &options);
    //S->AddChildElement(DTestOptions);
    // DTestOptions = new CSpinner(game, "WIND TYPE", &options, DEFAULT_LABEL_MARGIN);
    //S->AddChildElement(DTestOptions);

    S->AddChildElement(DSinglePlayerButton);
    S->AddChildElement(DMultiplayerButton);
    S->AddChildElement(DOptionsButton);
    S->AddChildElement(DExitButton);
    //S->AddChildElement(DTestOptions);
    DRootElement->AddChildElement(S);
}

void CMainMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DSinglePlayerButton->IsPressed()){
        game->SwitchMode(new CMapSelectMenuMode(game));
    }
    if(DMultiplayerButton->IsPressed()){
        game->SwitchMode(new CLoginMenuMode(game));
    }
    if(DOptionsButton->IsPressed()){
        game->SwitchMode(new COptionsMode(game));
    }
    if(DExitButton->IsPressed()){   
        exit(0);
    }
}


