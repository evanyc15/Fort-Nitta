#ifndef LOGIN_MENU_MODE_H
#define LOGIN_MENU_MODE_H

#include "MenuMode.h"
#include <string>

class CGame;
class CButton;
class CLabel;
class CTextField;

class CLoginMenuMode : public CMenuMode{
    public:
        CLoginMenuMode(CGame* game);
        ~CLoginMenuMode();

        virtual void Enter(CGame* game);
        virtual void Update(CGame* game);
    private:
        CButton* DBackButton;
        CButton* DLoginButton;
        CLabel* DUsernameLabel;
        CLabel* DPasswordLabel;
        CTextField* DUsernameField;
        CTextField* DPasswordField;
        CLabel* DResponseLabel;
        CLabel* DErrorLabel;
        std::string DPassword;
};

#endif

