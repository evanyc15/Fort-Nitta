#include "GameOptionsMenuMode.h"

#include <string>
#include <vector>

#include "../ui/Button.h"
#include "../ui/Spinner.h"
#include "../ui/StackElement.h"
#include "../Game.h"
#include "MapSelectMenuMode.h"
#include "SelectCastleMode.h"
#include "BannerTransitionMode.h"
#include "../players/HumanPlayer.h"
#include "../players/AIPlayer.h"

CGameOptionsMenuMode::CGameOptionsMenuMode(CGame* game)
        : CMenuMode("GAME SELECTION"){

    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));

    DContinueButton = new CButton(game, "CONTINUE");
    DContinueButton->Position(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DContinueButton->Anchor(SDouble2(1, 1));

    CStackElement* S = new CStackElement();
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Position(SInt2(GAME_WIDTH - 50, GAME_HEIGHT/2));
    S->Anchor(SDouble2(1, 0.5));

    int LongestHorizontalSize = 0;

    std::vector<std::string> options;
    options.push_back("None");
    options.push_back("Mild");
    options.push_back("Moderate");
    options.push_back("Erratic");
    DWindTypeSpinner = new CSpinner(game, "WIND TYPE", &options);
    DWindTypeSpinner->Anchor(SDouble2(0.5, 0));
    LongestHorizontalSize = std::max(DWindTypeSpinner->LongestHorizontalSize(),
            LongestHorizontalSize);

    options.clear();
    options.push_back("Blue");
    options.push_back("Red");
    DPlayerColorSpinner = new CSpinner(game, "PLAYER COLOR", &options);
    DPlayerColorSpinner->Anchor(SDouble2(0.5, 0));
    LongestHorizontalSize = std::max(DPlayerColorSpinner->LongestHorizontalSize(),
            LongestHorizontalSize);

    options.clear();
    options.push_back("Easy");
    options.push_back("Normal");
    options.push_back("Hard");
    options.push_back("Insane");
    DAIDifficultySpinner = new CSpinner(game, "AI DIFFICULTY", &options);
    DAIDifficultySpinner->Anchor(SDouble2(0.5, 0));
    LongestHorizontalSize = std::max(DAIDifficultySpinner->LongestHorizontalSize(),
            LongestHorizontalSize);

    DWindTypeSpinner->LongestHorizontalSize(LongestHorizontalSize);
    DWindTypeSpinner->LayoutElements();
    DPlayerColorSpinner->LongestHorizontalSize(LongestHorizontalSize);
    DPlayerColorSpinner->LayoutElements();
    DAIDifficultySpinner->LongestHorizontalSize(LongestHorizontalSize);
    DAIDifficultySpinner->LayoutElements();

    S->AddChildElement(DWindTypeSpinner);
    S->AddChildElement(DPlayerColorSpinner);
    S->AddChildElement(DAIDifficultySpinner);

    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(DContinueButton);
    DRootElement->AddChildElement(S);

    DWindTypeMap["None"] = CWind::wtNone;
    DWindTypeMap["Mild"] = CWind::wtMild;
    DWindTypeMap["Moderate"] = CWind::wtModerate;
    DWindTypeMap["Erratic"] = CWind::wtErratic;

    DPlayerColorMap["Blue"] = CPlayer::pcBlue;
    DPlayerColorMap["Red"] = CPlayer::pcRed;

    DAIDifficultyMap["Easy"] = CGameState::aiEasy;
    DAIDifficultyMap["Normal"] = CGameState::aiNormal;
    DAIDifficultyMap["Hard"] = CGameState::aiHard;
    DAIDifficultyMap["Insane"] = CGameState::aiInsane;
}

void CGameOptionsMenuMode::Update(CGame* game){
    CMenuMode::Update(game);
    if (DBackButton->IsPressed()){
        game->SwitchMode(new CMapSelectMenuMode(game));
    }
    if (DContinueButton->IsPressed()){

        CPlayer* Player = new CHumanPlayer();
        Player->DColor = DPlayerColorMap[DPlayerColorSpinner->SelectedOption()];
        game->GameState()->DPlayers.push_back(Player);

        Player = new CAIPlayer(game);
        Player->DColor = DPlayerColorMap[DPlayerColorSpinner->SelectedOption()] == CPlayer::pcRed ?
                CPlayer::pcBlue : CPlayer::pcRed;
        game->GameState()->DPlayers.push_back(Player);

        game->GameState()->SetAIDifficulty(DAIDifficultyMap[DAIDifficultySpinner->SelectedOption()]);

       // TODO: set wind type in GameState
        game->GameState()->DWind.DWindType = DWindTypeMap[DWindTypeSpinner->SelectedOption()];

        game->SwitchMode(new CBannerTransitionMode(
                    game, "SELECT CASTLE",
                    this, new CSelectCastleMode()));
    }
}


