#ifndef MAIN_MENU_MODE_H
#define MAIN_MENU_MODE_H

#include "MenuMode.h"

class CGame;
class CButton;
class CSpinner;

/**
 * @brief Mode with menu including single player, multiplayer, and options
 */
class CMainMenuMode : public CMenuMode{
    public:
        /**
         * @brief Makes a new main menu mode with options
         *
         * @param game Game playing
         */
        CMainMenuMode(CGame* game);
        ~CMainMenuMode();
        /**
         * @brief Switches to mode clicked
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
    private:
        /**
         * @brief Button for single player mode
         */
        CButton* DSinglePlayerButton;
        CButton* DMultiplayerButton;
        CButton* DOptionsButton;
        CButton* DExitButton;
        //CSpinner* DTestOptions;
};

#endif
