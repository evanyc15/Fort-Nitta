#include "SoundOptionsMenuMode.h"

#include "stdlib.h"
#include "../ui/Spinner.h"
#include "../ui/Button.h"
#include "../ui/Label.h"
#include "../Game.h"
#include "../ui/StackElement.h"
#include "MainMenuMode.h"
#include "OptionsMode.h"

CSoundOptionsMenuMode::CSoundOptionsMenuMode(CGame* game)
        : CMenuMode("SOUND OPTIONS"){
    CStackElement* S = new CStackElement();
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2));
    S->Anchor(SDouble2(0.5, 0.5));

    std::vector<std::string> options;
    options.push_back("0");
    options.push_back("1");
    options.push_back("2");
    options.push_back("3");
    options.push_back("4");
    options.push_back("5");
    Volume = new CSpinner(game, "VOLUME", &options, DEFAULT_LABEL_MARGIN);
    S->AddChildElement(Volume);
    DRootElement->AddChildElement(S);

    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));
    DRootElement->AddChildElement(DBackButton);


}

void CSoundOptionsMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->SwitchMode(new COptionsMode(game));
    }

    //TODO: set volume
    
}
