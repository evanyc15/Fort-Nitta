#ifndef GAMEOVERMODE_H
#define GAMEOVERMODE_H

#include "MapMode.h"

class CUIElement;
class CStackElement;

/**
 * @brief Mode that shows who won
 */
class CGameOverMode : public CMapMode{
    public:
        /**
         * @brief Makes a new game over mode and sets up UI
         */
        CGameOverMode(int winner_id=-1);
        /**
         * @brief Layouts the message and sets up the message rendering
         *
         * @param game The game entering
         */
        virtual void Enter(CGame* game);
        /**
         * @brief Cleans up the message rendering
         *
         * @param game The game leaving
         */
        virtual void Leave(CGame* game);
        /**
         * @brief Moves back to main menu if main player clicks
         *
         * @param game The game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the 3D map and the message
         *
         * @param game The game drawing
         */
        virtual void Draw(CGame* game);
    protected:
        /**
         * @brief Stores the winner from multiplayer mode
         */
        int DWinnerID;
        /**
         * @brief Caches the message into the message pixmap
         *
         * @param game The game to cache for
         */
        void CacheMessage(CGame* game);
        /**
         * @brief Draws the message
         *
         * @param game The game drawing
         */
        void DrawMessage(CGame* game);
        /**
         * @brief The root UI element used to draw message
         */
        CUIElement* DRootElement; 
        /**
         * @brief The element used to stack the labels for the message
         */
        CStackElement* DStackElement;
};

#endif
