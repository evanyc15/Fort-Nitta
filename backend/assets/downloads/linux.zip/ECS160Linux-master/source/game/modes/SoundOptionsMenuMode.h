#ifndef SOUNDOPTIONSMENUMODE_H
#define SOUNDOPTIONSMENUMODE_H

#include "MenuMode.h"
#include "OptionsMode.h"
#include "../ui/Spinner.h"
#include "../sounds/Sounds.h"

class CGame;
class CButton;
class CLabel;

/**
 *  @brief Mode where user edits options
 */
class CSoundOptionsMenuMode : public CMenuMode{
    public:
        CSoundOptionsMenuMode(CGame* game);
        ~CSoundOptionsMenuMode();

        virtual void Update(CGame* game);

    private:
        //@Button for going back to main menu
        CButton* DBackButton;
        //@List of buttons for each option
        std::vector<CButton* > DOptions;
        //@Spinner for volume
        CSpinner* Volume;
};

#endif
