#ifndef ROOM_NAME_MENU_MODE_H
#define ROOM_NAME_MENU_MODE_H

#include "MenuMode.h"

class CGame;
class CButton;
class CTextField;
class CSpinner;

class CCreateRoomMenuMode : public CMenuMode{
    public:
        CCreateRoomMenuMode(CGame* game);
        ~CCreateRoomMenuMode();

        virtual void Update(CGame* game);
    private:
        CButton* DBackButton;
        CButton* DNextButton;
        CTextField* DRoomNameField;
        CSpinner* DTypeSpinner;
};

#endif
