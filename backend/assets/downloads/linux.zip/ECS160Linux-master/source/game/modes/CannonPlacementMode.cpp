#include "CannonPlacementMode.h"
#include "../Game.h"
#include "../players/Player.h"
#include "../../util/TimeUtil.h"
#include "MainMenuMode.h"
#include "BattleMode.h"
#include "BannerTransitionMode.h"
#include "../animations/PlumeAnimation.h"

void CCannonPlacementMode::Enter(CGame* game){
    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        (*it)->DAvailableCannons = 0;
    }
    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        (*it)->DAvailableCannons += (*it)->OwnedCastleCount(game) + (*it)->DExtraCannons;
        (*it)->DExtraCannons = 0;
    }
    CTimer& Timer = game->GameState()->DTimer;
    Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(15);
    Timer.DIsVisible = true;
    Timer.DIsAudible = true;
    game->Resources()->DSounds->SwitchSong(CSounds::ESongType::stPlace, 1.0);
}

void CCannonPlacementMode::Update(CGame* game){
    bool AllCannonsPlaced = true;
    std::vector<CPlayer*>& Players = game->GameState()->DPlayers;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        CPlayer* Player = *it;
        if(Player->ShouldTakePrimaryAction(game)){
            Player->TryToPlaceCannon(game, Player->DCursorTilePosition);
        }
        else if(Player-> DIsAI){
            Player->TryToPlaceCannon(game, Player->DCursorTilePosition);
        }
        AllCannonsPlaced &= Player->DAvailableCannons == 0;
    }
    if(AllCannonsPlaced || CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0){
        game->SwitchMode(new CBannerTransitionMode(game, "PREPARE FOR BATTLE", this, new CBattleMode()));

    }
    CMapMode::Update(game);
}

void CCannonPlacementMode::Draw(CGame* game){
    CMapMode::Draw2D(game);
    CMapMode::Draw(game);
    CTerrainMap* Map = game->GameState()->TerrainMap();

    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        if((*it)->DAvailableCannons > 0){
            game->Resources()->DTilesets->D2DCastleCannonTileset.Draw2DCannonToPlaceTile(game,
                    Map->ConvertToScreenPosition((*it)->DCursorTilePosition),
                    (*it)->DColor, (*it)->DAvailableCannons);
        }
    }

}
