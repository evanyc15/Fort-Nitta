#include "RoomMenuMode.h"

#include "../Game.h"
#include "../ui/Label.h"
#include "../ui/StackElement.h"
#include "MultiplayerMenuMode.h"
#include "../ui/Button.h"
#include "../players/Player.h"

CRoomMenuMode::CRoomMenuMode(CGame* game)
        : CMenuMode("ROOM"){
    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));
    
    DStartRoomButton = new CButton(game, "START GAME");
    DStartRoomButton->Position(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DStartRoomButton->Anchor(SDouble2(1, 1));

    CLabel* PlayerLabel = new CLabel(game, "PLAYERS");
    PlayerLabel->Position(SInt2(0, 60));
    DRootElement->AddChildElement(PlayerLabel);

    DPlayers = new CStackElement();
    DPlayers->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DPlayers->Position(SInt2(0, 100));
    DPlayers->Anchor(SDouble2(0, 0));

    DSpectators = new CStackElement();
    if(game->GameState()->DRoom.DIsBroadcast) {
        CLabel* SpectatorLabel = new CLabel(game, "SPECTATORS");
        SpectatorLabel->Position(SInt2(GAME_WIDTH, 60));
        SpectatorLabel->Anchor(SDouble2(1, 0));
        DRootElement->AddChildElement(SpectatorLabel);

        DSpectators->Size(SInt2(GAME_WIDTH/2, GAME_HEIGHT));
        DSpectators->Position(SInt2(GAME_WIDTH, 100));
        DSpectators->Anchor(SDouble2(1, 0));
        DRootElement->AddChildElement(DSpectators);
    }

    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(DPlayers);
    if(game->GameState()->DRoom.DIsOwnedByLocalUser){
        DRootElement->AddChildElement(DStartRoomButton);
    }
}

void CRoomMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    CRoom& Room = game->GameState()->DRoom;

    DPlayers->ClearChildren();
    for(std::vector<std::string>::iterator it = Room.DPlayerUsernames.begin();
            it != Room.DPlayerUsernames.end();
            it++){
        if(DPlayerLabels.find(*it) == DPlayerLabels.end()){
            DPlayerLabels[*it] = new CLabel(game, *it, SInt2(20, 5));
        }
        DPlayers->AddChildElement(DPlayerLabels[*it]);
    }
    DSpectators->ClearChildren();
    for(std::vector<std::string>::iterator it = Room.DSpectatorUsernames.begin();
            it != Room.DSpectatorUsernames.end();
            it++){
        if(DSpectatorLabels.find(*it) == DSpectatorLabels.end()){
            DSpectatorLabels[*it] = new CLabel(game, *it, SInt2(20, 5));
        }
        DSpectators->AddChildElement(DSpectatorLabels[*it]);
    }

    if(DBackButton->IsPressed()){
        game->GameState()->Network()->LeaveRoom(Room.Name());
        game->SwitchMode(new CMultiplayerMenuMode(game));
    }

    if(DStartRoomButton->IsPressed()){     
        game->GameState()->TerrainMap(game->Resources()->DTerrainMaps[0]);
        game->GameState()->TerrainMap()->Reset();
        game->GameState()->TerrainMap()->Cache3DMap(game);
        game->GameState()->Network()->StartGame(game->GameState()->TerrainMap()->MapFileData());
    }
}
