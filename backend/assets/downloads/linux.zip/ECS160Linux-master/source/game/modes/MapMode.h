#ifndef MAPMODE_H
#define MAPMODE_H

#include <string>
#include "GameMode.h"
#include "../../types/Int2.h"
#include <sys/time.h>

class CGame;

/**
 * @brief Mode which draws a map
 */
class CMapMode : public CGameMode{
    public:
        CMapMode();
        ~CMapMode();
        /**
         * @brief Same as base class
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws animations and cannonballs
         *
         * @param game Game drawing
         */
        virtual void Draw(CGame* game);
    protected:
        /**
         * @brief Draws the terrain and construction maps in 2D
         *
         * @param game Game drawing
         */
        void Draw2D(CGame* game);
        /**
         * @brief Draws the terrain and construction maps in 3D
         *
         * @param game Game drawing
         */
        void Draw3D(CGame* game);
};

#endif
