#include "GameOverMode.h"

#include "../Game.h"
#include <gtk/gtk.h>
#include "../ui/UIElement.h"
#include "../ui/StackElement.h"
#include "../ui/Label.h"
#include "MainMenuMode.h"

CGameOverMode::CGameOverMode(int winner_id){
    DWinnerID = winner_id;
    DRootElement = new CUIElement();
    DStackElement = new CStackElement();
    DStackElement->Anchor(SDouble2(0.5, 0));
}

void CGameOverMode::Enter(CGame* game){
    CMapMode::Enter(game);

    bool IsMultiplayer = DWinnerID != -1;
    CPlayer* LivingPlayer;
    CPlayer::EPlayerColor PlayerColor;
    if(IsMultiplayer){
        LivingPlayer = game->GameState()->GetPlayerWithColor(CPlayer::GetColorForID(DWinnerID+1));
        PlayerColor = LivingPlayer->DColor;
    }else{
        LivingPlayer = game->GameState()->GetPlayersWithOwnedCastles(game).at(0);
        PlayerColor = game->GameState()->GetMainPlayerColor();
    }

    std::string Message;
    if(CPlayer::pcBlue == PlayerColor){
        Message = "BLUE";
    }else if(CPlayer::pcRed == PlayerColor){
        Message = "RED";                    
    }else{
        Message = "YELLOW";
    }
    CUIElement* S = new CUIElement();
    S->Size(SInt2(0, 20));
    DStackElement->AddChildElement(S);
    CLabel* L = new CLabel(game, Message, SInt2(0, 0), &(game->Resources()->DTilesets->DWhiteFont));
    DStackElement->AddChildElement(L);

    L = new CLabel(game, "ARMY", SInt2(0, 0), &(game->Resources()->DTilesets->DWhiteFont));
    DStackElement->AddChildElement(L);

    if(IsMultiplayer || LivingPlayer->DColor == PlayerColor){
        Message = "CONQUERS";
        game->Resources()->DSounds->SwitchSong(CSounds::ESongType::stWin, 1.0);
    }else{
        game->Resources()->DSounds->SwitchSong(CSounds::ESongType::stLoss, 1.0);
        Message = "DEFEATED";
    }
    L = new CLabel(game, Message, SInt2(22, 0), &(game->Resources()->DTilesets->DWhiteFont));
    DStackElement->AddChildElement(L);

    DStackElement->AddChildElement(S);

    DStackElement->Size(SInt2(L->Size().DX, DStackElement->Size().DY));
    DStackElement->Position(SInt2(DStackElement->Size().DX, 0));

    DRootElement->AddChildElement(DStackElement);

    game->Rendering()->DMessagePixmap = gdk_pixmap_new(game->DrawingArea()->window,
            DStackElement->Size().DX, DStackElement->Size().DY, -1);
    CacheMessage(game); 
}

void CGameOverMode::Leave(CGame* game){
    if(game->Rendering()->DMessagePixmap != NULL){
        g_object_unref(game->Rendering()->DMessagePixmap);
        game->Rendering()->DMessagePixmap = NULL;
    }
}

void CGameOverMode::Update(CGame* game){
    CMapMode::Update(game);

    if(game->GameState()->GetPlayerWithColor(
                game->GameState()->GetMainPlayerColor())
            ->ShouldTakePrimaryAction(game)){
        game->SwitchMode(new CMainMenuMode(game));
    }
}

void CGameOverMode::Draw(CGame* game){
    CRendering* Rendering = game->Rendering();
    CMapMode::Draw3D(game);
    CMapMode::Draw(game);
    gdk_draw_pixmap(Rendering->DWorkingBufferPixmap,
            Rendering->DDrawingContext,
            Rendering->DMessagePixmap,
            0, 0, 
            GAME_WIDTH/2 - DStackElement->Size().DX/2,
            GAME_HEIGHT/2 - DStackElement->Size().DY/2,
            -1, -1);
}

void CGameOverMode::DrawMessage(CGame* game){
    DrawTextBackgroundFrame(game, DStackElement->Size());
    DrawBrickFrame(game, SInt2(0, 0), DStackElement->Size());
    DrawMortar(game, SInt2(0, 0), DStackElement->Size());
    DRootElement->Draw(game);
}

void CGameOverMode::CacheMessage(CGame* game){
    GdkPixmap* OriginalPixmap = game->Rendering()->DWorkingBufferPixmap;
    game->Rendering()->DWorkingBufferPixmap = game->Rendering()->DMessagePixmap;
    DrawMessage(game);
    game->Rendering()->DWorkingBufferPixmap = OriginalPixmap;
}
