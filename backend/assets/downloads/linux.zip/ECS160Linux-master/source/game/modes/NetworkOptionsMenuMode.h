#ifndef NETWORKOPTIONSMENUMODE_H
#define NETWORKOPTIONSMENUMODE_H

#include "MenuMode.h"
#include "OptionsMode.h"

class CGame;
class CButton;
class CLabel;
class CTextField;

/**
 *  @brief Mode where user edits options
 */
class CNetworkOptionsMenuMode : public CMenuMode{
    public:
        CNetworkOptionsMenuMode(CGame* game);
        ~CNetworkOptionsMenuMode();

        virtual void Update(CGame* game);

    private:
        //@Button for going back to main menu
        CButton* DBackButton;
        //@List of buttons for each option
        std::vector<CButton* > DOptions;

        /**
         * @brief The connection string for the network
         */
        CTextField* DConnectionStringField;

};

#endif
