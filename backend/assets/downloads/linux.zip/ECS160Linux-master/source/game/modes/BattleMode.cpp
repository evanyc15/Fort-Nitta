#include "../Game.h"
#include "BattleMode.h"
#include "../players/Player.h"
#include "../../util/TimeUtil.h"
#include "../Cannon.h"
#include "RebuildMode.h"
#include "BannerTransitionMode.h"

void CBattleMode::Enter(CGame* game){
    CMapMode::Enter(game);
    CTimer& Timer = game->GameState()->DTimer;
    Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(1);
    game->Resources()->DSounds->PlaySoundClip(game->Resources()->DSounds->sctReady);
    std::vector<CPlayer*> &Players = game->GameState()->DPlayers;
    for(std::vector<CPlayer*>::iterator it = Players.begin();
            it != Players.end();
            it++){
        (*it)->DReadyCannons.clear();
    }

    std::vector<CCannon*> &Cannons = game->GameState()->ConstructionMap()->Cannons();
    for(std::vector<CCannon*>::iterator it = Cannons.begin();
            it != Cannons.end();
            it++){
        CPlayer* Player = (*it)->GetPlayerOwner(game);
        if(Player != NULL){
            Player->DReadyCannons.push_back(*it);
        }
    }
    DBattleType = 0;
}

void CBattleMode::Update(CGame* game){
   CMapMode::Update(game);
   game->GameState()->DWind.WindUpdate(game->GameState()->DRandomNumberGenerator.Random(),
                                       game->GameState()->DRandomNumberGenerator.Random(),
                                       game->GameState()->DRandomNumberGenerator.Random());
   if (DBattleType == 0){
       if (CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0){
           DBattleType++;
           CTimer& Timer = game->GameState()->DTimer;
           Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(1);
           game->Resources()->DSounds->PlaySoundClip(game->Resources()->DSounds->sctAim);
       }
   } else if (DBattleType == 1){
       if (CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0){
           DBattleType++;
           CTimer& Timer = game->GameState()->DTimer;
           Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(15);
           game->Resources()->DSounds->PlaySoundClip(game->Resources()->DSounds->sctFire);
       }
   } else if(DBattleType == 2){
       for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
           it != game->GameState()->DPlayers.end();
           it++){
           CPlayer* Player = *it;
           if(Player->ShouldTakePrimaryAction(game)
                   && CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) >= 0){
               Player->FireNextCannon(game);
           }else if(Player-> DIsAI && CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) >= 0){
               Player->FireNextCannon(game);
           }
       }
       if(CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0){
            DBattleType++;
            CTimer& Timer = game->GameState()->DTimer;
            Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(2);
            game->Resources()->DSounds->PlaySoundClip(game->Resources()->DSounds->sctCeasefire);
       }
   }else if (DBattleType == 3){
       if(CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0
               && game->GameState()->DCannonballs.size() == 0
               && game->GameState()->DAnimations.size() == 0){
            game->SwitchMode(new CBannerTransitionMode(game, "REBUILD WALLS TO STAY ALIVE",
                                                  this, new CRebuildMode()));
        }
    }
}

void CBattleMode::Draw(CGame* game){
    CMapMode::Draw3D(game);
    CMapMode::Draw(game);
    CMapMode::DrawTargetCursors(game);
}
