#include "TestGameMode.h"

#include "../Game.h"
#include "../ui/Rectangle.h"
#include "../ui/Label.h"
#include "../ui/Button.h"
#include "../ui/StackElement.h"

CTestGameMode::CTestGameMode(CGame *game){
  DRootElement = new CUIElement();
  DRootElement->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
  DRootElement->Position(SInt2(0, 0));

  CStackElement* S = new CStackElement();
  S->Size(SInt2(500, 700));
  S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2));
  S->Anchor(SDouble2(0.5, 0.5));

  CButton *B = new CButton(game, "SINGLEPLAYER");
  B->Anchor(SDouble2(0.5, 0));
  S->AddChildElement(B);

  DRootElement->AddChildElement(S);
}

CTestGameMode::~CTestGameMode(){
  delete DRootElement;
}

void CTestGameMode::Update(CGame* game){
  DRootElement->Update(game);
}

void CTestGameMode::Draw(CGame* game){
  DRootElement->Draw(game);
}
