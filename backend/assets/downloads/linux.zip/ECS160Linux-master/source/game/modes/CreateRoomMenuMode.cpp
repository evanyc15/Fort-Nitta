#include "CreateRoomMenuMode.h"

#include <string>
#include <vector>

#include "../Game.h"
#include "../ui/Button.h"
#include "../ui/Label.h"
#include "../ui/StackElement.h"
#include "../ui/TextField.h"
#include "MapSelectMenuMode.h"
#include "MultiplayerMenuMode.h"
#include "../ui/Spinner.h"

#define BROADCAST_OPTION "Broadcast"
#define REGULAR_OPTION   "Regular"

CCreateRoomMenuMode::CCreateRoomMenuMode(CGame* game)
    : CMenuMode("CREATE ROOM"){

    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));

    DNextButton = new CButton(game, "NEXT");
    DNextButton ->Position(SInt2(GAME_WIDTH, GAME_HEIGHT));
    DNextButton->Anchor(SDouble2(1, 1));

    CStackElement* S = new CStackElement();
    S->Position(SInt2(GAME_WIDTH/2, GAME_HEIGHT/2+10));
    S->Size(SInt2(GAME_WIDTH, GAME_HEIGHT));
    S->Anchor(SDouble2(0.5, 0.5));

    CLabel* RoomNameLabel = new CLabel(game, "ROOM NAME", SInt2(15, 0));
    S->AddChildElement(RoomNameLabel);
    DRoomNameField = new CTextField(game, "");
    DRoomNameField->Size(SInt2(300, 60));
    S->AddChildElement(DRoomNameField);

    std::vector<std::string> options;
    options.push_back(REGULAR_OPTION);
    options.push_back(BROADCAST_OPTION);
    DTypeSpinner = new CSpinner(game, "GAME TYPE", &options);
    DTypeSpinner->Anchor(SDouble2(0.5, 0));
    S->AddChildElement(DTypeSpinner);

    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(DNextButton);
    DRootElement->AddChildElement(S);
}

void CCreateRoomMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->SwitchMode(new CMultiplayerMenuMode(game));
    }
    if(DNextButton->IsPressed() && DRoomNameField->Text().length() > 0){
        game->GameState()->DRoom = CRoom();
        game->GameState()->DRoom.DName = DRoomNameField->TextEntered();
        game->GameState()->DRoom.DIsOwnedByLocalUser = true;
        game->GameState()->DRoom.DIsBroadcast =
            DTypeSpinner->SelectedOption() == BROADCAST_OPTION;
        game->GameState()->DRoom.DPlayerUsernames.push_back(
                game->GameState()->DUsername);
        game->SwitchMode(new CMapSelectMenuMode(game, true));
    }
}
