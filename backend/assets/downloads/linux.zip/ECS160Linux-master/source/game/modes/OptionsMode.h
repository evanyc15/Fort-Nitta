#ifndef OPTIONSMODE_H
#define OPTIONSMODE_H

#include "MenuMode.h"

class CGame;
class CButton;
class CLabel;

/**
 *  @brief Mode where user edits options
 */
class COptionsMode : public CMenuMode{
    public:
        COptionsMode(CGame* game);
        ~COptionsMode();

        virtual void Update(CGame* game);

    private:
        //@Button for going back to main menu
        CButton* DBackButton;
        //@List of buttons for each option
        std::vector<CButton* > DOptions;

};

#endif