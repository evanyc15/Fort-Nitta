#ifndef CANNONPLACEMENTMODE_H
#define CANNONPLACEMENTMODE_H

#include "MapMode.h"

/**
 * @brief Mode where players place cannons on their land based on the castles they have
 */
class CCannonPlacementMode : public CMapMode{
    public:
        /**
         * @brief Sets up timer and number of cannons each player can place
         *
         * @param game The game entering
         */
        virtual void Enter(CGame* game);
        /**
         * @brief Places cannons if needed and moves on to battle mode if the all
         *        the cannons are placed or the timer has run out
         *
         * @param game The game updating in
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the 2D map and the cursors for placing cannons
         *
         * @param game The game drawing in
         */
        virtual void Draw(CGame* game);
};

#endif
