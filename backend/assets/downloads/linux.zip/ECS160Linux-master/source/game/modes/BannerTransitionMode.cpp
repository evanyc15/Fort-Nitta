#include "BannerTransitionMode.h" 

#include "../Game.h"
#include "../ui/UIElement.h"
#include "../ui/Label.h"
#include "../ui/Button.h"
#include "../tilesets/WallFloorTileset.h"
#include "../ui/StackElement.h"
#include "../../util/TimeUtil.h"
#include "../sounds/Sounds.h"
#include <gtk/gtk.h>
#include <iostream>

CBannerTransitionMode::CBannerTransitionMode(CGame* game, std::string title, CGameMode* previous, CGameMode* next)
        : CMenuMode(""){
    DPreviousGameMode = previous;
    DNextGameMode = next;
    
    DRootElement = new CUIElement();

    DStackElement = new CStackElement();
    DStackElement->Size(SInt2(GAME_WIDTH, 0));
    DStackElement->Position(SInt2(GAME_WIDTH/2, 0));
    DStackElement->Anchor(SDouble2(0.5, 0));

    CLabel* L = new CLabel(game, title, DEFAULT_LABEL_MARGIN, &(game->Resources()->DTilesets->DWhiteFont));
    DStackElement->AddChildElement(L);

    DRootElement->AddChildElement(DStackElement);

    CTimer& Timer = game->GameState()->DTimer;
    Timer.DTimeout = CTimeUtil::MakeTimeoutSecondsInFuture(3);
}

void CBannerTransitionMode::Enter(CGame* game){
    game->Resources()->DSounds->StopSong();
    game->Rendering()->DBannerPixmap = gdk_pixmap_new(game->DrawingArea()->window,
            DStackElement->Size().DX, DStackElement->Size().DY, -1);
    CacheBanner(game);
    CachePreviousMode(game);
    DBannerPosition = -DStackElement->Size().DY;

    DNextGameMode->WillEnter(game);
}

void CBannerTransitionMode::Leave(CGame* game){
    if(game->Rendering()->DBannerPixmap != NULL){
        g_object_unref(game->Rendering()->DBannerPixmap);
        game->Rendering()->DBannerPixmap = NULL;
    }
}

void CBannerTransitionMode::Update(CGame* game){
    CMenuMode::Update(game);
    bool WasBannerPositionNegative = DBannerPosition < 0;
#ifdef FAST_MODE
    DBannerPosition += 200;
#else
    DBannerPosition += 5;
#endif
    if(CTimeUtil::SecondsUntilDeadline(game->GameState()->DTimer.DTimeout) < 0) {
        game->SwitchMode(DNextGameMode);
    }
    if(WasBannerPositionNegative && DBannerPosition >= 0){
        game->Resources()->DSounds->PlaySoundClip(CSounds::sctTransition);
    }
}

void CBannerTransitionMode::Draw(CGame* game){
    CRendering* Rendering = game->Rendering();
    DNextGameMode->Draw(game);
    gdk_draw_pixmap(Rendering->DWorkingBufferPixmap, 
            Rendering->DDrawingContext,
            Rendering->DPreviousWorkingBufferPixmap, 
            0, DBannerPosition, 
            0, DBannerPosition, 
            -1, GAME_HEIGHT - DBannerPosition);
    gdk_draw_pixmap(Rendering->DWorkingBufferPixmap,
            Rendering->DDrawingContext,
            Rendering->DBannerPixmap,
            0, 0, 0, DBannerPosition, -1, -1);
}

void CBannerTransitionMode::DrawBanner(CGame* game){
    DrawTextBackgroundFrame(game, DStackElement->Size());
    DrawBrickFrame(game, SInt2(0, 0), DStackElement->Size());
    DrawMortar(game, SInt2(0, 0), DStackElement->Size());
    DRootElement->Draw(game);
}

void CBannerTransitionMode::CacheBanner(CGame* game){
    GdkPixmap* OriginalPixmap = game->Rendering()->DWorkingBufferPixmap;
    game->Rendering()->DWorkingBufferPixmap = game->Rendering()->DBannerPixmap;
    DrawBanner(game);
    game->Rendering()->DWorkingBufferPixmap = OriginalPixmap;

}

void CBannerTransitionMode::CachePreviousMode(CGame* game){
    GdkPixmap* OriginalPixmap = game->Rendering()->DWorkingBufferPixmap;
    game->Rendering()->DWorkingBufferPixmap = game->Rendering()->DPreviousWorkingBufferPixmap;
    DPreviousGameMode->Draw(game);
    game->Rendering()->DWorkingBufferPixmap = OriginalPixmap;
}
