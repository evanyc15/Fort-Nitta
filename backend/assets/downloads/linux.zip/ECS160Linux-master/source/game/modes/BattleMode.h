#ifndef BATTLEMODE_H
#define BATTLEMODE_H

#include "MapMode.h"
#include "../Timer.h"

/**
 * @brief Mode where players fire cannonballs and destroy walls
 */
class CBattleMode : public CMapMode{
    public:
        /**
         * @brief Sets up the timer and cannons that are ready
         *
         * @param game The game entering
         */
        virtual void Enter(CGame* game);
        /**
         * @brief Determines if players are firing cannons and whether game
         *        should go to next mode
         *
         * @param game The game updating
         */
        virtual void Update(CGame* game);
        /**
         * @brief Draws the 3D map and the target reticules for the players
         *
         * @param game The game drawing
         */
        virtual void Draw(CGame* game);

    private:
        /**
        * @brief Updates current wind speed and direction
         *
         * @param game The game entering
        */
        //void WindUpdate(CGame* game);

        int DBattleType;
};

#endif
