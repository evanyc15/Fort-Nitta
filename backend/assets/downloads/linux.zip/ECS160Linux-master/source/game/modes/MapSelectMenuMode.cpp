#include "MapSelectMenuMode.h"

#include "../ui/Button.h"
#include "../ui/Label.h"
#include "../Game.h"
#include "../ui/StackElement.h"
#include "MapMode.h"
#include "SelectCastleMode.h"
#include "BannerTransitionMode.h"
#include "GameOptionsMenuMode.h"
#include "../players/HumanPlayer.h"
#include "../TerrainMap.h"
#include "../tilesets/BrickTileset.h"
#include "MainMenuMode.h"

CMapSelectMenuMode::CMapSelectMenuMode(CGame* game, bool multiplayer, bool broadcast)
        : CMenuMode("SELECT MAP"), DIsMultiplayer(multiplayer), DIsBroadcast(broadcast){
    DText.DX = 30;
    DText.DY = 100;
    DMapIndex = -1;       
    
    CStackElement* S = new CStackElement();
    S->Size(SInt2(GAME_WIDTH, 700));
    S->Position(SInt2(DText.DX, DText.DY));
    S->Anchor(SDouble2(0, 0));
    
    DBackButton = new CButton(game, "BACK");
    DBackButton->Position(SInt2(0, GAME_HEIGHT));
    DBackButton->Anchor(SDouble2(0, 1));
    
    DMapInfo = new CStackElement();
    DMapInfo->Size(SInt2(GAME_WIDTH, 700));
    DMapInfo->Anchor(SDouble2(0, 0));
    

    DNumPlayers = new CLabel(game, "" );
    DMapInfo->AddChildElement(DNumPlayers);
    
    DMapSize = new CLabel(game, "" );
    DMapInfo->AddChildElement(DMapSize);
    
    //Add all maps to map select
    for( auto *Map : game->Resources()->DTerrainMaps){
        CButton* M = new CButton(game, Map->MapName() );
        DMaps.push_back(M);
        S->AddChildElement(M);
    }

    DRootElement->AddChildElement(DBackButton);
    DRootElement->AddChildElement(S);
    DRootElement->AddChildElement(DMapInfo);
}

void CMapSelectMenuMode::Update(CGame* game){
    CMenuMode::Update(game);

    if(DBackButton->IsPressed()){
        game->SwitchMode(new CMainMenuMode(game));
    }
    
    //Initializing Index and Position for minimap to Default
    DMapIndex = -1;
    DMini.DX = GAME_WIDTH - (game->Resources()->DTilesets->DBrickTileset.TileWidth() * 3) / 2;
    DMini.DY = DText.DY;
    
    DNumPlayers->Text("");
    DMapSize->Text("");
            
    //Get the highlighted map and modify the location for it
    for(int Index = 0; Index < game->Resources()->DTerrainMaps.size(); Index++){
        if(DMaps[Index]->IsPressed()){
            game->GameState()->Reset();
            game->GameState()->TerrainMap(game->Resources()->DTerrainMaps[Index]);
            game->GameState()->TerrainMap()->LoadMapTileset(game);
            game->Resources()->DSounds->SoundLibraryMixer()->LoadMapLibrary(game->Resources()->DTerrainMaps[Index]->SongPath());

            if(DIsMultiplayer){
                game->GameState()->DRoom.DIsMultiplayer = true;
                game->GameState()->DRoom.DPlayerCount = 
                    game->GameState()->TerrainMap()->PlayerCount();
                game->GameState()->Network()->CreateRoom(
                        game->GameState()->DRoom.PlayerCount(),
                        game->GameState()->DRoom.Name());
            }else{
                game->GameState()->DRoom.DIsMultiplayer = false;
                game->SwitchMode(new CGameOptionsMenuMode(game));
            }
        }else if(DMaps[Index]->IsSelected()){
            DMini.DX -= game->Resources()->DTerrainMaps[Index]->Width() * 2;
            DMapIndex = Index;
            UpdateMiniMap(game);       
        }
    }
}

void CMapSelectMenuMode::Draw(CGame* game){
    CMenuMode::Draw(game);
    
    if( 0 <= DMapIndex){
        //Drawing the Map Preview
        game->Resources()->DTerrainMaps[DMapIndex]->DrawPreviewMap(game->Rendering()->DWorkingBufferPixmap, game->Rendering()->DDrawingContext, DMini.DX, DMini.DY);
    }

    
}

void CMapSelectMenuMode::UpdateMiniMap(CGame* game){
    
    //game->Resources()->DTerrainMaps[0];
    SInt2 DInfo;

            
    std::stringstream TempStringStream1, TempStringStream2;
            
    //Getting the information for below the preview
    TempStringStream1 << game->Resources()->DTerrainMaps[DMapIndex]->PlayerCount() << " PLAYERS";
    TempStringStream2 << game->Resources()->DTerrainMaps[DMapIndex]->Width() << " x " << game->Resources()->DTerrainMaps[DMapIndex]->Height();
    
    DNumPlayers->Text(TempStringStream1.str());
    DMapSize->Text(TempStringStream2.str());

    //Modifying the X and Y posityions to add text below map
    DInfo.DX = DMini.DX + game->Resources()->DTerrainMaps[DMapIndex]->Width();
    DInfo.DY = DMini.DY + game->Resources()->DTerrainMaps[DMapIndex]->Height() * 2; //+ TextHeight/2;

    
    SInt2 LabelSize = DNumPlayers->Size();
    DInfo.DX = DInfo.DX - LabelSize.DX / 2;
    
    DMapInfo->Position(DInfo);
    
            
    
    
}
