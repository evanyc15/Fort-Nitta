#include "Sounds.h"

#include <stdlib.h>

CSounds::CSounds(){
    DCurrentSong = stNotPlaying;
    DLibraryName = "data/SoundClips.dat";
}

void CSounds::Load(CGame *game){
    if(!DSoundMixer.LoadLibrary(DLibraryName)){
        printf("Failed to load sound clips.\n");
        exit(EXIT_FAILURE);
    }

    LoadSoundClipIndices();
    LoadSongIndices();
}

void CSounds::PlaySoundClip(ESoundClipType sound_clip, float volume, float right_bias){
    DSoundMixer.PlayClip(DSoundClipIndices[sound_clip], volume, right_bias);
}

void CSounds::PlaySong(ESongType song, float volume){
    if(song == stNotPlaying) { //signifies that should stop playing current song
        StopSong();
        return;
    }
    DSoundMixer.PlaySong(DSongIndices[song], volume);
}

void CSounds::StopSong() {
    DSoundMixer.StopSong();
}

void CSounds::SwitchSong(ESongType song, float volume = 1) {
    if(song != DCurrentSong) {
        StopSong();
        PlaySong(song, volume);
        DCurrentSong = song;
    }
}

/**
 * The following initializes the sound indices.
 * This allows GTK to find the right sound to play.
 */
void CSounds::LoadSoundClipIndices(){

    DSoundClipIndices[sctTick] = DSoundMixer.FindClip("tick");
    DSoundClipIndices[sctTock] = DSoundMixer.FindClip("tock");
    DSoundClipIndices[sctCannon0] = DSoundMixer.FindClip("cannon0");
    DSoundClipIndices[sctCannon1] = DSoundMixer.FindClip("cannon1");
    DSoundClipIndices[sctPlace] = DSoundMixer.FindClip("place");
    DSoundClipIndices[sctTriumph] = DSoundMixer.FindClip("triumph");
    DSoundClipIndices[sctExplosion0] = DSoundMixer.FindClip("explosion0");
    DSoundClipIndices[sctExplosion1] = DSoundMixer.FindClip("explosion1");
    DSoundClipIndices[sctExplosion2] = DSoundMixer.FindClip("explosion2");
    DSoundClipIndices[sctExplosion3] = DSoundMixer.FindClip("explosion3");
    DSoundClipIndices[sctGroundExplosion0] = DSoundMixer.FindClip("groundexplosion0");
    DSoundClipIndices[sctGroundExplosion1] = DSoundMixer.FindClip("groundexplosion1");
    DSoundClipIndices[sctWaterExplosion0] = DSoundMixer.FindClip("waterexplosion0");
    DSoundClipIndices[sctWaterExplosion1] = DSoundMixer.FindClip("waterexplosion1");
    DSoundClipIndices[sctWaterExplosion2] = DSoundMixer.FindClip("waterexplosion2");
    DSoundClipIndices[sctWaterExplosion3] = DSoundMixer.FindClip("waterexplosion3");
    DSoundClipIndices[sctReady] = DSoundMixer.FindClip("ready");
    DSoundClipIndices[sctAim] = DSoundMixer.FindClip("aim");
    DSoundClipIndices[sctFire] = DSoundMixer.FindClip("fire");
    DSoundClipIndices[sctCeasefire] = DSoundMixer.FindClip("ceasefire");
    DSoundClipIndices[sctTransition] = DSoundMixer.FindClip("transition");

}

/**
 * The following initializes the song indices.
 * This allows GTK to find the right sound to play.
 */
void CSounds::LoadSongIndices(){

    DSongIndices[stLoss] = DSoundMixer.FindSong("loss");
    DSongIndices[stWin] = DSoundMixer.FindSong("win");
    DSongIndices[stMenu] = DSoundMixer.FindSong("menu");
    DSongIndices[stRebuild] = DSoundMixer.FindSong("rebuild");
    DSongIndices[stPlace] = DSoundMixer.FindSong("place");

}
