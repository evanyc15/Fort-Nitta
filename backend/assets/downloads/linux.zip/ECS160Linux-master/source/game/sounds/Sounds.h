#ifndef SOUNDS_H
#define SOUNDS_H

#include <string>

#include "SoundLibraryMixer.h"

class CGame;

class CSounds{
    public:
        CSounds();

        /**
         * @brief Loads sound resources
         * @param game Game to load for
         */
        void Load(CGame* game);

        /**
         * @brief Clips that can be played
         */
        typedef enum{
            sctTick = 0,
            sctTock,
            sctCannon0,
            sctCannon1,
            sctPlace,
            sctTriumph,
            sctExplosion0,
            sctExplosion1,
            sctExplosion2,
            sctExplosion3,
            sctGroundExplosion0,
            sctGroundExplosion1,
            sctWaterExplosion0,
            sctWaterExplosion1,
            sctWaterExplosion2,
            sctWaterExplosion3,
            sctReady,
            sctAim,
            sctFire,
            sctCeasefire,
            sctTransition,
            sctMax
        } ESoundClipType, *ESoundClipTypeRef;

        /**
         * @brief Songs that can be played
         */
        typedef enum{
            stNotPlaying,
            stMenu,
            stLoss,
            stWin,
            stPlace,
            stRebuild,
            stMax
        } ESongType, *ESongTypeRef;

        /**
         * @brief Plays a sound clip
         * @param sound_clip The clip to play
         * @param volume The volume to play at
         * @param right_bias The stereo effect to use
         */
        void PlaySoundClip(ESoundClipType sound_clip, float volume=1, float right_bias=0);
        /**
         * @brief Plays a song
         * @param song The song to play
         * @param volume The volume to play the song at
         */
        void PlaySong(ESongType song, float volume=1);
        
        CSoundLibraryMixer* SoundLibraryMixer() { return &DSoundMixer; }

        /**
         * @brief Stops current song
         */
        void StopSong();
        /**
         * @brief Plays song if is different than the one already playing
         * @param song The song to play
         * @param volume The volume to play the song at
         */
        void SwitchSong(ESongType song, float volume);

        /**
         * @brief Sounds mixer that plays the clips and songs
         */
        CSoundLibraryMixer DSoundMixer;

    protected:
        /**
         * @brief Filename of the library to use
         */
        std::string DLibraryName;

        /**
         * @brief Sound clip indexes used by DSoundMixer to play clips
         */
        int DSoundClipIndices[sctMax];
        /**
         * @brief Song indexes used by DSoundMixer to play clips
         */
        int DSongIndices[stMax];

        /**
         * @brief Finds songs in DSoundMixer
         */
        void LoadSongIndices();
        /**
         * @brief Finds sound clips in DSoundMixer
         */
        void LoadSoundClipIndices();

        /**
         * @brief Keeps track of currently playing song
         */
        ESongType DCurrentSong;
};

#endif
