#ifndef CONSTRUCTIONTILE_H
#define CONSTRUCTIONTILE_H

#include "players/Player.h"

class CGame;

/**
 * @brief A tile in a construction map with a type and number of hits taken
 */
class CConstructionTile{
    public:
        /**
         * @brief The type of construction in tile
         */
        typedef enum{
            cttNone,
            cttBlueFloor,
            cttBlueWall,
            cttBlueWallDamaged,
            cttRedFloor,
            cttRedWall,
            cttRedWallDamaged,
            cttYellowFloor,
            cttYellowWall,
            cttYellowWallDamaged,
            cttGroundDamaged,
            cttBlueFloorDamaged,
            cttRedFloorDamaged,
            cttYellowFloorDamaged
        } EConstructionTileType, *EConstructionTileTypeRef;

        /**
         * @brief The type of this tile
         */
        EConstructionTileType DType;
        /**
         * @brief The number of hits tile has taken
         */
        int DHitsTaken;

        /**
         * @brief Resets hits and sets to no construction
         */
        void Reset();
        /**
         * @brief Returns if the type is a floor tile
         *
         * @return true if floor, otherwise false
         */
        bool IsFloor();
        /**
         * @brief Returns if type is a damaged floor
         *
         * @return true if damaged floor, otherwise false
         */
        bool IsFloorDamaged();
        /**
         * @brief Returns if type is a wall
         *
         * @return true if wall, otherwise false
         */
        bool IsWall();
        /**
         * @brief Returns if type is a damaged wall
         *
         * @return true if damaged wall, otherwise false
         */
        bool IsWallDamaged();        
        /**
         * @brief Returns if ground damaged
         *
         * @return true if damaged ground, otherwise false
         */
        bool IsGroundDamaged();
        /**
         * @brief Turns wall into damaged wall
         */
        void DestroyWall();
        /**
         * @brief Gets the color of tile
         *
         * @return The player color of this tile
         */
        CPlayer::EPlayerColor GetColor();
};

#endif
