#include "Castle.h"

#include "Game.h"
#include "tilesets/CastleSelectTileset.h"

SInt2 Castle::CSize(2, 2);

const SInt2 Castle::IndexPosition() const{
    return DIndexPosition;
}

void Castle::IndexPosition(const SInt2 position){
    DIndexPosition = position;
}

void Castle::Update(CGame* game){
    DHovered = false;
    DAnimationStep += game->GameState()->DWind.DWindSpeed;
    for(std::vector<CPlayer*>::iterator it = game->GameState()->DPlayers.begin();
            it != game->GameState()->DPlayers.end();
            it++){
        if((*it)->DHoveredCastle == this){
            DHovered = true;
        }
    }
}

void Castle::Draw3D(CGame* game){
    C3DCastleTileset& Tileset = game->Resources()->DTilesets->D3DCastleTileset;
    CTerrainMap* Map = game->GameState()->TerrainMap();
    SInt2 Position = Map->ConvertToScreenPosition(DIndexPosition - SInt2(0, 1));
    CPlayer::EPlayerColor Color = (DSurrounded || DHovered) ? DColor : CPlayer::pcNone;
    int Index = (game->GameState()->DWind.DWindDirection * CASTLE_ANIMATION_TIMESTEPS)
        + (DAnimationStep/4) % CASTLE_ANIMATION_TIMESTEPS;
    Tileset.Draw3DCastleTile(game,
            Position,
            Color,
            Color == CPlayer::pcNone ? 0 : Index);
}

void Castle::Draw2D(CGame* game){
    CCastleCannonTileset& Tileset = game->Resources()->DTilesets->D2DCastleCannonTileset;
    CTerrainMap* Map = game->GameState()->TerrainMap();
    SInt2 Position = Map->ConvertToScreenPosition(DIndexPosition);
    Tileset.Draw2DCastleTile(game,
            Position.DX,
            Position.DY,
            (DSurrounded || DHovered) ? DColor : CPlayer::pcNone);
    if(DHovered){
        DrawSelectionRing(game);
    }
    
}

void Castle::DrawSelectionRing(CGame* game){
    CCastleSelectTileset *Tileset = &game->Resources()->DTilesets->D2DCastleSelectTileset;
    CTerrainMap* Map = game->GameState()->TerrainMap();
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2(DIndexPosition.DX, (DIndexPosition.DY - 1))), DColor, 0);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 1), (DIndexPosition.DY - 1))), DColor, 0);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 2), (DIndexPosition.DY - 1))), DColor, 1);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 2), DIndexPosition.DY)), DColor, 2);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 2), (DIndexPosition.DY + 1))), DColor, 2);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 2), (DIndexPosition.DY + 2))), DColor, 3);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX + 1), (DIndexPosition.DY + 2))), DColor, 4);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2(DIndexPosition.DX, (DIndexPosition.DY + 2))), DColor, 4);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX - 1), (DIndexPosition.DY + 2))), DColor, 5);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX - 1), (DIndexPosition.DY + 1))), DColor, 6);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX - 1), DIndexPosition.DY)), DColor, 6);
    Tileset->Draw2DCastleSelectTile(game, Map->ConvertToScreenPosition(SInt2((DIndexPosition.DX - 1), (DIndexPosition.DY - 1))), DColor, 7);
}

void Castle::Reset(){
    DSurrounded = false;
    DHovered = false;
}
