#ifndef CASTLE_H
#define CASTLE_H

#include "../types/Int2.h"
#include "players/Player.h"

#define CASTLE_ANIMATION_TIMESTEPS 4

class CGame;

/**
 * Castle class, used to store information of castle.
 */
class Castle{
    private:
        /**
         * @brief The position of the castle
         */
        SInt2 DIndexPosition;

    public:
        /**
         * @brief The size of castles (2, 2)
         */
        static SInt2 CSize;
        /**
         * @brief The color of the castle
         */
        CPlayer::EPlayerColor DColor;
        /**
         * @brief If the castle is surrounded by walls
         */
        bool DSurrounded;
        /**
         * @brief If the castle is being hovered by a player for selection
         */
        bool DHovered;
        /**
         * @brief Which animation step the castle is at
         */
        int DAnimationStep;
        /**
         * Castle constructor.
         */
        Castle() : DSurrounded(false), DHovered(false), DColor(CPlayer::pcNone),
            DAnimationStep(0) {}

        /**
         * Castle destructor.
         */
        ~Castle(){}

        /**
         * @brief Sets not surrounded or hovered
         */
        void Reset();

        /**
         * Gets pos of castle.
         *
         * @return Returns position of castle.
         */
        const SInt2 IndexPosition() const;

        /**
         * Sets pos of castle.
         *
         * @param position Used to set position of castle.
         */
        void IndexPosition(const SInt2 index_position);
        
        /**
         * @brief Updates if player is hovering
         *
         * @param game Game updating in
         */
        void Update(CGame* game);
        /**
         * @brief Draws the 2D tile, and if hovered, draws the selection ring around as well
         *
         * @param game Drawing in
         */
        void Draw2D(CGame* game);
        /**
         * @brief Draws the 3D tiles
         *
         * @param game Game to draw in
         */
        void Draw3D(CGame* game);
        /**
         * @brief Draws the selection ring around the 2D tile to indicate hovering
         *
         * @param game Game to draw in
         */
        void DrawSelectionRing(CGame* game);
};

#endif

