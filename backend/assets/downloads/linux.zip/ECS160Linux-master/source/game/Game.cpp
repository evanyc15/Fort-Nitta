#include "Game.h"
#include "Resources.h"
#include <stdio.h>

#include "modes/MainMenuMode.h"

CGame::CGame(GtkWidget* drawing_area) {
    DDrawingArea = drawing_area;
    DNextGameMode = NULL;
    DGameMode = NULL;
    
    DInputState = new CInputState();
    DGameState = new CGameState();
    DRendering = new CRendering(drawing_area, GAME_WIDTH, GAME_HEIGHT);
    DResources = new CResources();

    DResources->Load(this);
    
    SwitchMode(new CMainMenuMode(this));
}

CGame::~CGame(){
    delete DInputState;
    delete DRendering;
    delete DGameMode;
    delete DGameState;
}

void CGame::SwitchMode(CGameMode* new_mode){
    DNextGameMode = new_mode;
    GameState()->DTimer.DIsAudible = false;
    GameState()->DTimer.DIsVisible = false;
}

void CGame::Update(){
    if(DNextGameMode != DGameMode){
        if(DGameMode != NULL){
            DGameMode->Leave(this);
        }
        DNextGameMode->Enter(this);
        if(DGameMode){
            delete DGameMode;
        }
        DGameMode = DNextGameMode;
    }

    DGameMode->Update(this);

    DInputState->Reset();
}

GdkPixmap* CGame::Draw(GdkGC *drawing_context){
    DRendering->DDrawingContext = drawing_context;
    
    GdkPixmap* p = DRendering->DWorkingBufferPixmap;

    DGameMode->Draw(this);

    return p;
}

void CGame::MouseMoved(SInt2 position){
    DInputState->DMousePosition = position;
}

void CGame::KeyPressed(unsigned int keyval){
    DInputState->KeyPressed(keyval);
}

void CGame::ButtonPressed(CInputState::EInputButton button){
    DInputState->ButtonPressed(button);
}
