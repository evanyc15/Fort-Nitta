#ifndef WIND_H
#define WIND_H

#include "../types/Double3.h"

#define TIMEOUT_INTERVAL 50
#define TIMESTEP_PERIOD ((double)TIMEOUT_INTERVAL/500.0)
#define RANDOM_NUMBER_MAX 1000000
#define WINDSPEED_COUNT 8
#define WINDDIRECTION_COUNT 9

/**
 * @brief Wind state of game
 */
class CWind{
    public:
        /**
         * @brief Makes wind with basic settings
         */
        CWind();
        /**
         * @brief Type of wind 
         */
        typedef enum{
            wtNone,
            wtMild,
            wtModerate,
            wtErratic,
        } EWindType, *EWindTypeRef;

        /**
         * @brief Update DWindSpeed and DWindDirection
         *
         * @param The game that is running
         */
        void WindUpdate(int Change, int DirChange, int SpeedChange);

        SDouble3 GetVector();

        //Stores the WindType Setting
        EWindType DWindType;
        //Stores the current Windspeed and Wind Direction
        int DWindSpeed, DWindDirection;
        //Stores whether the wind changes direction next update
        bool DWindDirectionChange;
};

#endif
