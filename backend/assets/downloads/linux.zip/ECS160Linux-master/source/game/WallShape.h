#ifndef WALLSHAPE_H
#define WALLSHAPE_H
/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.
    
    All source material (source code, images, sounds, etc.) have been provided to 
    University of California, Davis students of course ECS 160 for educational 
    purposes. It may not be distributed beyond those enrolled in the course without 
    prior permission from the copyright holder. 
    
    Some sound files, sound fonts, and midi files have been included that were 
    freely available via internet sources. They have been included in this 
    distribution for educational purposes only and this copyright notice does not 
    attempt to claim any ownership of this material.
*/
#include <vector>
#include "../types/Int2.h"

class CGame;
class CPlayer;

/**
 * WallShape class
 */
class CWallShape{
    protected:
        std::vector< std::vector< bool > > DLocations; /*!< Polyomino square locations */
        int DOrientation; /*!< Polyomino orientation */ 
        
    public:
        /**
         * WallShape constructor.
         */
        CWallShape();

        /**
         * WallShape destructor.
         */
        ~CWallShape();
        
        /**
         * Gets width of polyomino.
         */
        int Width();

        /**
         * Gets height of polyomino. 
         */
        int Height();
        
        /**
         * Sets type and orientation of polyomino.
         *
         * @param val Seed value
         */
        void Randomize(unsigned int val);
        
        /**
         * Changes polyomino orientation.
         */
        void Rotate();
        
        /**
         * Determines if part of the polyomino is contained at the position specified.
         *
         * @param x x position
         * @param y y position
         *
         * @returns True if position contains part of polyomino, false if it does not
         */
        bool IsBlock(int x, int y);

        /**
         * @brief Draws wall shape for player
         *
         * @param game Game drawing
         * @param player Player drawing for
         * @param tile_position Position drawing at
         */
        void Draw(CGame* game, CPlayer* player, SInt2 tile_position);

        /**
         * @brief Determines if wall shape can be placed by player
         *
         * @param game Game updating
         * @param player Player placing shape
         * @param tile_position Position to place at
         *
         * @return true if can be placed, false otherwise
         */
        bool CanBePlaced(CGame* game, CPlayer* player, SInt2 tile_position);
        /**
         * @brief Places wall shape into construction map
         *
         * @param game Game updating
         * @param player Player placing shape
         * @param tile_position Position placing shape
         *
         * @return 
         */
        bool Place(CGame* game, CPlayer* player, SInt2 tile_position);
        /**
         * @brief Calculates the position bounded by the map
         *
         * @param game Game updating
         * @param tile_position Position trying to plae
         *
         * @return The position after bounding to the map
         */
        SInt2 GetBoundedPosition(CGame* game, SInt2 tile_position);
};

#endif
