#ifndef ANIMATION_H
#define ANIMATION_H

#include "../../types/Int2.h"
#include "BurnAndExplode.h"

class CGame;
class CGraphicTileset;

/**
 * @brief An sprite-based animation that has a frame count and a base frame
 *        to start from
 */
class CAnimation{
    public:
        /**
         * @brief Makes a new animation at a position and frame parameters
         *
         * @param position The position to draw at
         * @param base_frame_index The index in tileset of the first frame
         * @param frame_count The number of frames in the animation
         */
        CAnimation(SInt2 position, SInt2 index, int base_frame_index, int frame_count)
            : DBaseFrameIndex(base_frame_index),
                DFrameIndex(0), DFrameCount(frame_count),
                DPosition(position), DIndex(index){}
        /**
         * @brief Virtual destructorr
         */
        virtual ~CAnimation(){}
        /**
         * @brief Moves to the next frame
         *
         * @param game Game being animated in
         */
        virtual void Update(CGame* game);
        /**
         * @brief Pure virtual implemented by subclasses to specify which tileset to use
         *
         * @param game The game to draw in
         */
        virtual void Draw(CGame* game) = 0;
        /**
         * @brief Determines if animation should continue or has reached the end
         *        based on the current frame and the frame count
         *
         * @return True if there are more frames to draw
         */
        bool ShouldContinuePlaying();

        SInt2 Position();

        SInt2 Index();

        int tileType = 0;

    protected:
        /**
         * @brief Internal drawing that draws the frame at the position given
         *        the tileset
         *
         * @param game Game to draw in
         * @param tileset Tileset to draw with
         */
        void Draw(CGame* game, CGraphicTileset& tileset);

        /**
         * @brief The index of the first frame in the tileset
         */
        int DBaseFrameIndex;
        /**
         * @brief Which frame the animation is currently at
         */
        int DFrameIndex;
        /**
         * @brief The number of frames in the animation
         */
        int DFrameCount;
        /**
         * @brief The position of the animation
         */
        SInt2 DPosition;

        /**
         * @brief The tile index for the animation
         */
        SInt2 DIndex;
};

#endif
