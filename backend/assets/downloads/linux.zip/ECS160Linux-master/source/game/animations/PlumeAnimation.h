#ifndef PLUME_ANIMATION_H
#define PLUME_ANIMATION_H

#include "Animation.h"
#include "../../types/Direction.h"

/**
 * @brief The animation played when a cannon fires
 */
class CPlumeAnimation : public CAnimation{
    public:
        /**
         * @brief Makes a new animation at a position, facing a direction
         *
         * @param game The game playing
         * @param position The position to play at
         * @param direction The direction cannon was facing
         */
        CPlumeAnimation(CGame* game, SInt2 position, SInt2 index, SDirection::EValue direction);
        /**
         * @brief Draws the animation using the cannon plume tileset
         *
         * @param game The game drawing
         */
        virtual void Draw(CGame* game);
};

#endif
