#include "Animation.h"
#include "../tilesets/GraphicTileset.h"

void CAnimation::Update(CGame* game){
    DFrameIndex++;
}

SInt2 CAnimation::Position(){
    return DPosition;
}

SInt2 CAnimation::Index(){
    return DIndex;
}

bool CAnimation::ShouldContinuePlaying(){
    return DFrameIndex < DFrameCount;
}

void CAnimation::Draw(CGame* game, CGraphicTileset& tileset){
    tileset.DrawTile(game, DPosition, DBaseFrameIndex + DFrameIndex);
}
