#ifndef BURN_ANIMATION_H
#define BURN_ANIMATION_H

#include "Animation.h"

/**
 * @brief The animation played while a wall or floor burns
 */
class CBurnAnimation : public CAnimation{
    public:
        /**
         * @brief Makes a new animation at a position
         *
         * @param game The game playing
         * @param position The position to play at
         * @param burnType The type of burn
         */
        CBurnAnimation(CGame* game, SInt2 position, SInt2 index, SBurnAndExplosion::EBurnType burnType);

        /**
         * @brief Draws the animation using the burn tileset
         *
         * @param game The game drawing
         */
        virtual void Draw(CGame* game);
};

#endif
