#include "ExplosionAnimation.h"
#include "BurnAnimation.h"
#include "../Game.h"
#include "../../util/RandomNumberGenerator.h"

CExplosionAnimation::CExplosionAnimation(CGame* game, SInt2 position, SInt2 index, SBurnAndExplosion::EExplosionType explosionType)
    : CAnimation(SInt2(
                 (index.DX-0.5)*game->Resources()->DTilesets->D3DTerrainTileset.TileWidth(),
                 (index.DY-1.5)*game->Resources()->DTilesets->D3DTerrainTileset.TileHeight()),
                 index, game->Resources()->DTilesets->D3DExplosionTileset.GetBaseFrame(explosionType),
            game->Resources()->DTilesets->D3DExplosionTileset.TileCount() / SBurnAndExplosion::etMax){
    switch(explosionType){
        case SBurnAndExplosion::etGroundExplosion0:
        case SBurnAndExplosion::etGroundExplosion1: tileType = 0;
                                                    break;
        case SBurnAndExplosion::etWaterExplosion0:
        case SBurnAndExplosion::etWaterExplosion1:  tileType = 1;
                                                    break;
        case SBurnAndExplosion::etWallExplosion0:
        case SBurnAndExplosion::etWallExplosion1:   tileType = 2;
                                                    break;
        default:
                                                    break;
    }
}

void CExplosionAnimation::Update(CGame* game){
    CAnimation::Update(game);
    
    if(!ShouldContinuePlaying()){
        C3DTerrainTileset& TerrainTileset = game->Resources()->DTilesets->D3DTerrainTileset;
        if (tileType == 0){
            game->GameState()->DAnimations.push_back(new CBurnAnimation(
                        game,
                        SInt2((DIndex.DX)*TerrainTileset.TileWidth(),
                            (DIndex.DY)*TerrainTileset.TileHeight()),
                        DIndex,
                        game->GameState()->DRandomNumberGenerator.Random() % 2
                            ? SBurnAndExplosion::btHoleBurn0 
                            : SBurnAndExplosion::btHoleBurn1));
        } else if (tileType == 2){
            game->GameState()->DAnimations.push_back(new CBurnAnimation(
                        game,
                        SInt2((DIndex.DX)*TerrainTileset.TileWidth(),
                            (DIndex.DY)*TerrainTileset.TileHeight()),
                        DIndex,
                        game->GameState()->DRandomNumberGenerator.Random() % 2 
                            ? SBurnAndExplosion::btRubbleBurn0
                            : SBurnAndExplosion::btRubbleBurn1));
        }
    }
}

void CExplosionAnimation::Draw(CGame* game){
    CAnimation::Draw(game, game->Resources()->DTilesets->D3DExplosionTileset);
}
