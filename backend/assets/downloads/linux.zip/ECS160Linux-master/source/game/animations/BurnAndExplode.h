#ifndef BURN_AND_EXPLODE_H
#define BURN_AND_EXPLODE_H

/**
 * @brief Holds enumeration for directions
 */
class SBurnAndExplosion{
    public:
        /**
         * @brief Enum for Explosions
         */
        typedef enum{
            etWallExplosion0 = 0,
            etWallExplosion1,
            etWaterExplosion0,
            etWaterExplosion1,
            etGroundExplosion0,
            etGroundExplosion1,
            etMax
        } EExplosionType, *EExplosionTypeRef;

        /**
         * @brief Enum for Burns
         */
        typedef enum{
            btRubbleBurn0 = 0,
            btRubbleBurn1,
            btHoleBurn0,
            btHoleBurn1,
            btMax
        } EBurnType, *EBurnTypeRef;

         /**
         * @brief Enum for Burns
         */
        typedef enum{
            atBurn = 0,
            atExplosion,
            atPlume            
        } EAnimationType, *EAnimationTypeRef;
};

#endif
