#include "PlumeAnimation.h"

#include "../Game.h"

CPlumeAnimation::CPlumeAnimation(CGame* game, SInt2 position, SInt2 index, SDirection::EValue direction)
    : CAnimation(position + SInt2(
                game->Resources()->DTilesets->D3DTerrainTileset.TileWidth() -
                game->Resources()->DTilesets->D3DCannonPlumeTileset.TileWidth()/2,
                -game->Resources()->DTilesets->D3DTerrainTileset.TileHeight()), 
                index, game->Resources()->DTilesets->D3DCannonPlumeTileset.GetBaseFrame(direction),
            game->Resources()->DTilesets->D3DCannonPlumeTileset.TileCount() / SDirection::dMax){
}

void CPlumeAnimation::Draw(CGame* game){
    CAnimation::Draw(game, game->Resources()->DTilesets->D3DCannonPlumeTileset);
}
