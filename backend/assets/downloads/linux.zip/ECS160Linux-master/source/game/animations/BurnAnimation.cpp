#include "BurnAnimation.h"
#include "../Game.h"

CBurnAnimation::CBurnAnimation(CGame* game, SInt2 position, SInt2 index, SBurnAndExplosion::EBurnType burnType)
    : CAnimation(position, index,
                 game->Resources()->DTilesets->D3DBurnTileset.GetBaseFrame(burnType),
                 game->Resources()->DTilesets->D3DBurnTileset.TileCount() / SBurnAndExplosion::btMax){
}

void CBurnAnimation::Draw(CGame* game){
    CAnimation::Draw(game, game->Resources()->DTilesets->D3DBurnTileset);
}
