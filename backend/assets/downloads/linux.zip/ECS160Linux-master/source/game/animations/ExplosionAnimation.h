#ifndef EXPLOSION_ANIMATION_H
#define EXPLOSION_ANIMATION_H

#include "Animation.h"

/**
 * @brief The animation played when a cannonball explodes
 */
class CExplosionAnimation : public CAnimation{
    public:
        /**
         * @brief Makes a new animation at a position
         *
         * @param game The game playing
         * @param position The position to play at
         * @param explosionType The type of explosion
         */
        CExplosionAnimation(CGame* game, SInt2 position, SInt2 index, SBurnAndExplosion::EExplosionType explosionType);
        /**
         * @brief Draws the animation using the burn tileset
         *
         * @param game The game drawing
         */
        virtual void Draw(CGame* game);

        /**
         * @brief Updates the animation and spawns the appropriate animation if 
         * destroyed a wall or hit the ground
         *
         * @param game Game updating
         */
        virtual void Update(CGame* game);

        int tileType;
};

#endif
