/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.
    
    All source material (source code, images, sounds, etc.) have been provided to 
    University of California, Davis students of course ECS 160 for educational 
    purposes. It may not be distributed beyond those enrolled in the course without 
    prior permission from the copyright holder. 
    
    Some sound files, sound fonts, and midi files have been included that were 
    freely available via internet sources. They have been included in this 
    distribution for educational purposes only and this copyright notice does not 
    attempt to claim any ownership of this material.
*/
#include "TerrainMap.h"
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <algorithm>
#include "../util/MathUtil.h"
#include "Game.h"
#include <fstream>
#include <sstream>

CTerrainMap::CTerrainMap(){
    D2DTileset = NULL;
    D3DTileset = NULL;
    DAnimationStep = 0;
    DHasCached3D = false;
}

CTerrainMap::CTerrainMap(const CTerrainMap &map){
    D2DTileset = map.D2DTileset;
    D3DTileset = map.D3DTileset;
    D2DMap = map.D2DMap;
    D3DMap = map.D3DMap;
    DTileTypeMap = map.DTileTypeMap;
    DStringMap = map.DStringMap;
    DCastles = map.DCastles;
    DPlayerCount = map.DPlayerCount;
    DMapName = map.DMapName;
    DMapFileName = map.DMapFileName;
}

CTerrainMap::~CTerrainMap(){

}

CTerrainMap &CTerrainMap::operator=(const CTerrainMap &map){
    if(this != &map){
        D2DTileset = map.D2DTileset;
        D3DTileset = map.D3DTileset;
        D2DMap = map.D2DMap;
        D3DMap = map.D3DMap;
        DTileTypeMap = map.DTileTypeMap;
        DStringMap = map.DStringMap;
        DCastles = map.DCastles;
        DPlayerCount = map.DPlayerCount;
        DMapName = map.DMapName;   
        DMapFileName = map.DMapFileName;
    }
    return *this;
}

std::string CTerrainMap::MapName() const{
    return DMapName;   
}

int CTerrainMap::PlayerCount() const{
    return DPlayerCount;
}

std::vector< Castle > &CTerrainMap::Castles(){
    return DCastles;
}

std::vector< std::string > CTerrainMap::StringMap(){
    return DStringMap;
}

int CTerrainMap::Width() const{
    if(D2DMap.size()){
        return D2DMap[0].size();
    }
    return 0;
}

int CTerrainMap::Height() const{
    return D2DMap.size();
}

CPlayer::EPlayerColor CTerrainMap::TileType(int xindex, int yindex) const{
    if((0 > xindex)||(0 > yindex)){
        return CPlayer::pcMax;   
    }
    if(DTileTypeMap.size() <= yindex){
        return CPlayer::pcMax;    
    }
    if(DTileTypeMap[yindex].size() <= xindex){
        return CPlayer::pcMax;   
    }
    return DTileTypeMap[yindex][xindex];
}

bool CTerrainMap::LoadMap(CGraphicTileset *tileset2d, CGraphicTileset *tileset3d, const std::string &filename){
    DMapFileName = std::string(filename);
    std::ifstream ifs;
    ifs.open(filename, std::ifstream::in);
    if(ifs.good()){
        std::stringstream data;
        data << ifs.rdbuf();
        return LoadMapString(tileset2d, tileset3d, data.str());
    }else{
        printf("Failed to load file %s\n", filename.c_str());
        return false;   
    }
}

bool CTerrainMap::LoadMapString(CGraphicTileset *tileset2d, CGraphicTileset *tileset3d, const std::string &data){
    std::stringstream DataStream(data);
    std::vector< std::string > WaterNames2D, WaterNames3D;
    char TempBuffer[1024];
    size_t BufferSize = 1024;
    int LastChar, MapWidth, MapHeight, CastleCount;
    bool ReturnStatus = false;
    int PlayerColorsFound = 0;
    
    D2DTileset = tileset2d;
    D3DTileset = tileset3d;
    D2DMap.clear();
    
    //Getting the Map Title
    DataStream.getline(TempBuffer, BufferSize);
    DMapName = std::string(TempBuffer);
    
    /*
     * Bill:
     * 3 new lines to scan:
     * Tileset, AI Script, and Music File
     */
     
    //Getting the Tileset Path
    DataStream.getline(TempBuffer, BufferSize);
    D2DTilesetPath = std::string(TempBuffer);
    D2DTilesetPath.erase(std::remove(D2DTilesetPath.begin(), D2DTilesetPath.end(), '\n'), D2DTilesetPath.end());
    
    //Getting the Tileset Path
    DataStream.getline(TempBuffer, BufferSize);
    D3DTilesetPath = std::string(TempBuffer);
    D3DTilesetPath.erase(std::remove(D3DTilesetPath.begin(), D3DTilesetPath.end(), '\n'), D3DTilesetPath.end());
 
    //Getting the AI script Path
    DataStream.getline(TempBuffer, BufferSize);
    DAIPath = std::string(TempBuffer);
    DAIPath.erase(std::remove(DAIPath.begin(), DAIPath.end(), '\n'), DAIPath.end());
    
    //Getting the Song Path
    DataStream.getline(TempBuffer, BufferSize);
    DSongPath = std::string(TempBuffer);
    DSongPath.erase(std::remove(DSongPath.begin(), DSongPath.end(), '\n'), DSongPath.end());
    
    //Getting the Dimensions 
    DataStream.getline(TempBuffer, BufferSize);
    if(2 != sscanf(TempBuffer, "%d%d",&MapWidth, &MapHeight)){
        printf("Invalid map dimensions.\n");
        goto LoadMapExit;
    }
    if((8 > MapWidth)||(8 > MapHeight)){
        printf("Invalid map dimensions.\n");
        goto LoadMapExit;        
    }
    //Getting the Map
    while(!DataStream.eof() && (DStringMap.size() < MapHeight + 2)){
        DataStream.getline(TempBuffer, BufferSize);
        if(!DataStream.good()){
            if(!DataStream.eof()){
                printf("Failed to read map line.\n");
                goto LoadMapExit;
            }
            else{
                break;   
            }
        }
        LastChar = strlen(TempBuffer) - 1;
        while((0 <= LastChar)&&(('\r' == TempBuffer[LastChar])||('\n' == TempBuffer[LastChar]))){
            TempBuffer[LastChar] = '\0';
            LastChar--;
        }
        DStringMap.push_back(std::string(TempBuffer));
        if(MapWidth + 2 > DStringMap.back().length()){
            printf("Map line %zd too short!\n", DStringMap.size());
            goto LoadMapExit;
        }
    }
    if(MapHeight + 2 > DStringMap.size()){
        printf("Map has too few lines!\n");
        goto LoadMapExit;
    }
    D2DMap.resize(MapHeight);
    D3DMap.resize(MapHeight);
    DTileTypeMap.resize(MapHeight);
    for(int Index = 0; Index < D2DMap.size(); Index++){
        D2DMap[Index].resize(MapWidth);
        D3DMap[Index].resize(MapWidth);
        DTileTypeMap[Index].resize(MapWidth);
    }
    for(int Index = 0; Index < DStringMap.size(); Index++){
        std::string::iterator Iter = DStringMap[Index].begin();
        while(DStringMap[Index].end() != Iter){
            switch(*Iter){
                case 'B':   PlayerColorsFound |= 0x01;
                            break;
                case 'R':   PlayerColorsFound |= 0x02;
                            break;
                case 'Y':   PlayerColorsFound |= 0x04;
                            break;
                default:    break;
            }
            Iter++;   
        }
    }
    switch(PlayerColorsFound){
        case 3: // 2 player B & R
                DPlayerCount = 2;
                break;
        case 7: // 3 player B, R, & Y
                DPlayerCount = 3;
                break;
        case 5: 
        case 6: // 2 player need shiftdown
                for(int Index = 0; Index < DStringMap.size(); Index++){
                    std::string::iterator Iter = DStringMap[Index].begin();
                    while(DStringMap[Index].end() != Iter){
                        switch(*Iter){
                            case 'R':   *Iter = 'B';  
                                        break;
                            case 'Y':   *Iter = 'R';
                                        break;
                            default:    break;
                        }
                        Iter++;   
                    }
                }
                DPlayerCount = 2;
                break;
        default:    printf("Map has too few players!\n");
                    goto LoadMapExit;
    }
    
    
    WaterNames2D.resize(16);
    WaterNames2D[0] = "water";
    WaterNames2D[1] = "shore-n";
    WaterNames2D[2] = "shore-e";
    WaterNames2D[3] = "shore-ne";
    WaterNames2D[4] = "shore-s";
    WaterNames2D[5] = "shore-n";
    WaterNames2D[6] = "shore-se";
    WaterNames2D[7] = "shore-e";
    WaterNames2D[8] = "shore-w";
    WaterNames2D[9] = "shore-nw";
    WaterNames2D[10] = "shore-e";
    WaterNames2D[11] = "shore-n";
    WaterNames2D[12] = "shore-sw";
    WaterNames2D[13] = "shore-w";
    WaterNames2D[14] = "shore-s";
    WaterNames2D[15] = "water";
    WaterNames3D.resize(16);
    WaterNames3D[0] = "water-0";
    WaterNames3D[1] = "shore-n-0";
    WaterNames3D[2] = "shore-e-0";
    WaterNames3D[3] = "shore-ne-0";
    WaterNames3D[4] = "shore-s-0";
    WaterNames3D[5] = "shore-n-0";
    WaterNames3D[6] = "shore-se-0";
    WaterNames3D[7] = "shore-e-0";
    WaterNames3D[8] = "shore-w-0";
    WaterNames3D[9] = "shore-nw-0";
    WaterNames3D[10] = "shore-e-0";
    WaterNames3D[11] = "shore-n-0";
    WaterNames3D[12] = "shore-sw-0";
    WaterNames3D[13] = "shore-w-0";
    WaterNames3D[14] = "shore-s-0";
    WaterNames3D[15] = "water-0";
    
    for(int YPos = 0; YPos < D2DMap.size(); YPos++){
        for(int XPos = 0; XPos < D2DMap[YPos].size(); XPos++){
            bool IsEven = (YPos + XPos) & 0x01 ? false : true;
            
            switch(DStringMap[YPos+1][XPos+1]){
                case 'B': DTileTypeMap[YPos][XPos] = CPlayer::pcBlue;
                          break;
                case 'R': DTileTypeMap[YPos][XPos] = CPlayer::pcRed;
                          break;
                case 'Y': DTileTypeMap[YPos][XPos] = CPlayer::pcYellow;
                          break;
                default:  DTileTypeMap[YPos][XPos] = CPlayer::pcNone;
                          break;
            }
            
            if(DStringMap[YPos+1][XPos+1] == ' '){
                int WaterType = 0;
                
                if(DStringMap[YPos+1][XPos] != ' '){
                    WaterType |= 0x8;
                }
                if(DStringMap[YPos][XPos+1] != ' '){
                    WaterType |= 0x1;
                }
                if(DStringMap[YPos+1][XPos+2] != ' '){
                    WaterType |= 0x2;
                }
                if(DStringMap[YPos+2][XPos+1] != ' '){
                    WaterType |= 0x4;
                }
                if(WaterType && (WaterType != 15)){
                    D2DMap[YPos][XPos] = D2DTileset->FindTile(WaterNames2D[WaterType] + (IsEven ? "-even" : "-odd"));
                    D3DMap[YPos][XPos] = D3DTileset->FindTile(WaterNames3D[WaterType]);
                }
                else{
                    WaterType = 0;
                    if(DStringMap[YPos][XPos] != ' '){
                        WaterType |= 0x8;
                    }
                    if(DStringMap[YPos+2][XPos] != ' '){
                        WaterType |= 0x4;
                    }
                    if(DStringMap[YPos][XPos+2] != ' '){
                        WaterType |= 0x1;
                    }
                    if(DStringMap[YPos+2][XPos+2] != ' '){
                        WaterType |= 0x2;
                    }
                    switch(WaterType){
                        case 1:     D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-ne");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-nec-0");
                                    break;
                        case 2:     D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-se");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-sec-0");
                                    break;
                        case 4:     D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-sw");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-swc-0");
                                    break;
                        case 8:     D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-nw");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-nwc-0");
                                    break;
                        case 5:     D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-nesw");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-nesw-0");
                                    break;
                        case 10:    D2DMap[YPos][XPos] = D2DTileset->FindTile("shore-nwse");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("shore-nwse-0");
                                    break;
                        default:    D2DMap[YPos][XPos] = D2DTileset->FindTile("water");
                                    D3DMap[YPos][XPos] = D3DTileset->FindTile("water-0");
                                    break;
                    }
                }
            }
            else{
                if(IsEven){
                    D2DMap[YPos][XPos] = D2DTileset->FindTile("grass-even");
                }
                else{
                    D2DMap[YPos][XPos] = D2DTileset->FindTile("grass-odd");
                }
                D3DMap[YPos][XPos] = D3DTileset->FindTile("grass-0");
            }
        }
    }
    
    
    DataStream >> CastleCount;
    DCastles.resize(CastleCount);
    for(int Index = 0; Index < CastleCount; Index++){
        int XPos, YPos;
        
        DataStream >> XPos >> YPos;
        DCastles[Index].IndexPosition(SInt2(XPos, YPos));
        DCastles[Index].DColor = TileType(XPos, YPos);
    }

    SortCastlesForDrawing();
    
    ReturnStatus = true;

LoadMapExit:
    return ReturnStatus;
}

void CTerrainMap::SortCastlesForDrawing(){
    for(int Index = 0; Index < DCastles.size(); Index++){
        for(int Inner = Index + 1; Inner < DCastles.size(); Inner++){
            bool Swap = false;
            if(DCastles[Index].IndexPosition().DY > DCastles[Inner].IndexPosition().DY){
                Swap = true;
            }
            else if((DCastles[Index].IndexPosition().DY == DCastles[Inner].IndexPosition().DY)
                    && (DCastles[Index].IndexPosition().DX > DCastles[Inner].IndexPosition().DX)){
                Swap = true;
            }
            if(Swap){
                Castle TempCastle = DCastles[Index];
                DCastles[Index] = DCastles[Inner];
                DCastles[Inner] = TempCastle;
            }
        }
    }
}

void CTerrainMap::DrawPreviewMap(GdkDrawable *drawable, GdkGC *gc, gint xoff, gint yoff){
    for(int YIndex = 0, YPos = yoff; YIndex < D2DMap.size(); YIndex++, YPos += 2){
        for(int XIndex = 0, XPos = xoff; XIndex < D2DMap[YIndex].size(); XIndex++, XPos += 2){
            D2DTileset->DrawPixelCorners(drawable, gc, XPos, YPos, D2DMap[YIndex][XIndex]);
        }
    }
}

void CTerrainMap::Draw2DMap(CGame* game){
    int TileWidth, TileHeight;
    
    TileWidth = D2DTileset->TileWidth();
    TileHeight = D2DTileset->TileHeight();
    for(int YIndex = 0, YPos = 0; YIndex < D2DMap.size(); YIndex++, YPos += TileHeight){
        for(int XIndex = 0, XPos = 0; XIndex < D2DMap[YIndex].size(); XIndex++, XPos += TileWidth){
            D2DTileset->DrawTile(game, SInt2(XPos, YPos), D2DMap[YIndex][XIndex]);
        }
    }

}

void CTerrainMap::Draw2DCastles(CGame* game){
    for(std::vector<Castle>::iterator it = DCastles.begin();
            it != DCastles.end(); it++){
        it->Draw2D(game);
    }
}

void CTerrainMap::Draw3DCastles(CGame* game, int XPos, int YPos){
    for(std::vector<Castle>::iterator it = DCastles.begin();
            it != DCastles.end(); it++){
        if (it->IndexPosition() == SInt2(XPos-1,YPos-1)){
            it->Draw3D(game);
        }
    }
}

void CTerrainMap::Cache3DMap(CGame* game){
    std::vector<GdkPixmap*>& Pixmaps = game->Rendering()->D3DTerrainPixmaps;
    GdkPixmap* OriginalPixmap = game->Rendering()->DWorkingBufferPixmap;
    for(int Index = 0; Index < game->Rendering()->D3DTerrainPixmaps.size(); Index++){
        game->Rendering()->DWorkingBufferPixmap = game->Rendering()->D3DTerrainPixmaps[Index];
        Draw3DMap(game, game->GameState()->DWind.DWindDirection, TERRAIN_ANIMATION_TIMESTEPS, Index);
    }
    game->Rendering()->DWorkingBufferPixmap = OriginalPixmap;
    DHasCached3D = true;
}

void CTerrainMap::Draw3D(CGame* game){
    if(!DHasCached3D) {
        Cache3DMap(game);
    }
    CRendering* Rendering = game->Rendering();
    gdk_draw_pixmap(Rendering->DWorkingBufferPixmap,
            Rendering->DDrawingContext,
            Rendering->D3DTerrainPixmaps[(DAnimationStep / 4) % TERRAIN_ANIMATION_TIMESTEPS],
            0, 0, 0, 0, -1, -1);
}

void CTerrainMap::Draw3DMap(CGame* game, int winddir, int totalsteps, int timestep){
    int TileWidth, TileHeight;
    
    TileWidth = D3DTileset->TileWidth();
    TileHeight = D3DTileset->TileHeight();
    for(int YIndex = 0, YPos = 0; YIndex < D3DMap.size(); YIndex++, YPos += TileHeight){
        for(int XIndex = 0, XPos = 0; XIndex < D3DMap[YIndex].size(); XIndex++, XPos += TileWidth){
            D3DTileset->DrawTile(game, SInt2(XPos, YPos), D3DMap[YIndex][XIndex] + (winddir * totalsteps) + timestep);
        }
    }
}

SInt2 CTerrainMap::ConvertToTileIndex(SInt2 position){
    return SInt2(std::max(0, std::min(Width()-1, position.DX / D2DTileset->TileWidth())),
            std::max(0, std::min(Height()-1, position.DY / D2DTileset->TileHeight())));
}

SInt2 CTerrainMap::ConvertToScreenPosition(SInt2 index){
    return SInt2(index.DX * D2DTileset->TileWidth(), index.DY * D2DTileset->TileHeight());
}

void CTerrainMap::Update(CGame* game){
    for(std::vector<Castle>::iterator it = DCastles.begin();
            it != DCastles.end();
            it++){
        it->Update(game);
    }
    DAnimationStep += game->GameState()->DWind.DWindSpeed;
}

bool CTerrainMap::IsSpaceOpen(SInt2 position, SInt2 size){
    for(std::vector<Castle>::iterator it = DCastles.begin();
            it != DCastles.end();
            it++){
        if(CMathUtil::DoRectanglesOverlap(position, size, it->IndexPosition(), it->CSize)){
            return false;
        }
    }
    return true;
}

void CTerrainMap::Reset(){
    for(std::vector<Castle>::iterator it = DCastles.begin();
            it != DCastles.end();
            it++){
        it->Reset();
    }
    DHasCached3D = false;
}

std::string CTerrainMap::MapFileData() const{
    FILE* FilePointer;

    std::string MapData;
    FilePointer = fopen(DMapFileName.c_str(), "r");
    char *TempBuffer = NULL;
    size_t BufferSize = 0;
    while(!feof(FilePointer)){
        getline(&TempBuffer, &BufferSize, FilePointer); 
        MapData += std::string(TempBuffer);
    }
    return MapData;
}


void CTerrainMap::LoadMapTileset(CGame* game){
    D2DTileset->LoadTileset(game, D2DTilesetPath);
    D3DTileset->LoadTileset(game, D3DTilesetPath);
}
