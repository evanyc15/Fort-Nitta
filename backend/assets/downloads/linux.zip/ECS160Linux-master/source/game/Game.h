#ifndef GAME_H
#define GAME_H

#include <gtk/gtk.h>
#include <stdio.h>

#include "Resources.h"
#include "InputState.h" 
#include "Rendering.h"
#include "modes/GameMode.h"
#include "GameState.h"

#include "../types/Double3.h"
#include "Cannon.h"
#include "tilesets/GraphicTileset.h"

#ifdef FEDORA_BUILD
#include <lua.hpp>
#else
#include <lua5.2/lua.hpp>
#endif

#include "../LuaBridge/LuaBridge.h"

#define GAME_WIDTH 480
#define GAME_HEIGHT 288
#define STANDARD_GRAVITY 9.80665


//#define FAST_MODE

/**
 * @brief Manages all aspects of the game and is run by game modes and stores
 *        the game state and rendering
 */
class CGame{

    public:
        /**
         * @brief Constructs the game for a drawing area
         * @param drawing_area The canvas to be used to initialize rendering
         */
        CGame(GtkWidget* drawing_area);
        ~CGame();

        /**
         * @brief Advances the game by one frame by using the current game mode
         */
        void Update();

        /**
         * @brief Switches to new mode on next frame
         *
         * @param new_mode The mode to switch to
         */
        void SwitchMode(CGameMode* new_mode);
        /**
         * @brief Handles mouse events and hands off to DInputState
         * @param position 2D position
         */
        void MouseMoved(SInt2 position);
        /**
         * @brief Draws the game and returns the pixmap
         * @param drawing_context The drawing context
         * @return The resulting pixmap
         */
        GdkPixmap* Draw(GdkGC* drawing_context);

        /**
         * @brief Handles keyboard input and hands off to DInputState
         * @param keyval The key that was pressed
         */
        void KeyPressed(unsigned int keyval);
        /**
         * @brief Handles mouse button and hands off to DInputState
         * @param button If the mouse button was pressed
         */
        void ButtonPressed(CInputState::EInputButton button);

        /**
         * @brief Getter for rendering
         *
         * @return DRendering
         */
        CRendering* const Rendering() const { return DRendering; }
        /**
         * @brief Getter for resources
         *
         * @return DResources
         */
        CResources* const Resources() const { return DResources; }
        /**
         * @brief Getter for drawing area
         *
         * @return DDrawingArea
         */
        const GtkWidget* const DrawingArea() const { return DDrawingArea; }
        /**
         * @brief Getter for input state
         *
         * @return DInputState
         */
        CInputState* const InputState() const { return DInputState; }
        /**
         * @brief Getter for game mode
         *
         * @return DGameMode
         */
        CGameMode* GameMode() const { return DGameMode; }
        /**
         * @brief Getter for the game stats
         *
         * @return DGameState
         */
        CGameState* const GameState() const { return DGameState; }

    protected:
        GtkWidget* DDrawingArea;
        /**
         * @brief Holds the state of input in the game
         */
        CInputState* DInputState;
        /**
         * @brief Holds pixmaps used to render frames
         */
        CRendering* DRendering;
        /**
         * @brief Holds tilesets and sounds of game
         */
        CResources* DResources;
        /**
         * @brief Holds the state of the game
         */
        CGameState* DGameState;
        /**
         * @brief The current mode of the game
         */
        CGameMode* DGameMode;
        /**
         * @brief The mode switching next to
         */
        CGameMode* DNextGameMode;

};

#endif
