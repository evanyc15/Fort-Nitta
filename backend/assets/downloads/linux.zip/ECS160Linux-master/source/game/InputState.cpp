#include <stdlib.h>
#include <gdk/gdkkeysyms.h>

#include "InputState.h"
#include "Game.h"
#include "ui/UIElement.h"
#include <cctype>

CInputState::CInputState(){
    DMousePosition.DX = -1;
    DMousePosition.DY = -1;
    DSelectedUIElement = NULL;
    DActionPressed = false;
    DTextEntered = "";
    DBackSpacePressed = false;
}

void CInputState::Reset(){
    DActionPressed = false;
    DButtonPressed = CInputState::ibNone;
    DTextEntered = "";
    DBackSpacePressed = false;
}

void CInputState::SelectedElement(CUIElement* element){
    DSelectedUIElement = element;
}

void CInputState::KeyPressed(unsigned int keyval){
    if(isprint(keyval)){
        DTextEntered += (char)keyval;
    }
    if(GDK_BackSpace == keyval){
        DBackSpacePressed = true;
    }
    if(SelectedElement() != NULL){
        switch(keyval){
            case GDK_Down:
                if (SelectedElement()->DownElement()){
                    SelectedElement(SelectedElement()->DownElement());
                }
                break;
            case GDK_Up:
                if (SelectedElement()->UpElement()){
                    SelectedElement(SelectedElement()->UpElement());
                }
                break;
            case GDK_Left:
                if (SelectedElement()->LeftElement()){
                    SelectedElement(SelectedElement()->LeftElement());
                }
                break;
            case GDK_Right:
                if (SelectedElement()->RightElement()){
                    SelectedElement(SelectedElement()->RightElement());
                }
                break;
            case GDK_Return:
                DActionPressed = true;
                break;
        }
    }
}

void CInputState::UpdateSelectedElement(CUIElement* root){
    SelectedElement(root->DetermineSelected(DMousePosition));
}

void CInputState::ButtonPressed(CInputState::EInputButton button){
    DButtonPressed = button;
    DActionPressed = button == CInputState::ibLeftButton;
}
