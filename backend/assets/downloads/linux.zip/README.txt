Linux:

Enter ./make_and_run.sh in terminal to execute
Extra information on running the game is in the Github Wiki