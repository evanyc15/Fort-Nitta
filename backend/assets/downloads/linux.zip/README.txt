Linux:
1) Download zip
2) Enter ./make_and_run.sh in terminal to execute